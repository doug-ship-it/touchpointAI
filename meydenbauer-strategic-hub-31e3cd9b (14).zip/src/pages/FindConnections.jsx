import React from 'react';
import { FindConnectionsHero, TrialSignupForm, SecureContactUpload, FeatureComparison } from '../components/FindConnectionsComponents';

export default function FindConnectionsPage() {
  return (
    <div className="min-h-screen bg-[var(--navy-deep)]">
      <FindConnectionsHero />
      
      <div className="bg-[var(--navy-primary)]">
        <TrialSignupForm />
      </div>
      
      <div className="bg-[var(--navy-deep)]">
        <SecureContactUpload />
      </div>
      
      <div className="bg-[var(--navy-primary)]">
        <FeatureComparison />
      </div>
    </div>
  );
}