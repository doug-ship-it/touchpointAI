import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Hammer, Users, Cpu, Globe, Clock, Shield, ArrowRight, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const operationsServices = [
  {
    icon: Users,
    title: "Virtual Executive Assistants",
    description: "Dedicated EAs with specialized industry experience and advanced skill sets",
    features: ["Calendar & Project Management", "Communication & Coordination", "Research & Analysis", "Administrative Excellence"]
  },
  {
    icon: Cpu,
    title: "Process Automation",
    description: "AI-powered workflow automation to eliminate manual tasks and improve efficiency",
    features: ["Workflow Analysis", "Automation Implementation", "AI Integration", "Performance Monitoring"]
  },
  {
    icon: Hammer,
    title: "Back-office Optimization",
    description: "Comprehensive operational improvements across all business functions",
    features: ["Process Mapping", "Efficiency Analysis", "System Integration", "Quality Assurance"]
  },
  {
    icon: Globe,
    title: "Global Staffing Solutions",
    description: "Access to top-tier global talent for specialized roles and projects",
    features: ["Talent Sourcing", "Skills Assessment", "Cultural Fit", "Ongoing Support"]
  },
  {
    icon: Zap,
    title: "AI-powered Business Intelligence",
    description: "Data-driven insights and reporting to optimize business performance",
    features: ["Dashboard Creation", "Predictive Analytics", "Performance Metrics", "Strategic Insights"]
  },
  {
    icon: Shield,
    title: "Compliance & Risk Management",
    description: "Ensure operational compliance and mitigate business risks",
    features: ["Compliance Audits", "Risk Assessment", "Policy Development", "Training Programs"]
  }
];

const operationsMetrics = [
  { value: "45%", label: "Average Cost Reduction", icon: Hammer },
  { value: "3x", label: "Productivity Increase", icon: Zap },
  { value: "24/7", label: "Global Coverage", icon: Globe },
  { value: "99.5%", label: "Quality Assurance", icon: Shield }
];

const successCases = [
  {
    client: "PE-Backed Manufacturing Firm",
    challenge: "Operational inefficiencies across 12 facilities",
    solution: "ERP consolidation, process standardization, and AI-powered optimization",
    results: ["25% operational cost reduction", "18% faster time-to-market", "$5.2M EBITDA improvement"],
    timeframe: "9 months"
  },
  {
    client: "High-Growth SaaS Company",
    challenge: "Scaling operations while maintaining quality",
    solution: "Virtual EA team, automated workflows, and performance dashboards",
    results: ["40% reduction in administrative overhead", "60% faster project delivery", "95% client satisfaction maintained"],
    timeframe: "6 months"
  },
  {
    client: "Global Consulting Firm",
    challenge: "Need for 24/7 support across time zones",
    solution: "Global staffing model with specialized skill matching",
    results: ["100% timezone coverage achieved", "30% cost savings vs. local hires", "50% faster project turnaround"],
    timeframe: "4 months"
  }
];

export default function Operations() {
  const [selectedTab, setSelectedTab] = useState('services');

  useEffect(() => {
    // Guided tour animation for tabs
    const timers = [
      setTimeout(() => setSelectedTab('case-studies'), 1500),
      setTimeout(() => setSelectedTab('global-model'), 3000),
      setTimeout(() => setSelectedTab('services'), 4500)
    ];
    return () => timers.forEach(clearTimeout);
  }, []);
  
  const tabsConfig = [
      { id: 'services', label: 'Services' },
      { id: 'case-studies', label: 'Success' },
      { id: 'global-model', label: 'Global Model' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-yellow-50">
      {/* Hero Section */}
      <section className="py-8 sm:py-12 lg:py-16 text-center bg-white border-b">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto px-4 sm:px-6"
        >
          <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 bg-orange-100 rounded-full border border-orange-200 mb-4">
            <Hammer className="w-4 h-4 text-orange-600" />
            <span className="text-sm font-medium text-orange-700">MeydenbauerOps Services</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 text-gray-900">
            Operations + VA
          </h1>
          <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
            Streamline your operations with global talent, intelligent automation, and proven processes that scale with your business growth.
          </p>
        </motion.div>
      </section>

      {/* Success Metrics */}
      <section className="py-8 sm:py-12 bg-gradient-to-r from-orange-600 to-yellow-600 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {operationsMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-2">
                  <metric.icon className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8" />
                </div>
                <div className="text-xl sm:text-2xl lg:text-3xl font-bold mb-1">{metric.value}</div>
                <div className="text-xs sm:text-sm opacity-90">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-8 sm:space-y-10">
          <div className="flex justify-center">
            <TabsList className="relative grid w-full max-w-sm sm:max-w-md lg:max-w-3xl grid-cols-3 items-center justify-center rounded-2xl bg-gray-100 p-2 text-gray-500 border shadow-inner h-auto">
              {tabsConfig.map(tab => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="relative text-sm sm:text-base font-medium px-2 sm:px-4 py-3 sm:py-3.5 rounded-xl transition-colors data-[state=active]:text-white"
                >
                  <span className="relative z-10">{tab.label}</span>
                </TabsTrigger>
              ))}
              <motion.div
                layoutId="active-tab-ops"
                className="absolute inset-y-2 h-auto rounded-xl bg-gradient-to-r from-orange-600 to-yellow-600 shadow-md"
                style={{
                  width: `calc(100% / 3)`,
                  x: `${tabsConfig.findIndex(t => t.id === selectedTab) * 100}%`
                }}
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            </TabsList>
          </div>

          <TabsContent value="services">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8">
              {operationsServices.map((service, index) => (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 group">
                    <CardHeader>
                      <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-r from-orange-500 to-yellow-500 w-fit">
                        <service.icon className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                      </div>
                      <CardTitle className="group-hover:text-orange-600 transition-colors text-base sm:text-lg">
                        {service.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 text-sm sm:text-base">{service.description}</p>
                      <div className="space-y-1">
                        <h4 className="text-sm font-semibold text-gray-700">Key Features:</h4>
                        <ul className="text-xs text-gray-600">
                          {service.features.map(feature => (
                            <li key={feature} className="flex items-center gap-2">
                              <div className="w-1 h-1 bg-orange-500 rounded-full"></div>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="case-studies">
            <div className="space-y-6 sm:space-y-8">
              {successCases.map((case_study, index) => (
                <motion.div
                  key={case_study.client}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-4 sm:p-6">
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                        <div>
                          <h3 className="font-bold text-base sm:text-lg mb-2">{case_study.client}</h3>
                          <Badge variant="outline" className="mb-3 text-xs sm:text-sm">{case_study.timeframe}</Badge>
                          <div className="space-y-2">
                            <h4 className="font-semibold text-sm text-red-600">Challenge:</h4>
                            <p className="text-gray-600 text-sm">{case_study.challenge}</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm text-blue-600 mb-2">Solution:</h4>
                          <p className="text-gray-600 text-sm">{case_study.solution}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm text-green-600 mb-2">Results:</h4>
                          <ul className="space-y-1">
                            {case_study.results.map((result, i) => (
                              <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="global-model">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Globe className="w-4 sm:w-5 h-4 sm:h-5 text-orange-600" />
                    Global Talent Network
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Vetted professionals across 15+ time zones</li>
                    <li>• Specialized expertise in key business functions</li>
                    <li>• Cultural alignment and communication excellence</li>
                    <li>• Flexible engagement models (project to full-time)</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Clock className="w-4 sm:w-5 h-4 sm:h-5 text-orange-600" />
                    24/7 Operations Model
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Follow-the-sun workflow management</li>
                    <li>• Seamless handoffs between regions</li>
                    <li>• Real-time collaboration tools and processes</li>
                    <li>• Consistent quality standards globally</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <section className="mt-12 sm:mt-16 text-center">
          <Card className="bg-gradient-to-r from-orange-600 to-yellow-600 text-white">
            <CardContent className="p-6 sm:p-8">
              <h2 className="text-xl sm:text-2xl font-bold mb-4">Ready to Optimize Your Operations?</h2>
              <p className="mb-6 text-orange-100 text-sm sm:text-base lg:text-lg">
                Let's streamline your business processes and unlock new levels of efficiency and growth.
              </p>
              <Button size="lg" variant="outline" className="text-orange-600 bg-white hover:bg-gray-100" asChild>
                <Link to={createPageUrl('OperationsIntake')}>
                  Start Your Operations Assessment
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}