import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// AICRM has been consolidated into Command Center
// This page now redirects to Command Center
export default function AICRM() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to Command Center
    navigate(createPageUrl('CommandCenter'), { replace: true });
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[var(--primary-teal)] mx-auto mb-4"></div>
        <p className="text-gray-600">Redirecting to Command Center...</p>
      </div>
    </div>
  );
}