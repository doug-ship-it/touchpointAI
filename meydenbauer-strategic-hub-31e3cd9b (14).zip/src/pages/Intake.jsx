import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FormSubmission } from '@/api/entities';

import Step1ContactInfo from '../components/universal-intake/Step1ContactInfo';
import Step2CompanyProfile from '../components/universal-intake/Step2CompanyProfile';
import Step3BusinessChallenges from '../components/universal-intake/Step3BusinessChallenges';
import Step4HiringPriorities from '../components/universal-intake/Step4HiringPriorities';
import Step5SupportNeeds from '../components/universal-intake/Step5SupportNeeds';
import Step6AdditionalDetails from '../components/universal-intake/Step6AdditionalDetails';
import IntakeCompletion from '../components/universal-intake/IntakeCompletion';
import GamefiedProgressHeader from '../components/universal-intake/GamefiedProgressHeader';

const totalSteps = 6; // Steps 1-6, with step 7 being the completion

export default function UniversalIntakePage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    contact: {},
    company: {},
    challenges: [],
    hiring: [],
    support: [],
    additionalDetails: '',
    trackingId: `${Date.now()}-${Math.random().toString(36).substring(2)}`,
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const updateFormData = useCallback((section, data) => {
    setFormData(prev => ({
      ...prev,
      [section]: data
    }));
  }, []);

  const handleNext = () => setStep(prev => Math.min(prev + 1, totalSteps + 1));
  const handlePrevious = () => setStep(prev => Math.max(prev - 1, 1));

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const submissionData = {
        tracking_id: formData.trackingId,
        form_type: 'universal_intake_7_step',
        workflow_type: formData.company?.industry || 'general',
        intake_data: JSON.stringify(formData),
      };
      
      await FormSubmission.create(submissionData);
      
      // Store data in session storage for the personalized dashboard
      sessionStorage.setItem('intakeData', JSON.stringify(formData));

      handleNext(); // Move to the completion step
    } catch (error) {
      console.error("Submission failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return <Step1ContactInfo formData={formData} updateFormData={updateFormData} onNext={handleNext} />;
      case 2:
        return <Step2CompanyProfile formData={formData} updateFormData={updateFormData} onNext={handleNext} onPrevious={handlePrevious} />;
      case 3:
        return <Step3BusinessChallenges formData={formData} updateFormData={updateFormData} onNext={handleNext} onPrevious={handlePrevious} />;
      case 4:
        return <Step4HiringPriorities formData={formData} updateFormData={updateFormData} onNext={handleNext} onPrevious={handlePrevious} />;
      case 5:
        return <Step5SupportNeeds formData={formData} updateFormData={updateFormData} onNext={handleNext} onPrevious={handlePrevious} />;
      case 6:
        return <Step6AdditionalDetails formData={formData} updateFormData={updateFormData} onSubmit={handleSubmit} onPrevious={handlePrevious} isLoading={isLoading} />;
      case 7:
        return <IntakeCompletion formData={formData} onContinue={() => navigate(createPageUrl('PersonalizedDashboard'))} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50/20">
      {step <= totalSteps && (
        <GamefiedProgressHeader currentStep={step} totalSteps={totalSteps} />
      )}
      <div className="flex flex-col items-center justify-start pt-8 pb-12 px-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-4xl"
          >
            {renderStep()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}