import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Send } from "lucide-react";
import CompanyIdentification from "../components/operations-intake/CompanyIdentification";
import BusinessNeeds from "../components/operations-intake/BusinessNeeds";
import ServiceLevel from "../components/operations-intake/ServiceLevel";
import OperationalDetails from "../components/operations-intake/OperationalDetails";
import SuccessMetrics from "../components/operations-intake/SuccessMetrics";
import IntakeCompletion from "../components/operations-intake/IntakeCompletion";
import { FormSubmission } from "@/api/entities";

const steps = [
  { id: 1, name: "Company ID", component: CompanyIdentification },
  { id: 2, name: "Business Needs", component: BusinessNeeds },
  { id: 3, name: "Service Level", component: ServiceLevel },
  { id: 4, name: "Operational Details", component: OperationalDetails },
  { id: 5, name: "Success Metrics", component: SuccessMetrics },
];

export default function OperationsIntake() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    contact: { firstName: '', email: '' },
    company: { name: '', industry: '', size: '', stage: '', location: '' },
    needs: { challenges: [], impact: {} },
    service: { focus: '', hours: 20, urgency: 'Standard' },
    operations: { tech: [], compliance: [] },
    goals: { '30day': [], '60day': [], '90day': [], budget: 5000 },
  });

  const progress = useMemo(() => ((currentStep - 1) / steps.length) * 100, [currentStep]);

  const updateFormData = (section, data) => {
    setFormData(prev => ({ ...prev, [section]: { ...prev[section], ...data } }));
  };

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await FormSubmission.create({
        tracking_id: `ops-intake-${Date.now()}`,
        form_type: 'OPERATIONS_INTAKE',
        workflow_type: 'executive-support',
        intake_data: JSON.stringify(formData),
        submission_date: new Date().toISOString(),
      });
      setCurrentStep(steps.length + 1); // Move to completion screen
    } catch (error) {
      console.error("Submission failed:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const CurrentComponent = useMemo(() => {
    if (currentStep > steps.length) return IntakeCompletion;
    return steps[currentStep - 1].component;
  }, [currentStep]);
  
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl">
        {currentStep <= steps.length && (
          <div className="mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-center text-slate-800 mb-2">Operations & Executive Support Intake</h1>
            <p className="text-center text-slate-500 mb-6">Complete the following steps to get a tailored support plan.</p>
            <Progress value={progress} className="w-full h-2" />
            <div className="flex justify-between mt-2 text-xs text-slate-500">
              <span>{steps[currentStep-1].name}</span>
              <span>Step {currentStep} of {steps.length}</span>
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg border border-slate-200"
          >
            <CurrentComponent
              formData={formData}
              updateFormData={updateFormData}
            />
          </motion.div>
        </AnimatePresence>

        {currentStep <= steps.length && (
          <div className="flex justify-between items-center mt-8">
            <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            {currentStep === steps.length ? (
              <Button onClick={handleSubmit} disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
                {isSubmitting ? 'Submitting...' : 'Submit & Get Plan'}
                <Send className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleNext}>
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}