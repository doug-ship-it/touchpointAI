import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Network, Building2, Brain, Settings, FileText } from 'lucide-react';
import { createPageUrl } from '@/utils';
import MindMap from '../components/dashboard/MindMap';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const PersonalizedDashboard = () => {
  const [intakeData, setIntakeData] = useState(null);
  
  useEffect(() => {
    const data = sessionStorage.getItem('intakeData');
    if (data) {
      setIntakeData(JSON.parse(data));
    }
  }, []);

  const getRecommendedResources = () => {
    const industry = intakeData?.company?.industry?.toLowerCase() || '';
    const needs = intakeData?.triage?.support || [];
    
    let resources = [
      { id: 'network-intelligence', title: 'Network Intelligence', Icon: Network, description: "Explore our professional network.", link: createPageUrl('NetworkIntelligenceDeep'), priority: 'normal' },
      { id: 'vendor-marketplace', title: 'Vendor Portal', Icon: Building2, description: "Connect with vetted partners.", link: createPageUrl('VendorMarketplace'), priority: 'normal' },
      { id: 'archetype-dna', title: 'ArchetypeDNA', Icon: Brain, description: "Discover your leadership style.", link: createPageUrl('ArchetypeDNALearning'), priority: 'normal' },
      { id: 'tech-stack', title: 'Tech Stack Audit', Icon: Settings, description: "Analyze your tech stack for ROI.", link: createPageUrl('TechStackAnalysis'), priority: 'normal' },
      { id: 'resource-library', title: 'Resource Library', Icon: BookOpen, description: "Access curated guides.", link: createPageUrl('ResourceLibrary'), priority: 'normal' },
    ];
    
    if (industry.includes('tech')) {
        const techIndex = resources.findIndex(r => r.id === 'tech-stack');
        if (techIndex !== -1) resources[techIndex].priority = 'recommended';
    }
    if (needs.some(n => n.toLowerCase().includes('hiring') || n.toLowerCase().includes('search'))) {
        const networkIndex = resources.findIndex(r => r.id === 'network-intelligence');
        if (networkIndex !== -1) resources[networkIndex].priority = 'recommended';
    }
    if (needs.some(n => n.toLowerCase().includes('vendor') || n.toLowerCase().includes('technology'))) {
        const vendorIndex = resources.findIndex(r => r.id === 'vendor-marketplace');
        if (vendorIndex !== -1) resources[vendorIndex].priority = 'recommended';
    }
    
    return resources;
  };
  
  const allResources = getRecommendedResources();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-teal-50/30 overflow-x-hidden">
      <div className="relative z-10 text-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
            Your Personalized Dashboard
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto" style={{ fontFamily: 'Source Sans Pro, system-ui, sans-serif' }}>
            {intakeData?.contact?.firstName ? `Welcome, ${intakeData.contact.firstName}! ` : 'Welcome! '}
            Explore your interconnected resources from our central strategic hub.
          </p>
        </motion.div>
      </div>

      <div className="px-4 sm:px-6 lg:px-8 pb-16 space-y-12">
        {intakeData && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}>
            <Card className="max-w-4xl mx-auto bg-white/70 backdrop-blur-sm shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <FileText className="w-6 h-6 text-blue-600"/>
                  Your Intake Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                   <div>
                       <h4 className="font-semibold text-gray-700 mb-2">Company Details</h4>
                       <p><strong>Company:</strong> {intakeData.company?.name}</p>
                       <p><strong>Industry:</strong> {intakeData.company?.industry}</p>
                       <p><strong>Size:</strong> {intakeData.company?.employeeCount} employees</p>
                   </div>
                   <div>
                       <h4 className="font-semibold text-gray-700 mb-2">Identified Needs</h4>
                       {intakeData.triage?.challenges?.length > 0 && <p><strong>Challenges:</strong> {intakeData.triage.challenges.join(', ')}</p>}
                       {intakeData.triage?.hiring?.length > 0 && <p><strong>Hiring:</strong> {intakeData.triage.hiring.join(', ')}</p>}
                       {intakeData.triage?.support?.length > 0 && <p><strong>Support:</strong> {intakeData.triage.support.join(', ')}</p>}
                   </div>
                </div>
                 <div className="mt-6 text-right">
                    <Button variant="ghost" className="text-blue-600 hover:text-blue-700">View Full Submission <ArrowRight className="w-4 h-4 ml-2"/></Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="flex justify-center">
          <MindMap resources={allResources} />
        </div>
      </div>
    </div>
  );
};

export default PersonalizedDashboard;