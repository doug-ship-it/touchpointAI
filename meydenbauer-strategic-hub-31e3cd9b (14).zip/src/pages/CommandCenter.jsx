
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { NetworkConnection } from '@/api/entities';
import { PrioritySegment } from '@/api/entities';
import { ContactSegment } from '@/api/entities';
import { PriorityAnalysisCache } from '@/api/entities'; // Import new entity
import { toast } from 'sonner';
import {
  Target, TrendingUp, Users, BarChart3, Network,
  MoreVertical, Settings, Activity, LayoutGrid, Plus, Sparkles, Loader2
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

import UnifiedStatsBar from '../components/aicrm/unified/UnifiedStatsBar';
import UnifiedContactsTab from '../components/aicrm/unified/UnifiedContactsTab';
import UnifiedAnalyticsTab from '../components/aicrm/unified/UnifiedAnalyticsTab';
import PriorityDashboardTab from '../components/aicrm/unified/PriorityDashboardTab';
import DealPipelineTab from '../components/aicrm/unified/DealPipelineTab';

import SegmentConfigurationModal from '../components/command-center/SegmentConfigurationModal';
import SegmentManagerModal from '../components/command-center/SegmentManagerModal';
import BucketManagementModal from '../components/command-center/BucketManagementModal';
import { ICON_MAP } from '../components/command-center/IndustryTemplates';

import { universalPriorityService } from '../components/services/universalPriorityService';

const NavTab = ({ icon: Icon, label, active, onClick }) => (
  <button
    onClick={onClick}
    aria-label={`View ${label.toLowerCase()}`}
    aria-current={active ? 'page' : undefined}
    role="tab"
    className={cn(
      "flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium transition-all duration-200",
      active
        ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg"
        : "text-gray-600 hover:text-blue-600 hover:bg-blue-50"
    )}
  >
    <Icon className="h-4 w-4" />
    <span>{label}</span>
  </button>
);

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
  transition: { duration: 0.3 }
};

export default function CommandCenter() {
  const [activeTab, setActiveTab] = useState('priority');
  const [user, setUser] = useState(null);
  const [allLoadedContacts, setAllLoadedContacts] = useState([]);
  const [displayedContacts, setDisplayedContacts] = useState([]);
  const [priorityContacts, setPriorityContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPrioritizing, setIsPrioritizing] = useState(false);
  const [aiAnalysisAvailable, setAiAnalysisAvailable] = useState(false);
  const [lastAnalysisTime, setLastAnalysisTime] = useState(null); // New state for timestamp

  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const contactsPerPage = 50;

  const [priorityProgress, setPriorityProgress] = useState(0);

  const [userSegments, setUserSegments] = useState([]);
  const [segmentFilter, setSegmentFilter] = useState('all');
  const [selectedContact, setSelectedContact] = useState(null);
  const [showSegmentConfig, setShowSegmentConfig] = useState(false);
  const [showSegmentManager, setShowSegmentManager] = useState(false);
  const [showBucketModal, setShowBucketModal] = useState(false);
  const [editingBucket, setEditingBucket] = useState(null);

  const [userContext, setUserContext] = useState(null);
  const [priorityThreshold, setPriorityThreshold] = useState(null);

  const [stats, setStats] = useState({
    totalContacts: 0,
    activeRelationships: 0,
    pendingFollowUps: 0,
    monthConnections: 0,
    responseRate: 0,
    pipelineValue: 0,
    enrichedPercentage: 0,
    averageRelationshipScore: 0
  });

  const calculateStats = useCallback((contactList) => {
    if (!contactList || contactList.length === 0) {
      setStats({
        totalContacts: 0,
        activeRelationships: 0,
        pendingFollowUps: 0,
        monthConnections: 0,
        responseRate: 0,
        pipelineValue: 0,
        enrichedPercentage: 0,
        averageRelationshipScore: 0
      });
      return;
    }

    const now = new Date();
    const monthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const activeRelationships = contactList.filter(c => {
      if (!c.last_contact_date) return false;
      return new Date(c.last_contact_date) > monthAgo;
    }).length;

    const pendingFollowUps = contactList.filter(c => {
      if (c.reminder_next_contact) {
        const reminderDate = new Date(c.reminder_next_contact);
        return reminderDate <= now;
      }
      if (c.last_contact_date) {
        return new Date(c.last_contact_date) <= monthAgo;
      }
      return true;
    }).length;

    const monthConnections = contactList.filter(c => {
      if (!c.created_date) return false;
      return new Date(c.created_date) >= monthAgo;
    }).length;

    const recentlyContacted = contactList.filter(c => {
      if (!c.last_contact_date) return false;
      return new Date(c.last_contact_date) > weekAgo;
    }).length;

    const responseRate = contactList.length > 0
      ? Math.round((recentlyContacted / contactList.length) * 100)
      : 0;

    const enriched = contactList.filter(c =>
      c.intelligent_summary || c.enriched_industry
    ).length;

    const enrichedPercentage = contactList.length > 0
      ? Math.round((enriched / contactList.length) * 100)
      : 0;

    const scores = contactList.map(c => c.relationship_score || 5);
    const averageRelationshipScore = scores.length > 0
      ? parseFloat((scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1))
      : 0;

    setStats({
      totalContacts: contactList.length,
      activeRelationships,
      pendingFollowUps,
      monthConnections,
      responseRate,
      pipelineValue: 0,
      enrichedPercentage,
      averageRelationshipScore
    });
  }, []);

  const loadContacts = useCallback(async (page = 1, append = false) => {
    try {
      console.log(`[CommandCenter] 📥 Loading contacts for page ${page}...`);

      const offset = (page - 1) * contactsPerPage;
      const newContacts = await NetworkConnection.list('-updated_date', contactsPerPage, offset);

      if (append) {
        setAllLoadedContacts(prev => [...prev, ...newContacts]);
        setDisplayedContacts(prev => [...prev, ...newContacts]);
      } else {
        setAllLoadedContacts(newContacts);
        setDisplayedContacts(newContacts);
      }

      setCurrentPage(page);
      setHasMore(newContacts.length === contactsPerPage);

      console.log(`[CommandCenter] ✅ Loaded ${newContacts?.length || 0} contacts for page ${page}`);

      return newContacts;
    } catch (error) {
      console.error('[CommandCenter] ❌ Failed to load contacts:', error);
      toast.error('Failed to load contacts');
      setAllLoadedContacts([]);
      setDisplayedContacts([]);
      setHasMore(false);
      return [];
    }
  }, []);

  const loadUserSegments = useCallback(async () => {
    try {
      const segments = await PrioritySegment.list('segment_order');
      const segmentsWithCounts = await Promise.all(
        (segments || []).map(async (segment) => {
          const assignments = await ContactSegment.filter({ segment_id: segment.id });
          return {
            ...segment,
            contact_count: assignments.length
          };
        })
      );
      setUserSegments(segmentsWithCounts);
    } catch (error) {
      console.error('[CommandCenter] Error loading segments:', error);
      setUserSegments([]);
    }
  }, []);

  const runPriorityAnalysis = useCallback(async () => {
    if (!user || allLoadedContacts.length === 0) {
      toast.info("No contacts to analyze");
      return;
    }

    if (!window.confirm("Run AI priority analysis? This may use API credits.")) {
      return;
    }

    setIsPrioritizing(true);
    setPriorityProgress(0);
    setAiAnalysisAvailable(false);

    try {
      console.log('[CommandCenter] 🧠 Starting manual priority analysis...');

      const contactsToAnalyze = allLoadedContacts.slice(0, 75);
      const batchSize = 5;
      let processedCount = 0;

      for (let i = 0; i < contactsToAnalyze.length; i += batchSize) {
        const batch = contactsToAnalyze.slice(i, i + batchSize);
        processedCount += batch.length;
        setPriorityProgress(Math.min(100, Math.round((processedCount / contactsToAnalyze.length) * 100)));
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      const finalPriorityResults = await universalPriorityService.calculatePriorityThreshold(allLoadedContacts, user.email);

      setPriorityContacts(finalPriorityResults.priorityContacts);
      setPriorityThreshold(finalPriorityResults.threshold);
      setAiAnalysisAvailable(true);
      setLastAnalysisTime(new Date()); // Update time immediately for UI feedback

      console.log(`[CommandCenter] ✅ Identified ${finalPriorityResults.priorityCount} priority contacts`);
      toast.success(`Identified ${finalPriorityResults.priorityCount} high-priority contacts!`);

      // NEW: Save results to cache
      const cachePayload = {
        user_email: user.email,
        analysis_results: JSON.stringify(finalPriorityResults.priorityContacts),
        threshold: finalPriorityResults.threshold,
        analysis_timestamp: new Date().toISOString()
      };

      const existingCache = await PriorityAnalysisCache.filter({ user_email: user.email });
      if (existingCache && existingCache.length > 0) {
        await PriorityAnalysisCache.update(existingCache[0].id, cachePayload);
        console.log('[CommandCenter] Updated analysis cache.');
      } else {
        await PriorityAnalysisCache.create(cachePayload);
        console.log('[CommandCenter] Created new analysis cache.');
      }

    } catch (error) {
      console.error('[CommandCenter] ❌ Priority analysis failed:', error);
      toast.error('Failed to analyze priority contacts');
    } finally {
      setIsPrioritizing(false);
      setPriorityProgress(0);
    }
  }, [user, allLoadedContacts]);

  useEffect(() => {
    const initializeCommandCenter = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        const loadedContactsPage1 = await loadContacts(1, false);
        await loadUserSegments();
        calculateStats(loadedContactsPage1);

        setAiAnalysisAvailable(false);
        setPriorityContacts([]);

        // NEW: Load cached analysis
        if (currentUser && currentUser.email) {
          const cachedAnalysis = await PriorityAnalysisCache.filter({ user_email: currentUser.email }, '-analysis_timestamp', 1);
          if (cachedAnalysis && cachedAnalysis.length > 0) {
            const latestCache = cachedAnalysis[0];
            console.log('[CommandCenter] Found cached priority analysis from:', latestCache.analysis_timestamp);
            setPriorityContacts(JSON.parse(latestCache.analysis_results));
            setPriorityThreshold(latestCache.threshold);
            setLastAnalysisTime(new Date(latestCache.analysis_timestamp));
            setAiAnalysisAvailable(true);
          }
        }


        if (!currentUser?.onboarding_segments_completed) {
          setShowSegmentConfig(true);
        }
      } catch (error) {
        console.error('[CommandCenter] Initialization error:', error);
        toast.error('Failed to initialize Command Center');
      } finally {
        setIsLoading(false);
      }
    };

    initializeCommandCenter();
  }, [loadContacts, loadUserSegments, calculateStats]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    const reloadedContacts = await loadContacts(1, false);
    await loadUserSegments();
    calculateStats(reloadedContacts);
    // Don't clear AI analysis on manual refresh
    // setAiAnalysisAvailable(false);
    // setPriorityContacts([]);
    toast.success('Data refreshed');
    setIsRefreshing(false);
  };

  const handleLoadMore = () => {
    if (hasMore) {
      loadContacts(currentPage + 1, true).then(newContacts => {
        calculateStats([...allLoadedContacts, ...newContacts]);
      });
    }
  };

  const handleContactUpdate = async (contactId, updates) => {
    try {
      await NetworkConnection.update(contactId, updates);
      await loadContacts(1, false);
      await loadUserSegments();
      toast.success('Contact updated');
    } catch (error) {
      console.error('[CommandCenter] Failed to update contact:', error);
      toast.error('Failed to update contact');
    }
  };

  const handleContactDelete = async (contactId) => {
    try {
      await NetworkConnection.delete(contactId);
      await loadContacts(1, false);
      await loadUserSegments();
      toast.success('Contact deleted');
    } catch (error) {
      console.error('[CommandCenter] Failed to delete contact:', error);
      toast.error('Failed to delete contact');
    }
  };

  // NEW: Handle deletion of priority contacts
  const handleDeletePriorityContacts = useCallback(async (contactIdsToDelete) => {
    // Optimistic UI update
    const newPriorityContacts = priorityContacts.filter(
      (p) => !contactIdsToDelete.includes(p.contact.id)
    );
    setPriorityContacts(newPriorityContacts);

    toast.info(`Removing ${contactIdsToDelete.length} contact(s) from priority list...`);

    // Update cache in the background
    try {
      if (user && user.email) {
        const existingCache = await PriorityAnalysisCache.filter({ user_email: user.email });
        if (existingCache && existingCache.length > 0) {
          const updatedPayload = {
            analysis_results: JSON.stringify(newPriorityContacts),
            // Preserve other fields like threshold and analysis_timestamp if needed
            threshold: priorityThreshold, // Preserve current threshold
            analysis_timestamp: lastAnalysisTime ? lastAnalysisTime.toISOString() : new Date().toISOString() // Preserve last analysis time or use current
          };
          await PriorityAnalysisCache.update(existingCache[0].id, updatedPayload);
          toast.success(`${contactIdsToDelete.length} contact(s) removed from priority list.`);
        } else {
          // This case should ideally not be hit if aiAnalysisAvailable is true and contacts are displayed.
          // If it is hit, it means the UI showed priority contacts but no cache was found.
          console.warn('[CommandCenter] Attempted to delete from priority list but no existing cache found for user.');
          toast.warn('No existing priority analysis cache to update. Changes may not persist across sessions.');
        }
      }
    } catch (error) {
      console.error('[CommandCenter] ❌ Failed to update cache after deletion:', error);
      toast.error('Failed to save changes to cache. Reverting...');
      // Revert UI on failure
      setPriorityContacts(priorityContacts); // Revert to original state
    }
  }, [priorityContacts, user, priorityThreshold, lastAnalysisTime]);

  const handleSegmentConfigComplete = async () => {
    await loadUserSegments();
    await loadContacts(1, false);
    setShowSegmentConfig(false);
    if (user && !user.onboarding_segments_completed) {
      try {
        await User.update(user.id, { onboarding_segments_completed: true });
        setUser(prev => ({ ...prev, onboarding_segments_completed: true }));
      } catch (err) {
        console.error('[CommandCenter] Failed to update onboarding status:', err);
      }
    }
  };

  const handleCreateBucket = () => {
    setEditingBucket(null);
    setShowBucketModal(true);
  };

  const handleEditBucket = (bucket) => {
    setEditingBucket(bucket);
    setShowBucketModal(true);
  };

  const handleSaveBucket = async (bucketData) => {
    try {
      const currentUser = await User.me();

      if (bucketData.id) {
        await PrioritySegment.update(bucketData.id, {
          segment_name: bucketData.segment_name,
          icon_name: bucketData.icon_name,
          color: bucketData.color,
          segment_order: bucketData.segment_order
        });
        toast.success('Bucket updated successfully');
      } else {
        const nextOrder = userSegments.length + 1;
        if (nextOrder > 8) {
          toast.error('Maximum 8 custom buckets allowed');
          return;
        }

        await PrioritySegment.create({
          user_id: currentUser.id,
          segment_name: bucketData.segment_name,
          icon_name: bucketData.icon_name,
          color: bucketData.color,
          segment_order: nextOrder,
          is_active: true
        });
        toast.success('Bucket created successfully');
      }

      await loadUserSegments();
      setShowBucketModal(false);
      setEditingBucket(null);
    } catch (error) {
      console.error('[CommandCenter] Error saving bucket:', error);
      toast.error('Failed to save bucket');
    }
  };

  const handleDeleteBucket = async (bucketId) => {
    try {
      const assignments = await ContactSegment.filter({ segment_id: bucketId });
      for (const assignment of assignments) {
        await ContactSegment.delete(assignment.id);
      }

      await PrioritySegment.delete(bucketId);

      await loadUserSegments();
      setShowBucketModal(false);
      setEditingBucket(null);
      toast.success('Bucket deleted successfully');
    } catch (error) {
      console.error('[CommandCenter] Error deleting bucket:', error);
      toast.error('Failed to delete bucket');
    }
  };

  const getImmediateOutreachCount = () => {
    return priorityContacts.filter(c => c.tier === 'hot').length;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin h-16 w-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading Command Center...</p>
        </div>
      </div>
    );
  }

  const showEmptyState = userSegments.length === 0 && !user?.onboarding_segments_completed;
  const immediateOutreachCount = getImmediateOutreachCount();

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-200 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <LayoutGrid className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Command Center</h1>
                  <p className="text-gray-600">
                    {displayedContacts.length.toLocaleString()} contacts • {priorityContacts.length} priority
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  onClick={() => {
                    let proceed = true;
                    if (lastAnalysisTime) {
                      const hoursSince = (new Date() - lastAnalysisTime) / (1000 * 60 * 60);
                      if (hoursSince < 24) {
                        const nextAvailableHours = (24 - hoursSince).toFixed(0);
                        proceed = window.confirm(`You ran an analysis recently. Next recommended analysis in ~${nextAvailableHours} hours. Run again now?`);
                      }
                    }
                    if (proceed) {
                      runPriorityAnalysis();
                    }
                  }}
                  disabled={isPrioritizing || allLoadedContacts.length === 0}
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl shadow-lg"
                >
                  {isPrioritizing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing... {priorityProgress}%
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Analyze Priorities with AI
                    </>
                  )}
                </Button>

                {userSegments.length > 0 && (
                  <Button
                    onClick={() => setShowSegmentManager(true)}
                    variant="outline"
                    className="border-gray-200 text-gray-700 hover:bg-gray-50 rounded-xl"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Manage Segments
                  </Button>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="border-gray-200 rounded-xl">
                      <MoreVertical className="w-5 h-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={handleCreateBucket}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Priority Bucket
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowSegmentConfig(true)}>
                      <Settings className="w-4 h-4 mr-2" />
                      Configure Segments
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleRefresh} disabled={isRefreshing}>
                      <Activity className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                      Refresh Data
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <UnifiedStatsBar stats={stats} isLoading={false} />

          {showEmptyState ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-20"
            >
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
                <Network className="w-12 h-12 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Welcome to Touchpoint OS</h2>
              <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
                Organize your network into priority segments that match your workflow.
              </p>
              <Button
                onClick={() => setShowSegmentConfig(true)}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-6 text-lg rounded-xl"
              >
                Configure Segments
              </Button>
            </motion.div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                  <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 border-2 border-blue-500 bg-blue-50 rounded-2xl">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#3B82F615' }}>
                          <Target className="w-6 h-6" style={{ color: '#3B82F6' }} />
                        </div>
                        <Badge className="bg-blue-100 text-blue-700 px-3 py-1 rounded-md">AI-Powered</Badge>
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-1">{immediateOutreachCount.toLocaleString()}</h3>
                      <p className="text-sm font-medium text-gray-600">Immediate Outreach</p>
                      {priorityThreshold && (
                        <p className="text-xs text-gray-500 mt-2">Threshold: {priorityThreshold}/100</p>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>

                {userSegments.map((segment, index) => {
                  const Icon = ICON_MAP[segment.icon_name] || Target;
                  return (
                    <motion.div key={segment.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (index + 1) * 0.1 }}>
                      <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 border-2 border-gray-200 hover:border-purple-300 rounded-2xl group relative">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-4">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${segment.color || '#8B5CF6'}15` }}>
                              <Icon className="w-6 h-6" style={{ color: segment.color || '#8B5CF6' }} />
                            </div>
                            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => { e.stopPropagation(); handleEditBucket(segment); }}>
                              <Settings className="w-4 h-4 text-gray-500" />
                            </Button>
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 mb-1">{segment.contact_count.toLocaleString()}</h3>
                          <p className="text-sm font-medium text-gray-600">{segment.segment_name}</p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}

                {userSegments.length < 8 && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (userSegments.length + 1) * 0.1 }}>
                    <Card className="cursor-pointer border-2 border-dashed border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 rounded-2xl h-full" onClick={handleCreateBucket}>
                      <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                        <Plus className="w-12 h-12 text-gray-400 mb-2" />
                        <p className="text-sm font-medium text-gray-600">Add Priority Bucket</p>
                        <p className="text-xs text-gray-500 mt-1">{8 - userSegments.length} remaining</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </div>

              <div className="bg-white rounded-2xl shadow-lg border border-gray-200 mb-8">
                <div className="border-b border-gray-200 px-6">
                  <nav className="flex gap-2 overflow-x-auto" role="tablist">
                    <NavTab icon={Target} label="Priority" active={activeTab === 'priority'} onClick={() => setActiveTab('priority')} />
                    <NavTab icon={Users} label="Contacts" active={activeTab === 'contacts'} onClick={() => setActiveTab('contacts')} />
                    <NavTab icon={BarChart3} label="Analytics" active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} />
                    <NavTab icon={TrendingUp} label="Pipeline" active={activeTab === 'pipeline'} onClick={() => setActiveTab('pipeline')} />
                  </nav>
                </div>

                <div className="p-6">
                  <AnimatePresence mode="wait">
                    {activeTab === 'priority' && (
                      <motion.div key="priority" {...fadeInUp}>
                        {aiAnalysisAvailable ? (
                          <PriorityDashboardTab 
                            contactsPromise={Promise.resolve(priorityContacts.map(p => p.contact))} 
                            onContactClick={setSelectedContact} 
                            segmentFilter={segmentFilter} 
                            userSegments={userSegments}
                            onDeleteContacts={handleDeletePriorityContacts} // Pass delete handler
                          />
                        ) : (
                          <div className="py-20 text-center">
                            <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">AI Priority Analysis Not Run</h3>
                            <p className="text-gray-600 mb-6 max-w-md mx-auto">Click "Analyze Priorities with AI" above to identify your highest-value contacts.</p>
                            <Button onClick={runPriorityAnalysis} disabled={isPrioritizing || allLoadedContacts.length === 0} className="bg-purple-600 hover:bg-purple-700 text-white">
                              {isPrioritizing ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Analyzing... {priorityProgress}%
                                </>
                              ) : (
                                <>
                                  <Sparkles className="w-4 h-4 mr-2" />
                                  Run AI Analysis
                                </>
                              )}
                            </Button>
                          </div>
                        )}
                      </motion.div>
                    )}
                    {activeTab === 'contacts' && (
                      <motion.div key="contacts" {...fadeInUp}>
                        <UnifiedContactsTab contactsPromise={Promise.resolve(displayedContacts)} onContactUpdate={handleContactUpdate} onContactDelete={handleContactDelete} onContactSelect={setSelectedContact} userSegments={userSegments} onSegmentUpdate={loadUserSegments} onRefresh={handleRefresh} />
                        {hasMore && (
                          <div className="mt-8 text-center">
                            <Button onClick={handleLoadMore} disabled={isLoading} variant="outline">
                              {isLoading ? <Loader2 className="animate-spin w-4 h-4 mr-2" /> : null}
                              Load More Contacts
                            </Button>
                          </div>
                        )}
                      </motion.div>
                    )}
                    {activeTab === 'analytics' && (
                      <motion.div key="analytics" {...fadeInUp}>
                        <UnifiedAnalyticsTab contacts={allLoadedContacts} stats={stats} />
                      </motion.div>
                    )}
                    {activeTab === 'pipeline' && (
                      <motion.div key="pipeline" {...fadeInUp}>
                        <DealPipelineTab />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <SegmentConfigurationModal isOpen={showSegmentConfig} onClose={() => setShowSegmentConfig(false)} onComplete={handleSegmentConfigComplete} />
      <SegmentManagerModal isOpen={showSegmentManager} onClose={() => setShowSegmentManager(false)} onUpdate={() => { loadUserSegments(); handleRefresh(); }} />
      <BucketManagementModal isOpen={showBucketModal} onClose={() => { setShowBucketModal(false); setEditingBucket(null); }} bucket={editingBucket} onSave={handleSaveBucket} onDelete={handleDeleteBucket} />
    </>
  );
}
