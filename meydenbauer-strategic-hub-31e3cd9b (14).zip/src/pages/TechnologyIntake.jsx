import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Send, Rocket } from "lucide-react";
import { FormSubmission } from "@/api/entities";
import { toast } from "sonner";

// Import step components
import ProjectIdentification from "../components/technology-intake/ProjectIdentification";
import ProjectScope from "../components/technology-intake/ProjectScope";
import TechnicalRequirements from "../components/technology-intake/TechnicalRequirements";
import TeamTimeline from "../components/technology-intake/TeamTimeline";
import TechIntakeCompletion from "../components/technology-intake/TechIntakeCompletion";


const steps = [
  { id: 1, name: "Project Lead & Company", component: ProjectIdentification },
  { id: 2, name: "Project Scope & Goals", component: ProjectScope },
  { id: 3, name: "Technical Requirements", component: TechnicalRequirements },
  { id: 4, name: "Team & Timeline", component: TeamTimeline },
];

export default function TechnologyIntake() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    contact: { firstName: '', email: '' },
    project: { name: '' },
    company: { name: '', industry: '', size: '', stage: '', location: '' },
    scope: { description: '', goals: [], kpis: '' },
    technical: { platform: '', techStack: [], integrations: [], security: [], scalability: '' },
    timeline: { team: '', budget: 50000, startDate: '' },
  });

  const progress = useMemo(() => ((currentStep - 1) / steps.length) * 100, [currentStep]);

  const updateFormData = (section, data) => {
    setFormData(prev => ({ ...prev, [section]: { ...prev[section], ...data } }));
  };

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await FormSubmission.create({
        tracking_id: `tech-intake-${Date.now()}`,
        form_type: 'TECHNOLOGY_INTAKE',
        workflow_type: 'saas-cloud-ai',
        intake_data: JSON.stringify(formData),
        submission_date: new Date().toISOString(),
      });
      setCurrentStep(steps.length + 1); // Move to completion screen
      toast.success("Project intake submitted successfully!");
    } catch (error) {
      console.error("Submission failed:", error);
      toast.error("There was an error submitting your form. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const CurrentComponent = useMemo(() => {
    if (currentStep > steps.length) return TechIntakeCompletion;
    return steps[currentStep - 1].component;
  }, [currentStep]);
  
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl">
        {currentStep <= steps.length && (
          <div className="mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-center text-slate-800 mb-2 flex items-center justify-center gap-3">
              <Rocket className="w-8 h-8 text-blue-600" />
              Intelligent Technology Intake
            </h1>
            <p className="text-center text-slate-500 mb-6">Complete these steps to define your project and get a tailored proposal.</p>
            <Progress value={progress} className="w-full h-2" />
            <div className="flex justify-between mt-2 text-xs text-slate-500">
              <span>{steps[currentStep-1].name}</span>
              <span>Step {currentStep} of {steps.length}</span>
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg border border-slate-200"
          >
            <CurrentComponent
              formData={formData}
              updateFormData={updateFormData}
            />
          </motion.div>
        </AnimatePresence>

        {currentStep <= steps.length && (
          <div className="flex justify-between items-center mt-8">
            <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            {currentStep === steps.length ? (
              <Button onClick={handleSubmit} disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
                {isSubmitting ? 'Submitting...' : 'Submit Project Intake'}
                <Send className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleNext}>
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}