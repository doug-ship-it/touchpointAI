import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Search, Users, Upload, Filter, X, PlusCircle, Share2, Lock } from 'lucide-react';
import { NetworkConnection } from '.@/api/entities/NetworkConnection';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import ContactCard from '../components/network/ContactCard';
import Pagination from '../components/network/Pagination';
import { Toaster, toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';

import DataEnrichmentTool from '../components/network/DataEnrichmentTool';
import StatsOverview from '../components/dashboard/StatsOverview';
import PrivacyControlledUploadModal from '../components/network/PrivacyControlledUploadModal';

import ShortlistAuthModal from '../components/network/ShortlistAuthModal';
import ShortlistSidebar from '../components/network/ShortlistSidebar';
import { createShortlist } from '@/api/functions';
import { manageShortlistContact } from '@/api/functions';

import EnrichmentPasswordModal, { useEnrichmentAccess } from '../components/network/EnrichmentPasswordModal';
import ApolloEnrichmentTool from '../components/network/ApolloEnrichmentTool';
import AdvancedFilters from '../components/network/AdvancedFilters';
import PersonalizedMessageModal from '../components/network/PersonalizedMessageModal';
import LinkedInUrlQuickInput from '../components/network/LinkedInUrlQuickInput';

export default function NetworkIntelligenceDeep() {
  const [contacts, setContacts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    companySizes: [],
    seniorityLevels: [],
    industries: []
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [resultsPerPage] = useState(25);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [user, setUser] = useState(null);

  const [stats, setStats] = useState({
    totalContacts: 0,
    totalShortlists: 0,
    avgJobSeekerScore: 0,
    avgBusinessScore: 0
  });

  const [selectedContacts, setSelectedContacts] = useState(new Set());
  const [shortlistContacts, setShortlistContacts] = useState([]);
  const [currentShortlist, setCurrentShortlist] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showShortlistSidebar, setShowShortlistSidebar] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hideSelected, setHideSelected] = useState(false);

  const [isEnriching, setIsEnriching] = useState(false);

  const {
    hasAccess: hasEnrichmentAccess,
    showPasswordModal: showEnrichmentPassword,
    setShowPasswordModal: setShowEnrichmentPassword,
    requestAccess: requestEnrichmentAccess,
    grantAccess: grantEnrichmentAccess
  } = useEnrichmentAccess();

  const [showMessageModal, setShowMessageModal] = useState(false);
  const [selectedContactForMessage, setSelectedContactForMessage] = useState(null);

  // Load contacts
  const fetchContacts = useCallback(async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    setError(null);
    try {
      const connections = await NetworkConnection.list('-updated_date');
      setContacts(connections || []);
    } catch (e) {
      console.error('Failed to load connections:', e);
      setError('Unable to load network data. Please refresh the page.');
      toast.error('Failed to load connections.');
      setContacts([]);
    } finally {
      if (showLoading) setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        await fetchContacts(false);
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (e) {
        console.warn("Not logged in, proceeding with public access.");
      } finally {
        setIsLoading(false);
      }
    };
    loadInitialData();
  }, [fetchContacts]);

  // Calculate stats when contacts change
  useEffect(() => {
    if (contacts.length > 0) {
      const enrichedCount = contacts.filter(c => c.enriched_industry).length;
      const enrichmentPercentage = Math.round((enrichedCount / contacts.length) * 100);
      
      setStats({
        totalContacts: contacts.length,
        totalShortlists: shortlistContacts.length,
        avgJobSeekerScore: enrichmentPercentage,
        avgBusinessScore: selectedContacts.size
      });
    }
  }, [contacts, shortlistContacts, selectedContacts]);

  // Helper function to normalize company size for matching
  const normalizeCompanySize = (size) => {
    if (!size) return null;
    const normalized = size.toString().toLowerCase().trim();
    
    // Extract core range pattern (e.g., "1-10", "11-50")
    const rangeMatch = normalized.match(/(\d+[-–]\d+|\d+\+)/);
    if (rangeMatch) {
      return rangeMatch[1].replace('–', '-'); // Normalize dash
    }
    
    return normalized;
  };

  // Helper function to check if seniority matches
  const matchesSeniority = (contactSeniority, contactTitle, filterLevels) => {
    if (!filterLevels || filterLevels.length === 0) return true;
    
    const seniority = (contactSeniority || '').toLowerCase();
    const title = (contactTitle || '').toLowerCase();
    
    return filterLevels.some(filterLevel => {
      const level = filterLevel.toLowerCase();
      
      // Direct match on seniority field
      if (seniority.includes(level)) return true;
      
      // Check title for seniority keywords
      if (level.includes('cxo') && (title.includes('ceo') || title.includes('cfo') || title.includes('cto') || title.includes('cmo') || title.includes('chief'))) return true;
      if (level.includes('owner') && (title.includes('owner') || title.includes('founder') || title.includes('partner'))) return true;
      if (level.includes('vice president') && (title.includes('vp') || title.includes('vice president'))) return true;
      if (level.includes('director') && title.includes('director')) return true;
      if (level.includes('manager') && title.includes('manager')) return true;
      if (level.includes('senior') && title.includes('senior')) return true;
      if (level.includes('entry') && (title.includes('entry') || title.includes('junior') || title.includes('associate'))) return true;
      
      return false;
    });
  };

  // Apply filters with proper logic
  const filteredContacts = useMemo(() => {
    if (!contacts || contacts.length === 0) return [];

    let results = contacts;

    // Text search (applied first)
    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase().trim();
      const queryWords = query.split(' ').filter(word => word.length > 0);

      results = results.filter(contact => {
        const searchableText = [
          contact.connection_name,
          contact.connection_company,
          contact.connection_title,
          contact.enriched_location,
          contact.enriched_industry,
          contact.enriched_function,
          contact.enriched_seniority,
          contact.company_size,
          contact.relationship_strength,
          contact.user_email
        ].filter(Boolean).join(' ').toLowerCase();

        return queryWords.every(word => searchableText.includes(word));
      });
    }

    // Company Size Filter (OR logic within category)
    if (filters.companySizes && filters.companySizes.length > 0) {
      results = results.filter(contact => {
        const contactSize = normalizeCompanySize(contact.company_size);
        if (!contactSize) return false;
        
        return filters.companySizes.some(filterSize => {
          const normalizedFilter = normalizeCompanySize(filterSize);
          if (!normalizedFilter) return false;
          
          // Exact match on normalized values
          return contactSize === normalizedFilter || contactSize.includes(normalizedFilter);
        });
      });
    }

    // Seniority Level Filter (OR logic within category)
    if (filters.seniorityLevels && filters.seniorityLevels.length > 0) {
      results = results.filter(contact => 
        matchesSeniority(contact.enriched_seniority, contact.connection_title, filters.seniorityLevels)
      );
    }

    // Industry Filter (OR logic within category)
    if (filters.industries && filters.industries.length > 0) {
      results = results.filter(contact => {
        const contactIndustry = (contact.enriched_industry || '').toLowerCase();
        if (!contactIndustry) return false;
        
        return filters.industries.some(filterIndustry => {
          const normalizedFilter = filterIndustry.toLowerCase();
          return contactIndustry === normalizedFilter || contactIndustry.includes(normalizedFilter);
        });
      });
    }

    return results;
  }, [searchTerm, filters, contacts]);

  const displayedContacts = useMemo(() => {
    let results = filteredContacts;

    if (hideSelected && selectedContacts.size > 0) {
      results = results.filter(contact => !selectedContacts.has(contact.id));
    }

    return results;
  }, [filteredContacts, hideSelected, selectedContacts]);

  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * resultsPerPage;
    return displayedContacts.slice(start, start + resultsPerPage);
  }, [displayedContacts, currentPage, resultsPerPage]);

  const totalPages = Math.ceil(displayedContacts.length / resultsPerPage);

  // Count active filters
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.companySizes?.length > 0) count += filters.companySizes.length;
    if (filters.seniorityLevels?.length > 0) count += filters.seniorityLevels.length;
    if (filters.industries?.length > 0) count += filters.industries.length;
    return count;
  }, [filters]);

  // Shortlist management
  const handleAuthenticate = async (authData) => {
    try {
      const response = await createShortlist({
        ...authData,
        title: `${authData.company || 'My'} Strategic Network`
      });

      if (response.data.success) {
        setCurrentShortlist(response.data.shortlist);
        setIsAuthenticated(true);
        setShowAuthModal(false);

        if (selectedContacts.size > 0) {
          const contactsToAdd = Array.from(selectedContacts).map(id => contacts.find(c => c.id === id)).filter(Boolean);
          await addContactsToShortlist(contactsToAdd);
        }

        toast.success(`Shortlist "${response.data.shortlist.title}" created! Welcome to strategic network intelligence.`);
      } else {
        toast.error(response.data.message || 'Failed to create shortlist. Please try again.');
      }
    } catch (error) {
      console.error('Authentication failed:', error);
      toast.error('Failed to create shortlist. Please try again.');
    }
  };

  const addContactsToShortlist = async (contactsToAdd) => {
    if (!currentShortlist) {
      toast.error("No active shortlist to add contacts to.");
      return;
    }

    for (const contact of contactsToAdd) {
      try {
        const response = await manageShortlistContact({
          shortlistId: currentShortlist.id,
          contactId: contact.id,
          action: 'add',
          contactData: contact,
          category: 'secondary'
        });

        if (response.data.success) {
          setShortlistContacts(prev => {
            if (!prev.some(c => c.contact_id === contact.id)) {
              return [...prev, {
                contact_id: contact.id,
                ...contact,
                category: response.data.shortlistContact.category || 'secondary',
                notes: response.data.shortlistContact.notes || '',
                engagement_score: response.data.shortlistContact.engagement_score
              }];
            }
            return prev;
          });
        }
      } catch (error) {
        console.error('Failed to add contact to shortlist:', error);
        toast.error(`Failed to add ${contact.connection_name} to shortlist.`);
      }
    }
  };

  const handleToggleContactSelection = async (contact) => {
    const isSelected = selectedContacts.has(contact.id);

    if (!isAuthenticated && !isSelected) {
      setSelectedContacts(new Set([contact.id]));
      setShowAuthModal(true);
      return;
    }

    if (isSelected) {
      setSelectedContacts(prev => {
        const newSet = new Set(prev);
        newSet.delete(contact.id);
        return newSet;
      });

      if (currentShortlist) {
        try {
          await manageShortlistContact({
            shortlistId: currentShortlist.id,
            contactId: contact.id,
            action: 'remove'
          });
          setShortlistContacts(prev => prev.filter(c => c.contact_id !== contact.id));
          toast.info(`${contact.connection_name} removed from shortlist.`);
        } catch (error) {
          console.error('Failed to remove contact from shortlist:', error);
          toast.error(`Failed to remove ${contact.connection_name} from shortlist.`);
        }
      }
    } else {
      setSelectedContacts(prev => new Set([...prev, contact.id]));

      if (currentShortlist) {
        await addContactsToShortlist([contact]);
        toast.success(`${contact.connection_name} added to shortlist.`);
      }
    }
  };

  const handleBulkSelection = async (action) => {
    const visibleContacts = paginatedData;

    if (action === 'selectAll') {
      const newSelections = new Set([...selectedContacts, ...visibleContacts.map(c => c.id)]);
      setSelectedContacts(newSelections);

      if (currentShortlist) {
        const contactsToBulkAdd = visibleContacts
          .filter(c => !selectedContacts.has(c.id));
        await addContactsToShortlist(contactsToBulkAdd);
        toast.success(`Added ${contactsToBulkAdd.length} contacts to shortlist.`);
      } else {
        setSelectedContacts(newSelections);
        if (newSelections.size > 0) {
          setShowAuthModal(true);
        }
      }
    } else if (action === 'clearAll') {
      setSelectedContacts(new Set());
      if (currentShortlist) {
        const removedCount = shortlistContacts.length;
        for (const contact of shortlistContacts) {
          try {
            await manageShortlistContact({
              shortlistId: currentShortlist.id,
              contactId: contact.contact_id,
              action: 'remove'
            });
          } catch (error) {
            console.error(`Failed to remove ${contact.connection_name} during clearAll:`, error);
          }
        }
        setShortlistContacts([]);
        toast.info(`${removedCount} contacts removed from shortlist.`);
      }
    }
  };

  const handleUploadComplete = () => {
    fetchContacts();
    setIsCsvModalOpen(false);
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setFilters({ companySizes: [], seniorityLevels: [], industries: [] });
    setCurrentPage(1);
  };

  const handleEnrichContacts = async () => {
    if (!hasEnrichmentAccess) {
      toast.error("Access denied for enrichment. Please unlock first.");
      return;
    }
    setIsEnriching(true);
    toast.info("AI Data Enrichment is now active. You can use the enrichment tool below.");
    setTimeout(() => {
      setIsEnriching(false);
    }, 1000);
  };

  const handleEnrichClick = () => {
    if (!requestEnrichmentAccess()) {
      return;
    }
    handleEnrichContacts();
  };

  const handleQuickGenerate = (linkedinUrl, existingContact) => {
    if (existingContact) {
      setSelectedContactForMessage(existingContact);
      setShowMessageModal(true);
    } else if (linkedinUrl) {
      toast.info('Enriching LinkedIn profile...');
      toast.error('LinkedIn URL enrichment coming soon!');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-16 w-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Loading Network Data</h2>
          <p className="text-gray-600">Preparing intelligent search capabilities...</p>
        </div>
      </div>
    );
  }

  if (!isLoading && contacts.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
        <PrivacyControlledUploadModal
          isOpen={isCsvModalOpen}
          onClose={() => setIsCsvModalOpen(false)}
          onUploadComplete={handleUploadComplete}
        />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="mx-auto w-32 h-32 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl flex items-center justify-center mb-8 shadow-2xl">
              <Users className="w-16 h-16 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">Build Your Network Intelligence</h1>
            <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
              Import your professional connections to unlock powerful relationship insights and strategic networking opportunities.
            </p>
            
            <div className="max-w-2xl mx-auto">
              <Card className="border-0 shadow-2xl bg-white">
                <CardContent className="p-8">
                  <div className="flex items-center justify-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900">Import Connections</h2>
                  </div>
                  <p className="text-gray-600 mb-6">
                    Upload CSV, Excel, or other contact files from LinkedIn, Google, or any platform.
                  </p>
                  <Button 
                    onClick={() => setIsCsvModalOpen(true)}
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold px-8 py-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Toaster richColors />
      <ShortlistAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onAuthenticate={handleAuthenticate}
        contactCount={selectedContacts.size}
      />

      <ShortlistSidebar
        isOpen={showShortlistSidebar}
        shortlist={currentShortlist}
        contacts={shortlistContacts}
        onClose={() => setShowShortlistSidebar(false)}
        onRemoveContact={(contactId) => {
          const contact = contacts.find(c => c.id === contactId);
          if (contact) handleToggleContactSelection(contact);
        }}
        onUpdateContactNotes={async (contactId, notes) => {
          if (!currentShortlist) return;
          try {
            const response = await manageShortlistContact({
              shortlistId: currentShortlist.id,
              contactId: contactId,
              action: 'update',
              notes: notes
            });
            if (response.data.success) {
              setShortlistContacts(prev =>
                prev.map(c => c.contact_id === contactId ? { ...c, notes } : c)
              );
              toast.success("Note updated.");
            }
          } catch (error) {
            console.error('Failed to update notes:', error);
            toast.error("Failed to update note.");
          }
        }}
        onUpdateContactCategory={async (contactId, category) => {
          if (!currentShortlist) return;
          try {
            const response = await manageShortlistContact({
              shortlistId: currentShortlist.id,
              contactId: contactId,
              action: 'update',
              category: category
            });
            if (response.data.success) {
              setShortlistContacts(prev =>
                prev.map(c => c.contact_id === contactId ? { ...c, category } : c)
              );
              toast.success("Category updated.");
            }
          } catch (error) {
            console.error('Failed to update category:', error);
            toast.error("Failed to update category.");
          }
        }}
        onExportShortlist={() => {
          if (shortlistContacts.length === 0) {
            toast.info("No contacts in the shortlist to export.");
            return;
          }

          const csvContent = [
            'Name,Title,Company,Email,LinkedIn,Category,Notes',
            ...shortlistContacts.map(contact => [
              `"${contact.connection_name || ''}"`,
              `"${contact.connection_company || ''}"`,
              `"${contact.connection_title || ''}"`,
              `"${contact.connection_email || ''}"`,
              `"${contact.linkedin_url || ''}"`,
              `"${contact.category || ''}"`,
              `"${contact.notes || ''}"`
            ].join(','))
          ].join('\n');

          const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `strategic-shortlist-${new Date().toISOString().split('T')[0]}.csv`;
          a.click();
          URL.revokeObjectURL(url);
          a.remove();

          toast.success('Shortlist exported successfully!');
        }}
        onClearAll={() => handleBulkSelection('clearAll')}
        totalEstimatedValue={0}
      />

      <PrivacyControlledUploadModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        onUploadComplete={handleUploadComplete}
      />

      <EnrichmentPasswordModal
        isOpen={showEnrichmentPassword}
        onClose={() => setShowEnrichmentPassword(false)}
        onSuccess={grantEnrichmentAccess}
        featureName="Contact Data Enrichment"
      />

      <PersonalizedMessageModal
        isOpen={showMessageModal}
        onClose={() => setShowMessageModal(false)}
        contact={selectedContactForMessage}
        triggerSource="find_connections"
      />

      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-lg border-b border-gray-200/50 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Find Connections</h1>
                  <p className="text-gray-600">{contacts.length.toLocaleString()} contacts in your network</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Button
                  onClick={() => setIsCsvModalOpen(true)}
                  variant="outline"
                  className="border-blue-200 text-blue-700 hover:bg-blue-50 rounded-xl"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Import
                </Button>
                <Button
                  onClick={() => toast.info('Sharing features coming soon!')}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl shadow-lg"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>

            <LinkedInUrlQuickInput
              onGenerate={handleQuickGenerate}
              existingContacts={contacts}
              className="mb-6"
            />
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Statistics Overview */}
          {contacts.length > 0 && (
            <StatsOverview stats={stats} />
          )}

          {/* AI Data Enrichment Tool */}
          {contacts.length > 0 && (
            <>
              {!hasEnrichmentAccess ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mb-8"
                >
                  <Card className="bg-white border-0 shadow-lg p-6 flex flex-col md:flex-row justify-between items-start md:items-center rounded-2xl">
                    <div className="mb-4 md:mb-0">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">Unlock AI Data Enrichment</h3>
                      <p className="text-gray-600">Enter your password to access powerful AI features for contact data enrichment.</p>
                    </div>
                    <Button
                      onClick={handleEnrichClick}
                      disabled={isEnriching}
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl shadow-lg px-6 py-6 min-w-[180px]"
                    >
                      {!isEnriching ? 'Unlock Enrichment' : 'Unlocking...'}
                    </Button>
                  </Card>
                </motion.div>
              ) : (
                <DataEnrichmentTool
                  connections={contacts}
                  onEnrichmentComplete={fetchContacts}
                />
              )}

              <ApolloEnrichmentTool
                contacts={contacts}
                onEnrichmentComplete={fetchContacts}
              />
            </>
          )}

          {/* Search and Advanced Filters Card */}
          <Card className="border-0 shadow-lg bg-white mb-8 rounded-2xl">
            <CardContent className="p-6">
              {/* Search Bar */}
              <div className="relative mb-6">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search by name, title, company, industry, seniority..."
                  className="w-full pl-12 pr-10 py-6 border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-2 top-1/2 -translate-y-1/2 hover:bg-gray-100 rounded-xl" 
                    onClick={() => setSearchTerm('')}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>

              {/* Advanced Filters */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mb-6"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Filter className="w-5 h-5 text-gray-600" />
                  <h3 className="text-lg font-semibold text-gray-900">Advanced Filters</h3>
                  {activeFilterCount > 0 && (
                    <Badge className="bg-blue-600 text-white">
                      {activeFilterCount}
                    </Badge>
                  )}
                </div>
                <AdvancedFilters
                  filters={filters}
                  onFiltersChange={setFilters}
                />
              </motion.div>

              {/* Controls below Advanced Filters */}
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between flex-wrap">
                  <div className="flex items-center gap-3">
                    <p className="text-sm text-gray-600">
                      <span className="font-semibold text-gray-900">{filteredContacts.length.toLocaleString()}</span> results match your criteria
                    </p>
                    {(activeFilterCount > 0 || searchTerm) && (
                      <Button onClick={clearAllFilters} variant="ghost" size="sm" className="rounded-xl text-blue-600 hover:bg-blue-50">
                        <X className="w-3 h-3 mr-1" /> Clear all
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    {selectedContacts.size > 0 && (
                      <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-600">
                        <input
                          type="checkbox"
                          checked={hideSelected}
                          onChange={(e) => setHideSelected(e.target.checked)}
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span>Hide {selectedContacts.size} selected</span>
                      </label>
                    )}
                    {selectedContacts.size > 0 && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setShowShortlistSidebar(true)}
                        className="rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                      >
                        <Users className="w-3 h-3 mr-1" />
                        View Shortlist ({selectedContacts.size})
                      </Button>
                    )}
                  </div>
                </div>

                {/* Bulk Actions */}
                {filteredContacts.length > 0 && (
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200 gap-4">
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="text-sm text-slate-700 font-medium">Bulk actions:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleBulkSelection('selectAll')}
                        className="rounded-xl border-slate-200 hover:bg-white"
                      >
                        <PlusCircle className="w-3 h-3 mr-1" />
                        Select Page
                      </Button>
                      {selectedContacts.size > 0 && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleBulkSelection('clearAll')}
                          className="rounded-xl border-slate-200 hover:bg-white"
                        >
                          Clear All
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Shortlist Summary */}
          <AnimatePresence>
            {selectedContacts.size > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6"
              >
                <Card className="bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200 border-0 shadow-lg">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-emerald-500 rounded-2xl flex items-center justify-center">
                          <Users className="w-5 h-5 text-white" />
                        </div>
                        <span className="font-semibold text-emerald-900">
                          {selectedContacts.size} contacts saved to shortlist
                        </span>
                      </div>
                      <Button 
                        variant="ghost" 
                        onClick={() => setShowShortlistSidebar(true)} 
                        className="text-emerald-700 hover:text-emerald-800 hover:bg-emerald-100 font-semibold rounded-xl"
                      >
                        View Shortlist →
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Results */}
          {paginatedData.length > 0 ? (
            <>
              <AnimatePresence mode="wait">
                <motion.div 
                  key={currentPage} 
                  initial={{ opacity: 0, y: 20 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8"
                >
                  {paginatedData.map((contact, index) => (
                    <div key={contact.id} className="relative">
                      <ContactCard
                        contact={contact}
                        index={index}
                        isSelected={selectedContacts.has(contact.id)}
                        onToggleSelection={() => handleToggleContactSelection(contact)}
                        showShortlistButton={true}
                      />
                    </div>
                  ))}
                </motion.div>
              </AnimatePresence>
              <Pagination currentPage={currentPage} totalPages={totalPages} setCurrentPage={setCurrentPage} />
            </>
          ) : (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-20">
              <div className="w-24 h-24 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Users className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">No connections found</h3>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                {(activeFilterCount > 0 || searchTerm) 
                  ? "Try adjusting your search terms or filters to find relevant contacts." 
                  : "Start building your network by importing contacts from various sources."}
              </p>
              {(activeFilterCount > 0 || searchTerm) ? (
                <Button onClick={clearAllFilters} variant="outline" className="rounded-xl">
                  Clear Search & Filters
                </Button>
              ) : (
                <Button onClick={() => setIsCsvModalOpen(true)} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl shadow-lg">
                  <Upload className="w-4 h-4 mr-2" />
                  Import Connections
                </Button>
              )}
            </motion.div>
          )}
        </div>

        {/* Floating Shortlist Button */}
        <AnimatePresence>
          {selectedContacts.size > 0 && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="fixed bottom-8 right-8 z-50"
            >
              <Button
                onClick={() => setShowShortlistSidebar(true)}
                size="lg"
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white shadow-2xl rounded-2xl h-16 px-6 text-lg font-semibold transform hover:scale-105 transition-all duration-200"
              >
                <Users className="w-6 h-6 mr-3" />
                Shortlist ({selectedContacts.size})
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}