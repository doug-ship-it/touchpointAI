
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Target,
  Zap,
  Users,
  BarChart3,
  Megaphone,
  ArrowRight,
  DollarSign,
  Linkedin,
  Star
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useExpandedView } from '../components/expanded-view/ExpandedViewProvider';
import SalesTechEcosystem from '../components/gtm/SalesTechEcosystem';
import GTMLeadGenModal from '../components/gtm/GTMLeadGenModal'; 

const gtmServices = [
  {
    icon: DollarSign,
    title: "RevOps Optimization",
    description: "Revenue operations alignment and automation for scalable growth",
    deliverables: ["Process Mapping", "Technology Stack", "Reporting Dashboard", "Team Training"]
  },
  {
    icon: BarChart3,
    title: "Demand Gen & LinkedinSDR",
    description: "Multi-channel lead generation campaigns with advanced tracking and optimization",
    deliverables: ["Campaign Setup", "Lead Magnets", "Landing Pages", "Conversion Optimization"],
    externalLink: "https://mdbrp.com/demand-gen"
  },
  {
    icon: Zap,
    title: "TouchpointAI Linkedin Copilot",
    description: "Intelligent outreach campaigns and relationship building on LinkedIn",
    deliverables: ["Touchpoint Setup", "Message Sequences", "Lead Scoring", "Analytics Dashboard"],
    promotion: "14-Day Free Trial",
    externalLink: "https://app.touchpointconsulting.co/register"
  },
  {
    icon: Target,
    title: "Strategic GTM Planning",
    description: "Market analysis, positioning strategy, and comprehensive go-to-market roadmaps",
    deliverables: ["Market Research", "Competitive Analysis", "Positioning Strategy", "Launch Timeline"]
  },
  {
    icon: Megaphone,
    title: "Content Marketing",
    description: "Strategic content creation and distribution to build authority and generate leads",
    deliverables: ["Content Strategy", "Blog Posts", "Case Studies", "Social Media"]
  },
  {
    icon: Users,
    title: "Sales Enablement",
    description: "Sales process optimization, training, and technology implementation",
    deliverables: ["Sales Process", "CRM Setup", "Training Materials", "Performance Metrics"]
  }
];

const successStories = [
  {
    client: "Series-B SaaS Company",
    challenge: "Struggling with lead generation and conversion rates",
    solution: "Implemented comprehensive GTM strategy with LinkedIn automation and content marketing",
    results: ["$392K additional revenue generated", "340% increase in qualified leads", "52% improvement in conversion rates"],
    timeframe: "6 months"
  },
  {
    client: "Nordic Partners",
    challenge: "Low brand awareness in target markets",
    solution: "Strategic content marketing and thought leadership campaign",
    results: ["380% surge in website traffic", "12x increase in demo requests", "Featured in 15 industry publications"],
    timeframe: "4 months"
  },
  {
    client: "AI Startup",
    challenge: "Needed to secure Series-A funding",
    solution: "GTM strategy refinement and investor outreach campaign",
    results: ["$2.1M Series-A secured", "45% faster fundraising timeline", "3 strategic partnerships established"],
    timeframe: "3 months"
  }
];

const gtmMetrics = [
  { value: "800%", label: "Average ROI Increase", icon: TrendingUp },
  { value: "340%", label: "Lead Generation Boost", icon: Target },
  { value: "52%", label: "Conversion Improvement", icon: Zap },
  { value: "$2.1M", label: "Revenue Generated", icon: DollarSign }
];

const testimonials = [
  {
    quote: "Great work team. Pleasantly surprised with what we've achieved over the past month and excited about what's ahead.",
    author: "Partner",
    company: "Dalrae Solutions"
  },
  {
    quote: "I've consulted with Doug on LinkedIn for years. We've phased out internal SDRs for Touchpoint, providing better ROI that our marketing teams embraced.",
    author: "Nick",
    company: "SAP Concur"
  },
  {
    quote: "After trying multiple appointment setting services and in-house campaigns, I'm delighted to have found Touchpoint. There's simply no comparison.",
    author: "Jeff Derus",
    company: "Nordic Partners"
  }
];


export default function GTMDemandGen() {
  const [selectedTab, setSelectedTab] = useState('services');
  const [isLeadGenModalOpen, setIsLeadGenModalOpen] = useState(false); 
  const { openExpandedView } = useExpandedView();

  useEffect(() => {
    // Guided tour animation for tabs
    const tabTimers = [
      setTimeout(() => setSelectedTab('success-stories'), 1500),
      setTimeout(() => setSelectedTab('process'), 3000),
      setTimeout(() => setSelectedTab('services'), 4500),
    ];

    const leadGenTimer = setTimeout(() => {
      if (!sessionStorage.getItem('gtmLeadGenModalShown')) {
        setIsLeadGenModalOpen(true);
        sessionStorage.setItem('gtmLeadGenModalShown', 'true');
      }
    }, 5000); // Open Lead Gen modal after 5 seconds

    return () => {
      tabTimers.forEach(clearTimeout);
      clearTimeout(leadGenTimer);
    };
  }, []);

  const handleVideoOpen = () => {
    const videoUrl = "https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Ffast.wistia.net%2Fembed%2Fiframe%2Fmhjxg9valb&display_name=Wistia%2C%2BInc.&url=https%3A%2F%2Fprashant-3528.wistia.com%2Fmedias%2Fmhjxg9valb&image=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2F9c05a17d0c8c2fb63e32d517d5d39ce2a3983758.jpg%3Fimage_crop_resized%3D960x540&key=96f1f04c5f4143bcb0f2e68c87d65feb&type=text%2Fhtml&schema=wistia&wvideo=mhjxg9valb";
    openExpandedView(videoUrl, "LinkedIn Copilot Explainer Video");
  };

  const tabsConfig = [
    { id: 'services', label: 'Services' },
    { id: 'success-stories', label: 'Success' },
    { id: 'process', label: 'Process' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-teal-50">
      <GTMLeadGenModal isOpen={isLeadGenModalOpen} onClose={() => setIsLeadGenModalOpen(false)} />
      
      {/* Floating Video Button */}
      <motion.div
        className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-50"
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <motion.div
          animate={{ scale: [1, 1.04, 1] }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <Button
            onClick={handleVideoOpen}
            className="bg-white hover:bg-gray-100 text-gray-800 shadow-lg hover:shadow-xl border border-gray-200 rounded-full px-4 sm:px-8 py-3 sm:py-5 h-auto flex items-center gap-2 sm:gap-4 group text-sm sm:text-base"
          >
            <Linkedin className="w-6 sm:w-8 h-6 sm:h-8 text-blue-600 transition-transform group-hover:scale-110" />
            <span className="font-semibold text-left leading-tight">
              View Touchpoint LI Copilot Demo
            </span>
          </Button>
        </motion.div>
      </motion.div>

      {/* Hero Section */}
      <section className="py-8 sm:py-12 lg:py-16 text-center bg-white border-b">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto px-4 sm:px-6"
        >
          <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 bg-green-100 rounded-full border border-green-200 mb-4">
            <TrendingUp className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-700">Marketing & Sales</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 text-gray-900">
            GTM + Demand Generation
          </h1>
          <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
            Accelerate your go-to-market strategy with data-driven campaigns, intelligent automation, and proven frameworks that generate qualified leads and drive revenue growth.
          </p>
        </motion.div>
      </section>

      {/* Success Metrics */}
      <section className="py-8 sm:py-12 bg-gradient-to-r from-green-600 to-teal-600 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {gtmMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-2">
                  <metric.icon className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8" />
                </div>
                <div className="text-xl sm:text-2xl lg:text-3xl font-bold mb-1">{metric.value}</div>
                <div className="text-xs sm:text-sm opacity-90">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Sales Tech Ecosystem Visualization */}
      <SalesTechEcosystem />
      
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-8 sm:space-y-10">
          <div className="flex justify-center">
            <TabsList className="relative grid w-full max-w-sm sm:max-w-md lg:max-w-3xl grid-cols-3 items-center justify-center rounded-2xl bg-gray-100 p-2 text-gray-500 border shadow-inner h-auto">
              {tabsConfig.map(tab => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="relative text-sm sm:text-base font-medium px-2 sm:px-4 py-3 sm:py-3.5 rounded-xl transition-colors data-[state=active]:text-white"
                >
                  <span className="relative z-10">{tab.label}</span>
                </TabsTrigger>
              ))}
              <motion.div
                layoutId="active-tab-gtm"
                className="absolute inset-y-2 h-auto rounded-xl bg-gradient-to-r from-green-600 to-teal-600 shadow-md"
                style={{
                  width: `calc(100% / 3)`,
                  x: `${tabsConfig.findIndex(t => t.id === selectedTab) * 100}%`
                }}
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            </TabsList>
          </div>

          <TabsContent value="services">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8">
              {gtmServices.map((service, index) => (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {service.externalLink ? (
                    <a href={service.externalLink} target="_blank" rel="noopener noreferrer" className="block h-full">
                      <Card className="h-full hover:shadow-xl transition-all duration-300 group relative">
                        {service.promotion && (
                          <div className="absolute top-4 right-4 bg-gradient-to-r from-green-500 to-teal-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
                            {service.promotion}
                          </div>
                        )}
                        <CardHeader>
                          <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-r from-green-500 to-teal-500 w-fit">
                            <service.icon className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                          </div>
                          <CardTitle className="group-hover:text-green-600 transition-colors text-base sm:text-lg">
                            {service.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 mb-4 text-sm sm:text-base">{service.description}</p>
                          <div className="space-y-1">
                            <h4 className="text-sm font-semibold text-gray-700">Key Deliverables:</h4>
                            <ul className="text-xs text-gray-600">
                              {service.deliverables.map(deliverable => (
                                <li key={deliverable} className="flex items-center gap-2">
                                  <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                                  {deliverable}
                                </li>
                              ))}
                            </ul>
                          </div>
                          {service.title === "Demand Gen & LinkedinSDR" && (
                             <Button variant="outline" className="mt-4 w-full text-green-600 border-green-600 hover:bg-green-50 hover:text-green-700 text-sm">Learn More <ArrowRight className="w-4 h-4 ml-2" /></Button>
                          )}
                        </CardContent>
                      </Card>
                    </a>
                  ) : (
                    <Card className="h-full hover:shadow-xl transition-all duration-300 group">
                      <CardHeader>
                        <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-r from-green-500 to-teal-500 w-fit">
                          <service.icon className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                        </div>
                        <CardTitle className="group-hover:text-green-600 transition-colors text-base sm:text-lg">
                          {service.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 mb-4 text-sm sm:text-base">{service.description}</p>
                        <div className="space-y-1">
                          <h4 className="text-sm font-semibold text-gray-700">Key Deliverables:</h4>
                          <ul className="text-xs text-gray-600">
                            {service.deliverables.map(deliverable => (
                              <li key={deliverable} className="flex items-center gap-2">
                                <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                                {deliverable}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="success-stories">
            <div className="space-y-6 sm:space-y-8">
              {successStories.map((story, index) => (
                <motion.div
                  key={story.client}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-4 sm:p-6">
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                        <div>
                          <h3 className="font-bold text-base sm:text-lg mb-2">{story.client}</h3>
                          <Badge variant="outline" className="mb-3 text-xs sm:text-sm">{story.timeframe}</Badge>
                          <div className="space-y-2">
                            <h4 className="font-semibold text-sm text-red-600">Challenge:</h4>
                            <p className="text-gray-600 text-sm">{story.challenge}</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm text-blue-600 mb-2">Solution:</h4>
                          <p className="text-gray-600 text-sm">{story.solution}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm text-green-600 mb-2">Results:</h4>
                          <ul className="space-y-1">
                            {story.results.map((result, i) => (
                              <li key={i} className="text-sm text-gray-600 flex items-center gap-2">
                                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="process">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Strategic Foundation</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Market analysis and competitive positioning</li>
                    <li>• Target audience identification and segmentation</li>
                    <li>• Value proposition refinement</li>
                    <li>• Channel strategy and budget allocation</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Execution & Optimization</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Multi-channel campaign deployment</li>
                    <li>• Real-time performance monitoring</li>
                    <li>• A/B testing and continuous optimization</li>
                    <li>• Scalable process implementation</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Testimonials Section */}
        <section className="mt-8 sm:mt-12 lg:mt-16 py-12 sm:py-16 bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
            <p className="text-sm sm:text-base lg:text-lg text-gray-600 mb-8 sm:mb-12">
              We're proud to partner with industry leaders to drive meaningful results.
            </p>
          </div>
          <div className="relative h-64 flex items-center">
            <motion.div
              className="flex gap-8 px-4"
              animate={{
                x: ['0%', '-100%'],
                transition: {
                  ease: 'linear',
                  duration: 25,
                  repeat: Infinity,
                }
              }}
            >
              {[...testimonials, ...testimonials].map((testimonial, index) => (
                <div key={index} className="flex-shrink-0 w-96">
                  <Card className="text-left border-gray-200 shadow-sm h-full flex flex-col">
                    <CardContent className="p-6 flex-grow flex flex-col justify-center">
                      <div className="flex items-center mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                        ))}
                      </div>
                      <blockquote className="text-gray-700 italic text-lg mb-4 flex-grow">
                        "{testimonial.quote}"
                      </blockquote>
                      <div>
                        <div className="font-semibold text-gray-900">{testimonial.author}</div>
                        <div className="text-sm text-gray-500">{testimonial.company}</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="mt-8 sm:mt-12 lg:mt-16 text-center">
          <Card className="bg-gradient-to-r from-green-600 to-teal-600 text-white">
            <CardContent className="p-6 sm:p-8">
              <h2 className="text-lg sm:text-xl lg:text-2xl font-bold mb-4">Ready to Accelerate Your Growth?</h2>
              <p className="mb-6 text-green-100 text-sm sm:text-base lg:text-lg">
                Let's create a GTM strategy that turns your vision into measurable revenue results.
              </p>
              <Button size="lg" variant="outline" className="text-green-600 bg-white hover:bg-gray-100">
                Start Your GTM Strategy
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
