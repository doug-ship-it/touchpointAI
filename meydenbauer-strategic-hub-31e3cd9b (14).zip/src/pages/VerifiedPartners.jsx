import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Vendor } from '@/api/entities';
import { Lead } from '@/api/entities';
import { User } from '@/api/entities';
import VendorCard from '../components/network/VendorCard';
import PaywallModal from '../components/network/PaywallModal';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, Search, SlidersHorizontal, Info, Building2, Award, Globe } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { toast, Toaster } from 'sonner';

export default function VerifiedPartners() {
    const [vendors, setVendors] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [user, setUser] = useState(null);
    const [showPaywall, setShowPaywall] = useState(false);
    
    const [filters, setFilters] = useState({
        searchTerm: '',
        category: 'all',
        region: 'all',
        businessModel: 'all',
    });

    const filterOptions = {
        categories: [
            "AI & Emerging Tech",
            "Enterprise Development",
            "Specialized Industries",
            "Global Delivery",
            "Strategic Advisory",
            "Growth & GTM"
        ],
        regions: [
            "NORTH_AMERICA",
            "LATIN_AMERICA",
            "EUROPE",
            "ASIA_PACIFIC",
            "GLOBAL"
        ],
        businessModels: [
            "Service-based",
            "Product-based",
            "Hybrid"
        ],
    };

    useEffect(() => {
        const checkUserAndFetchData = async () => {
            setIsLoading(true);
            try {
                const [currentUser, fetchedVendors] = await Promise.all([
                    User.me().catch(() => null),
                    Vendor.list()
                ]);
                setUser(currentUser);
                setVendors(fetchedVendors || []);
            } catch (error) {
                console.error("Failed to fetch data:", error);
                toast.error('Failed to load vendor data');
            } finally {
                setIsLoading(false);
            }
        };
        checkUserAndFetchData();
    }, []);

    const handleInquiry = async (vendor) => {
        if (!user) {
            toast.error("Please log in to request an introduction");
            setTimeout(() => {
                User.login();
            }, 1500);
            return;
        }
        
        if ((user.credits || 0) < 1) {
            setShowPaywall(true);
            return;
        }
        
        try {
            await Lead.create({
                vendor_id: vendor.vendorId || vendor.id,
                user_id: user.id,
                user_email: user.email,
                vendor_name: vendor.name,
                inquiry_type: 'introduction_request',
                status: 'pending',
                source: 'verified_partners_portal',
                user_company: user.company_name || '',
                user_title: user.job_title || ''
            });

            const newCredits = (user.credits || 0) - 1;
            await User.updateMyUserData({ credits: newCredits });
            setUser(prevUser => ({ ...prevUser, credits: newCredits }));

            toast.success(`Your inquiry for ${vendor.name} has been submitted successfully!`, {
                description: 'A Meydenbauer partner will contact you within 24 hours.'
            });
        } catch (error) {
            console.error('Failed to submit lead:', error);
            toast.error('Failed to submit inquiry. Please try again.');
        }
    };

    const filteredVendors = useMemo(() => {
        if (!vendors || vendors.length === 0) return [];
        
        return vendors.filter(vendor => {
            if (!vendor) return false;
            
            const { searchTerm, category, region, businessModel } = filters;
            const term = searchTerm.toLowerCase();

            const searchTermMatch = !term ||
                (vendor.name && vendor.name.toLowerCase().includes(term)) ||
                (vendor.validatedTechnologyStack?.specializations || []).some(cap => 
                    cap && cap.toLowerCase().includes(term)
                ) ||
                (vendor.validatedTechnologyStack?.technologies || []).some(spec => 
                    spec && spec.toLowerCase().includes(term)
                ) ||
                (vendor.description && vendor.description.toLowerCase().includes(term));
            
            const categoryMatch = category === 'all' || vendor.category === category;
            const regionMatch = region === 'all' || vendor.region === region;
            const businessModelMatch = businessModel === 'all' || vendor.businessModel === businessModel;

            return searchTermMatch && categoryMatch && regionMatch && businessModelMatch;
        });
    }, [vendors, filters]);

    const handleClearFilters = () => {
        setFilters({
            searchTerm: '',
            category: 'all',
            region: 'all',
            businessModel: 'all',
        });
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="h-16 w-16 animate-spin text-blue-600 mx-auto mb-4" />
                    <p className="text-gray-600 text-lg">Loading verified partners...</p>
                </div>
            </div>
        );
    }

    return (
        <>
            <Toaster richColors />
            <PaywallModal open={showPaywall} onOpenChange={setShowPaywall} />
            
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
                {/* Hero Section */}
                <section className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 text-white py-16">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.7 }}
                            className="text-center"
                        >
                            <div className="flex items-center justify-center gap-2 mb-4">
                                <Building2 className="w-10 h-10" />
                                <Badge className="bg-white/20 text-white border-white/30 px-4 py-1">
                                    <Award className="w-4 h-4 mr-2" />
                                    {vendors.length}+ Vetted Partners
                                </Badge>
                            </div>
                            <h1 className="text-4xl sm:text-5xl font-bold mb-4">
                                Curated Vendor Network
                            </h1>
                            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
                                Access our exclusive network of verified technology and service partners. 
                                Each vendor is thoroughly vetted for quality, reliability, and expertise.
                            </p>
                        </motion.div>
                    </div>
                </section>
                
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    {/* User Credits Alert */}
                    <AnimatePresence>
                        {user && (
                            <motion.div
                                initial={{ opacity: 0, y: -20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -20 }}
                            >
                                <Alert className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                                    <Info className="h-5 w-5 text-blue-600" />
                                    <AlertTitle className="text-gray-900 font-semibold">
                                        Welcome, {user.full_name}
                                    </AlertTitle>
                                    <AlertDescription className="text-gray-700">
                                        You have <span className="font-bold text-blue-600 text-lg">{user.credits || 0}</span> inquiry credit{(user.credits || 0) !== 1 ? 's' : ''} remaining. 
                                        {(user.credits || 0) === 0 && (
                                            <span className="ml-2">
                                                <Button 
                                                    variant="link" 
                                                    className="p-0 h-auto text-blue-600 font-semibold underline"
                                                    onClick={() => setShowPaywall(true)}
                                                >
                                                    Get more credits →
                                                </Button>
                                            </span>
                                        )}
                                    </AlertDescription>
                                </Alert>
                            </motion.div>
                        )}
                    </AnimatePresence>
                    
                    {/* Filters */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                    >
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-8">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                                    <SlidersHorizontal className="w-5 h-5 text-blue-600" />
                                    Filter Partners
                                </h2>
                                {(filters.searchTerm || filters.category !== 'all' || filters.region !== 'all' || filters.businessModel !== 'all') && (
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={handleClearFilters}
                                        className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                    >
                                        Clear All Filters
                                    </Button>
                                )}
                            </div>
                            
                            <div className="space-y-4">
                                {/* Search Bar */}
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                    <Input
                                        type="text"
                                        placeholder="Search by name, capability, or technology..."
                                        value={filters.searchTerm}
                                        onChange={(e) => setFilters(prev => ({...prev, searchTerm: e.target.value}))}
                                        className="w-full pl-10 h-12 bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                    />
                                </div>
                                
                                {/* Filter Dropdowns */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <Select 
                                        value={filters.category} 
                                        onValueChange={(value) => setFilters(prev => ({...prev, category: value}))}
                                    >
                                        <SelectTrigger className="h-12 bg-white border-gray-300">
                                            <SelectValue placeholder="Category" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Categories</SelectItem>
                                            {filterOptions.categories.map(opt => (
                                                <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    
                                    <Select 
                                        value={filters.region} 
                                        onValueChange={(value) => setFilters(prev => ({...prev, region: value}))}
                                    >
                                        <SelectTrigger className="h-12 bg-white border-gray-300">
                                            <SelectValue placeholder="Region" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Regions</SelectItem>
                                            {filterOptions.regions.map(opt => (
                                                <SelectItem key={opt} value={opt}>
                                                    {opt.replace(/_/g, ' ')}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    
                                    <Select 
                                        value={filters.businessModel} 
                                        onValueChange={(value) => setFilters(prev => ({...prev, businessModel: value}))}
                                    >
                                        <SelectTrigger className="h-12 bg-white border-gray-300">
                                            <SelectValue placeholder="Business Model" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Models</SelectItem>
                                            {filterOptions.businessModels.map(opt => (
                                                <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                        </div>
                    </motion.div>

                    {/* Results Count */}
                    <div className="mb-6 flex items-center justify-between">
                        <p className="text-gray-600">
                            Showing <span className="font-semibold text-gray-900">{filteredVendors.length}</span> of {vendors.length} partners
                        </p>
                    </div>

                    {/* Vendor Grid */}
                    {filteredVendors.length > 0 ? (
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredVendors.map((vendor, index) => (
                                <motion.div
                                    key={vendor.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                >
                                    <VendorCard 
                                        vendor={vendor} 
                                        user={user} 
                                        onInquiry={handleInquiry}
                                    />
                                </motion.div>
                            ))}
                        </div>
                    ) : (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-center py-20"
                        >
                            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                <SlidersHorizontal className="w-10 h-10 text-gray-400" />
                            </div>
                            <h3 className="text-2xl font-semibold text-gray-900 mb-2">No Partners Found</h3>
                            <p className="text-gray-600 mb-6 max-w-md mx-auto">
                                Try adjusting your search terms or filters to find matching partners.
                            </p>
                            <Button onClick={handleClearFilters} variant="outline">
                                Clear All Filters
                            </Button>
                        </motion.div>
                    )}
                </div>
            </div>
        </>
    );
}