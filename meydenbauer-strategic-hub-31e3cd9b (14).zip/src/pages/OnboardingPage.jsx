
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { CheckCircle, ArrowRight, Calendar, Users, Briefcase, Brain } from 'lucide-react';

const nextSteps = [
  {
    title: "Schedule a 15-Minute Call",
    description: "Get personalized insights and strategic recommendations with one of our Managing Partners.",
    buttonText: "Book a Call",
    icon: Calendar,
    color: "text-blue-500",
    link: "https://calendly.com/dougsandstedt",
    external: true,
  },
  {
    title: "Network Intelligence Tool",
    description: "Find people within our network of 9K+ connections that we may be able to introduce you to.",
    buttonText: "Explore Network",
    icon: Users,
    color: "text-teal-500",
    link: createPageUrl("NetworkIntelligence"),
    external: false,
  },
  {
    title: "Intelligent Vendor Network",
    description: "Browse our recommended partners and vendors we've worked with and recommend.",
    buttonText: "View Vendor Network",
    icon: Briefcase,
    color: "text-purple-500",
    link: createPageUrl("VendorMarketplace"),
    external: false,
  },
  {
    title: "ArchetypeDNA Assessment",
    description: "Complete our leadership and decision-making style assessment to uncover your unique strengths.",
    buttonText: "Discover Your Archetype",
    icon: Brain,
    color: "text-orange-500",
    link: createPageUrl("ArchetypeDNA"),
    external: false,
  },
];

const ActionItem = ({ number, item, delay }) => {
  const content = (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="flex items-start space-x-6"
    >
      <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 border-2 border-teal-500">
        <span className="text-xl font-bold text-teal-600">{number}</span>
      </div>
      <div className="flex-1">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{item.title}</h3>
        <p className="text-gray-600 mb-4">{item.description}</p>
        <Button className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white font-bold">
          {item.buttonText}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  );

  return item.external ? (
    <a href={item.link} target="_blank" rel="noopener noreferrer" className="block">
      {content}
    </a>
  ) : (
    <Link to={item.link} className="block">
      {content}
    </Link>
  );
};

export default function OnboardingPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="shadow-xl border-gray-200">
            <CardHeader className="text-center p-8 border-b border-gray-200">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 260, damping: 20 }}
              >
                <CheckCircle className="w-16 h-16 mx-auto text-teal-500 mb-4" />
              </motion.div>
              <h1 className="text-3xl font-bold text-gray-800">Thank You!</h1>
              <p className="text-gray-600 text-lg mt-2 max-w-2xl mx-auto">
                Thanks for taking the time to share these insights. They've been shared with our internal team to help put together some relevant insights on how we might be able to help in the coming week.
              </p>
            </CardHeader>
            <CardContent className="p-8 md:p-12">
              <div className="space-y-10">
                {nextSteps.map((item, index) => (
                  <ActionItem key={item.title} number={index + 1} item={item} delay={0.4 + index * 0.15} />
                ))}
              </div>
              <div className="text-center mt-12">
                <Link to={createPageUrl('Home')}>
                  <Button variant="ghost">Back to Home</Button>
                </Link>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col items-center justify-center p-6 border-t border-gray-200 text-gray-600 text-sm">
              <p className="text-center">
                If you have questions, contact us at{" "}
                <a
                  href="mailto:admin@mbcpartners.co"
                  className="text-teal-600 hover:underline"
                >
                  admin@mbcpartners.co
                </a>
                .
              </p>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
