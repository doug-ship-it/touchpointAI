
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Check, ArrowRight, Brain, Target, Cog, Zap, Users, TrendingUp, BookOpen, Award, PlayCircle, BrainCircuit, Loader2, Edit, UserSearch, Bot } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const archetypeInfo = {
  "The Strategist": {
    icon: Target,
    color: "from-blue-500 to-indigo-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
    textColor: "text-blue-900",
    description: "You excel at market positioning, competitive analysis, and aligning technology initiatives with business outcomes. Your superpower is seeing the big picture and making strategic decisions that drive sustainable growth.",
    traits: ["Market Analysis", "Competitive Intelligence", "Strategic Planning", "ROI Optimization"],
    strengths: [
      "Exceptional at identifying market opportunities and competitive advantages",
      "Natural ability to align technology decisions with business objectives", 
      "Strong analytical skills for evaluating complex business scenarios",
      "Talent for communicating strategic vision to diverse stakeholders"
    ],
    learningPath: [
      "Advanced Strategic Planning Frameworks",
      "Market Intelligence & Competitive Analysis", 
      "Business Model Innovation",
      "Executive Communication & Influence"
    ]
  },
  "The Builder": {
    icon: Cog,
    color: "from-emerald-500 to-teal-600", 
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
    textColor: "text-emerald-900",
    description: "You thrive on creating robust, scalable systems and elegant technical solutions. Your expertise lies in translating business requirements into solid technical architecture that stands the test of time.",
    traits: ["Systems Architecture", "Technical Excellence", "Scalable Solutions", "Process Engineering"],
    strengths: [
      "Exceptional technical problem-solving and system design capabilities",
      "Natural talent for creating scalable, maintainable technical solutions",
      "Strong focus on code quality, performance optimization, and best practices", 
      "Ability to mentor technical teams and establish engineering standards"
    ],
    learningPath: [
      "Advanced System Architecture Patterns",
      "Cloud-Native Design & Implementation",
      "Technical Leadership & Team Building",
      "DevOps & Platform Engineering"
    ]
  },
  "The Visionary": {
    icon: Brain,
    color: "from-purple-500 to-pink-600",
    bgColor: "bg-purple-50", 
    borderColor: "border-purple-200",
    textColor: "text-purple-900",
    description: "You have an innate ability to see future trends and inspire others with transformative possibilities. Your leadership style focuses on innovation, user experience, and creating meaningful change in your industry.",
    traits: ["Future Thinking", "Innovation Leadership", "User Experience Focus", "Transformational Vision"],
    strengths: [
      "Exceptional ability to identify emerging trends and market disruptions",
      "Natural talent for inspiring teams and stakeholders with compelling visions",
      "Strong focus on user experience and customer-centric innovation",
      "Skill in communicating complex ideas in accessible and motivating ways"
    ],
    learningPath: [
      "Innovation Strategy & Methodology",
      "Design Thinking & User Experience",
      "Change Management & Transformation",
      "Emerging Technology Assessment"
    ]
  },
  "The Optimizer": {
    icon: TrendingUp,
    color: "from-orange-500 to-red-600",
    bgColor: "bg-orange-50",
    borderColor: "border-orange-200", 
    textColor: "text-orange-900",
    description: "You excel at identifying inefficiencies and creating streamlined, high-performance operations. Your strength lies in process improvement, resource optimization, and delivering consistent, measurable results.",
    traits: ["Process Optimization", "Operational Excellence", "Efficiency Gains", "Performance Metrics"],
    strengths: [
      "Exceptional ability to identify and eliminate operational inefficiencies",
      "Natural talent for creating standardized processes and quality systems",
      "Strong focus on data-driven decision making and performance metrics",
      "Skill in change management and continuous improvement methodologies"
    ],
    learningPath: [
      "Lean Operations & Process Optimization",
      "Data Analytics & Performance Management",
      "Operational Excellence Frameworks",
      "Automation & Workflow Design"
    ]
  }
};

const platformFeatures = [
  {
    icon: BookOpen,
    title: "Personalized Learning Paths",
    description: "Curated courses and resources tailored to your archetype and career goals"
  },
  {
    icon: Users,
    title: "Community & Networking",
    description: "Connect with like-minded professionals and industry leaders"
  },
  {
    icon: Award,
    title: "Certification Programs", 
    description: "Earn recognized credentials that validate your expertise"
  },
  {
    icon: Brain,
    title: "AI-Powered Insights",
    description: "Get intelligent recommendations for skill development and career advancement"
  }
];

const learningMetrics = [
  { value: "10,000+", label: "Learners Assessed", icon: Users },
  { value: "95%", label: "Career Advancement Rate", icon: TrendingUp },
  { value: "500+", label: "Learning Resources", icon: BookOpen },
  { value: "50+", label: "Industry Experts", icon: Award }
];

const fallbackQuestions = [
  {
    question: "When facing a major business decision, what's your primary approach?",
    options: [
      { text: "Analyze market data and competitive landscape thoroughly", archetype: "The Strategist" },
      { text: "Design a robust system that can scale and adapt", archetype: "The Builder" },
      { text: "Envision the future impact and inspire stakeholders", archetype: "The Visionary" },
      { text: "Identify inefficiencies and optimize for measurable results", archetype: "The Optimizer" }
    ]
  },
  {
    question: "Your team is struggling with a complex challenge. How do you respond?",
    options: [
      { text: "Develop a strategic framework to guide decision-making", archetype: "The Strategist" },
      { text: "Build systematic processes to prevent similar issues", archetype: "The Builder" },
      { text: "Inspire creative thinking and innovative solutions", archetype: "The Visionary" },
      { text: "Implement immediate improvements and track progress", archetype: "The Optimizer" }
    ]
  },
  {
    question: "When evaluating new opportunities, what matters most to you?",
    options: [
      { text: "Strategic alignment with long-term business objectives", archetype: "The Strategist" },
      { text: "Technical feasibility and sustainable implementation", archetype: "The Builder" },
      { text: "Potential to create transformative change", archetype: "The Visionary" },
      { text: "Clear ROI and operational efficiency gains", archetype: "The Optimizer" }
    ]
  },
  {
    question: "How do you prefer to communicate with your team?",
    options: [
      { text: "Share market insights and strategic context", archetype: "The Strategist" },
      { text: "Provide clear technical specifications and standards", archetype: "The Builder" },
      { text: "Paint a compelling picture of future possibilities", archetype: "The Visionary" },
      { text: "Focus on metrics, progress, and concrete outcomes", archetype: "The Optimizer" }
    ]
  },
  {
    question: "What energizes you most in your work?",
    options: [
      { text: "Solving complex business puzzles and competitive challenges", archetype: "The Strategist" },
      { text: "Creating elegant, lasting solutions that work at scale", archetype: "The Builder" },
      { text: "Pioneering new approaches and inspiring others", archetype: "The Visionary" },
      { text: "Achieving measurable improvements and operational excellence", archetype: "The Optimizer" }
    ]
  }
];

const variants = {
  enter: { opacity: 0, x: 300 },
  center: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -300 },
};

export default function ArchetypeDNALearning() {
  const [assessmentStage, setAssessmentStage] = useState('overview'); // overview, analyzing_profile, confirming_profile, generating_questions, answering_questions, showing_results
  const [user, setUser] = useState(null);
  const [profileData, setProfileData] = useState(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [dynamicQuestions, setDynamicQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [finalArchetype, setFinalArchetype] = useState(null);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
      } catch (error) {
        console.log("User not signed in, proceeding as guest.");
      }
    };
    loadUser();
  }, []);
  
  const handleStartAssessment = () => {
    setAssessmentStage('analyzing_profile');
    analyzeProfile();
  };

  const analyzeProfile = async () => {
    let email = user?.email;
    if (!email) {
      // If no user, we can't do the intelligent part. Skip to a default questionnaire.
      // For this implementation, we'll generate generic questions.
      setProfileData({
        jobTitle: "Leader",
        industry: "General Business",
        seniority: "Manager"
      });
      setAssessmentStage('confirming_profile'); // Go to confirm profile for guest, allowing them to edit
      setIsEditingProfile(true); // Automatically set to editing for guests
      return;
    }
    
    const domain = email.split('@')[1];
    
    try {
      const prompt = `Analyze the company with domain "${domain}" and infer the professional profile of a user with email "${email}".
      Search for the company's official website, LinkedIn page, and other public sources.
      Based on this, provide a best-effort guess for the user's professional context.
      
      Return a JSON object with:
      - "companyName": string
      - "industry": A concise industry description (e.g., "SaaS", "Financial Services", "Manufacturing").
      - "jobTitle": A plausible job title (e.g., "Software Engineer", "Marketing Manager", "CTO").
      - "seniority": One of "Executive", "Director", "Manager", "Senior", "Individual Contributor".
      - "confidence": Your confidence in this assessment, one of "high", "medium", "low".
      `;
      const enrichedProfile = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            companyName: { type: "string" },
            industry: { type: "string" },
            jobTitle: { type: "string" },
            seniority: { type: "string" },
            confidence: { type: "string", enum: ["high", "medium", "low"] }
          }
        }
      });

      setProfileData(enrichedProfile);
      if(enrichedProfile.confidence === 'low' || !enrichedProfile.jobTitle || !enrichedProfile.industry || !enrichedProfile.seniority){
        setIsEditingProfile(true);
      }
      setAssessmentStage('confirming_profile');
    } catch (error) {
      console.error("Profile analysis failed:", error);
      // Fallback to manual entry if AI fails
      setProfileData({ companyName: '', industry: '', jobTitle: '', seniority: '' });
      setIsEditingProfile(true);
      setAssessmentStage('confirming_profile');
    }
  };

  const generateQuestions = async (confirmedProfile) => {
    setAssessmentStage('generating_questions');
    setError(null);
    
    try {
      console.log('Generating questions for profile:', confirmedProfile);
      
      const prompt = `You are an expert business consultant and leadership assessment designer. 
      
      Based on the user's professional profile:
      - Role: ${confirmedProfile.jobTitle || 'Professional'}
      - Industry: ${confirmedProfile.industry || 'General Business'}
      - Seniority: ${confirmedProfile.seniority || 'Manager'}
      - Company: ${confirmedProfile.companyName || 'A typical company'}
      
      Create exactly 5 multiple-choice questions that will identify their leadership archetype. Each question should present a realistic business scenario that someone in their position would face.
      
      The four possible archetypes are:
      - "The Strategist": Focuses on market analysis, competitive positioning, strategic planning
      - "The Builder": Emphasizes technical excellence, systems thinking, scalable solutions
      - "The Visionary": Champions innovation, transformation, future-thinking
      - "The Optimizer": Prioritizes efficiency, process improvement, measurable results
      
      Make each question relevant to their industry and role level. Each question must have exactly 4 options, with each option clearly mapping to one of the four archetypes.
      
      Return the questions in the specified JSON format.`;
      
      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        text: { type: "string" },
                        archetype: { type: "string", enum: ["The Strategist", "The Builder", "The Visionary", "The Optimizer"] }
                      },
                      required: ["text", "archetype"]
                    }
                  }
                },
                required: ["question", "options"]
              }
            }
          },
          required: ["questions"]
        }
      });

      console.log('Generated questions:', response);

      // Extract questions from the response object
      const questions = response.questions || [];

      // Validate the response
      if (!Array.isArray(questions) || questions.length !== 5) {
        throw new Error('Invalid question format received: not an array or incorrect length.');
      }

      // Validate each question has 4 options and correct archetype mapping
      for (const q of questions) {
        if (!q.options || q.options.length !== 4) {
          throw new Error('Each question must have exactly 4 options.');
        }
        for (const opt of q.options) {
          if (!archetypeInfo[opt.archetype]) {
            throw new Error(`Invalid archetype "${opt.archetype}" found in options.`);
          }
        }
      }

      setDynamicQuestions(questions);
      setAssessmentStage('answering_questions');
      
    } catch (error) {
      console.error("Failed to generate personalized questions:", error);
      console.log("Using fallback questions instead");
      
      // Use fallback questions if AI generation fails or returns invalid data
      setDynamicQuestions(fallbackQuestions);
      setAssessmentStage('answering_questions');
    }
  };

  const handleProfileConfirm = () => {
    if (!profileData?.jobTitle || !profileData?.industry || !profileData?.seniority) {
      setError("Please fill in all required profile fields (Job Title, Industry, Seniority).");
      return;
    }
    generateQuestions(profileData);
  };

  const handleProfileUpdate = (field, value) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
    setError(null); // Clear error on input change
  };

  const handleAnswer = async (option) => {
    setSelectedAnswer(option);
    
    setTimeout(async () => {
      const newAnswers = [...answers, option.archetype];
      setAnswers(newAnswers);
      
      if (currentQuestionIndex < dynamicQuestions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setSelectedAnswer(null);
      } else {
        await calculateResult(newAnswers);
      }
    }, 500);
  };

  const calculateResult = async (allAnswers) => {
    const counts = {};
    allAnswers.forEach(archetype => {
      counts[archetype] = (counts[archetype] || 0) + 1;
    });

    let result = 'The Strategist';
    let maxCount = 0;
    for (const archetype in counts) {
      if (counts[archetype] > maxCount) {
        maxCount = counts[archetype];
        result = archetype;
      }
    }
    
    setFinalArchetype(result);
    setAssessmentStage('showing_results');
    
    if (user) {
      try {
        await User.updateMyUserData({
          archetype_dna: {
            primary_archetype: result,
            assessment_date: new Date().toISOString(),
            scores: counts,
            profile_context: profileData
          }
        });
      } catch (error) {
        console.error('Error saving archetype:', error);
      }
    }
  };

  const handleRetake = () => {
    setAssessmentStage('overview');
    setAnswers([]);
    setDynamicQuestions([]);
    setCurrentQuestionIndex(0);
    setFinalArchetype(null);
    setProfileData(null); // Clear profile data
    setIsEditingProfile(false); // Reset edit state
    setError(null); // Clear errors
  };

  const handleContinue = () => {
    navigate(createPageUrl('Home'));
  };

  // ----- RENDER FUNCTIONS -----

  const renderLoadingScreen = (title, subtitle) => (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="relative mb-6">
        <motion.div
          className="w-16 h-16 border-4 border-teal-200 border-t-teal-600 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Bot className="w-8 h-8 text-teal-500" />
        </motion.div>
      </div>
      <h2 className="text-3xl font-bold text-gray-800 mb-2">{title}</h2>
      <p className="text-gray-600 max-w-md">{subtitle}</p>
      <div className="mt-4 text-sm text-gray-500">
        This may take a few moments...
      </div>
    </div>
  );

  const renderProfileConfirmation = () => (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <UserSearch className="w-12 h-12 text-teal-600 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-gray-800">Please Confirm Your Profile</h2>
        <p className="text-gray-600 mt-2">Our AI has detected the following professional profile. Please confirm or edit it to personalize your assessment.</p>
      </div>

      <Card className="bg-white/70 backdrop-blur-sm shadow-xl border-gray-200">
        <CardContent className="p-8 space-y-6">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}
          
          {isEditingProfile ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="jobTitle">Job Title *</Label>
                <Input 
                  id="jobTitle" 
                  value={profileData?.jobTitle || ''} 
                  onChange={(e) => handleProfileUpdate('jobTitle', e.target.value)}
                  placeholder="e.g., Software Engineer, Marketing Manager"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="industry">Industry *</Label>
                <Input 
                  id="industry" 
                  value={profileData?.industry || ''} 
                  onChange={(e) => handleProfileUpdate('industry', e.target.value)}
                  placeholder="e.g., Technology, Healthcare, Finance"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="seniority">Seniority Level *</Label>
                <Input 
                  id="seniority" 
                  value={profileData?.seniority || ''} 
                  onChange={(e) => handleProfileUpdate('seniority', e.target.value)}
                  placeholder="e.g., Executive, Director, Manager, Individual Contributor"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="companyName">Company (Optional)</Label>
                <Input 
                  id="companyName" 
                  value={profileData?.companyName || ''} 
                  onChange={(e) => handleProfileUpdate('companyName', e.target.value)}
                  placeholder="Your company name"
                />
              </div>
            </>
          ) : (
            <div className="space-y-4">
              {profileData?.companyName && (
                <div className="p-3 bg-gray-50 rounded-lg">
                  <strong>Company:</strong> {profileData.companyName}
                </div>
              )}
              <div className="p-3 bg-gray-50 rounded-lg">
                <strong>Role:</strong> {profileData?.jobTitle || 'Not specified'}
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <strong>Industry:</strong> {profileData?.industry || 'Not specified'}
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <strong>Seniority:</strong> {profileData?.seniority || 'Not specified'}
              </div>
              {profileData?.confidence && (
                <div className="text-sm text-gray-500">
                  AI Confidence: {profileData.confidence}
                </div>
              )}
            </div>
          )}
          
          <div className="flex justify-between items-center pt-4 border-t">
            <Button variant="ghost" onClick={() => {setIsEditingProfile(!isEditingProfile); setError(null);}}>
              <Edit className="w-4 h-4 mr-2" />
              {isEditingProfile ? 'Cancel' : 'Edit Profile'}
            </Button>
            <Button onClick={handleProfileConfirm} className="bg-teal-600 hover:bg-teal-700">
              Confirm & Start Assessment <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderAnsweringQuestions = () => {
    if (dynamicQuestions.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Loading Error</h2>
          <p className="text-gray-600 mb-6">We encountered an issue generating your personalized questions. Please try again or use the default questions.</p>
          <Button onClick={handleRetake} className="bg-teal-600 hover:bg-teal-700">
            Start Over
          </Button>
        </div>
      );
    }
    
    const currentQuestion = dynamicQuestions[currentQuestionIndex];
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-3">Leadership ArchetypeDNA</h1>
            <p className="text-slate-300">Personalized for your role and industry</p>
          </div>
          
          <div className="mb-12">
            <div className="flex justify-between mb-3 text-sm text-slate-400">
              <span>Progress</span>
              <span>Question {currentQuestionIndex + 1} of {dynamicQuestions.length}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-3 shadow-inner">
              <motion.div
                className="bg-gradient-to-r from-teal-400 to-purple-500 h-3 rounded-full shadow-lg"
                initial={{ width: `${(currentQuestionIndex / dynamicQuestions.length) * 100}%` }}
                animate={{ width: `${((currentQuestionIndex + 1) / dynamicQuestions.length) * 100}%` }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
              />
            </div>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuestionIndex}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.4 }}
              className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 shadow-2xl"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-10 leading-relaxed text-center">
                {currentQuestion.question}
              </h2>
              <div className="space-y-4">
                {currentQuestion.options.map((option, index) => {
                  const isSelected = selectedAnswer === option;
                  return (
                    <motion.button
                      key={index}
                      onClick={() => handleAnswer(option)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className={`w-full text-left p-6 rounded-2xl border-2 transition-all duration-300 group ${
                        isSelected 
                          ? 'bg-gradient-to-r from-teal-500/20 to-purple-500/20 border-teal-400 shadow-lg shadow-teal-400/20' 
                          : 'border-slate-600/50 bg-slate-800/30 hover:bg-slate-700/50 hover:border-teal-500/50'
                      }`}
                    >
                      <div className="flex items-start space-x-4">
                         <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                            isSelected ? 'bg-teal-400 text-white' : 'bg-slate-700 text-slate-400 group-hover:bg-teal-400 group-hover:text-white'
                          }`}>
                            <span className="font-bold">{String.fromCharCode(65 + index)}</span>
                          </div>
                        <div className="flex-grow">
                          <span className={`block text-base leading-relaxed transition-colors ${
                            isSelected ? 'text-white' : 'text-slate-200 group-hover:text-white'
                          }`}>
                            {option.text}
                          </span>
                        </div>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    );
  };
  
  if (assessmentStage === 'showing_results' && finalArchetype) {
    const archetype = archetypeInfo[finalArchetype];
    const IconComponent = archetype.icon;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="flex flex-col items-center justify-center min-h-screen p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-4xl"
          >
            {/* Header */}
            <div className="text-center mb-12">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3, type: "spring", duration: 0.6 }}
                className={`w-24 h-24 mx-auto mb-6 rounded-3xl bg-gradient-to-r ${archetype.color} flex items-center justify-center shadow-2xl`}
              >
                <IconComponent className="w-12 h-12 text-white" />
              </motion.div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Your Leadership ArchetypeDNA
              </h1>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className={`inline-block px-8 py-4 rounded-2xl bg-gradient-to-r ${archetype.color} text-white font-bold text-2xl mb-6 shadow-lg`}
              >
                {finalArchetype}
              </motion.div>
              <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
                {archetype.description}
              </p>
            </div>

            {/* Learning Path */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className={`${archetype.bgColor} ${archetype.borderColor} border-2 rounded-2xl p-8 text-gray-900 mb-8`}
            >
              <h3 className={`text-2xl font-bold mb-6 ${archetype.textColor} flex items-center gap-3`}>
                <BookOpen className="w-6 h-6" />
                Your Personalized Learning Path
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {archetype.learningPath.map((course, index) => (
                  <motion.div
                    key={course}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="flex items-center gap-3 p-4 bg-white rounded-lg shadow-sm"
                  >
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-r ${archetype.color} flex items-center justify-center`}>
                      <span className="text-white font-bold text-sm">{index + 1}</span>
                    </div>
                    <span className="font-medium">{course}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="text-center space-y-4"
            >
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleContinue}
                  className={`bg-gradient-to-r ${archetype.color} hover:opacity-90 text-white px-8 py-4 text-lg font-semibold shadow-xl`}
                  size="lg"
                >
                  Explore Learning Platform
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  onClick={handleRetake}
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg"
                  size="lg"
                >
                  Retake Assessment
                </Button>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      {assessmentStage === 'overview' && (
        <>
          {/* Hero Section */}
          <section className="py-16 text-center bg-white border-b">
            <motion.div 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.7 }}
              className="max-w-4xl mx-auto px-6"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 rounded-full border border-indigo-200 mb-4">
                <BrainCircuit className="w-4 h-4 text-indigo-600" />
                <span className="text-sm font-medium text-indigo-700">New Educational Platform</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-gray-900">
                ArchetypeDNA Learning Platform
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
                Discover your unique leadership archetype and access personalized learning paths designed to accelerate your professional growth and business impact.
              </p>
              
              <Button 
                onClick={handleStartAssessment}
                size="lg" 
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-lg px-8 py-4 h-auto shadow-lg"
              >
                <PlayCircle className="w-6 h-6 mr-2" />
                Start Your Intelligent Assessment
              </Button>
            </motion.div>
          </section>

          {/* Success Metrics */}
          <section className="py-12 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                {learningMetrics.map((metric, index) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="text-center"
                  >
                    <div className="flex justify-center mb-2">
                      <metric.icon className="w-8 h-8" />
                    </div>
                    <div className="text-3xl font-bold mb-1">{metric.value}</div>
                    <div className="text-sm opacity-90">{metric.label}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Platform Features */}
          <section className="py-16 bg-white">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Personalized Learning Experience</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  Our platform adapts to your unique leadership archetype, providing targeted resources and community connections.
                </p>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                {platformFeatures.map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="text-center h-full p-6 hover:shadow-lg transition-all duration-300">
                      <CardContent className="space-y-4">
                        <div className="p-3 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 w-fit mx-auto">
                          <feature.icon className="w-6 h-6 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                        <p className="text-gray-600">{feature.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Archetypes Overview */}
          <section className="py-16 bg-gray-50">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Four Leadership Archetypes</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  Discover which archetype resonates with your leadership style and business approach.
                </p>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {Object.entries(archetypeInfo).map(([name, info], index) => (
                  <motion.div
                    key={name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="text-center h-full p-6 hover:shadow-lg transition-all duration-300 group">
                      <CardContent className="space-y-4">
                        <div className={`p-3 rounded-xl bg-gradient-to-r ${info.color} w-fit mx-auto`}>
                          <info.icon className="w-6 h-6 text-white" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900">{name}</h3>
                        <div className="flex flex-wrap gap-1 justify-center">
                          {info.traits.slice(0, 2).map(trait => (
                            <Badge key={trait} variant="outline" className="text-xs">
                              {trait}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </>
      )}
      {assessmentStage === 'analyzing_profile' && renderLoadingScreen('Analyzing Your Professional Profile...', 'Our AI is searching public data to create a baseline for your assessment.')}
      {assessmentStage === 'confirming_profile' && profileData && renderProfileConfirmation()}
      {assessmentStage === 'generating_questions' && renderLoadingScreen('Crafting Your Personalized Questions...', 'The assessment is being tailored to your unique professional context.')}
      {assessmentStage === 'answering_questions' && renderAnsweringQuestions()}
    </div>
  );
}
