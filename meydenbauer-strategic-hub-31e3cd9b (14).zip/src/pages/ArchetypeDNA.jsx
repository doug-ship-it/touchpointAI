
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Check, ArrowRight, Brain, Target, Cog, Zap, Users, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const questions = [
  {
    question: "When tackling a complex business challenge, what's your instinctive approach?",
    options: [
      { text: "Analyze market data, competitive landscape, and create a comprehensive strategic roadmap with clear KPIs.", archetype: "The Strategist", icon: Target },
      { text: "Dive into the technical architecture, identify scalability bottlenecks, and design robust solutions.", archetype: "The Builder", icon: Cog },
      { text: "Envision the transformative impact on users and inspire the team with a compelling future vision.", archetype: "The Visionary", icon: Brain },
      { text: "Focus on optimizing processes, eliminating inefficiencies, and maximizing operational excellence.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
  {
    question: "In team meetings discussing new initiatives, you typically contribute by:",
    options: [
      { text: "Presenting market analysis, ROI projections, and alignment with business objectives.", archetype: "The Strategist", icon: Target },
      { text: "Evaluating technical feasibility, resource requirements, and implementation timelines.", archetype: "The Builder", icon: Cog },
      { text: "Painting a picture of the end-user experience and long-term industry transformation.", archetype: "The Visionary", icon: Brain },
      { text: "Identifying workflow improvements, resource allocation, and process standardization.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
  {
    question: "What energizes you most about your professional work?",
    options: [
      { text: "Outmaneuvering competitors through superior positioning and winning in the marketplace.", archetype: "The Strategist", icon: Target },
      { text: "Creating elegant, scalable systems that other professionals admire and want to learn from.", archetype: "The Builder", icon: Cog },
      { text: "Being the first to identify emerging trends and pioneering innovative solutions.", archetype: "The Visionary", icon: Brain },
      { text: "Transforming chaotic processes into smooth, efficient operations that deliver consistent results.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
  {
    question: "When evaluating a potential business partnership or vendor, you prioritize:",
    options: [
      { text: "Their market reputation, financial stability, and strategic alignment with our goals.", archetype: "The Strategist", icon: Target },
      { text: "Their technical expertise, platform compatibility, and development methodology.", archetype: "The Builder", icon: Cog },
      { text: "Their innovation potential, cultural fit, and shared vision for industry transformation.", archetype: "The Visionary", icon: Brain },
      { text: "Their operational efficiency, service reliability, and ability to streamline our workflows.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
  {
    question: "Your ideal outcome for a 6-month business initiative would be:",
    options: [
      { text: "Capturing significant market share, establishing competitive moats, and exceeding revenue targets.", archetype: "The Strategist", icon: Target },
      { text: "Deploying a robust, scalable platform that becomes the foundation for future growth.", archetype: "The Builder", icon: Cog },
      { text: "Creating breakthrough customer experiences that set new industry standards.", archetype: "The Visionary", icon: Brain },
      { text: "Achieving measurable efficiency gains, cost reductions, and operational excellence metrics.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
  {
    question: "When facing a crisis or major setback, your leadership approach is to:",
    options: [
      { text: "Quickly assess the situation, reallocate resources, and pivot strategy to minimize losses.", archetype: "The Strategist", icon: Target },
      { text: "Dive deep into root cause analysis and implement systematic fixes to prevent recurrence.", archetype: "The Builder", icon: Cog },
      { text: "Inspire the team with a renewed sense of purpose and rally around an evolved vision.", archetype: "The Visionary", icon: Brain },
      { text: "Establish emergency protocols, optimize crisis response, and restore operational stability.", archetype: "The Optimizer", icon: TrendingUp },
    ],
  },
];

const archetypeInfo = {
  "The Strategist": {
    icon: Target,
    color: "from-blue-500 to-indigo-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
    textColor: "text-blue-900",
    description: "You excel at market positioning, competitive analysis, and aligning technology initiatives with business outcomes. Your superpower is seeing the big picture and making strategic decisions that drive sustainable growth.",
    traits: ["Market Analysis", "Competitive Intelligence", "Strategic Planning", "ROI Optimization"],
    strengths: [
      "Exceptional at identifying market opportunities and competitive advantages",
      "Natural ability to align technology decisions with business objectives", 
      "Strong analytical skills for evaluating complex business scenarios",
      "Talent for communicating strategic vision to diverse stakeholders"
    ],
    recommendations: [
      "Consider exploring our Business Intelligence and Market Analysis resources",
      "Network Intelligence platform could help you identify strategic partnerships",
      "Full Proposal Generation would leverage your strategic thinking for business transformation"
    ]
  },
  "The Builder": {
    icon: Cog,
    color: "from-emerald-500 to-teal-600", 
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
    textColor: "text-emerald-900",
    description: "You thrive on creating robust, scalable systems and elegant technical solutions. Your expertise lies in translating business requirements into solid technical architecture that stands the test of time.",
    traits: ["Systems Architecture", "Technical Excellence", "Scalable Solutions", "Process Engineering"],
    strengths: [
      "Exceptional technical problem-solving and system design capabilities",
      "Natural talent for creating scalable, maintainable technical solutions",
      "Strong focus on code quality, performance optimization, and best practices", 
      "Ability to mentor technical teams and establish engineering standards"
    ],
    recommendations: [
      "Tech stack optimization resources would align with your technical expertise",
      "Consider exploring our vendor network for specialized technical partners",
      "Your skills would benefit from advanced architecture and DevOps resources"
    ]
  },
  "The Visionary": {
    icon: Brain,
    color: "from-purple-500 to-pink-600",
    bgColor: "bg-purple-50", 
    borderColor: "border-purple-200",
    textColor: "text-purple-900",
    description: "You have an innate ability to see future trends and inspire others with transformative possibilities. Your leadership style focuses on innovation, user experience, and creating meaningful change in your industry.",
    traits: ["Future Thinking", "Innovation Leadership", "User Experience Focus", "Transformational Vision"],
    strengths: [
      "Exceptional ability to identify emerging trends and market disruptions",
      "Natural talent for inspiring teams and stakeholders with compelling visions",
      "Strong focus on user experience and customer-centric innovation",
      "Skill in communicating complex ideas in accessible and motivating ways"
    ],
    recommendations: [
      "Innovation workshops and trend analysis resources would enhance your forward-thinking",
      "Consider leveraging our network to connect with other visionary leaders",
      "User experience and design thinking resources would complement your vision"
    ]
  },
  "The Optimizer": {
    icon: TrendingUp,
    color: "from-orange-500 to-red-600",
    bgColor: "bg-orange-50",
    borderColor: "border-orange-200", 
    textColor: "text-orange-900",
    description: "You excel at identifying inefficiencies and creating streamlined, high-performance operations. Your strength lies in process improvement, resource optimization, and delivering consistent, measurable results.",
    traits: ["Process Optimization", "Operational Excellence", "Efficiency Gains", "Performance Metrics"],
    strengths: [
      "Exceptional ability to identify and eliminate operational inefficiencies",
      "Natural talent for creating standardized processes and quality systems",
      "Strong focus on data-driven decision making and performance metrics",
      "Skill in change management and continuous improvement methodologies"
    ],
    recommendations: [
      "Process automation and workflow optimization resources would amplify your strengths",
      "Consider exploring operational excellence frameworks and lean methodologies",  
      "Performance analytics and KPI dashboard tools would support your optimization focus"
    ]
  }
};

const variants = {
  enter: { opacity: 0, x: 300 },
  center: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -300 },
};

export default function ArchetypeDNAPage() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResult, setShowResult] = useState(false);
  const [finalArchetype, setFinalArchetype] = useState(null);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const navigate = useNavigate();

  const handleAnswer = async (option) => {
    setSelectedAnswer(option);
    
    // Brief animation delay
    setTimeout(async () => {
      const newAnswers = { ...answers, [step]: option.archetype };
      setAnswers(newAnswers);
      
      if (step < questions.length - 1) {
        setStep(step + 1);
        setSelectedAnswer(null);
      } else {
        await calculateResult(newAnswers);
      }
    }, 500);
  };

  const calculateResult = async (allAnswers) => {
    const counts = {};
    Object.values(allAnswers).forEach(archetype => {
      counts[archetype] = (counts[archetype] || 0) + 1;
    });

    let result = 'The Strategist';
    let maxCount = 0;
    for (const archetype in counts) {
      if (counts[archetype] > maxCount) {
        maxCount = counts[archetype];
        result = archetype;
      }
    }
    
    setFinalArchetype(result);
    setShowResult(true);
    
    try {
      await User.updateMyUserData({
        archetype_dna: {
          primary_archetype: result,
          assessment_date: new Date().toISOString(),
          scores: counts
        }
      });
    } catch (error) {
      console.error('Error saving archetype:', error);
    }
  };

  const handleContinue = () => {
    navigate(createPageUrl('Home'));
  };

  const handleRetake = () => {
    setStep(0);
    setAnswers({});
    setShowResult(false);
    setFinalArchetype(null);
    setSelectedAnswer(null);
  };

  if (showResult && finalArchetype) {
    const archetype = archetypeInfo[finalArchetype];
    const IconComponent = archetype.icon;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="flex flex-col items-center justify-center min-h-screen p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-4xl"
          >
            {/* Header */}
            <div className="text-center mb-12">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3, type: "spring", duration: 0.6 }}
                className={`w-24 h-24 mx-auto mb-6 rounded-3xl bg-gradient-to-r ${archetype.color} flex items-center justify-center shadow-2xl`}
              >
                <IconComponent className="w-12 h-12 text-white" />
              </motion.div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Your Leadership ArchetypeDNA
              </h1>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className={`inline-block px-8 py-4 rounded-2xl bg-gradient-to-r ${archetype.color} text-white font-bold text-2xl mb-6 shadow-lg`}
              >
                {finalArchetype}
              </motion.div>
              <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
                {archetype.description}
              </p>
            </div>

            {/* Details Grid */}
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {/* Key Strengths */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className={`${archetype.bgColor} ${archetype.borderColor} border-2 rounded-2xl p-8 text-gray-900`}
              >
                <h3 className={`text-2xl font-bold mb-6 ${archetype.textColor} flex items-center gap-3`}>
                  <Zap className="w-6 h-6" />
                  Core Strengths
                </h3>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {archetype.traits.map((trait, index) => (
                    <motion.div
                      key={trait}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.8 + index * 0.1 }}
                      className="flex items-center space-x-2"
                    >
                      <Check className={`w-5 h-5 ${archetype.textColor}`} />
                      <span className="font-medium text-sm">{trait}</span>
                    </motion.div>
                  ))}
                </div>
                <div className="space-y-3">
                  {archetype.strengths.map((strength, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1 + index * 0.1 }}
                      className="flex items-start space-x-2"
                    >
                      <div className={`w-2 h-2 rounded-full ${archetype.color} bg-gradient-to-r mt-2 flex-shrink-0`}></div>
                      <p className="text-sm text-gray-700 leading-relaxed">{strength}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Recommendations */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 }}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20"
              >
                <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-3">
                  <Users className="w-6 h-6" />
                  Personalized Recommendations  
                </h3>
                <div className="space-y-4">
                  {archetype.recommendations.map((rec, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 1.2 + index * 0.15 }}
                      className="flex items-start space-x-3 p-4 bg-white/5 rounded-xl border border-white/10"
                    >
                      <ArrowRight className="w-5 h-5 text-teal-400 mt-0.5 flex-shrink-0" />
                      <p className="text-slate-300 text-sm leading-relaxed">{rec}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5 }}
              className="text-center space-y-4"
            >
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleContinue}
                  className={`bg-gradient-to-r ${archetype.color} hover:opacity-90 text-white px-8 py-4 text-lg font-semibold shadow-xl`}
                  size="lg"
                >
                  Explore Personalized Resources
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  onClick={handleRetake}
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg"
                  size="lg"
                >
                  Retake Assessment
                </Button>
              </div>
              <p className="text-sm text-slate-400 max-w-2xl mx-auto">
                Your ArchetypeDNA has been saved to your profile. Access personalized resources and recommendations anytime from your dashboard.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[step];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <div className="w-full max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-teal-400 to-purple-500 rounded-3xl flex items-center justify-center shadow-2xl">
              <Brain className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">Leadership ArchetypeDNA</h1>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto">
              Discover your unique leadership style and receive personalized business recommendations
            </p>
          </div>

          {/* Progress */}
          <div className="mb-12">
            <div className="flex justify-between mb-3 text-sm text-slate-400">
              <span>Progress</span>
              <span>Question {step + 1} of {questions.length}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-3 shadow-inner">
              <motion.div
                className="bg-gradient-to-r from-teal-400 to-purple-500 h-3 rounded-full shadow-lg"
                initial={{ width: `${(step / questions.length) * 100}%` }}
                animate={{ width: `${((step + 1) / questions.length) * 100}%` }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
              />
            </div>
          </div>

          {/* Question */}
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.4 }}
              className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 shadow-2xl"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-10 leading-relaxed text-center">
                {currentQuestion.question}
              </h2>
              
              <div className="space-y-4">
                {currentQuestion.options.map((option, index) => {
                  const IconComponent = option.icon;
                  const isSelected = selectedAnswer === option;
                  
                  return (
                    <motion.button
                      key={option.text}
                      onClick={() => handleAnswer(option)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className={`w-full text-left p-6 rounded-2xl border-2 transition-all duration-300 group ${
                        isSelected 
                          ? 'bg-gradient-to-r from-teal-500/20 to-purple-500/20 border-teal-400 shadow-lg shadow-teal-400/20' 
                          : 'border-slate-600/50 bg-slate-800/30 hover:bg-slate-700/50 hover:border-teal-500/50'
                      }`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                          isSelected ? 'bg-teal-400 text-white' : 'bg-slate-700 text-slate-400 group-hover:bg-teal-400 group-hover:text-white'
                        }`}>
                          <IconComponent className="w-4 h-4" />
                        </div>
                        <div className="flex-grow">
                          <span className={`block text-base leading-relaxed transition-colors ${
                            isSelected ? 'text-white' : 'text-slate-200 group-hover:text-white'
                          }`}>
                            {option.text}
                          </span>
                        </div>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          </AnimatePresence>
          
          <div className="text-center mt-8 text-sm text-slate-400">
            <p>Your responses help us understand your unique leadership style and business approach</p>
          </div>
        </div>
      </div>
    </div>
  );
}
