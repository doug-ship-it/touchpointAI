import React from 'react';
import SystemAudit from '../components/audit/SystemAudit';

export default function SystemAuditPage() {
  return <SystemAudit />;
}