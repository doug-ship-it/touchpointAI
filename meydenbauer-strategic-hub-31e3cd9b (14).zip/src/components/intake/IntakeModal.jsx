import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { InvokeLLM } from '@/api/integrations';
import { FormSubmission } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  X, 
  ArrowRight, 
  ArrowLeft,
  Phone,
  Target,
  Briefcase,
  Search,
  Settings,
  Mail,
  ExternalLink,
  Linkedin,
  Loader2,
  CheckCircle,
  Calendar
} from 'lucide-react';

const primaryOptions = [
  {
    id: 'executive_consultation',
    icon: Phone,
    title: 'Executive Consultation',
    subtitle: 'Schedule time with Doug directly',
    action: 'direct_calendly',
    estimatedValue: '$50K+'
  },
  {
    id: 'strategic_challenge',
    icon: Target,
    title: 'Strategic Challenge',
    subtitle: 'I have a specific business problem to solve',
    workflow: 'business_challenge_qualification',
    estimatedValue: '$75K-$200K'
  },
  {
    id: 'exec_opportunities',
    icon: Briefcase,
    title: 'Executive Opportunities',
    subtitle: 'Explore senior leadership roles',
    workflow: 'career_opportunity_qualification',
    estimatedValue: 'Placement fees'
  },
  {
    id: 'leadership_search',
    icon: Search,
    title: 'Leadership Search',
    subtitle: 'Find and recruit top-tier talent',
    workflow: 'executive_search_qualification',
    estimatedValue: '$100K-$200K'
  },
  {
    id: 'tech_assessment',
    icon: Settings,
    title: 'Technology Assessment',
    subtitle: 'Evaluate vendors, tech stack, or development needs',
    workflow: 'technical_assessment_qualification',
    estimatedValue: '$15K-$150K'
  },
  {
    id: 'intelligence_briefing',
    icon: Mail,
    title: 'Intelligence Briefing',
    subtitle: 'Access our network intelligence and market insights',
    workflow: 'intelligence_access_qualification',
    estimatedValue: 'Network access'
  }
];

export default function IntakeModal({ isOpen, onClose, initialData = {} }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [intakeData, setIntakeData] = useState({
    userId: '',
    timestamp: new Date().toISOString(),
    workflowType: '',
    primaryContact: {
      firstName: initialData.firstName || '',
      email: initialData.email || '',
      linkedin: initialData.linkedin || 'https://www.linkedin.com/in/',
    },
    companyIntelligence: {
      domain: '',
      companyName: '',
      industry: '',
      size: '',
      confidence: 'low'
    },
    workflowResponses: {},
    qualificationScore: 0,
    routingDecision: 'nurture_sequence',
    ...initialData
  });
  
  const [isAutoFilling, setIsAutoFilling] = useState(false);
  const [autoFillComplete, setAutoFillComplete] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCalendly, setShowCalendly] = useState(false);
  const navigate = useNavigate();

  // Email intelligence auto-fill
  const handleEmailAutoFill = useCallback(async (email) => {
    if (!email || !email.includes('@') || isAutoFilling || autoFillComplete) return;

    const domain = email.split('@')[1];
    const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com', 'protonmail.com'];
    
    if (personalDomains.includes(domain)) {
      setAutoFillComplete(true);
      return;
    }

    setIsAutoFilling(true);
    
    try {
      const companyData = await InvokeLLM({
        prompt: `Analyze the company with domain "${domain}" and provide: company name, industry, employee count estimate, business stage, and confidence level of the data.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            companyName: { type: "string" },
            industry: { type: "string" },
            employeeCount: { type: "number" },
            size: { type: "string" },
            businessStage: { type: "string" },
            confidence: { type: "string", enum: ["high", "medium", "low"] }
          }
        }
      });

      if (companyData && companyData.confidence !== 'low') {
        setIntakeData(prev => ({
          ...prev,
          companyIntelligence: {
            domain,
            companyName: companyData.companyName || '',
            industry: companyData.industry || '',
            size: companyData.size || '',
            confidence: companyData.confidence || 'medium'
          }
        }));
      }
      
      setAutoFillComplete(true);
    } catch (error) {
      console.error('Company analysis failed:', error);
      setAutoFillComplete(true);
    }
    
    setIsAutoFilling(false);
  }, [isAutoFilling, autoFillComplete]);

  useEffect(() => {
    if (intakeData.primaryContact.email && intakeData.primaryContact.email.includes('@')) {
      const handler = setTimeout(() => {
        handleEmailAutoFill(intakeData.primaryContact.email);
      }, 1000);
      return () => clearTimeout(handler);
    }
  }, [intakeData.primaryContact.email, handleEmailAutoFill]);

  // Progressive data saving
  useEffect(() => {
    if (currentStep > 0) {
      sessionStorage.setItem('intakeProgress', JSON.stringify(intakeData));
    }
  }, [intakeData, currentStep]);

  const handlePrimarySelection = (optionId) => {
    const selectedOption = primaryOptions.find(opt => opt.id === optionId);
    
    if (selectedOption.action === 'direct_calendly') {
      setIntakeData(prev => ({ ...prev, workflowType: optionId }));
      setShowCalendly(true);
      return;
    }

    setIntakeData(prev => ({ ...prev, workflowType: optionId }));
    setCurrentStep(1);
  };

  const calculateQualificationScore = (data) => {
    let score = 0;
    const { workflowType, workflowResponses, companyIntelligence } = data;

    const workflowScoring = {
      executive_consultation: 100,
      leadership_search: 85,
      tech_assessment: 75,
      strategic_challenge: 70,
      intelligence_briefing: 40,
      exec_opportunities: 30
    };

    score += workflowScoring[workflowType] || 0;

    // Add scoring modifiers based on responses
    if (workflowResponses.budget_range?.includes('$200K+') || 
        workflowResponses.compensation_range?.includes('$350K+')) {
      score += 15;
    }

    if (workflowResponses.timeline?.includes('critical') || 
        workflowResponses.urgency === 'high') {
      score += 10;
    }

    if (companyIntelligence?.confidence === 'high') score += 10;

    return Math.min(score, 100);
  };

  const determineRouting = (score, workflowType) => {
    if (workflowType === 'executive_consultation') return 'doug_direct';
    if (score >= 80) return 'doug_direct';
    if (score >= 60) return 'senior_team';
    return 'nurture_sequence';
  };

  const handleIntakeCompletion = async (finalData) => {
    setIsSubmitting(true);
    
    try {
      const qualificationScore = calculateQualificationScore(finalData);
      const routing = determineRouting(qualificationScore, finalData.workflowType);
      
      const completedIntake = {
        ...finalData,
        qualificationScore,
        routingDecision: routing,
        completedAt: new Date().toISOString()
      };

      // Save to database
      await FormSubmission.create({
        tracking_id: `II-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        form_type: 'IntelligentIntake',
        workflow_type: completedIntake.workflowType,
        qualification_score: qualificationScore,
        routing_decision: routing,
        intake_data: JSON.stringify(completedIntake),
        submission_date: new Date().toISOString()
      });

      // Route based on qualification
      if (routing === 'doug_direct' || completedIntake.workflowType === 'executive_consultation') {
        setShowCalendly(true);
      } else if (routing === 'senior_team') {
        navigate(createPageUrl('QuickValueDiscovery'));
        onClose();
      } else {
        navigate(createPageUrl('ResourceLibrary'));
        onClose();
      }
      
    } catch (error) {
      console.error('Intake submission failed:', error);
    }
    
    setIsSubmitting(false);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div 
          className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-teal-600 to-blue-600 text-white p-6 relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            
            <h2 className="text-2xl font-bold mb-2">
              {currentStep === 0 ? 'What Brings You Here?' : primaryOptions.find(opt => opt.id === intakeData.workflowType)?.title}
            </h2>
            <p className="text-white/90">
              {currentStep === 0 
                ? 'Select the option that best describes your current need' 
                : 'A few details to ensure we connect you with the right expertise'
              }
            </p>
            
            {currentStep > 0 && !showCalendly && (
              <div className="mt-4">
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div 
                    className="bg-white rounded-full h-2 transition-all duration-300"
                    style={{ width: `${(currentStep / 5) * 100}%` }}
                  />
                </div>
                <p className="text-sm text-white/80 mt-1">Step {currentStep} of 5</p>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-6 max-h-[70vh] overflow-y-auto">
            {showCalendly ? (
              <CalendlyStep 
                intakeData={intakeData}
                onComplete={handleIntakeCompletion}
              />
            ) : currentStep === 0 ? (
              <PrimarySelectionStep 
                options={primaryOptions}
                onSelect={handlePrimarySelection}
              />
            ) : (
              <WorkflowStep 
                step={currentStep}
                workflowType={intakeData.workflowType}
                data={intakeData}
                onNext={(stepData) => {
                  setIntakeData(prev => ({ ...prev, ...stepData }));
                  if (currentStep === 5) {
                    handleIntakeCompletion({ ...intakeData, ...stepData });
                  } else {
                    setCurrentStep(currentStep + 1);
                  }
                }}
                onBack={() => setCurrentStep(Math.max(0, currentStep - 1))}
                isAutoFilling={isAutoFilling}
                autoFillComplete={autoFillComplete}
                companyData={intakeData.companyIntelligence}
              />
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Primary selection step
const PrimarySelectionStep = ({ options, onSelect }) => (
  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
    {options.map((option) => (
      <motion.div
        key={option.id}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <Card 
          className="cursor-pointer transition-all duration-200 hover:shadow-lg border-2 hover:border-teal-300"
          onClick={() => onSelect(option.id)}
        >
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-blue-500 rounded-xl flex items-center justify-center mx-auto mb-4">
              <option.icon className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">{option.title}</h3>
            <p className="text-gray-600 text-sm mb-3">{option.subtitle}</p>
            <div className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
              {option.estimatedValue}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    ))}
  </div>
);

// Calendly integration step
const CalendlyStep = ({ intakeData, onComplete }) => {
  useEffect(() => {
    // Initialize Calendly widget
    if (window.Calendly) {
      window.Calendly.initInlineWidget({
        url: 'https://calendly.com/dougsandstedt',
        parentElement: document.getElementById('calendly-container'),
        prefill: {
          name: intakeData.primaryContact.firstName,
          email: intakeData.primaryContact.email,
          customAnswers: {
            a1: intakeData.companyIntelligence?.companyName || '',
            a2: intakeData.workflowType,
            a3: JSON.stringify(intakeData.workflowResponses)
          }
        }
      });

      const handleScheduled = (e) => {
        if (e.data.event === 'calendly.event_scheduled') {
          onComplete({
            ...intakeData,
            scheduledMeeting: e.data.payload
          });
        }
      };

      window.addEventListener('message', handleScheduled);
      return () => window.removeEventListener('message', handleScheduled);
    }
  }, [intakeData, onComplete]);

  return (
    <div>
      <div className="text-center mb-6">
        <Calendar className="w-16 h-16 text-teal-600 mx-auto mb-4" />
        <h3 className="text-xl font-bold mb-2">Schedule Your Executive Consultation</h3>
        <p className="text-gray-600">Select a time that works best for your schedule</p>
      </div>
      <div id="calendly-container" style={{ minWidth: '320px', height: '630px' }} />
    </div>
  );
};

// Generic workflow step component
const WorkflowStep = ({ step, workflowType, data, onNext, onBack, isAutoFilling, autoFillComplete, companyData }) => {
  const [stepData, setStepData] = useState({});
  const [errors, setErrors] = useState({});

  const handleSubmit = () => {
    // Basic validation
    if (step === 1 && (!data.primaryContact.firstName || !data.primaryContact.email)) {
      setErrors({ contact: 'Please provide your contact information' });
      return;
    }

    onNext(stepData);
  };

  if (step === 1) {
    return (
      <ContactInformationStep
        data={data}
        onUpdate={setStepData}
        onNext={handleSubmit}
        onBack={onBack}
        isAutoFilling={isAutoFilling}
        autoFillComplete={autoFillComplete}
        companyData={companyData}
        errors={errors}
      />
    );
  }

  // Dynamic workflow steps based on type
  return (
    <GenericWorkflowStep
      step={step}
      workflowType={workflowType}
      data={data}
      onUpdate={setStepData}
      onNext={handleSubmit}
      onBack={onBack}
    />
  );
};

// Contact information step
const ContactInformationStep = ({ data, onUpdate, onNext, onBack, isAutoFilling, autoFillComplete, companyData, errors }) => {
  const [formData, setFormData] = useState({
    primaryContact: data.primaryContact
  });

  const handleInputChange = (field, value) => {
    const updated = {
      ...formData,
      primaryContact: {
        ...formData.primaryContact,
        [field]: value
      }
    };
    setFormData(updated);
    onUpdate(updated);
  };

  return (
    <div className="space-y-6">
      {isAutoFilling && (
        <Alert>
          <Loader2 className="h-4 w-4 animate-spin" />
          <AlertDescription>🤖 Analyzing your company profile...</AlertDescription>
        </Alert>
      )}

      {autoFillComplete && companyData?.companyName && (
        <Alert>
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription>
            ✨ Found {companyData.companyName} - {companyData.industry}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="firstName">First Name *</Label>
          <Input
            id="firstName"
            value={formData.primaryContact.firstName}
            onChange={(e) => handleInputChange('firstName', e.target.value)}
            className={errors.contact ? 'border-red-500' : ''}
          />
        </div>
        <div>
          <Label htmlFor="email">Business Email *</Label>
          <Input
            id="email"
            type="email"
            value={formData.primaryContact.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            className={errors.contact ? 'border-red-500' : ''}
          />
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-2">
          <Label htmlFor="linkedin">LinkedIn Profile (Optional)</Label>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-sm text-teal-600 hover:text-teal-700"
          >
            <Linkedin className="w-4 h-4" />
            Open LinkedIn
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        <Input
          id="linkedin"
          value={formData.primaryContact.linkedin}
          onChange={(e) => handleInputChange('linkedin', e.target.value)}
        />
      </div>

      {errors.contact && (
        <Alert variant="destructive">
          <AlertDescription>{errors.contact}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button onClick={onNext} className="bg-teal-600 hover:bg-teal-700">
          Continue
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

// Generic workflow step for different pathways
const GenericWorkflowStep = ({ step, workflowType, data, onUpdate, onNext, onBack }) => {
  // This would contain the specific workflow logic for each type
  // For now, simplified version
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-bold mb-2">Step {step}</h3>
        <p className="text-gray-600">Additional qualification questions for {workflowType}</p>
      </div>
      
      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button onClick={onNext} className="bg-teal-600 hover:bg-teal-700">
          {step === 5 ? 'Complete' : 'Continue'}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};