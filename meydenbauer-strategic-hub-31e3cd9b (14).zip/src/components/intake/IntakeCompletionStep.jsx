
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  CheckCircle, 
  BookOpen, 
  Users, 
  Target, 
  ArrowRight, 
  Sparkles,
  Trophy,
  Zap
} from "lucide-react";
import MeydenbauerLogo from "@/components/ui/MeydenbauerLogo"; // Added import

export default function IntakeCompletionStep({ formData, onContinue }) {
  const nextSteps = [
    {
      title: "Personalized Resource Library",
      description: "Access curated resources tailored to your industry and challenges",
      icon: BookOpen,
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Network Intelligence",
      description: "Discover valuable connections and potential partnerships",
      icon: Users,
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "Strategic Recommendations",
      description: "Get AI-powered insights based on your specific objectives",
      icon: Target,
      color: "from-emerald-500 to-teal-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-teal-50/30 to-blue-50/30 flex items-center justify-center px-6">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-teal-600 to-blue-600 rounded-full mb-6 shadow-lg">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-teal-200 mb-6">
            <Trophy className="w-4 h-4 text-teal-600" />
            <span className="text-sm font-medium text-teal-700" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              Assessment Complete
            </span>
          </div>
          
          {/* Modified section to include MeydenbauerLogo */}
          <div className="flex items-center justify-center gap-4 mb-4">
            <MeydenbauerLogo className="w-12 h-12" />
            <h1 className="text-3xl md:text-5xl font-bold text-gray-900 leading-tight" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              Welcome to Your Strategic Hub,
            </h1>
          </div>
          <span className="bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent text-3xl md:text-5xl font-bold">
            {formData.company_name}
          </span>
          
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mt-4" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            Your profile is now complete! We've analyzed your industry, challenges, and objectives to create 
            a personalized experience designed to accelerate your strategic transformation.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-3 gap-6 mb-12"
        >
          {nextSteps.map((step, index) => (
            <Card key={step.title} className="bg-white/90 backdrop-blur-sm border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${step.color} rounded-xl mb-4 shadow-md`}>
                  <step.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                  {step.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border border-gray-200 shadow-xl mb-8"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Zap className="w-6 h-6 text-teal-600" />
            <h3 className="text-2xl font-bold text-gray-900" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              Your Journey Begins Now
            </h3>
          </div>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            Based on your {formData.industry_segment?.replace('_', ' ')} focus and strategic objectives, 
            we've curated a collection of resources, tools, and insights to help you achieve your goals faster.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onContinue}
              size="lg"
              className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              style={{fontFamily: 'Inter, system-ui, sans-serif'}}
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Explore Personalized Resources
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-sm text-gray-500"
          style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}
        >
          Your data is secure and will only be used to provide you with relevant strategic insights and resources.
        </motion.div>
      </div>
    </div>
  );
}
