import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, TrendingUp, Clock, DollarSign, Calendar } from 'lucide-react';

const goalCategories = [
  { id: 'efficiency', name: 'Operational Efficiency', description: 'Streamline processes and reduce manual work' },
  { id: 'cost', name: 'Cost Reduction', description: 'Lower operational expenses and improve ROI' },
  { id: 'scale', name: 'Scalability', description: 'Prepare for growth and increased capacity' },
  { id: 'quality', name: 'Quality Improvement', description: 'Enhance accuracy and consistency' },
  { id: 'compliance', name: 'Compliance & Risk', description: 'Meet regulatory requirements and reduce risk' },
  { id: 'experience', name: 'User Experience', description: 'Improve internal and external customer experience' }
];

const successMetrics = [
  'Time saved per week (hours)',
  'Cost reduction percentage',
  'Process completion time reduction',
  'Error rate reduction',
  'Employee satisfaction increase',
  'Customer satisfaction improvement',
  'Revenue per employee increase',
  'Task automation percentage'
];

export default function SuccessMetrics({ formData, updateFormData }) {
  const handleGoalToggle = (goalId) => {
    const currentGoals = formData.goals.categories || [];
    const newGoals = currentGoals.includes(goalId)
      ? currentGoals.filter(g => g !== goalId)
      : [...currentGoals, goalId];
    updateFormData('goals', { categories: newGoals });
  };

  const handleMetricToggle = (metric) => {
    const currentMetrics = formData.goals.metrics || [];
    const newMetrics = currentMetrics.includes(metric)
      ? currentMetrics.filter(m => m !== metric)
      : [...currentMetrics, metric];
    updateFormData('goals', { metrics: newMetrics });
  };

  const handleTimelineGoalChange = (period, value) => {
    const currentTimeline = formData.goals.timeline || {};
    updateFormData('goals', { timeline: { ...currentTimeline, [period]: value } });
  };

  return (
    <div className="space-y-8">
      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Target className="w-5 h-5 text-blue-600" />
          Primary Success Categories
        </Label>
        <p className="text-sm text-slate-500 mb-4">Select the areas where you want to see the most improvement.</p>
        
        <div className="grid md:grid-cols-2 gap-4">
          {goalCategories.map(goal => (
            <Card key={goal.id} className={`cursor-pointer transition-all border-2 ${
              (formData.goals.categories || []).includes(goal.id) 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}>
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    checked={(formData.goals.categories || []).includes(goal.id)}
                    onCheckedChange={() => handleGoalToggle(goal.id)}
                    className="mt-1"
                  />
                  <div>
                    <h4 className="font-semibold text-slate-800">{goal.name}</h4>
                    <p className="text-sm text-slate-600 mt-1">{goal.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-green-600" />
          Timeline-Based Goals
        </Label>
        <p className="text-sm text-slate-500 mb-6">What specific outcomes do you want to achieve in each timeframe?</p>
        
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4 text-green-600" />
                30-Day Goals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="e.g., Establish communication protocols, complete system setup, reduce email processing time by 50%..."
                value={formData.goals.timeline?.['30day'] || ''}
                onChange={(e) => handleTimelineGoalChange('30day', e.target.value)}
                className="min-h-[80px]"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                60-Day Goals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="e.g., Implement automation workflows, achieve 10 hours/week time savings, optimize reporting processes..."
                value={formData.goals.timeline?.['60day'] || ''}
                onChange={(e) => handleTimelineGoalChange('60day', e.target.value)}
                className="min-h-[80px]"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-600" />
                90-Day Goals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="e.g., Achieve full operational efficiency, reduce admin overhead by 30%, prepare for scale..."
                value={formData.goals.timeline?.['90day'] || ''}
                onChange={(e) => handleTimelineGoalChange('90day', e.target.value)}
                className="min-h-[80px]"
              />
            </CardContent>
          </Card>
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-orange-600" />
          Key Performance Indicators
        </Label>
        <p className="text-sm text-slate-500 mb-4">Which metrics will you use to measure success?</p>
        
        <div className="grid md:grid-cols-2 gap-3">
          {successMetrics.map(metric => (
            <div key={metric} className="flex items-center space-x-2">
              <Checkbox
                checked={(formData.goals.metrics || []).includes(metric)}
                onCheckedChange={() => handleMetricToggle(metric)}
              />
              <Label className="font-normal text-slate-700">{metric}</Label>
            </div>
          ))}
        </div>
        
        <div className="mt-4">
          <Label htmlFor="customMetrics">Additional custom metrics:</Label>
          <Textarea
            id="customMetrics"
            placeholder="Describe any other specific KPIs or success measurements important to your organization..."
            value={formData.goals.customMetrics || ''}
            onChange={(e) => updateFormData('goals', { customMetrics: e.target.value })}
            className="mt-2 min-h-[80px]"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              Investment Range
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-sm text-slate-600 mb-2">
                Monthly budget: ${(formData.goals.budget || 5000).toLocaleString()}
              </div>
              <Slider
                value={[formData.goals.budget || 5000]}
                onValueChange={([value]) => updateFormData('goals', { budget: value })}
                max={20000}
                min={1000}
                step={500}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-slate-500">
                <span>$1,000</span>
                <span>$20,000+</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">ROI Expectations</CardTitle>
          </CardHeader>
          <CardContent>
            <Select 
              value={formData.goals.roiExpectation} 
              onValueChange={(value) => updateFormData('goals', { roiExpectation: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Expected return timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Immediate (within 30 days)</SelectItem>
                <SelectItem value="short">Short-term (2-3 months)</SelectItem>
                <SelectItem value="medium">Medium-term (3-6 months)</SelectItem>
                <SelectItem value="long">Long-term (6+ months)</SelectItem>
                <SelectItem value="strategic">Strategic investment</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      <div>
        <Label htmlFor="successDefinition" className="text-lg font-semibold text-slate-800">Success Definition</Label>
        <p className="text-sm text-slate-500 mb-3">In your own words, what would make this engagement a complete success?</p>
        <Textarea
          id="successDefinition"
          placeholder="Describe what success looks like for your organization, including both quantitative and qualitative measures..."
          value={formData.goals.successDefinition || ''}
          onChange={(e) => updateFormData('goals', { successDefinition: e.target.value })}
          className="min-h-[120px]"
        />
      </div>
    </div>
  );
}