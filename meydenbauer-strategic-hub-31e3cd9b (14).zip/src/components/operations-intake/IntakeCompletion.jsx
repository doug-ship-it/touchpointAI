
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Network, Calendar, Mail } from 'lucide-react'; // Added Calendar and Mail
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function IntakeCompletion() {
  const navigate = useNavigate();

  useEffect(() => {
    // Auto-redirect to NetworkAI Portal after 3 seconds
    const timer = setTimeout(() => {
      navigate(createPageUrl('NetworkAIPortal'));
    }, 3000);

    return () => clearTimeout(timer);
  }, [navigate]);

  const handleContinue = () => {
    navigate(createPageUrl('NetworkAIPortal'));
  };

  return (
    <motion.div 
      className="text-center"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
    >
      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold mb-2">Assessment Complete!</h2>
      <p className="text-slate-600 mb-6 max-w-md mx-auto">
        Thank you for completing your operations assessment. Our team will review your requirements and get back to you shortly. 
      </p>
      <p className="text-slate-600 mb-8 max-w-md mx-auto">
        You're being redirected to our NetworkAI Portal where you can explore our professional network and find strategic connections.
      </p>
      
      {/* New section for scheduling a meeting and contact */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
        <Button asChild size="lg">
          <a href="https://calendly.com/dougsandstedt/30min" target="_blank" rel="noopener noreferrer">
            <Calendar className="w-4 h-4 mr-2" />
            Schedule a Meeting
          </a>
        </Button>
        <Button variant="outline" asChild size="lg">
          <a href="mailto:admin@mbcpartners.co"> {/* Updated email address */}
            <Mail className="w-4 h-4 mr-2" />
            Contact Us
          </a>
        </Button>
      </div>

      {/* Existing buttons for navigation */}
      <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center"> {/* Adjusted margin-top to separate from new buttons */}
        <Button onClick={handleContinue} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
          <Network className="w-4 h-4 mr-2" />
          Access NetworkAI Portal
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
        <Button variant="outline" onClick={() => navigate(createPageUrl('Home'))}>
          Return to Homepage
        </Button>
      </div>
      
      <div className="mt-6 text-sm text-slate-500">
        Redirecting automatically in 3 seconds...
      </div>
    </motion.div>
  );
}
