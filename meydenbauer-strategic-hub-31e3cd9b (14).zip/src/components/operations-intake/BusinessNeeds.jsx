import React from 'react';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';

const challengeOptions = [
  "Administrative overload",
  "Executive time constraints",
  "Operational inefficiencies",
  "Marketing & content gaps",
  "Customer experience issues",
  "Data & reporting limitations",
  "Calendar & scheduling challenges",
  "Travel & logistics coordination",
];

export default function BusinessNeeds({ formData, updateFormData }) {
  const handleChallengeChange = (challenge) => {
    const currentChallenges = formData.needs.challenges || [];
    const newChallenges = currentChallenges.includes(challenge)
      ? currentChallenges.filter((c) => c !== challenge)
      : [...currentChallenges, challenge];
    updateFormData('needs', { challenges: newChallenges });
  };

  const handleImpactChange = (field, value) => {
    updateFormData('needs', { impact: { ...formData.needs.impact, [field]: value } });
  };
  
  const otherChallengeSelected = formData.needs.challenges?.includes("Other");

  return (
    <div className="space-y-8">
      <div>
        <Label className="text-lg font-semibold text-slate-800">Business Challenges</Label>
        <p className="text-sm text-slate-500 mb-4">Select all current challenges your team is facing.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {challengeOptions.map((challenge) => (
            <div key={challenge} className="flex items-center space-x-2">
              <Checkbox
                id={challenge}
                checked={formData.needs.challenges?.includes(challenge)}
                onCheckedChange={() => handleChallengeChange(challenge)}
              />
              <Label htmlFor={challenge} className="font-normal text-slate-700">{challenge}</Label>
            </div>
          ))}
          <div className="flex items-center space-x-2">
              <Checkbox
                id="Other"
                checked={otherChallengeSelected}
                onCheckedChange={() => handleChallengeChange("Other")}
              />
              <Label htmlFor="Other" className="font-normal text-slate-700">Other</Label>
            </div>
        </div>
        {otherChallengeSelected && (
            <Textarea
                placeholder="Please specify other challenges..."
                value={formData.needs.impact?.other_challenges || ''}
                onChange={(e) => handleImpactChange('other_challenges', e.target.value)}
                className="mt-4"
            />
        )}
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800">Impact Assessment</Label>
        <p className="text-sm text-slate-500 mb-4">Help us quantify the impact of these challenges.</p>
        <div className="space-y-6">
          <div>
            <Label htmlFor="adminHours" className="font-medium text-slate-700">Hours per week spent on administrative tasks</Label>
            <div className="flex items-center gap-4 mt-2">
              <Slider
                id="adminHours"
                min={0}
                max={40}
                step={1}
                value={[formData.needs.impact?.admin_hours || 10]}
                onValueChange={([value]) => handleImpactChange('admin_hours', value)}
                className="flex-1"
              />
              <span className="font-semibold text-slate-800 w-12 text-center">{formData.needs.impact?.admin_hours || 10} hrs</span>
            </div>
          </div>
          <div>
             <Label htmlFor="keyPositions" className="font-medium text-slate-700">Key leadership positions needing support (comma-separated)</Label>
             <Input
                id="keyPositions"
                placeholder="e.g., CEO, CTO, Head of Sales"
                value={formData.needs.impact?.key_positions || ''}
                onChange={(e) => handleImpactChange('key_positions', e.target.value)}
                className="mt-2"
             />
          </div>
        </div>
      </div>
    </div>
  );
}