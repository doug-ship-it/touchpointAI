import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Globe, 
  Zap, 
  TrendingUp, 
  BarChart3, 
  Trophy, 
  Rocket, 
  ExternalLink,
  ArrowRight,
  Flame,
  Star,
  Target,
  Briefcase
} from "lucide-react";

const trendingResources = [
  {
    id: "network_platform",
    icon: Globe,
    title: "Network Intelligence Platform",
    metric: { icon: Flame, text: "247 active users" },
    description: "Unlock hidden connections and identify warm introductions through AI-powered relationship mapping and LinkedIn automation for accelerated B2B growth.",
    link: "/network-intelligence", // Internal link
    isExternal: false,
    trackingCode: "trending_network_platform"
  },
  {
    id: "rfi_case_study",
    icon: Zap,
    title: "How Our 8-Day RFI Process Saved a Seed-Stage Startup's Launch, Cut Costs 18%, and Boosted Development Speed 40%+",
    metric: { icon: TrendingUp, text: "192 downloads" },
    description: "See how we helped a VC-backed HealthTech client turn around an underperforming software development engagement through strategic RFI management, resulting in a long-term Eastern European partnership with specialized EHR and HCLS security expertise.",
    link: "https://mdbrp.com/vendor-rfi",
    isExternal: true,
    trackingCode: "trending_rfi_case_study",
    featured: true
  },
  {
    id: "tech_library",
    icon: Zap,
    title: "Tech Resource Library",
    metric: { icon: TrendingUp, text: "189 downloads" },
    description: "Curated collection of implementation guides, vendor comparisons, and technology roadmaps for scaling companies and PE portfolio optimization.",
    link: "https://mdbrp.com/tech-notion-library",
    isExternal: true,
    trackingCode: "trending_tech_library"
  },
  {
    id: "case_studies",
    icon: BarChart3,
    title: "Success Stories & Case Studies",
    metric: { icon: Star, text: "Most shared resource" },
    description: "Real transformation stories from PE-backed companies and high-growth firms achieving 25-40% operational efficiency gains through strategic implementations.",
    link: "/case-studies", // Internal link
    isExternal: false,
    trackingCode: "trending_case_studies"
  },
  {
    id: "vendor_directory",
    icon: Trophy,
    title: "Top Software Development, Cloud & AI Vendors",
    metric: { icon: Target, text: "Featured this quarter" },
    description: "Vetted marketplace of premier technology partners with performance metrics, client reviews, and direct connect capabilities for faster procurement decisions.",
    link: "/vendors", // Internal link
    isExternal: false,
    trackingCode: "trending_vendor_directory"
  },
  {
    id: "digital_ops",
    icon: Rocket,
    title: "Digital Operations & Executive Assistance",
    metric: { icon: Briefcase, text: "Executive favorite" },
    description: "Transform back-office operations with AI-powered virtual assistants and process automation for commercial real estate and professional services.",
    link: "https://mdbrp.com/va",
    isExternal: true,
    trackingCode: "trending_digital_ops"
  }
];

export default function TrendingResourcesSection() {
  const handleResourceClick = (resource) => {
    // Track the click for analytics
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'resource_click', {
        'custom_parameter': resource.trackingCode
      });
    }
    
    if (resource.isExternal) {
      window.open(resource.link, '_blank', 'noopener,noreferrer');
    } else {
      // Handle internal navigation if needed
      window.location.href = resource.link;
    }
  };

  return (
    <div className="px-6 pb-16">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
            Most Accessed Resources This Month
          </h2>
          <p className="text-gray-600 italic" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            See what industry leaders are using to accelerate growth
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingResources.map((resource, index) => {
            const IconComponent = resource.icon;
            const MetricIcon = resource.metric.icon;
            
            return (
              <motion.div
                key={resource.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.9 + index * 0.1 }}
              >
                <Card 
                  className={`h-full cursor-pointer border-2 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-white/90 backdrop-blur-sm border-gray-200 hover:border-teal-300 group ${
                    resource.featured ? 'ring-2 ring-yellow-200 bg-gradient-to-br from-white to-yellow-50/30' : ''
                  }`}
                  onClick={() => handleResourceClick(resource)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="p-3 rounded-xl bg-gradient-to-r from-teal-500 to-blue-500 shadow-md">
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex items-center gap-2">
                        {resource.featured && (
                          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 text-xs">
                            Featured
                          </Badge>
                        )}
                        {resource.isExternal ? (
                          <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-teal-600 transition-colors" />
                        ) : (
                          <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-teal-600 transition-colors transform group-hover:translate-x-1 duration-200" />
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-lg font-bold text-gray-900 leading-tight group-hover:text-teal-700 transition-colors flex-1" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                        {resource.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      <MetricIcon className="w-4 h-4 text-teal-600" />
                      <span className="text-sm font-medium text-teal-700" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                        {resource.metric.text}
                      </span>
                    </div>
                    
                    <p className="text-gray-600 text-sm leading-relaxed mb-6" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                      {resource.description}
                    </p>
                    
                    <div className="flex justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-teal-600 hover:text-teal-700 hover:bg-teal-50 font-medium p-0"
                        style={{fontFamily: 'Inter, system-ui, sans-serif'}}
                      >
                        {resource.isExternal ? 'Access Resource' : 'Access Platform'}
                        {resource.isExternal ? (
                          <ExternalLink className="w-4 h-4 ml-1" />
                        ) : (
                          <ArrowRight className="w-4 h-4 ml-1" />
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}