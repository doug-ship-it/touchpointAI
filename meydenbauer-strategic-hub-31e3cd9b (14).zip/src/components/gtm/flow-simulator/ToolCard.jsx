import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Circle } from 'lucide-react';

export default function ToolCard({ tool, isSelected, onToggle }) {
  const handleClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onToggle(tool.id);
  };

  const handleLogoClick = (e) => {
    e.stopPropagation();
    if (tool.url) {
      window.open(tool.url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      className={`relative bg-white rounded-xl border-2 transition-all duration-300 cursor-pointer group ${
        isSelected 
          ? 'border-blue-500 shadow-lg shadow-blue-100' 
          : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
      }`}
      onClick={handleClick}
    >
      {/* Selection indicator */}
      <div className="absolute top-3 right-3 z-10">
        {isSelected ? (
          <CheckCircle className="w-5 h-5 text-blue-500" />
        ) : (
          <Circle className="w-5 h-5 text-gray-300 group-hover:text-gray-400" />
        )}
      </div>

      <div className="p-4">
        {/* Logo and basic info */}
        <div className="flex items-start gap-3 mb-3">
          <div 
            className="flex-shrink-0 cursor-pointer hover:scale-110 transition-transform"
            onClick={handleLogoClick}
          >
            {tool.logo ? (
              <img 
                src={tool.logo} 
                alt={`${tool.name} logo`}
                className="w-10 h-10 object-contain"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextElementSibling.style.display = 'flex';
                }}
              />
            ) : null}
            <div 
              className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center"
              style={{ display: tool.logo ? 'none' : 'flex' }}
            >
              <span className="text-white font-bold text-sm">
                {tool.name?.charAt(0) || 'T'}
              </span>
            </div>
          </div>
          
          <div className="flex-grow min-w-0">
            <h4 className="font-semibold text-gray-900 text-sm leading-tight mb-1">
              {tool.name}
            </h4>
            <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
              {tool.description}
            </p>
          </div>
        </div>

        {/* Category indicator */}
        <div className="flex items-center justify-between">
          <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium capitalize ${
            tool.category === 'crm' ? 'bg-blue-100 text-blue-700' :
            tool.category === 'workflow' ? 'bg-orange-100 text-orange-700' :
            tool.category === 'data' ? 'bg-green-100 text-green-700' :
            tool.category === 'copywriting' ? 'bg-purple-100 text-purple-700' :
            tool.category === 'scheduling' ? 'bg-blue-100 text-blue-700' :
            tool.category === 'meeting' ? 'bg-orange-100 text-orange-700' :
            tool.category === 'social' ? 'bg-green-100 text-green-700' :
            tool.category === 'engagement' ? 'bg-purple-100 text-purple-700' :
            'bg-gray-100 text-gray-700'
          }`}>
            {tool.category}
          </span>
          
          {tool.url && (
            <button
              onClick={handleLogoClick}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium opacity-0 group-hover:opacity-100 transition-opacity"
            >
              Visit →
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}