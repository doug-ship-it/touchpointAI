import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Zap, ArrowRight, CheckCircle, RefreshCw, Loader2, ChevronRight, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toolCategories, toolDatabase } from './toolData';
import ToolCard from './ToolCard';
import { GTMAnalysisEngine } from './AnalysisEngine';
import ComprehensiveAnalysisDisplay from './ComprehensiveAnalysisDisplay';

export default function GTMFlowSimulator({ onClose }) {
  const [step, setStep] = useState('intro'); // intro, selection, analysis, results
  const [currentCategoryIndex, setCurrentCategoryIndex] = useState(0);
  const [selectedTools, setSelectedTools] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analysisEngine = useMemo(() => new GTMAnalysisEngine(), []);

  const handleToolToggle = (toolId) => {
    setSelectedTools(prev => {
      const newSet = new Set(prev);
      if (newSet.has(toolId)) {
        newSet.delete(toolId);
      } else {
        newSet.add(toolId);
      }
      return newSet;
    });
  };

  const handleNextCategory = () => {
    if (currentCategoryIndex < toolCategories.length - 1) {
      setCurrentCategoryIndex(prev => prev + 1);
      setSearchTerm(''); // Clear search when moving to next category
    } else {
      // All categories completed, start analysis
      handleAnalyzeStack();
    }
  };

  const handlePrevCategory = () => {
    if (currentCategoryIndex > 0) {
      setCurrentCategoryIndex(prev => prev - 1);
      setSearchTerm(''); // Clear search when moving to previous category
    }
  };

  const handleSkipCategory = () => {
    handleNextCategory(); // Same as next, but semantically different
  };

  const handleAnalyzeStack = async () => {
    if (selectedTools.size === 0) return;
    
    setIsAnalyzing(true);
    setStep('analysis');
    
    // Simulate processing time for better UX
    setTimeout(() => {
      const analysisResult = analysisEngine.analyzeStack(selectedTools);
      setAnalysis(analysisResult);
      setStep('results');
      setIsAnalyzing(false);
    }, 2000);
  };
  
  const filteredTools = useMemo(() => {
    if (!searchTerm) return toolDatabase;
    const lowercasedFilter = searchTerm.toLowerCase();
    return Object.fromEntries(
      Object.entries(toolDatabase).filter(([key, tool]) =>
        tool.name.toLowerCase().includes(lowercasedFilter) ||
        tool.description.toLowerCase().includes(lowercasedFilter)
      )
    );
  }, [searchTerm]);

  const currentCategory = toolCategories[currentCategoryIndex];
  const currentCategoryTools = Object.values(filteredTools).filter(tool => 
    tool.category === currentCategory.id
  );
  const selectedInCurrentCategory = currentCategoryTools.filter(tool => 
    selectedTools.has(tool.id)
  ).length;

  const IntroScreen = () => (
    <motion.div
      key="intro"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="text-center p-8 flex flex-col items-center justify-center h-full"
    >
      <Zap className="w-20 h-20 text-yellow-400 mb-6" />
      <h2 className="text-4xl font-bold text-white mb-4">Discover Your Optimal Tech Stack</h2>
      <p className="text-xl text-slate-300 max-w-2xl mb-8">
        We'll guide you through 9 tool categories to build a complete picture of your current tech stack, then provide intelligent recommendations.
      </p>
      <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 mb-8">
        <p className="text-slate-200 text-sm">
          ✨ AI-powered analysis • 💰 Cost optimization • 🚀 ROI projections • ⚡ Integration strategies
        </p>
      </div>
      <Button onClick={() => setStep('selection')} size="lg" className="bg-white text-slate-900 hover:bg-slate-200 h-14 px-8 text-lg font-semibold">
        Start Stack Analysis (2 min)
        <ArrowRight className="w-5 h-5 ml-2" />
      </Button>
    </motion.div>
  );

  const SelectionScreen = () => (
    <motion.div
      key="selection"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col h-full bg-slate-100 rounded-2xl overflow-hidden"
    >
      {/* Compact Header with Progress */}
      <div className="p-4 border-b border-slate-200 bg-white">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-xl font-bold text-slate-800">
              {currentCategory.name}
            </h2>
            <p className="text-sm text-slate-500">
              Step {currentCategoryIndex + 1} of {toolCategories.length} • Select tools you currently use
            </p>
          </div>
          <Badge variant="outline" className="px-2 py-1 text-xs">
            {selectedTools.size} selected
          </Badge>
        </div>
        
        {/* Compact Progress Bar */}
        <div className="mb-3">
          <Progress 
            value={((currentCategoryIndex + 1) / toolCategories.length) * 100} 
            className="h-1.5"
          />
        </div>

        {/* Compact Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder={`Search ${currentCategory.name.toLowerCase()}...`}
            className="pl-9 h-10 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Compact Category Info */}
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
        <div className="flex items-center gap-2 mb-2">
          <div className={`w-3 h-3 rounded-full ${
            currentCategory.color === 'blue' ? 'bg-blue-500' :
            currentCategory.color === 'orange' ? 'bg-orange-500' :
            currentCategory.color === 'green' ? 'bg-green-500' :
            'bg-purple-500'
          }`}></div>
          <h3 className="text-base font-semibold text-slate-800">
            {currentCategory.name}
          </h3>
          {selectedInCurrentCategory > 0 && (
            <Badge variant="secondary" className="text-xs">
              {selectedInCurrentCategory} selected
            </Badge>
          )}
        </div>
        <p className="text-xs text-slate-600">
          {currentCategory.id === 'crm' && "Customer Relationship Management platforms to organize and track your prospects and customers."}
          {currentCategory.id === 'workflow' && "Automation tools that connect your apps and streamline repetitive processes."}
          {currentCategory.id === 'data' && "Data enrichment and intelligence platforms to enhance your prospect information."}
          {currentCategory.id === 'copywriting' && "AI-powered tools for creating sales content, emails, and marketing copy."}
          {currentCategory.id === 'scheduling' && "Meeting scheduling and calendar management solutions."}
          {currentCategory.id === 'meeting' && "Tools for recording, transcribing, and analyzing sales conversations."}
          {currentCategory.id === 'social' && "Social media management and engagement platforms."}
          {currentCategory.id === 'engagement' && "Outreach and sales engagement platforms for systematic prospecting."}
          {currentCategory.id === 'intent' && "Buyer intent and customer intelligence platforms."}
        </p>
      </div>

      {/* Tools Grid - Optimized spacing */}
      <div className="flex-grow overflow-y-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {currentCategoryTools.map(tool => (
            <ToolCard 
              key={tool.id} 
              tool={tool}
              isSelected={selectedTools.has(tool.id)}
              onToggle={handleToolToggle}
            />
          ))}
        </div>

        {currentCategoryTools.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-500">No tools found matching your search.</p>
          </div>
        )}
      </div>

      {/* Prominent Navigation Footer */}
      <div className="p-4 border-t border-slate-200 bg-white">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            {currentCategoryIndex > 0 && (
              <Button 
                variant="outline" 
                onClick={handlePrevCategory}
                className="flex items-center gap-1 h-10 px-3"
                size="sm"
              >
                <ChevronLeft className="w-4 h-4" />
                Back
              </Button>
            )}
            <Button 
              variant="ghost" 
              onClick={handleSkipCategory}
              className="text-slate-600 h-10 px-3 text-sm"
              size="sm"
            >
              Skip
            </Button>
          </div>
          
          {/* Large Pulsing Next Button */}
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <Button 
              onClick={handleNextCategory}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 h-12 px-8 text-base font-semibold shadow-lg"
              size="lg"
            >
              {currentCategoryIndex === toolCategories.length - 1 ? (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Analyze My Stack
                </>
              ) : (
                <>
                  Next: {toolCategories[currentCategoryIndex + 1].name}
                  <ChevronRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </motion.div>
        </div>
        
        {/* Selection Summary */}
        <div className="text-center mt-2">
          <div className="text-xs text-slate-600">
            {selectedInCurrentCategory > 0 ? 
              `${selectedInCurrentCategory} ${currentCategory.name.toLowerCase()} tool${selectedInCurrentCategory === 1 ? '' : 's'} selected` :
              `No ${currentCategory.name.toLowerCase()} tools selected`
            }
          </div>
        </div>
      </div>
    </motion.div>
  );
  
  const AnalysisScreen = () => (
    <motion.div
      key="analysis"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col h-full bg-white rounded-2xl justify-center items-center p-8"
    >
      <Loader2 className="w-16 h-16 animate-spin text-blue-600 mb-6" />
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Analyzing Your Tech Stack</h2>
      <p className="text-gray-600 text-center max-w-md mb-8">
        Our AI engine is processing your {selectedTools.size} selected tools to identify optimization opportunities, cost efficiencies, and integration strategies.
      </p>
      <div className="space-y-3 text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-green-600" />
          Calculating current stack costs
        </div>
        <div className="flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-green-600" />
          Identifying capability gaps
        </div>
        <div className="flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          Generating intelligent recommendations
        </div>
      </div>
    </motion.div>
  );

  const ResultsScreen = () => (
    <motion.div
      key="results"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="h-full bg-white rounded-2xl overflow-hidden"
    >
      <ComprehensiveAnalysisDisplay 
        analysis={analysis} 
        onClose={onClose}
      />
    </motion.div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-slate-900/80 backdrop-blur-lg z-[100] flex items-center justify-center p-4"
    >
      <motion.div 
        className="relative w-full h-full max-w-[95vw] max-h-[95vh] bg-slate-800 rounded-2xl shadow-2xl overflow-hidden"
        layout
      >
        {step !== 'results' && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute top-4 right-4 z-10 text-white/70 hover:text-white hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </Button>
        )}
        
        <AnimatePresence mode="wait">
          {step === 'intro' && <IntroScreen />}
          {step === 'selection' && <SelectionScreen />}
          {step === 'analysis' && <AnalysisScreen />}
          {step === 'results' && <ResultsScreen />}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}