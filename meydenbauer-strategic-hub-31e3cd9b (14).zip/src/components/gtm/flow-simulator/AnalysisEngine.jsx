// Enhanced GTM Analysis Engine with comprehensive intelligence
export class GTMAnalysisEngine {
  constructor() {
    this.workflowStages = [
      {
        id: 'prospecting',
        name: 'Lead Generation & Prospecting',
        requiredCapabilities: ['data_enrichment', 'crm', 'social_engagement'],
        tools: {
          data_enrichment: ['apollo', 'clay', 'zoominfo', 'clearbit'],
          crm: ['hubspot', 'pipedrive', 'salesforce', 'attio'],
          social_engagement: ['taplio', 'hootsuite', 'buffer']
        }
      },
      {
        id: 'qualification',
        name: 'Lead Qualification & Scoring', 
        requiredCapabilities: ['meeting_intelligence', 'scheduling', 'intent_data'],
        tools: {
          meeting_intelligence: ['fireflies', 'gong', 'chorus', 'otter'],
          scheduling: ['calendly', 'chili', 'acuity'],
          intent_data: ['6sense', 'bombora', 'g2']
        }
      },
      {
        id: 'engagement',
        name: 'Multi-Channel Engagement',
        requiredCapabilities: ['email_automation', 'content_creation', 'workflow_automation'],
        tools: {
          email_automation: ['outreach', 'reply', 'smartlead', 'salesloft'],
          content_creation: ['jasper', 'copy', 'claude', 'chatgpt'],
          workflow_automation: ['zapier', 'make', 'n8n']
        }
      },
      {
        id: 'closing',
        name: 'Deal Management & Closing',
        requiredCapabilities: ['crm', 'meeting_intelligence', 'workflow_automation'],
        tools: {
          crm: ['hubspot', 'pipedrive', 'salesforce'],
          meeting_intelligence: ['gong', 'chorus', 'fireflies'],
          workflow_automation: ['zapier', 'make']
        }
      }
    ];

    // Enhanced tool database with pricing and detailed features
    this.toolPricing = {
      // CRM Systems
      hubspot: { monthly: 45, annual: 450, tier: 'Starter', seats: 2 },
      pipedrive: { monthly: 49, annual: 490, tier: 'Advanced', seats: 1 },
      salesforce: { monthly: 150, annual: 1500, tier: 'Professional', seats: 1 },
      attio: { monthly: 29, annual: 290, tier: 'Plus', seats: 1 },
      
      // Data & Enrichment
      apollo: { monthly: 79, annual: 790, tier: 'Professional', seats: 1 },
      clay: { monthly: 149, annual: 1490, tier: 'Pro', seats: 1 },
      zoominfo: { monthly: 200, annual: 2000, tier: 'Professional', seats: 1 },
      clearbit: { monthly: 99, annual: 990, tier: 'Growth', seats: 1 },
      
      // Engagement Platforms
      outreach: { monthly: 80, annual: 800, tier: 'Sales Edge', seats: 1 },
      reply: { monthly: 60, annual: 600, tier: 'Email Starter', seats: 1 },
      smartlead: { monthly: 39, annual: 390, tier: 'Pro', seats: 1 },
      salesloft: { monthly: 125, annual: 1250, tier: 'Sell', seats: 1 },
      
      // Meeting Intelligence
      gong: { monthly: 100, annual: 1000, tier: 'Connect', seats: 1 },
      fireflies: { monthly: 10, annual: 100, tier: 'Pro', seats: 1 },
      chorus: { monthly: 80, annual: 800, tier: 'Standard', seats: 1 },
      
      // Workflow Automation
      zapier: { monthly: 20, annual: 200, tier: 'Professional', seats: 1 },
      make: { monthly: 9, annual: 90, tier: 'Core', seats: 1 },
      n8n: { monthly: 20, annual: 200, tier: 'Pro', seats: 1 },
      
      // Scheduling
      calendly: { monthly: 10, annual: 100, tier: 'Professional', seats: 1 },
      chili: { monthly: 30, annual: 300, tier: 'Instant Booker', seats: 1 },
      
      // Content Creation
      jasper: { monthly: 39, annual: 390, tier: 'Creator', seats: 1 },
      claude: { monthly: 25, annual: 250, tier: 'Pro', seats: 1 },
      chatgpt: { monthly: 20, annual: 200, tier: 'Plus', seats: 1 },
      copy: { monthly: 36, annual: 360, tier: 'Pro', seats: 1 }
    };

    this.detailedFeatures = {
      hubspot: {
        core: ['Contact Management', 'Deal Pipeline', 'Email Tracking', 'Lead Scoring'],
        advanced: ['Marketing Automation', 'Custom Reporting', 'Workflow Builder', 'Sales Analytics'],
        integrations: ['Gmail', 'Outlook', 'Slack', 'Zoom', 'LinkedIn'],
        strengths: ['All-in-one platform', 'Free tier available', 'Extensive integrations'],
        limitations: ['Can be complex', 'Expensive at scale', 'Learning curve']
      },
      apollo: {
        core: ['Contact Database', 'Email Sequences', 'Phone Dialer', 'Email Finder'],
        advanced: ['Intent Data', 'Technographics', 'Account Intelligence', 'Sales Analytics'],
        integrations: ['Salesforce', 'HubSpot', 'Pipedrive', 'Slack'],
        strengths: ['Large database', 'Good deliverability', 'Built-in dialer'],
        limitations: ['Data accuracy varies', 'Limited customization', 'UI can be cluttered']
      },
      gong: {
        core: ['Call Recording', 'Conversation Analytics', 'Deal Intelligence', 'Coaching Insights'],
        advanced: ['Revenue Intelligence', 'Forecast Analysis', 'Competitor Mentions', 'Risk Alerts'],
        integrations: ['Salesforce', 'HubSpot', 'Outreach', 'SalesLoft'],
        strengths: ['Best-in-class AI', 'Deep insights', 'Proven ROI'],
        limitations: ['High cost', 'Complex setup', 'Requires buy-in']
      },
      outreach: {
        core: ['Email Sequences', 'Call Management', 'Task Automation', 'Template Library'],
        advanced: ['A/B Testing', 'Advanced Analytics', 'Territory Management', 'Conversation Intelligence'],
        integrations: ['Salesforce', 'HubSpot', 'LinkedIn', 'Zoom'],
        strengths: ['Powerful automation', 'Great analytics', 'Scalable'],
        limitations: ['Expensive', 'Complex setup', 'Requires training']
      }
    };

    this.integrationMatrix = {
      hubspot: ['zapier', 'make', 'apollo', 'clay', 'outreach', 'calendly', 'fireflies'],
      salesforce: ['outreach', 'salesloft', 'gong', 'chorus', 'zapier', 'apollo'],
      apollo: ['hubspot', 'pipedrive', 'clay', 'outreach', 'reply'],
      gong: ['salesforce', 'hubspot', 'outreach', 'salesloft'],
      outreach: ['salesforce', 'hubspot', 'apollo', 'gong'],
      zapier: ['hubspot', 'pipedrive', 'apollo', 'calendly', 'fireflies'],
      make: ['hubspot', 'clay', 'apollo', 'fireflies']
    };

    this.gapAnalysis = {
      prospecting: {
        'no_crm': {
          impact: 95,
          description: 'Missing centralized customer data management',
          recommendations: ['hubspot', 'pipedrive', 'attio'],
          roi_impact: '25-40% increase in lead conversion'
        },
        'no_data_enrichment': {
          impact: 85,
          description: 'Manual research reduces prospecting efficiency',
          recommendations: ['apollo', 'clay', 'zoominfo'],
          roi_impact: '50-70% reduction in research time'
        }
      },
      engagement: {
        'no_email_automation': {
          impact: 90,
          description: 'Manual outreach limits scale and consistency',
          recommendations: ['outreach', 'reply', 'smartlead'],
          roi_impact: '300% increase in outreach volume'
        },
        'no_meeting_intelligence': {
          impact: 80,
          description: 'Missing insights from prospect conversations',
          recommendations: ['gong', 'fireflies', 'chorus'],
          roi_impact: '15-25% improvement in close rates'
        }
      }
    };

    this.workflowOptimizations = {
      'crm_enrichment_integration': {
        tools: ['hubspot', 'apollo'],
        description: 'Auto-enrich new leads in CRM with contact and company data',
        time_saved: '2-3 hours per day',
        cost_benefit: '$2,400/month in productivity gains',
        setup_complexity: 'Easy'
      },
      'meeting_to_crm_sync': {
        tools: ['fireflies', 'hubspot'],
        description: 'Automatically sync meeting notes and action items to CRM',
        time_saved: '1-2 hours per day',
        cost_benefit: '$1,600/month in productivity gains',
        setup_complexity: 'Moderate'
      },
      'sequence_trigger_automation': {
        tools: ['outreach', 'zapier', 'hubspot'],
        description: 'Trigger personalized sequences based on prospect behavior',
        time_saved: '3-4 hours per day',
        cost_benefit: '$3,200/month in productivity gains',
        setup_complexity: 'Complex'
      }
    };
  }

  analyzeStack(selectedToolIds) {
    const selectedTools = Array.from(selectedToolIds);
    const analysis = {
      selectedTools: selectedTools,
      costAnalysis: this.generateCostAnalysis(selectedTools),
      featureAnalysis: this.generateFeatureAnalysis(selectedTools),
      workflowCoverage: this.calculateWorkflowCoverage(selectedTools),
      gaps: this.identifyDetailedGaps(selectedTools),
      recommendations: this.generateIntelligentRecommendations(selectedTools),
      integrationStrategies: this.generateIntegrationStrategies(selectedTools),
      workflowOptimizations: this.identifyWorkflowOptimizations(selectedTools),
      overlapAnalysis: this.analyzeOverlaps(selectedTools),
      roiProjections: this.calculateROIProjections(selectedTools)
    };

    return analysis;
  }

  generateCostAnalysis(selectedTools) {
    let totalMonthlyCost = 0;
    let totalAnnualCost = 0;
    const costBreakdown = [];

    selectedTools.forEach(toolId => {
      const pricing = this.toolPricing[toolId];
      if (pricing) {
        totalMonthlyCost += pricing.monthly;
        totalAnnualCost += pricing.annual;
        costBreakdown.push({
          tool: toolId,
          monthly: pricing.monthly,
          annual: pricing.annual,
          tier: pricing.tier,
          seats: pricing.seats
        });
      }
    });

    return {
      totalMonthlyCost,
      totalAnnualCost,
      costBreakdown,
      costPerEmployee: selectedTools.length > 0 ? totalMonthlyCost / 10 : 0, // Assuming 10 employees
      industryBenchmark: {
        range: '$150-400/employee/month',
        status: totalMonthlyCost <= 250 ? 'below_average' : totalMonthlyCost <= 350 ? 'average' : 'above_average'
      }
    };
  }

  generateFeatureAnalysis(selectedTools) {
    const featureAnalysis = {};
    const allFeatures = new Set();
    const featureOverlaps = {};

    selectedTools.forEach(toolId => {
      const features = this.detailedFeatures[toolId];
      if (features) {
        featureAnalysis[toolId] = {
          core: features.core,
          advanced: features.advanced,
          integrations: features.integrations,
          strengths: features.strengths,
          limitations: features.limitations
        };

        // Track feature overlaps
        features.core.forEach(feature => {
          if (allFeatures.has(feature)) {
            if (!featureOverlaps[feature]) {
              featureOverlaps[feature] = [];
            }
            featureOverlaps[feature].push(toolId);
          } else {
            allFeatures.add(feature);
          }
        });
      }
    });

    return {
      toolFeatures: featureAnalysis,
      featureOverlaps,
      uniqueFeatures: Array.from(allFeatures),
      overlapCount: Object.keys(featureOverlaps).length
    };
  }

  identifyDetailedGaps(selectedTools) {
    const gaps = [];
    
    Object.keys(this.gapAnalysis).forEach(category => {
      Object.keys(this.gapAnalysis[category]).forEach(gapKey => {
        const gap = this.gapAnalysis[category][gapKey];
        const hasCapability = gap.recommendations.some(tool => selectedTools.includes(tool));
        
        if (!hasCapability) {
          gaps.push({
            category,
            type: gapKey,
            impact: gap.impact,
            description: gap.description,
            recommendations: gap.recommendations,
            roiImpact: gap.roi_impact,
            priority: gap.impact >= 85 ? 'High' : gap.impact >= 70 ? 'Medium' : 'Low'
          });
        }
      });
    });

    return gaps.sort((a, b) => b.impact - a.impact);
  }

  generateIntelligentRecommendations(selectedTools) {
    const recommendations = [];
    const gaps = this.identifyDetailedGaps(selectedTools);
    
    gaps.slice(0, 8).forEach(gap => {
      gap.recommendations.forEach(toolId => {
        if (!selectedTools.includes(toolId)) {
          const pricing = this.toolPricing[toolId];
          const features = this.detailedFeatures[toolId];
          const integrations = this.getToolIntegrations(toolId, selectedTools);
          
          recommendations.push({
            toolId,
            category: gap.category,
            gapAddress: gap.description,
            impact: gap.impact,
            roiImpact: gap.roiImpact,
            pricing: pricing,
            features: features,
            integrations: integrations,
            implementationComplexity: integrations.length > 2 ? 'Easy' : integrations.length > 0 ? 'Moderate' : 'Complex',
            paybackPeriod: this.calculatePaybackPeriod(toolId, gap.impact)
          });
        }
      });
    });

    return recommendations.sort((a, b) => (b.impact * (4 - b.integrations.length)) - (a.impact * (4 - a.integrations.length)));
  }

  generateIntegrationStrategies(selectedTools) {
    const strategies = [];
    
    selectedTools.forEach(tool1 => {
      selectedTools.forEach(tool2 => {
        if (tool1 !== tool2) {
          const integrations = this.integrationMatrix[tool1] || [];
          if (integrations.includes(tool2)) {
            const optimization = this.findWorkflowOptimization(tool1, tool2);
            if (optimization) {
              strategies.push({
                primaryTool: tool1,
                secondaryTool: tool2,
                integrationType: 'native',
                optimization: optimization,
                setupComplexity: optimization.setup_complexity,
                businessValue: optimization.cost_benefit
              });
            }
          }
        }
      });
    });

    return strategies;
  }

  identifyWorkflowOptimizations(selectedTools) {
    const optimizations = [];
    
    Object.keys(this.workflowOptimizations).forEach(key => {
      const optimization = this.workflowOptimizations[key];
      const hasAllTools = optimization.tools.every(tool => selectedTools.includes(tool));
      
      if (hasAllTools) {
        optimizations.push({
          id: key,
          ...optimization,
          status: 'available'
        });
      } else {
        const missingTools = optimization.tools.filter(tool => !selectedTools.includes(tool));
        if (missingTools.length <= 1) {
          optimizations.push({
            id: key,
            ...optimization,
            status: 'potential',
            missingTools
          });
        }
      }
    });

    return optimizations.sort((a, b) => {
      const aValue = parseInt(a.cost_benefit.replace(/[^0-9]/g, ''));
      const bValue = parseInt(b.cost_benefit.replace(/[^0-9]/g, ''));
      return bValue - aValue;
    });
  }

  calculateROIProjections(selectedTools) {
    const gaps = this.identifyDetailedGaps(selectedTools);
    const recommendations = this.generateIntelligentRecommendations(selectedTools);
    
    let totalImplementationCost = 0;
    let totalAnnualBenefit = 0;
    let totalProductivityGains = 0;

    recommendations.slice(0, 5).forEach(rec => {
      if (rec.pricing) {
        totalImplementationCost += rec.pricing.annual;
        const benefitValue = this.estimateAnnualBenefit(rec.toolId, rec.impact);
        totalAnnualBenefit += benefitValue;
        totalProductivityGains += this.estimateProductivityGain(rec.toolId);
      }
    });

    const roiPercentage = totalImplementationCost > 0 ? 
      Math.round(((totalAnnualBenefit - totalImplementationCost) / totalImplementationCost) * 100) : 0;
    
    const paybackMonths = totalAnnualBenefit > 0 ? 
      Math.round((totalImplementationCost / totalAnnualBenefit) * 12) : 0;

    return {
      totalImplementationCost,
      totalAnnualBenefit,
      totalProductivityGains,
      roiPercentage,
      paybackMonths,
      confidenceScore: Math.min(95, 60 + (selectedTools.length * 5))
    };
  }

  // Helper methods
  calculateWorkflowCoverage(selectedTools) {
    return this.workflowStages.map(stage => {
      const coverage = stage.requiredCapabilities.map(capability => {
        const availableTools = stage.tools[capability] || [];
        const hasCapability = availableTools.some(tool => selectedTools.includes(tool));
        return {
          capability,
          covered: hasCapability,
          availableTools: availableTools.filter(tool => selectedTools.includes(tool))
        };
      });

      const coveragePercentage = Math.round(
        (coverage.filter(c => c.covered).length / coverage.length) * 100
      );

      return {
        stage: stage.name,
        coverage: coveragePercentage,
        capabilities: coverage,
        status: coveragePercentage >= 80 ? 'excellent' : 
                coveragePercentage >= 60 ? 'good' : 
                coveragePercentage >= 40 ? 'moderate' : 'needs_improvement'
      };
    });
  }

  getToolIntegrations(toolId, selectedTools) {
    const toolIntegrations = this.integrationMatrix[toolId] || [];
    return toolIntegrations.filter(integration => selectedTools.includes(integration));
  }

  findWorkflowOptimization(tool1, tool2) {
    return Object.values(this.workflowOptimizations).find(opt => 
      opt.tools.includes(tool1) && opt.tools.includes(tool2)
    );
  }

  calculatePaybackPeriod(toolId, impact) {
    const pricing = this.toolPricing[toolId];
    if (!pricing) return '6-12 months';
    
    const monthlyCost = pricing.monthly;
    const impactValue = impact * 50; // $50 per impact point per month
    
    if (impactValue > monthlyCost * 2) return '1-3 months';
    if (impactValue > monthlyCost) return '3-6 months';
    return '6-12 months';
  }

  estimateAnnualBenefit(toolId, impact) {
    // Conservative estimates based on impact scores
    const baseBenefit = impact * 600; // $600 per impact point annually
    return Math.round(baseBenefit);
  }

  estimateProductivityGain(toolId) {
    const productivityMap = {
      apollo: 15, gong: 25, outreach: 30, hubspot: 20,
      fireflies: 10, zapier: 12, make: 12, clay: 18
    };
    return productivityMap[toolId] || 10;
  }

  analyzeOverlaps(selectedTools) {
    const overlaps = {};
    const toolsWithFeatures = selectedTools.filter(toolId => this.detailedFeatures[toolId]);

    for (let i = 0; i < toolsWithFeatures.length; i++) {
        for (let j = i + 1; j < toolsWithFeatures.length; j++) {
            const tool1Id = toolsWithFeatures[i];
            const tool2Id = toolsWithFeatures[j];
            const tool1Features = new Set(this.detailedFeatures[tool1Id]?.core || []);
            const tool2Features = new Set(this.detailedFeatures[tool2Id]?.core || []);
            
            const commonFeatures = [...tool1Features].filter(feature => tool2Features.has(feature));
            
            if (commonFeatures.length > 0) {
                if (!overlaps[tool1Id]) overlaps[tool1Id] = [];
                if (!overlaps[tool2Id]) overlaps[tool2Id] = [];
                
                overlaps[tool1Id].push({ partner: tool2Id, features: commonFeatures });
                overlaps[tool2Id].push({ partner: tool1Id, features: commonFeatures });
            }
        }
    }
    return overlaps;
  }
}