import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Calendar, Network, Building, Brain, ArrowRight, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CompletionScreen({ onBackToHome }) {
  const options = [
    {
      number: 1,
      title: "Schedule a 15-Minute Call",
      description: "Get personalized insights and strategic recommendations with one of our Managing Partners.",
      buttonText: "Book a Call",
      icon: Calendar,
      action: () => window.open('https://calendly.com/dougsandstedt', '_blank'),
      color: "from-teal-500 to-cyan-500"
    },
    {
      number: 2,
      title: "Network Intelligence Tool",
      description: "Find people within our network of 9K+ connections that we may be able to introduce you to.",
      buttonText: "Explore Network",
      icon: Network,
      link: createPageUrl('NetworkAIPortal'),
      color: "from-blue-500 to-indigo-500"
    },
    {
      number: 3,
      title: "Intelligent Vendor Network",
      description: "Browse our recommended partners and vendors we've worked with and recommend.",
      buttonText: "View Vendor Network",
      icon: Building,
      link: createPageUrl('VendorMarketplace'),
      color: "from-purple-500 to-pink-500"
    },
    {
      number: 4,
      title: "ArchetypeDNA Assessment",
      description: "Complete our leadership and decision-making style assessment to uncover your unique strengths.",
      buttonText: "Discover Your Archetype",
      icon: Brain,
      link: createPageUrl('ArchetypeDNALearning'),
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Success Icon and Header */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Thank You!</h1>
          <p className="text-gray-600 max-w-lg mx-auto leading-relaxed">
            Thanks for taking the time to share these insights. They've been shared with our 
            internal team to help put together some relevant insights on how we might be able 
            to help in the coming week.
          </p>
        </motion.div>

        {/* Options List */}
        <div className="space-y-6 mb-8">
          {options.map((option, index) => (
            <motion.div
              key={option.number}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Step Number */}
                    <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-lg">{option.number}</span>
                    </div>
                    
                    {/* Content */}
                    <div className="flex-grow">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {option.title}
                      </h3>
                      <p className="text-gray-600 mb-4 leading-relaxed">
                        {option.description}
                      </p>
                      
                      {/* Action Button */}
                      {option.link ? (
                        <Button 
                          asChild 
                          className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
                        >
                          <Link to={option.link}>
                            {option.buttonText}
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Link>
                        </Button>
                      ) : (
                        <Button 
                          onClick={option.action}
                          className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
                        >
                          {option.buttonText}
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Back to Home */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center"
        >
          <Button
            variant="ghost"
            onClick={onBackToHome}
            className="text-gray-500 hover:text-gray-700"
          >
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </motion.div>
      </div>
    </div>
  );
}