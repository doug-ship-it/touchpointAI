import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ecosystemData } from './EcosystemData';
import ToolNode from './ToolNode';
import { X, Maximize, Minimize, Zap, RefreshCw, Calculator, BarChart, FlaskConical, PlayCircle, TrendingUp, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GTMFlowSimulator from './flow-simulator/GTMFlowSimulator';

const pillarColors = {
  blue: { border: 'border-blue-300', bg: 'bg-blue-50/50' },
  green: { border: 'border-green-300', bg: 'bg-green-50/50' },
  orange: { border: 'border-orange-300', bg: 'bg-orange-50/50' },
  purple: { border: 'border-purple-300', bg: 'bg-purple-50/50' },
};

export default function SalesTechEcosystem() {
  const [selectedToolIds, setSelectedToolIds] = useState([]);
  const [activePillars, setActivePillars] = useState(['discovery', 'prospecting', 'acceleration', 'engagement']);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  const handleToolClick = (toolId) => {
    setSelectedToolIds(prev =>
      prev.includes(toolId) ? prev.filter(id => id !== toolId) : [...prev, toolId]
    );
  };
  
  const handlePillarToggle = (pillarId) => {
    setActivePillars(prev =>
      prev.includes(pillarId) ? prev.filter(p => p !== pillarId) : [...prev, pillarId]
    );
  };

  const visiblePillars = useMemo(() => {
    return ecosystemData.pillars.filter(p => activePillars.includes(p.id));
  }, [activePillars]);
  
  const handleFlowSimulatorLaunch = () => {
    setIsSimulatorOpen(true);
  };

  return (
    <section className="bg-slate-50 py-20">
      <AnimatePresence>
        {isSimulatorOpen && (
          <GTMFlowSimulator onClose={() => setIsSimulatorOpen(false)} />
        )}
      </AnimatePresence>
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">The Integrated Revenue Engine</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore our interconnected sales technology ecosystem, designed to drive predictable revenue growth from first touch to final close.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl border p-4 md:p-6 lg:p-8 overflow-hidden">
          <div className="flex flex-wrap gap-2 mb-6 border-b pb-4">
            <span className="text-sm font-semibold mr-4">Categories:</span>
            {ecosystemData.pillars.map(p => (
              <motion.button
                key={p.id}
                onClick={() => handlePillarToggle(p.id)}
                className={`text-xs px-3 py-1 rounded-full border-2 font-bold transition-all ${
                  activePillars.includes(p.id)
                    ? `bg-${p.color}-500 text-white border-${p.color}-500`
                    : `bg-white text-gray-600 border-gray-300 hover:border-${p.color}-400`
                }`}
                whileTap={{ scale: 0.95 }}
              >
                {p.name.split('&')[0]}
              </motion.button>
            ))}
            <button onClick={() => { setSelectedToolIds([]); setActivePillars(['discovery', 'prospecting', 'acceleration', 'engagement']); }} className="text-xs px-3 py-1 ml-auto flex items-center gap-1 text-gray-500 hover:text-gray-800">
                <RefreshCw className="w-3 h-3"/> Reset View
            </button>
          </div>

          {/* Contemporary Revenue Engine Rectangle */}
          <div className="mb-8">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-8 text-white shadow-2xl relative overflow-hidden"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-purple-400/10"
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              />
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between">
                <div className="flex items-center gap-6">
                  <Zap className="w-16 h-16 text-yellow-300" />
                  <div>
                    <h3 className="text-3xl font-bold mb-2">Revenue Engine</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      <Metric value="35%" label="Productivity" Icon={TrendingUp} />
                      <Metric value="45%" label="Conversion" Icon={Target} />
                      <Metric value="27%" label="Meetings" Icon={PlayCircle} />
                      <Metric value="32%" label="Deal Value" Icon={Zap} />
                    </div>
                  </div>
                </div>
                <div className="mt-6 md:mt-0">
                  <Button 
                    onClick={handleFlowSimulatorLaunch} 
                    size="lg" 
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-xl transform hover:scale-105 transition-all duration-300 text-lg px-8 py-4"
                  >
                    <PlayCircle className="w-6 h-6 mr-3"/>
                    Launch GTM Flow Simulator
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Expanded Pillars Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {visiblePillars.map(pillar => (
              <Pillar key={pillar.id} pillar={pillar} selectedTools={selectedToolIds} handleToolClick={handleToolClick} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const Pillar = ({ pillar, selectedTools, handleToolClick }) => (
  <motion.div
    layout
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.4 }}
    className={`p-6 rounded-xl border-2 space-y-6 ${pillarColors[pillar.color].bg} ${pillarColors[pillar.color].border}`}
  >
    <h3 className={`text-xl font-bold text-${pillar.color}-800`}>{pillar.name}</h3>
    <p className="text-sm text-gray-600">{pillar.description}</p>
    {pillar.categories.map(category => (
      <div key={category.name}>
        <h4 className="text-base font-semibold text-gray-700 mb-3">{category.name}</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
          {category.tools.map(toolId => {
            const tool = ecosystemData.tools[toolId];
            return (
              tool && <ToolNode
                key={toolId}
                tool={tool}
                pillarColor={pillar.color}
                isSelected={selectedTools.includes(toolId)}
                onClick={() => handleToolClick(toolId)}
              />
            );
          })}
        </div>
      </div>
    ))}
    <div className={`mt-6 text-base font-bold text-center p-3 rounded-lg bg-${pillar.color}-100 text-${pillar.color}-800`}>
        Result: {pillar.results}
    </div>
  </motion.div>
);

const Metric = ({ value, label, Icon }) => (
    <div className="text-center">
        <div className="font-bold text-base text-yellow-300">{value}</div>
        <div className="text-sm opacity-80">{label}</div>
    </div>
)