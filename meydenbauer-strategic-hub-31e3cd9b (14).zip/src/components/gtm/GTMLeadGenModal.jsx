import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Zap, Send, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { SendEmail } from '@/api/integrations';
import { toast } from 'sonner';

export default function GTMLeadGenModal({ isOpen, onClose }) {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter a valid email address.");
      return;
    }
    setIsSubmitting(true);

    try {
      const subject = "New GTM Lead Gen Signup";
      const body = `
        <div style="font-family: sans-serif; line-height: 1.6;">
            <h2 style="color: #1a202c;">New GTM Lead Generation Signup</h2>
            <p>A new user has signed up for the GTM lead generation offer from the website pop-up.</p>
            <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <p><strong>Email Address:</strong> <a href="mailto:${email}">${email}</a></p>
            <p><strong>Offer Details:</strong> "Receive 50 contacts with custom messaging to gauge interest."</p>
            <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <p style="color: #4a5568;">Please follow up with this individual to begin the process.</p>
        </div>
      `;

      // Send email to both recipients
      await Promise.all([
        SendEmail({ to: 'ops@mbcpartners.co', subject, body, from_name: "Touchpoint GTM Offer" }),
        SendEmail({ to: 'doug@mbcpartners.co', subject, body, from_name: "Touchpoint GTM Offer" })
      ]);

      setIsSubmitted(true);
      toast.success("Thank you! We'll be in touch shortly.");

    } catch (error) {
      console.error("Failed to send email:", error);
      toast.error("Something went wrong. Please try again later.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    onClose();
    // Reset state after a short delay to allow for exit animation
    setTimeout(() => {
        setEmail('');
        setIsSubmitted(false);
        setIsSubmitting(false);
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: -20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: -20 }}
            className="w-full max-w-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <Card className="shadow-2xl border-0 overflow-hidden">
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" onClick={handleClose}>
                <X className="w-5 h-5" />
              </Button>
              <CardHeader className="text-center p-8 bg-gradient-to-br from-green-50 to-teal-50">
                  <div className="w-16 h-16 mx-auto bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center mb-4 text-white shadow-lg">
                      <Zap className="w-8 h-8" />
                  </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Jumpstart Your Outreach</CardTitle>
                <CardDescription className="text-gray-600 text-base mt-2">
                  Enter your email to receive 50 contacts with custom messaging that we'll send on your behalf to gauge their interest in your services.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                {isSubmitted ? (
                  <div className="text-center space-y-4">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1, transition: { type: 'spring', stiffness: 260, damping: 20 } }}
                    >
                      <CheckCircle className="w-16 h-16 mx-auto text-green-600" />
                    </motion.div>
                    <h3 className="text-xl font-semibold text-gray-800">Thank You!</h3>
                    <p className="text-gray-600">We've received your request and will be in touch shortly to get started.</p>
                    <Button onClick={handleClose} className="mt-4">Close</Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input
                          type="email"
                          placeholder="your.email@company.com"
                          className="pl-10 h-12 text-lg"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          disabled={isSubmitting}
                        />
                    </div>
                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full h-12 text-lg bg-green-600 hover:bg-green-700" 
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Submitting...' : 'Get My Free Contacts'}
                      {!isSubmitting && <Send className="w-5 h-5 ml-2" />}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}