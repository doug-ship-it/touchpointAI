import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BrainCircuit, Layers, GitBranch, Search, Users, Code, Briefcase, FileText, Presentation, Shield, Zap, ArrowRight, Calendar, BookOpen, Lightbulb } from 'lucide-react';

const philosophyItems = [
  { icon: Layers, title: "Tool-Agnostic Architecture", description: "Systems that work across platforms and can evolve with technology." },
  { icon: Zap, title: "Automation-First Mindset", description: "Eliminating repetitive tasks through intelligent orchestration." },
  { icon: GitBranch, title: "Continuous Improvement", description: "Regular optimization based on performance metrics and user feedback." },
  { icon: Users, title: "Knowledge Transfer", description: "Enabling clients to maintain and extend systems independently." }
];

const toolCategories = [
  { category: "Core Workflow Automation", icon: GitBranch, tools: [ { name: "n8n", description: "Primary workflow automation engine for complex, agentic AI workflows." }, { name: "Zapier", description: "User-friendly automation for simpler workflows and G-Suite connections." }, { name: "Make.com", description: "Advanced scenario builder for complex multi-step processes." }, { name: "Gumloop", description: "Specialized AI agent orchestration for complex reasoning tasks." } ] },
  { category: "Talent Acquisition", icon: Users, tools: [ { name: "Apollo/LinkedIn Sales Navigator", description: "Targeted candidate identification and research." }, { name: "Salesrobot", description: "Automated outreach sequences with personalization." }, { name: "Manatal", description: "ATS with AI-powered candidate matching." }, { name: "Superhuman", description: "Accelerated communication with candidates and hiring managers." } ] },
  { category: "Research & Knowledge Work", icon: Search, tools: [ { name: "Claude Team/ClaudeMAX", description: "Deep reasoning, comprehensive research, and technical validation." }, { name: "ChatGPT Team", description: "Collaborative content creation and workflow automation." }, { name: "Perplexity Pro", description: "Real-time research with source citations." }, { name: "Apify", description: "Web scraping and data enrichment for market intelligence." } ] },
  { category: "Technical Evaluation", icon: Code, tools: [ { name: "ClaudeMAX", description: "Code evaluation, architecture review, and performance benchmarking." } ] },
  { category: "Prototyping & Delivery (POC / MVP)", icon: Layers, tools: [ { name: "Lovable, Base44, CursorAI, GitHub", description: "Collaborative development environments and rapid prototyping." } ] },
  { category: "Meeting & Collaboration Intelligence", icon: Presentation, tools: [ { name: "ZoomAI + ReadAI", description: "Real-time transcription, automated summaries, and action item tracking." } ] },
  { category: "Visual & Narrative Design", icon: Lightbulb, tools: [ { name: "Gamma.app", description: "Dynamic visual storytelling and pitch creation for impactful presentations." } ] },
  { category: "Documentation, Legal & Contracts", icon: FileText, tools: [ { name: "NotionAI", description: "Centralized project documentation and knowledge management." }, { name: "inhouse.app", description: "Streamlined legal workflows and contract management." }, { name: "Jotform", description: "Secure contract generation, e-signatures, and compliance management." } ] },
];

const promptTemplates = [
  { title: "Call Preparation Briefs", prompt: "Generate a structured CEO-style call prep for [NAME]. Include company context, shared connections, agenda points, and objections." },
  { title: "Company Intelligence Reports", prompt: "Create a Bain-style company brief on [FIRM] with key levers, stakeholder map, and competitive risks." },
  { title: "Follow-Up Email Frameworks", prompt: "Draft a 200-word follow-up for [NAME] referencing [KEY INSIGHT], value proposition, and Call To Action (CTA) with suggested time." },
  { title: "Meeting Summary Generator", prompt: "Summarize this transcript into a 5-bullet executive brief. Include action owners, insights, and due dates." }
];

const useCases = [
  "GTM strategy articulation", "Competitive positioning breakdown", "LinkedIn prompt + post optimization",
  "LinkedIn Sales Navigator targeting", "Heyreach sequence testing", "Persona-driven messaging",
  "Zapier workflow mapping", "Make.com multi-step automation", "Weekly reporting systems",
  "SOP creation for offshore assistants", "Interview question generation", "Meeting summary & action tracking",
  "Investor updates & deck copy", "Website content generation", "Funnel stage diagnosis",
  "Lifecycle campaign logic", "GTM diagnostics (CAC, payback)", "Campaign QA & message variance",
  "Trigify/Clay data enrichment", "Signal-based outreach scripting", "Notion dashboard reconfiguration",
  "Slackbot campaign ops updates", "CRM logic flows & field mapping", "Event playbooks & checklists",
  "Time-tracking SOPs for VAs", "G-Suite add-on logic", "RFP response templates",
  "AI writing QA & rewrite comparison", "Asset tagging & attribution", "Intake form AI automation",
  "Rapid landing page creation", "Meeting notes to deliverables"
];

export default function OurStackSection() {
  return (
    <div className="bg-white/70 backdrop-blur-sm mt-12 sm:mt-16 py-12 sm:py-16 border-t border-gray-200">
      {/* Our AI Integration Stack Header */}
      <section className="text-center mb-16 lg:mb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-gray-900">
              Our AI Integration Stack & Prompts
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              This guide provides practical frameworks, AI tools, and workflows to accelerate execution across Go-To-Market, marketing, and operations for new hires and clients.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stack Image */}
      <section className="pb-16 lg:pb-24">
        <div className="max-w-6xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white p-4 rounded-xl border border-gray-200 shadow-2xl"
          >
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c25052c968dec7f2573047/6d81de416_OurStack.png" alt="MeydenbauerAI OS Stack" className="rounded-lg w-full" />
          </motion.div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h3 
                className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
            >
                Our Integration Philosophy
            </motion.h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                {philosophyItems.map((item, index) => (
                    <motion.div
                        key={item.title}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        className="text-center"
                    >
                        <div className="flex justify-center mb-4">
                            <div className="p-4 bg-blue-100 rounded-xl">
                                <item.icon className="w-8 h-8 text-blue-600" />
                            </div>
                        </div>
                        <h4 className="text-xl font-semibold mb-2 text-gray-900">{item.title}</h4>
                        <p className="text-gray-600">{item.description}</p>
                    </motion.div>
                ))}
            </div>
        </div>
      </section>
      
      {/* Tool Categories Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h3 
            className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            Core Tooling by Function
          </motion.h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {toolCategories.map((category, index) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="bg-white border-gray-200 h-full hover:shadow-xl transition-shadow duration-300">
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-blue-100 rounded-lg">
                        <category.icon className="w-6 h-6 text-blue-600" />
                      </div>
                      <CardTitle className="text-lg text-gray-900">{category.category}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {category.tools.map(tool => (
                        <li key={tool.name}>
                          <p className="font-semibold text-gray-800">{tool.name}</p>
                          <p className="text-gray-600 text-sm">{tool.description}</p>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Prompt Templates Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h3 
            className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            Common Use Cases & Prompt Templates
          </motion.h3>
          <div className="space-y-6">
            {promptTemplates.map((template, index) => (
              <motion.div
                key={template.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <Card className="bg-white border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-lg text-gray-900">{template.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="italic bg-gray-50 p-4 rounded-md border-l-4 border-blue-500 text-gray-700">"{template.prompt}"</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h3 
            className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            30+ AI-Driven Use Cases We've Implemented
          </motion.h3>
          <motion.div 
            className="columns-2 md:columns-3 lg:columns-4 gap-4"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {useCases.map(useCase => (
              <div key={useCase} className="bg-white border border-gray-200 p-3 rounded-lg mb-4 text-sm break-inside-avoid text-gray-700">
                {useCase}
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">See Our Stack in Action</h3>
            <p className="text-xl text-gray-600 mb-8">
              Curious how we can apply this technology to solve your business challenges? Let's talk.
            </p>
            <a href="https://calendly.com/dougsandstedt" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="px-8 py-4 text-lg shadow-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 text-white hover:opacity-90 transition-opacity">
                <Calendar className="w-5 h-5 mr-2" />
                Book a Free Consultation
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
}