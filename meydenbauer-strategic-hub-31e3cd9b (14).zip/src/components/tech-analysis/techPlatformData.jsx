export const techPlatformData = {
  categories: [
    {
      id: 'crm_sales',
      name: 'CRM & Sales',
      tools: ['salesforce', 'hubspot', 'attio', 'pipedrive', 'zoho_crm', 'close', 'copper']
    },
    {
      id: 'project_management',
      name: 'Project Management',
      tools: ['jira', 'asana', 'trello', 'monday', 'clickup', 'notion', 'smartsheet']
    },
    {
      id: 'communication',
      name: 'Communication',
      tools: ['slack', 'microsoft_teams', 'zoom', 'google_workspace', 'discord']
    },
    {
      id: 'marketing_automation',
      name: 'Marketing Automation',
      tools: ['marketo', 'pardot', 'hubspot_marketing', 'mailchimp', 'klaviyo', 'customerio']
    },
    {
      id: 'design_creative',
      name: 'Design & Creative',
      tools: ['figma', 'adobe_cc', 'sketch', 'canva', 'invision']
    },
    {
      id: 'development_devops',
      name: 'Development & DevOps',
      tools: ['github', 'gitlab', 'jenkins', 'docker', 'kubernetes', 'bitbucket', 'circleci']
    },
    {
      id: 'hr_recruitment',
      name: 'HR & Recruitment',
      tools: ['greenhouse', 'lever', 'workday', 'bamboohr', 'gusto', 'rippling']
    },
    {
      id: 'business_intelligence',
      name: 'Business Intelligence',
      tools: ['tableau', 'power_bi', 'looker', 'snowflake', 'databricks', 'fivetran', 'dbt']
    },
    {
      id: 'cloud_infrastructure',
      name: 'Cloud & Infrastructure',
      tools: ['aws', 'azure', 'gcp', 'vercel', 'netlify', 'digitalocean', 'heroku']
    }
  ],
  tools: {
    // CRM & Sales
    salesforce: { name: 'Salesforce', logo: 'https://logo.clearbit.com/salesforce.com' },
    hubspot: { name: 'HubSpot', logo: 'https://logo.clearbit.com/hubspot.com' },
    attio: { name: 'Attio', logo: 'https://logo.clearbit.com/attio.com' },
    pipedrive: { name: 'Pipedrive', logo: 'https://logo.clearbit.com/pipedrive.com' },
    zoho_crm: { name: 'Zoho CRM', logo: 'https://logo.clearbit.com/zoho.com' },
    close: { name: 'Close', logo: 'https://logo.clearbit.com/close.com' },
    copper: { name: 'Copper', logo: 'https://logo.clearbit.com/copper.com' },
    // Project Management
    jira: { name: 'Jira', logo: 'https://logo.clearbit.com/atlassian.com/jira' },
    asana: { name: 'Asana', logo: 'https://logo.clearbit.com/asana.com' },
    trello: { name: 'Trello', logo: 'https://logo.clearbit.com/trello.com' },
    monday: { name: 'Monday.com', logo: 'https://logo.clearbit.com/monday.com' },
    clickup: { name: 'ClickUp', logo: 'https://logo.clearbit.com/clickup.com' },
    notion: { name: 'Notion', logo: 'https://logo.clearbit.com/notion.so' },
    smartsheet: { name: 'Smartsheet', logo: 'https://logo.clearbit.com/smartsheet.com' },
    // Communication
    slack: { name: 'Slack', logo: 'https://logo.clearbit.com/slack.com' },
    microsoft_teams: { name: 'Microsoft Teams', logo: 'https://logo.clearbit.com/microsoft.com' },
    zoom: { name: 'Zoom', logo: 'https://logo.clearbit.com/zoom.us' },
    google_workspace: { name: 'Google Workspace', logo: 'https://logo.clearbit.com/google.com' },
    discord: { name: 'Discord', logo: 'https://logo.clearbit.com/discord.com' },
    // Marketing Automation
    marketo: { name: 'Marketo', logo: 'https://logo.clearbit.com/marketo.com' },
    pardot: { name: 'Pardot', logo: 'https://logo.clearbit.com/pardot.com' },
    hubspot_marketing: { name: 'HubSpot Marketing Hub', logo: 'https://logo.clearbit.com/hubspot.com' },
    mailchimp: { name: 'Mailchimp', logo: 'https://logo.clearbit.com/mailchimp.com' },
    klaviyo: { name: 'Klaviyo', logo: 'https://logo.clearbit.com/klaviyo.com' },
    customerio: { name: 'Customer.io', logo: 'https://logo.clearbit.com/customer.io' },
    // Design & Creative
    figma: { name: 'Figma', logo: 'https://logo.clearbit.com/figma.com' },
    adobe_cc: { name: 'Adobe Creative Cloud', logo: 'https://logo.clearbit.com/adobe.com' },
    sketch: { name: 'Sketch', logo: 'https://logo.clearbit.com/sketch.com' },
    canva: { name: 'Canva', logo: 'https://logo.clearbit.com/canva.com' },
    invision: { name: 'InVision', logo: 'https://logo.clearbit.com/invisionapp.com' },
    // Development & DevOps
    github: { name: 'GitHub', logo: 'https://logo.clearbit.com/github.com' },
    gitlab: { name: 'GitLab', logo: 'https://logo.clearbit.com/gitlab.com' },
    jenkins: { name: 'Jenkins', logo: 'https://logo.clearbit.com/jenkins.io' },
    docker: { name: 'Docker', logo: 'https://logo.clearbit.com/docker.com' },
    kubernetes: { name: 'Kubernetes', logo: 'https://logo.clearbit.com/kubernetes.io' },
    bitbucket: { name: 'Bitbucket', logo: 'https://logo.clearbit.com/bitbucket.org' },
    circleci: { name: 'CircleCI', logo: 'https://logo.clearbit.com/circleci.com' },
    // HR & Recruitment
    greenhouse: { name: 'Greenhouse', logo: 'https://logo.clearbit.com/greenhouse.io' },
    lever: { name: 'Lever', logo: 'https://logo.clearbit.com/lever.co' },
    workday: { name: 'Workday', logo: 'https://logo.clearbit.com/workday.com' },
    bamboohr: { name: 'BambooHR', logo: 'https://logo.clearbit.com/bamboohr.com' },
    gusto: { name: 'Gusto', logo: 'https://logo.clearbit.com/gusto.com' },
    rippling: { name: 'Rippling', logo: 'https://logo.clearbit.com/rippling.com' },
    // Business Intelligence
    tableau: { name: 'Tableau', logo: 'https://logo.clearbit.com/tableau.com' },
    power_bi: { name: 'Microsoft Power BI', logo: 'https://logo.clearbit.com/microsoft.com' },
    looker: { name: 'Looker', logo: 'https://logo.clearbit.com/looker.com' },
    snowflake: { name: 'Snowflake', logo: 'https://logo.clearbit.com/snowflake.com' },
    databricks: { name: 'Databricks', logo: 'https://logo.clearbit.com/databricks.com' },
    fivetran: { name: 'Fivetran', logo: 'https://logo.clearbit.com/fivetran.com' },
    dbt: { name: 'dbt', logo: 'https://logo.clearbit.com/getdbt.com' },
    // Cloud & Infrastructure
    aws: { name: 'Amazon Web Services', logo: 'https://logo.clearbit.com/amazon.com' },
    azure: { name: 'Microsoft Azure', logo: 'https://logo.clearbit.com/microsoft.com' },
    gcp: { name: 'Google Cloud Platform', logo: 'https://logo.clearbit.com/google.com' },
    vercel: { name: 'Vercel', logo: 'https://logo.clearbit.com/vercel.com' },
    netlify: { name: 'Netlify', logo: 'https://logo.clearbit.com/netlify.com' },
    digitalocean: { name: 'DigitalOcean', logo: 'https://logo.clearbit.com/digitalocean.com' },
    heroku: { name: 'Heroku', logo: 'https://logo.clearbit.com/heroku.com' },
  }
};