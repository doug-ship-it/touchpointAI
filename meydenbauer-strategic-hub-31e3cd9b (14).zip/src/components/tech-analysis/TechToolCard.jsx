import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { CheckCircle } from 'lucide-react';

export default function TechToolCard({ tool, isSelected, onSelect }) {
  return (
    <motion.div
      onClick={() => onSelect(tool.name)}
      className={cn(
        'relative w-full h-28 rounded-xl flex flex-col items-center justify-center p-2 text-center cursor-pointer border-2 transition-all duration-300 group',
        isSelected
          ? 'border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500 shadow-md'
          : 'bg-white border-gray-200 hover:border-indigo-400 hover:bg-indigo-50/50'
      )}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      layout
    >
      {isSelected && (
        <div className="absolute top-2 right-2 p-0.5 bg-indigo-600 text-white rounded-full z-10">
          <CheckCircle className="w-4 h-4" />
        </div>
      )}
      <img
        src={tool.logo}
        alt={`${tool.name} logo`}
        className="w-10 h-10 object-contain mb-2 flex-shrink-0"
        loading="lazy"
        onError={(e) => { 
            e.target.style.display = 'none';
            const textEl = e.target.nextSibling;
            if(textEl) textEl.style.display = 'block';
        }}
      />
      <div className="hidden text-xs font-bold mt-2">{tool.name}</div>
      <span className="text-xs font-bold leading-tight text-gray-800 line-clamp-2">{tool.name}</span>
    </motion.div>
  );
}