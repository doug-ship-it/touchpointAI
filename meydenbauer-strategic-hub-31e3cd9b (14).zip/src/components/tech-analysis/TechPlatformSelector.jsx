import React from 'react';
import { techPlatformData } from './techPlatformData';
import TechToolCard from './TechToolCard';
import { motion } from 'framer-motion';

export default function TechPlatformSelector({ selectedPlatforms, onSelectionChange }) {
  const handleSelectTool = (toolName) => {
    const newSelection = selectedPlatforms.includes(toolName)
      ? selectedPlatforms.filter((t) => t !== toolName)
      : [...selectedPlatforms, toolName];
    onSelectionChange(newSelection);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h3 className="text-xl font-bold text-gray-800">Select Your Technology Platforms</h3>
        <p className="text-gray-600 mt-1">Choose the primary tools your team currently uses across different functions.</p>
      </div>
      {techPlatformData.categories.map((category) => (
        <motion.div 
            key={category.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5 }}
        >
          <Card className="overflow-hidden">
            <CardHeader className="bg-gray-50 border-b">
              <CardTitle className="text-lg">{category.name}</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {category.tools.map((toolId) => {
                  const tool = techPlatformData.tools[toolId];
                  if (!tool) return null;
                  return (
                    <TechToolCard
                      key={toolId}
                      tool={tool}
                      isSelected={selectedPlatforms.includes(tool.name)}
                      onSelect={handleSelectTool}
                    />
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

// Add placeholder Card components if not globally available
const Card = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={`bg-white rounded-xl border border-gray-200 ${className}`} {...props} />
));
const CardHeader = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={`p-6 ${className}`} {...props} />
));
const CardTitle = React.forwardRef(({ className, ...props }, ref) => (
  <h3 ref={ref} className={`font-semibold leading-none tracking-tight ${className}`} {...props} />
));
const CardContent = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={`p-6 pt-0 ${className}`} {...props} />
));