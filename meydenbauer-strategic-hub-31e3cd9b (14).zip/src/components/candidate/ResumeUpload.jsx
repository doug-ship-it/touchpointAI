import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Upload, 
  FileText, 
  Camera, 
  ArrowLeft,
  AlertCircle,
  CheckCircle,
  Users
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ResumeUpload({ opportunityType, opportunityLabel, onUpload }) {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileSelect = (file) => {
    const validTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/png'
    ];
    
    if (!validTypes.includes(file.type)) {
      setError('Please upload a PDF, Word document, or image file.');
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError('File size must be under 10MB.');
      return;
    }
    
    setSelectedFile(file);
    setError(null);
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      onUpload(selectedFile);
    }
  };

  const colorScheme = opportunityType === 'full_time' 
    ? { gradient: 'from-blue-500 to-indigo-500', light: 'from-blue-50 to-indigo-50' }
    : { gradient: 'from-purple-500 to-pink-500', light: 'from-purple-50 to-pink-50' };

  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-8">
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl("IndustryHub"))}
            className="mb-6 flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Hub
          </Button>
          
          <div className={`inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${colorScheme.light} rounded-full border border-gray-200 mb-4`}>
            <Users className="w-4 h-4 text-gray-700" />
            <span className="text-sm font-medium text-gray-700" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              {opportunityLabel}
            </span>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
            Upload Your Resume
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            We'll analyze your resume and create a personalized profile to match you with the best opportunities.
          </p>
        </div>

        <Card className="bg-white/90 backdrop-blur-sm border border-gray-200 shadow-xl">
          <CardContent className="p-8">
            {!selectedFile ? (
              <div
                className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-200 ${
                  dragActive 
                    ? 'border-blue-400 bg-blue-50' 
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                  onChange={handleFileInputChange}
                  className="hidden"
                />
                
                <div className={`w-16 h-16 mx-auto mb-6 bg-gradient-to-r ${colorScheme.gradient} rounded-full flex items-center justify-center`}>
                  <Upload className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                  Drop your resume here
                </h3>
                <p className="text-gray-500 mb-6" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                  or click to browse and upload
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    size="lg"
                    className={`bg-gradient-to-r ${colorScheme.gradient} hover:opacity-90 text-white shadow-lg`}
                  >
                    <FileText className="w-5 h-5 mr-2" />
                    Browse Files
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Take Photo
                  </Button>
                </div>
                
                <p className="text-xs text-gray-400 mt-6">
                  Supported formats: PDF, Word (.doc, .docx), Images (.jpg, .png)
                  <br />
                  Maximum file size: 10MB
                </p>
              </div>
            ) : (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                  Resume Ready
                </h3>
                <p className="text-gray-600 mb-4" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                  {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                </p>
                
                <div className="flex items-center justify-center gap-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedFile(null);
                      setError(null);
                    }}
                  >
                    Choose Different File
                  </Button>
                  <Button
                    onClick={handleUpload}
                    size="lg"
                    className={`bg-gradient-to-r ${colorScheme.gradient} hover:opacity-90 text-white shadow-lg`}
                  >
                    Analyze Resume
                  </Button>
                </div>
              </div>
            )}
            
            {error && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-red-700 text-sm">{error}</span>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            Your resume is processed securely and used only to create your candidate profile.
            <br />
            We never share your information without your explicit consent.
          </p>
        </div>
      </div>
    </div>
  );
}