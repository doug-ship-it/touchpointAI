
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  CheckCircle,
  Users,
  Calendar,
  Mail,
  ArrowLeft, // Added ArrowLeft icon
  Trophy,
  Target,
  // Removed ArrowRight and Briefcase as they are no longer used in the button section
} from "lucide-react";
import { Link } from "react-router-dom"; // Added Link import for navigation

// Placeholder utility function for page URL generation.
// In a real application, this would typically be imported from a centralized routing utility
// or defined as part of the application's router configuration.
const createPageUrl = (pageName) => {
  // For the purpose of making this file functional, we'll return a static path.
  // Replace with actual routing logic if this component is part of a larger application.
  if (pageName === "CandidatePortal") {
    return "/candidate-portal";
  }
  // Generic fallback for other page names, if needed
  return `/${pageName.toLowerCase().replace(/\s/g, '-')}`;
};

export default function CandidateCompletion({ candidateData, opportunityType, onContinue }) {
  const nextSteps = [
    {
      title: "Profile Review",
      description: "Our team will review your profile and identify matching opportunities",
      icon: Users,
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Opportunity Matching",
      description: "We'll connect you with relevant companies and consulting projects",
      icon: Target,
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "Interview Coordination",
      description: "Get introduced to hiring managers and schedule interviews",
      icon: Calendar,
      color: "from-emerald-500 to-teal-500"
    }
  ];

  const opportunityLabel = opportunityType === 'full_time' ? 'Full-Time Positions' : 'Fractional & Consulting';
  const colorScheme = opportunityType === 'full_time'
    ? 'from-blue-600 to-indigo-600'
    : 'from-purple-600 to-pink-600';

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r ${colorScheme} rounded-full mb-6 shadow-lg`}>
            <CheckCircle className="w-10 h-10 text-white" />
          </div>

          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 mb-6">
            <Trophy className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-700" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              Profile Complete
            </span>
          </div>

          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4 leading-tight" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
            Welcome to Our Talent Network,
            <span className={`bg-gradient-to-r ${colorScheme} bg-clip-text text-transparent block`}>
              {candidateData?.full_name?.split(' ')[0] || 'Professional'}
            </span>
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mb-6" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            Your profile has been added to our exclusive network for {opportunityLabel.toLowerCase()}.
            We'll connect you with opportunities that match your expertise and career goals.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-3 gap-6 mb-12"
        >
          {nextSteps.map((step, index) => (
            <Card key={step.title} className="bg-white/90 backdrop-blur-sm border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${step.color} rounded-xl mb-4 shadow-md`}>
                  <step.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                  {step.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border border-gray-200 shadow-xl mb-8"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Mail className="w-6 h-6 text-teal-600" />
            <h3 className="text-2xl font-bold text-gray-900" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              What Happens Next?
            </h3>
          </div>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            Our recruitment team will review your profile within 24-48 hours. You'll receive an email
            confirmation and updates as we identify matching opportunities. We respect your time and only
            present high-quality, relevant positions.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="outline"
              asChild
              className="bg-white text-purple-700 border-purple-200 hover:bg-purple-50 px-8 py-3 font-semibold"
              style={{fontFamily: 'Inter, system-ui, sans-serif'}}
            >
              <a href="mailto:abby@mbcpartners.co?subject=Candidate Profile Submitted">
                <Mail className="w-4 h-4 mr-2" />
                Contact Recruitment Team
              </a>
            </Button>
            <Button
              asChild
              className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              style={{fontFamily: 'Inter, system-ui, sans-serif'}}
            >
              <Link to={createPageUrl("CandidatePortal")}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Portal
              </Link>
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-sm text-gray-500"
          style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}
        >
          Your information is kept confidential and only shared with your explicit consent for specific opportunities.
        </motion.div>
      </div>
    </div>
  );
}
