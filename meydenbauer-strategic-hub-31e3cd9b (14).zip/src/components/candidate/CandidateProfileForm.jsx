
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Loader2, Edit, Check, AlertTriangle, X, RefreshCw, MapPin, Globe, Clock, Info } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const EnrichedField = ({ label, value, confidence, onEdit, children, className }) => {
  const [isEditing, setIsEditing] = useState(false);

  const confidenceStyles = {
    high: { bg: 'bg-green-50', border: 'border-green-200', icon: <Check className="w-4 h-4 text-green-600" /> },
    medium: { bg: 'bg-yellow-50', border: 'border-yellow-300', icon: <AlertTriangle className="w-4 h-4 text-yellow-600" /> },
    none: { bg: 'bg-white', border: 'border-gray-300', icon: null },
  };
  const styles = confidenceStyles[confidence] || confidenceStyles.none;

  if (isEditing) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div className={className}>
      <Label>{label}</Label>
      <div className={`relative flex items-center justify-between p-3 rounded-md h-12 ${styles.bg} ${styles.border}`}>
        <span className="font-medium text-gray-800 truncate">{value || 'Not provided'}</span>
        <div className="flex items-center gap-2">
          {confidence !== 'none' && (
            <div className="flex items-center gap-1 text-xs text-gray-500">
              {styles.icon}
              <span>{confidence === 'high' ? 'Extracted' : 'Detected'}</span>
            </div>
          )}
          <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => setIsEditing(true)}>
            <Edit className="w-3 h-3 text-gray-600" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default function CandidateProfileForm({
  extractedData,
  extractionStatus,
  opportunityType,
  onSubmit,
  onStartOver,
  isSubmitting,
  errorMessage // Added errorMessage prop
}) {
  const [formData, setFormData] = useState({});
  const [completionPercentage, setCompletionPercentage] = useState(0);

  useEffect(() => {
    setFormData({
      full_name: extractedData?.full_name || '',
      email: extractedData?.email || '',
      phone: extractedData?.phone || '',
      current_title: extractedData?.current_title || '',
      location: extractedData?.location || '',
      linkedin_url: extractedData?.linkedin_url || '',
      years_experience: extractedData?.years_experience || 0,
      skills: extractedData?.skills || [],
      summary: extractedData?.summary || '',
      
      // Enhanced compensation fields
      compensation_type: 'annual_salary',
      currency: 'USD',
      base_salary_min: 100000,
      base_salary_max: 150000,
      total_comp_min: 120000,
      total_comp_max: 200000,
      hourly_rate_min: 100,
      hourly_rate_max: 200,
      expected_hours_per_week: '40+',
      
      // Enhanced work preferences
      work_location_preference: 'remote_global',
      preferred_cities: [],
      max_commute_time: '30min',
      travel_willingness: '25',
      working_hours_flexibility: 'flexible_hours',
      primary_timezone: 'America/New_York',
      
      // Enhanced industry focus
      industry_expertise: [],
      role_type_preference: opportunityType === 'full_time' ? 'full_time_employee' : 'consulting_engagement',
      engagement_duration: 'long_term',
      
      // Additional fields
      languages: [],
      security_clearance: 'none',
      visa_status: 'authorized',
      cultural_preferences: {
        work_style: 'collaborative',
        communication_style: 'direct'
      }
    });
  }, [extractedData, opportunityType]);

  useEffect(() => {
    // Calculate completion percentage
    const requiredFields = ['full_name', 'email', 'compensation_type', 'work_location_preference', 'industry_expertise'];
    const filledRequired = requiredFields.filter(field => {
      if (field === 'industry_expertise') return formData[field]?.length > 0;
      return formData[field];
    }).length;
    
    const optionalFields = ['phone', 'linkedin_url', 'summary', 'skills', 'languages'];
    const filledOptional = optionalFields.filter(field => {
      if (Array.isArray(formData[field])) return formData[field]?.length > 0;
      return formData[field];
    }).length;
    
    const percentage = Math.round(((filledRequired / requiredFields.length) * 70) + ((filledOptional / optionalFields.length) * 30));
    setCompletionPercentage(percentage);
  }, [formData]);

  const currencies = [
    { code: 'USD', symbol: '$', name: 'US Dollar' },
    { code: 'EUR', symbol: '€', name: 'Euro' },
    { code: 'GBP', symbol: '£', name: 'British Pound' },
    { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
    { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
    { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
    { code: 'CHF', symbol: 'Fr', name: 'Swiss Franc' },
    { code: 'SEK', symbol: 'kr', name: 'Swedish Krona' }
  ];

  const timezones = [
    'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
    'Europe/London', 'Europe/Berlin', 'Europe/Paris', 'Europe/Stockholm',
    'Asia/Tokyo', 'Asia/Shanghai', 'Asia/Dubai', 'Australia/Sydney'
  ];

  const industries = [
    { value: 'technology', label: 'Technology (SaaS, AI/ML, FinTech, HealthTech, DevTools)' },
    { value: 'consulting_professional', label: 'Consulting & Professional Services (Strategy, Operations, Legal, Accounting)' },
    { value: 'financial_services', label: 'Financial Services (Investment Banking, Asset Management, Insurance)' },
    { value: 'private_equity_real_estate', label: 'Private Equity & Real Estate (PE/VC, Property Management, Development)' },
    { value: 'non_profit', label: 'Non-Profit & Social Impact (Healthcare, Education, Environmental)' },
    { value: 'retail_consumer', label: 'Retail & Consumer Goods (E-commerce, CPG, Fashion, Automotive)' },
    { value: 'manufacturing_industrial', label: 'Manufacturing & Industrial (Supply Chain, Operations, Engineering)' },
    { value: 'energy_utilities', label: 'Energy & Utilities (Oil/Gas, Renewable, Infrastructure)' },
    { value: 'government_public', label: 'Government & Public Sector (Federal, State, Municipal, Defense)' },
    { value: 'healthcare_lifesciences', label: 'Healthcare & Life Sciences (Pharma, Medical Devices, Digital Health)' },
    { value: 'other', label: 'Other' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field, item) => {
    const current = formData[field] || [];
    const updated = current.includes(item)
      ? current.filter(i => i !== item)
      : [...current, item];
    setFormData(prev => ({ ...prev, [field]: updated }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      resume_url: extractedData?.resume_url,
      education: extractedData?.education || [],
      experience: extractedData?.experience || []
    });
  };

  const getCurrentSymbol = () => {
    return currencies.find(c => c.code === formData.currency)?.symbol || '$';
  };

  const getStatusMessage = () => {
    switch (extractionStatus) {
      case 'success':
        return {
          type: 'success',
          title: 'Resume Analyzed Successfully',
          message: 'We extracted key information from your resume. Please review and enhance your profile below.',
          icon: <Check className="w-5 h-5" />
        };
      case 'partial_failure':
        return {
          type: 'warning',
          title: 'Partial Resume Analysis',
          message: 'We had some difficulty reading your resume, but you can fill in any missing information manually.',
          icon: <AlertTriangle className="w-5 h-5" />
        };
      case 'upload_failure': // This status implies the file itself failed to upload/process at a basic level
        return {
          type: 'info',
          title: 'Manual Entry Mode',
          message: 'Please fill out your profile information manually. This ensures we have all the details we need.',
          icon: <Info className="w-5 h-5" />
        };
      case 'failure': // This status implies the analysis failed, but upload was fine
        return {
          type: 'warning',
          title: 'Resume Analysis Unavailable',
          message: 'Our analysis service is temporarily unavailable, but you can complete your profile manually.',
          icon: <AlertTriangle className="w-5 h-5" />
        };
      default:
        return null;
    }
  };

  const renderCompensationFields = () => {
    switch (formData.compensation_type) {
      case 'annual_salary':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Currency</Label>
                <Select value={formData.currency} onValueChange={(value) => handleInputChange('currency', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.symbol} {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Geographic Cost Adjustment</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Auto-adjust" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto-adjust for location</SelectItem>
                    <SelectItem value="none">No adjustment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label>Base Salary Range</Label>
              <div className="px-3 py-2 text-sm text-gray-600">
                {getCurrentSymbol()}{formData.base_salary_min?.toLocaleString()} - {getCurrentSymbol()}{formData.base_salary_max?.toLocaleString()}
              </div>
              <div className="mt-2 px-2">
                <Slider
                  value={[formData.base_salary_min, formData.base_salary_max]}
                  onValueChange={([min, max]) => {
                    handleInputChange('base_salary_min', min);
                    handleInputChange('base_salary_max', max);
                  }}
                  max={500000}
                  min={30000}
                  step={5000}
                  className="w-full"
                />
              </div>
            </div>

            <div>
              <Label>Total Compensation (including equity/bonuses)</Label>
              <div className="px-3 py-2 text-sm text-gray-600">
                {getCurrentSymbol()}{formData.total_comp_min?.toLocaleString()} - {getCurrentSymbol()}{formData.total_comp_max?.toLocaleString()}
              </div>
              <div className="mt-2 px-2">
                <Slider
                  value={[formData.total_comp_min, formData.total_comp_max]}
                  onValueChange={([min, max]) => {
                    handleInputChange('total_comp_min', min);
                    handleInputChange('total_comp_max', max);
                  }}
                  max={1000000}
                  min={30000}
                  step={10000}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        );

      case 'hourly_rate':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Currency</Label>
                <Select value={formData.currency} onValueChange={(value) => handleInputChange('currency', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.symbol} {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Expected Hours Per Week</Label>
                <Select value={formData.expected_hours_per_week} onValueChange={(value) => handleInputChange('expected_hours_per_week', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10-20">10-20 hours</SelectItem>
                    <SelectItem value="20-30">20-30 hours</SelectItem>
                    <SelectItem value="30-40">30-40 hours</SelectItem>
                    <SelectItem value="40+">40+ hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Hourly Rate Range</Label>
              <div className="px-3 py-2 text-sm text-gray-600">
                {getCurrentSymbol()}{formData.hourly_rate_min} - {getCurrentSymbol()}{formData.hourly_rate_max} per hour
              </div>
              <div className="mt-2 px-2">
                <Slider
                  value={[formData.hourly_rate_min, formData.hourly_rate_max]}
                  onValueChange={([min, max]) => {
                    handleInputChange('hourly_rate_min', min);
                    handleInputChange('hourly_rate_max', max);
                  }}
                  max={1000}
                  min={25}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (extractionStatus === 'pending') return null;

  const currentStatus = getStatusMessage();

  return (
    <div className="min-h-screen p-6 flex justify-center items-center">
      <div className="w-full max-w-5xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
            Complete Your Global Profile
          </h1>
          <p className="text-gray-600 text-lg" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
            {currentStatus?.message || "Please review and enhance your profile for global opportunities."}
          </p>
          
          <div className="mt-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <span className="text-sm font-medium text-gray-600">Profile Completion</span>
              <Badge variant={completionPercentage >= 70 ? "default" : "secondary"}>
                {completionPercentage}%
              </Badge>
            </div>
            <div className="w-full max-w-md mx-auto bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-teal-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${completionPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Status Message */}
        {currentStatus && (
          <div className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
            currentStatus.type === 'success' ? 'bg-green-50 border-l-4 border-green-400 text-green-700' :
            currentStatus.type === 'warning' ? 'bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700' :
            'bg-blue-50 border-l-4 border-blue-400 text-blue-700'
          }`}>
            {currentStatus.icon}
            <div>
              <p className="font-bold">{currentStatus.title}</p>
              <p>{currentStatus.message}</p>
            </div>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-400 text-red-700 flex items-center gap-3" role="alert">
            <X className="w-5 h-5" />
            <div>
              <p className="font-bold">Error</p>
              <p>{errorMessage}</p>
            </div>
          </div>
        )}

        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border border-gray-200 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-8">

            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-600" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <EnrichedField
                    label="Full Name"
                    value={formData.full_name}
                    confidence={extractedData?.full_name ? 'high' : 'none'}
                  >
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={e => handleInputChange('full_name', e.target.value)}
                    />
                  </EnrichedField>

                  <EnrichedField
                    label="Email"
                    value={formData.email}
                    confidence={extractedData?.email ? 'high' : 'none'}
                  >
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={e => handleInputChange('email', e.target.value)}
                    />
                  </EnrichedField>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <EnrichedField
                    label="Current Title"
                    value={formData.current_title}
                    confidence={extractedData?.current_title ? 'medium' : 'none'}
                  >
                    <Label htmlFor="current_title">Current/Recent Title</Label>
                    <Input
                      id="current_title"
                      value={formData.current_title}
                      onChange={e => handleInputChange('current_title', e.target.value)}
                    />
                  </EnrichedField>

                  <div className="space-y-2">
                    <Label htmlFor="years_experience">Years of Experience</Label>
                    <Input
                      id="years_experience"
                      type="number"
                      min="0"
                      max="50"
                      value={formData.years_experience}
                      onChange={e => handleInputChange('years_experience', parseInt(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="visa_status">Work Authorization</Label>
                    <Select
                      value={formData.visa_status}
                      onValueChange={(value) => handleInputChange('visa_status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="authorized">Authorized to work</SelectItem>
                        <SelectItem value="visa_required">Visa sponsorship required</SelectItem>
                        <SelectItem value="citizen">Citizen/Permanent resident</SelectItem>
                        <SelectItem value="remote_only">Remote work only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Compensation Expectations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-blue-600" />
                  Compensation Expectations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Compensation Type</Label>
                  <Select
                    value={formData.compensation_type}
                    onValueChange={(value) => handleInputChange('compensation_type', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="annual_salary">Annual Salary (Total Compensation)</SelectItem>
                      <SelectItem value="hourly_rate">Hourly Rate</SelectItem>
                      <SelectItem value="project_based">Project-Based/Contract Rate</SelectItem>
                      <SelectItem value="equity_focused">Equity-Focused (Startup/Growth Stage)</SelectItem>
                      <SelectItem value="performance_based">Performance-Based (Commission + Base)</SelectItem>
                      <SelectItem value="consulting_day_rate">Consulting Day Rate</SelectItem>
                      <SelectItem value="retainer_based">Retainer-Based Engagement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {renderCompensationFields()}
              </CardContent>
            </Card>

            {/* Enhanced Work Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-purple-600" />
                  Work Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Work Location Preference</Label>
                    <Select
                      value={formData.work_location_preference}
                      onValueChange={(value) => handleInputChange('work_location_preference', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="remote_global">Fully Remote (Global)</SelectItem>
                        <SelectItem value="hybrid">Hybrid (Specific Cities)</SelectItem>
                        <SelectItem value="on_site">On-site Required</SelectItem>
                        <SelectItem value="client_travel">Client Site Travel (Up to X%)</SelectItem>
                        <SelectItem value="flexible">Flexible/Negotiable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Working Hours Flexibility</Label>
                    <Select
                      value={formData.working_hours_flexibility}
                      onValueChange={(value) => handleInputChange('working_hours_flexibility', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard_hours">Standard Business Hours (Local Time Zone)</SelectItem>
                        <SelectItem value="flexible_hours">Flexible Hours Within Region</SelectItem>
                        <SelectItem value="cross_timezone">Cross-Time Zone Collaboration Preferred</SelectItem>
                        <SelectItem value="client_timezone">Follow Client Time Zone</SelectItem>
                        <SelectItem value="asynchronous">Asynchronous Work Preferred</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Primary Time Zone</Label>
                    <Select
                      value={formData.primary_timezone}
                      onValueChange={(value) => handleInputChange('primary_timezone', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timezones.map((tz) => (
                          <SelectItem key={tz} value={tz}>
                            {tz.replace('_', ' ').replace('/', ' - ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Travel Willingness (%)</Label>
                    <div className="px-3 py-2 text-sm text-gray-600">
                      Up to {formData.travel_willingness}% travel
                    </div>
                    <Slider
                      value={[parseInt(formData.travel_willingness)]}
                      onValueChange={([value]) => handleInputChange('travel_willingness', value.toString())}
                      max={100}
                      min={0}
                      step={5}
                      className="w-full"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Industry Expertise */}
            <Card>
              <CardHeader>
                <CardTitle>Industry Expertise</CardTitle>
              </CardHeader>
              <CardContent>
                <Label className="text-base font-medium mb-4 block">Select all industries that apply to your expertise:</Label>
                <div className="grid md:grid-cols-2 gap-3">
                  {industries.map((industry) => (
                    <div key={industry.value} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                      <Checkbox
                        id={industry.value}
                        checked={(formData.industry_expertise || []).includes(industry.value)}
                        onCheckedChange={() => handleArrayToggle('industry_expertise', industry.value)}
                      />
                      <Label htmlFor={industry.value} className="text-sm leading-tight cursor-pointer">
                        {industry.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Professional Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  Professional Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Role Type Preference</Label>
                    <Select
                      value={formData.role_type_preference}
                      onValueChange={(value) => handleInputChange('role_type_preference', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full_time_employee">Full-Time Employee</SelectItem>
                        <SelectItem value="contract_freelance">Contract/Freelance (1099)</SelectItem>
                        <SelectItem value="consulting_engagement">Consulting Engagement</SelectItem>
                        <SelectItem value="fractional_executive">Fractional Executive</SelectItem>
                        <SelectItem value="board_advisory">Board Advisory Role</SelectItem>
                        <SelectItem value="project_based">Project-Based Work</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Engagement Duration</Label>
                    <Select
                      value={formData.engagement_duration}
                      onValueChange={(value) => handleInputChange('engagement_duration', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="long_term">Long-term (1+ years)</SelectItem>
                        <SelectItem value="medium_term">Medium-term (3-12 months)</SelectItem>
                        <SelectItem value="short_term">Short-term (1-3 months)</SelectItem>
                        <SelectItem value="project_specific">Project-specific</SelectItem>
                        <SelectItem value="flexible">Flexible/Varies</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex items-center justify-between pt-6">
              <div className="flex gap-3">
                <Button type="button" variant="outline" onClick={onStartOver}>
                  <RefreshCw className="w-4 h-4 mr-2" /> 
                  Upload Different Resume
                </Button>
                <Button 
                  type="button" 
                  variant="ghost"
                  className="text-blue-600 hover:text-blue-700"
                  onClick={() => {
                    // Save progress functionality could be added here
                    console.log("Save progress");
                  }}
                >
                  Save Progress & Continue Later
                </Button>
              </div>
              
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onSubmit({
                    ...formData,
                    resume_url: extractedData?.resume_url,
                    education: extractedData?.education || [],
                    experience: extractedData?.experience || [],
                    quick_complete: true
                  })}
                  disabled={!formData.full_name || !formData.email}
                >
                  Quick Complete & Proceed
                </Button>
                <Button
                  type="submit"
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg hover:shadow-xl"
                  disabled={isSubmitting || !formData.full_name || !formData.email}
                >
                  {isSubmitting ? (
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  ) : null}
                  Complete Profile & Access Network
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
