import React from "react";

export default function MeydenbauerLogo({ className = "w-8 h-8" }) {
  return (
    <div className={`${className} flex-shrink-0`}>
      <img
        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c743df2b981f4e31e3cd9b/9cda6a859_TPpbisGIOhF13emLB8BVf.png"
        alt="Touchpoint Logo"
        className="w-full h-full object-contain"
      />
    </div>
  );
}