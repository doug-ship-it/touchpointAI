import React from 'react';
import { motion } from 'framer-motion';
import { useExpandedView } from '@/components/expanded-view/ExpandedViewProvider';
import { createPageUrl } from '@/utils';

export default function FloatingIntakeButton() {
  const { openExpandedView } = useExpandedView();

  const handleClick = () => {
    openExpandedView(
      createPageUrl('Intake'), 
      'Intelligent AI Routing & Enrichment'
    );
  };

  return (
    <motion.button
      onClick={handleClick}
      className="fixed bottom-8 left-8 w-16 h-16 bg-gray-800 rounded-full shadow-2xl z-50 flex items-center justify-center"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 1 }}
    >
      <motion.img
        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c743df2b981f4e31e3cd9b/eee7c4967_image.png"
        alt="Intake Icon"
        className="w-8 h-8"
        animate={{ rotate: 360 }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </motion.button>
  );
}