import React, { useState } from 'react';
import { Info, Upload, Sparkles, X, ArrowRight, Shield, Users } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function DemoModeBanner() {
  const [dismissed, setDismissed] = useState(false);
  
  if (dismissed) return null;
  
  return (
    <Alert className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50 mb-6 relative shadow-sm">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 mt-0.5">
          <Sparkles className="h-5 w-5 text-blue-600" />
        </div>
        
        <div className="flex-1 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-gray-900 text-lg">
              You're exploring Doug Sandstedt's executive network
            </h3>
            <Badge variant="secondary" className="bg-blue-100 text-blue-700 border-blue-200">
              <Shield className="h-3 w-3 mr-1" />
              Demo Mode
            </Badge>
          </div>
          
          <AlertDescription className="text-gray-700 leading-relaxed">
            This Command Center displays <strong>9,000+ executive connections</strong> from Meydenbauer Partners' 
            network. You're seeing real relationship intelligence data to experience the platform's 
            full capabilities. This is a <strong>demo environment</strong>—your own data will be completely 
            separate and private when you upload your contacts.
          </AlertDescription>
          
          <div className="flex flex-wrap gap-3 pt-2">
            <Button 
              size="sm" 
              className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm"
              onClick={() => window.location.href = '/FindConnections#upload-section'}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload My Own Contacts
            </Button>
            
            <Button 
              size="sm" 
              variant="outline"
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
              onClick={() => window.location.href = '/FindConnections#trial-form'}
            >
              Start 14-Day Free Trial
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
            
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-600"
              onClick={() => window.location.href = '/FindConnections'}
            >
              Learn More About Privacy & Security
            </Button>
          </div>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setDismissed(true)}
          className="flex-shrink-0 hover:bg-blue-100"
          aria-label="Dismiss demo banner"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </Alert>
  );
}

export function DemoDataFooter({ contactCount = 9124 }) {
  return (
    <div className="mt-8 p-5 bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl text-center shadow-sm">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Sparkles className="h-4 w-4 text-blue-600" />
        <p className="text-sm font-medium text-gray-900">
          Demo Network Data
        </p>
      </div>
      <p className="text-sm text-gray-600">
        Viewing <span className="font-semibold text-gray-900">Doug Sandstedt's network</span>
        {' '}• {contactCount.toLocaleString()} executive contacts • Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
      </p>
      <Button 
        variant="link" 
        size="sm" 
        className="mt-2 text-blue-600 hover:text-blue-700" 
        onClick={() => window.location.href = '/FindConnections'}
      >
        Switch to my own private network →
      </Button>
    </div>
  );
}

// Legacy export for backward compatibility
export function DataAttributionFooter({ contactCount = 9124, ownerName = "Doug Sandstedt", onSwitchClick }) {
  return (
    <div className="mt-8 p-5 bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl text-center shadow-sm">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Users className="w-4 h-4 text-gray-600" />
        <p className="text-sm text-gray-700">
          Viewing <span className="font-semibold text-gray-900">{ownerName}'s network data</span>
        </p>
      </div>
      
      <div className="flex items-center justify-center gap-4 text-xs text-gray-500 mb-3">
        <span>Network size: <strong className="text-gray-700">{contactCount.toLocaleString()}</strong> contacts</span>
        <span>•</span>
        <span>Last updated: <strong className="text-gray-700">{new Date().toLocaleDateString()}</strong></span>
      </div>
      
      <Button 
        variant="link" 
        size="sm" 
        className="text-blue-600 hover:text-blue-700 font-medium"
        onClick={onSwitchClick || (() => window.location.href = '/FindConnections')}
      >
        Switch to my own contacts
        <ArrowRight className="w-4 h-4 ml-1" />
      </Button>
    </div>
  );
}

export function CompactDemoBadge() {
  return (
    <Badge 
      variant="secondary" 
      className="bg-blue-100 text-blue-700 border-blue-200 flex items-center gap-1"
    >
      <Sparkles className="w-3 h-3" />
      Demo Mode
    </Badge>
  );
}