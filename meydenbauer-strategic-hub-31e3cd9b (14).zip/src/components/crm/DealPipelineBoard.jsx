import React, { useState, useMemo } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, DollarSign, Calendar, Building2, MoreVertical
} from 'lucide-react';
import { CRMDeal } from '@/api/entities';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const PIPELINE_STAGES = [
  { id: 'discovery', label: 'Discovery', color: 'bg-blue-500' },
  { id: 'qualification', label: 'Qualification', color: 'bg-purple-500' },
  { id: 'proposal', label: 'Proposal', color: 'bg-yellow-500' },
  { id: 'negotiation', label: 'Negotiation', color: 'bg-orange-500' },
  { id: 'closed_won', label: 'Closed Won', color: 'bg-green-500' },
  { id: 'closed_lost', label: 'Closed Lost', color: 'bg-gray-500' }
];

export default function DealPipelineBoard({ deals, onDealUpdate, onDealClick }) {
  // Group deals by stage
  const dealsByStage = useMemo(() => {
    const grouped = {};
    PIPELINE_STAGES.forEach(stage => {
      grouped[stage.id] = deals.filter(d => d.stage === stage.id);
    });
    return grouped;
  }, [deals]);

  // Calculate stage totals
  const stageTotals = useMemo(() => {
    const totals = {};
    PIPELINE_STAGES.forEach(stage => {
      const stageDeals = dealsByStage[stage.id] || [];
      totals[stage.id] = stageDeals.reduce((sum, deal) => 
        sum + (deal.estimated_value || 0), 0
      );
    });
    return totals;
  }, [dealsByStage]);

  const handleDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    if (!destination || destination.droppableId === source.droppableId) {
      return;
    }

    const dealId = draggableId;
    const newStage = destination.droppableId;

    try {
      await CRMDeal.update(dealId, { 
        stage: newStage,
        last_activity_date: new Date().toISOString()
      });

      toast.success('Deal moved successfully');
      
      if (onDealUpdate) {
        onDealUpdate();
      }
    } catch (error) {
      console.error('Failed to update deal:', error);
      toast.error('Failed to move deal');
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value || 0);
  };

  const getDealTypeColor = (type) => {
    const colors = {
      'Executive Search': 'bg-purple-100 text-purple-800',
      'Consulting': 'bg-blue-100 text-blue-800',
      'Software Development': 'bg-green-100 text-green-800',
      'Digital Operations': 'bg-orange-100 text-orange-800',
      'TouchpointAI': 'bg-pink-100 text-pink-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="h-full overflow-x-auto">
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="flex gap-4 pb-4 min-w-max">
          {PIPELINE_STAGES.map(stage => {
            const stageDeals = dealsByStage[stage.id] || [];
            const stageTotal = stageTotals[stage.id] || 0;

            return (
              <div key={stage.id} className="flex-shrink-0 w-80">
                {/* Stage Header */}
                <Card className="mb-4 border-none shadow-md">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${stage.color}`} />
                        <h3 className="font-semibold text-gray-900">
                          {stage.label}
                        </h3>
                        <Badge variant="secondary">
                          {stageDeals.length}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm font-semibold text-gray-600">
                      {formatCurrency(stageTotal)}
                    </p>
                  </CardContent>
                </Card>

                {/* Droppable Column */}
                <Droppable droppableId={stage.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`space-y-3 min-h-[200px] p-2 rounded-lg transition-colors ${
                        snapshot.isDraggingOver ? 'bg-blue-50' : ''
                      }`}
                    >
                      {stageDeals.map((deal, index) => (
                        <Draggable
                          key={deal.id}
                          draggableId={deal.id}
                          index={index}
                        >
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                            >
                              <motion.div
                                whileHover={{ scale: 1.02 }}
                                transition={{ duration: 0.2 }}
                              >
                                <Card 
                                  className={`border-none shadow-md hover:shadow-lg transition-all cursor-pointer ${
                                    snapshot.isDragging ? 'opacity-50 rotate-2' : ''
                                  }`}
                                  onClick={() => onDealClick && onDealClick(deal)}
                                >
                                  <CardContent className="p-4">
                                    {/* Deal Header */}
                                    <div className="flex items-start justify-between mb-3">
                                      <h4 className="font-semibold text-gray-900 text-sm leading-tight flex-1">
                                        {deal.deal_name}
                                      </h4>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 w-6 p-0"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                        }}
                                      >
                                        <MoreVertical className="w-4 h-4" />
                                      </Button>
                                    </div>

                                    {/* Company */}
                                    {deal.company && (
                                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                                        <Building2 className="w-4 h-4" />
                                        <span className="truncate">{deal.company}</span>
                                      </div>
                                    )}

                                    {/* Deal Type Badge */}
                                    {deal.deal_type && (
                                      <Badge className={`mb-3 ${getDealTypeColor(deal.deal_type)}`}>
                                        {deal.deal_type}
                                      </Badge>
                                    )}

                                    {/* Value & Probability */}
                                    <div className="flex items-center justify-between mb-3">
                                      <div className="flex items-center gap-1 text-sm font-semibold">
                                        <DollarSign className="w-4 h-4 text-green-600" />
                                        <span>{formatCurrency(deal.estimated_value)}</span>
                                      </div>
                                      {deal.probability && (
                                        <Badge variant="secondary">
                                          {deal.probability}% likely
                                        </Badge>
                                      )}
                                    </div>

                                    {/* Close Date */}
                                    {deal.expected_close_date && (
                                      <div className="flex items-center gap-2 text-xs text-gray-500">
                                        <Calendar className="w-3 h-3" />
                                        <span>
                                          Close: {new Date(deal.expected_close_date).toLocaleDateString()}
                                        </span>
                                      </div>
                                    )}
                                  </CardContent>
                                </Card>
                              </motion.div>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}

                      {/* Add Deal Button */}
                      <Button
                        variant="ghost"
                        className="w-full justify-start text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                        onClick={() => {
                          // TODO: Open create deal modal with stage pre-filled
                        }}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Deal
                      </Button>
                    </div>
                  )}
                </Droppable>
              </div>
            );
          })}
        </div>
      </DragDropContext>
    </div>
  );
}