import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import MeydenbauerLogo from '@/components/ui/MeydenbauerLogo';

export default function WebsiteEntryForm({ onSubmit }) {
    const [website, setWebsite] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const validateAndSubmit = (e) => {
        e.preventDefault();
        setError('');

        if (!website) {
            setError('Please enter a company website.');
            return;
        }

        let formattedUrl = website.trim();
        if (!/^(https?:\/\/)/i.test(formattedUrl)) {
            formattedUrl = `https://${formattedUrl}`;
        }

        try {
            const url = new URL(formattedUrl);
            // Basic domain check
            if (!url.hostname.includes('.')) {
                throw new Error('Invalid domain');
            }
        } catch (_) {
            setError('Please enter a valid company website URL.');
            return;
        }

        setIsLoading(true);
        onSubmit(formattedUrl);
    };

    return (
        <div className="flex items-center justify-center min-h-screen p-6">
            <motion.div 
                className="w-full max-w-2xl text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
            >
                <MeydenbauerLogo className="w-20 h-20 mx-auto mb-6" />
                <h1 
                    className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
                    style={{fontFamily: 'Inter, system-ui, sans-serif'}}
                >
                    Enter your company website to discover personalized business resources
                </h1>
                <p 
                    className="text-lg text-gray-600 mb-8"
                    style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}
                >
                    We'll analyze your business and show you relevant tools and resources in seconds.
                </p>

                <form onSubmit={validateAndSubmit} className="max-w-xl mx-auto">
                    <div className="flex flex-col sm:flex-row items-start gap-4">
                        <div className="w-full">
                           <Input
                                type="text"
                                placeholder="yourcompany.com"
                                value={website}
                                onChange={(e) => setWebsite(e.target.value)}
                                className={`h-14 text-lg text-center sm:text-left ${error ? 'border-red-500' : ''}`}
                                disabled={isLoading}
                           />
                           {error && (
                                <p className="text-red-500 text-sm mt-2 flex items-center justify-center sm:justify-start gap-1">
                                    <AlertCircle className="w-4 h-4" />
                                    {error}
                                </p>
                           )}
                        </div>
                        <Button 
                            type="submit" 
                            size="lg" 
                            className="w-full sm:w-auto h-14 text-lg bg-gradient-to-r from-teal-600 to-blue-600 text-white shadow-lg"
                            disabled={isLoading}
                        >
                            {isLoading ? (
                                <Loader2 className="w-6 h-6 animate-spin" />
                            ) : (
                                <>
                                    Analyze My Business
                                    <ArrowRight className="w-5 h-5 ml-2" />
                                </>
                            )}
                        </Button>
                    </div>
                </form>
            </motion.div>
        </div>
    );
}