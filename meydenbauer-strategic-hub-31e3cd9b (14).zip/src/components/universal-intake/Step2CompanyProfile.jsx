import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowRight, ArrowLeft, Building, Globe, Briefcase, Users, MapPin, Edit, CheckCircle, Sparkles, RotateCcw, Loader2, Search } from 'lucide-react';
import { debounce } from 'lodash';
import { InvokeLLM } from '@/api/integrations';

const companySizeOptions = [
  '1-10', '11-50', '51-200', '201-500', '501-1,000', '1,001-5,000', '5,001-10,000', '10,000+'
];

const AutoFilledField = ({ label, value, confidence, isEditing, onEdit, onSave, onCancel, Icon, placeholder, type = "input", options = [] }) => {
  const [editValue, setEditValue] = useState(value || '');
  
  useEffect(() => {
    setEditValue(value || '');
  }, [value]);
  
  const handleSave = () => {
    onSave(editValue);
  };

  const ConfidenceIcon = confidence >= 90 ? CheckCircle : confidence >= 80 ? Sparkles : Edit;
  const confidenceColor = confidence >= 90 ? "text-green-600" : confidence >= 80 ? "text-blue-600" : "text-yellow-600";
  
  return (
    <div className="space-y-2">
      <Label className="flex items-center gap-2 text-gray-700">
        <Icon className="w-4 h-4 text-gray-500" />
        {label}
        {confidence && (
          <span className={`text-xs font-medium ${confidenceColor} flex items-center gap-1`}>
            <ConfidenceIcon className="w-3 h-3" />
            {confidence}% confident
          </span>
        )}
      </Label>
      
      {isEditing ? (
        <div className="flex gap-2">
          {type === "select" ? (
            <Select value={editValue} onValueChange={setEditValue}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder={placeholder} />
              </SelectTrigger>
              <SelectContent>
                {options.map((option) => (
                  <SelectItem key={option} value={option}>{option}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <Input
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              placeholder={placeholder}
              className="flex-1"
            />
          )}
          <Button size="sm" onClick={handleSave} className="bg-teal-600 hover:bg-teal-700">Save</Button>
          <Button size="sm" variant="outline" onClick={onCancel}>Cancel</Button>
        </div>
      ) : (
        <div className="flex items-center justify-between p-3 bg-white border border-gray-300 rounded-md">
          <span className="font-medium text-gray-800">{value || "Not available"}</span>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onEdit}>
            <Edit className="w-4 h-4 text-gray-500" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default function Step2CompanyProfile({ formData, updateFormData, onNext, onPrevious }) {
  const [companyFormData, setCompanyFormData] = useState(formData.company || {});
  const [editingFields, setEditingFields] = useState({});
  const [isEnriching, setIsEnriching] = useState(false);
  const [enrichmentError, setEnrichmentError] = useState(null);
  const [autoFillComplete, setAutoFillComplete] = useState(false);
  const [enrichedData, setEnrichedData] = useState({});
  const [alternativeDomain, setAlternativeDomain] = useState('');
  const [isAlternativeSearch, setIsAlternativeSearch] = useState(false);

  const enrichCompanyData = useCallback(async (domain, functionRole, firstName) => {
    if (!domain || !functionRole) return;

    const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com'];
    if (personalDomains.includes(domain)) {
      setEnrichmentError('Personal email detected. Please enter company details manually or use a business email.');
      setAutoFillComplete(true);
      setIsEnriching(false);
      return;
    }

    setIsEnriching(true);
    setAutoFillComplete(false);
    setEnrichmentError(null);
    setEnrichedData({});

    const searchContext = firstName ? `${firstName} ${functionRole} ${domain}` : `${functionRole} ${domain}`;

    const prompt = `Based on email domain "${domain}", user's function as "${functionRole}", and search context "${searchContext}", research and provide detailed company and personal professional intelligence with confidence scores.

    **CRITICAL: Use LinkedIn, official company websites, business registries, and recent news sources for accurate data. Prioritize LinkedIn for employee count/company size.**

    **Required Response Format:**
    For each field, provide both the value and a confidence score (0-100):
    
    - company_name: {value: "Exact legal company name", confidence: 85}
    - industry: {value: "Specific industry relevant to ${functionRole}", confidence: 75}  
    - company_size: {value: "A value from this list: ${companySizeOptions.join(', ')}", confidence: 85}
    - website: {value: "Official website URL", confidence: 90}
    - location: {value: "Headquarters location", confidence: 80}
    - description: {value: "Brief company description", confidence: 85}
    - stage: {value: "Business stage (Startup, Growth, Established, Enterprise)", confidence: 75}
    - geographic_presence: {value: "Geographic presence/markets served", confidence: 70}
    
    Only provide data you can verify from reliable sources. Use LinkedIn specifically for company size verification. Be conservative with confidence scores - only use 90+ for data from official sources.`;

    try {
      const result = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: 'object',
          properties: {
            company_name: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            industry: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            company_size: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            website: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            location: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            description: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            stage: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            geographic_presence: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } }
          }
        }
      });

      if (result) {
        setEnrichedData(result);
        const newCompanyData = {};
        let hasAutoFilled = false;
        
        // Use 70% confidence threshold for auto-filling
        if (result.company_name?.confidence >= 70) { newCompanyData.name = result.company_name.value; hasAutoFilled = true; }
        if (result.industry?.confidence >= 70) { newCompanyData.industry = result.industry.value; hasAutoFilled = true; }
        if (result.company_size?.confidence >= 70) { newCompanyData.size = result.company_size.value; hasAutoFilled = true; }
        if (result.website?.confidence >= 70) { newCompanyData.website = result.website.value; hasAutoFilled = true; }
        if (result.location?.confidence >= 70) { newCompanyData.location = result.location.value; hasAutoFilled = true; }
        if (result.description?.confidence >= 70) { newCompanyData.description = result.description.value; hasAutoFilled = true; }
        if (result.stage?.confidence >= 70) { newCompanyData.stage = result.stage.value; hasAutoFilled = true; }
        if (result.geographic_presence?.confidence >= 70) { newCompanyData.geographicPresence = result.geographic_presence.value; hasAutoFilled = true; }

        if (hasAutoFilled) {
          setCompanyFormData(newCompanyData);
          updateFormData('company', newCompanyData);
        } else {
          setEnrichmentError('AI confidence was below 70% for all fields. Please enter company details manually.');
        }
        setAutoFillComplete(true);
      } else {
        throw new Error('No data returned from enrichment service.');
      }
    } catch (error) {
      console.error('Enrichment failed:', error);
      setEnrichmentError('Could not auto-fill company data. Please enter it manually.');
      setAutoFillComplete(true);
    } finally {
      setIsEnriching(false);
    }
  }, [updateFormData]);

  const debouncedEnrichment = useMemo(() => debounce(enrichCompanyData, 500), [enrichCompanyData]);

  useEffect(() => {
    const { email, function: functionRole, firstName } = formData.contact || {};
    if (email && functionRole && email.includes('@')) {
        const domain = email.split('@')[1];
        if (!autoFillComplete && !isEnriching) {
          debouncedEnrichment(domain, functionRole, firstName);
        }
    }
  }, [formData.contact, debouncedEnrichment, autoFillComplete, isEnriching]);

  const handleCompanyFieldEdit = (field) => setEditingFields({ ...editingFields, [field]: true });

  const handleCompanyFieldSave = (field, value) => {
    const newCompanyData = { ...companyFormData, [field]: value };
    setCompanyFormData(newCompanyData);
    updateFormData('company', newCompanyData);
    setEditingFields({ ...editingFields, [field]: false });
  };

  const handleCompanyFieldCancel = (field) => setEditingFields({ ...editingFields, [field]: false });

  const handleConfirmCompany = () => {
    onNext();
  };

  const handleAlternativeSearch = async () => {
    if (alternativeDomain) {
      let domainToSearch = alternativeDomain.trim();
      try {
        if (domainToSearch.startsWith('http')) {
            domainToSearch = new URL(domainToSearch).hostname.replace(/^www\./, '');
        }
      } catch (e) { /* It's likely just a domain, which is fine */ }
      
      const { function: functionRole, firstName } = formData.contact || {};
      setCompanyFormData({});
      setEnrichedData({});
      setAutoFillComplete(false);
      setEnrichmentError(null);
      setIsAlternativeSearch(true);
      await enrichCompanyData(domainToSearch, functionRole, firstName);
      setAlternativeDomain('');
      setIsAlternativeSearch(false);
    }
  };

  const isValid = companyFormData.name && companyFormData.industry && companyFormData.size;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-teal-50 mb-4">
          <Building className="w-8 h-8 text-teal-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Company Intelligence Summary</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">We've gathered insights about your organization. Please review the details below.</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        
        {isEnriching && (
          <div className="flex items-center gap-3 text-sm text-blue-600 bg-blue-50 p-4 rounded-lg mb-6">
            <Loader2 className="w-5 h-5 animate-spin" />
            {isAlternativeSearch ? 'Analyzing new company data...' : 'Analyzing your company data... This may take a moment.'}
          </div>
        )}

        {(autoFillComplete || enrichmentError) && (
          <>
            {companyFormData.name && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-blue-50 border border-blue-200 text-blue-800 rounded-lg p-6 mb-8">
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-md flex items-center justify-center flex-shrink-0">
                    <Building className="w-7 h-7 text-gray-500" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold mb-1">Hi {formData.contact?.firstName || 'there'}, here's what we found about {companyFormData.name}:</h2>
                    <p className="text-sm">
                      {companyFormData.name} is a <span className="font-medium text-teal-700">{companyFormData.industry || 'company'}</span>.
                    </p>
                    <p className="text-sm">
                      Based in <span className="font-medium">{companyFormData.location || 'their primary market'}</span>, they focus on <span className="font-medium">{companyFormData.description?.substring(0, 100) || 'their core business'}...</span>
                    </p>
                  </div>
                </div>
                {companyFormData.description && <p className="text-xs text-blue-700 italic mt-4">"{companyFormData.description}"</p>}
              </motion.div>
            )}

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Company Profile</h3>
              
              {enrichmentError && (
                <div className="text-sm text-orange-600 bg-orange-50 p-3 rounded-lg mb-4">
                  {enrichmentError}
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <AutoFilledField label="Company Name" value={companyFormData.name} confidence={enrichedData.company_name?.confidence} isEditing={editingFields.name} onEdit={() => handleCompanyFieldEdit('name')} onSave={(value) => handleCompanyFieldSave('name', value)} onCancel={() => handleCompanyFieldCancel('name')} Icon={Building} placeholder="Enter company name" />
                <AutoFilledField label="Industry" value={companyFormData.industry} confidence={enrichedData.industry?.confidence} isEditing={editingFields.industry} onEdit={() => handleCompanyFieldEdit('industry')} onSave={(value) => handleCompanyFieldSave('industry', value)} onCancel={() => handleCompanyFieldCancel('industry')} Icon={Briefcase} placeholder="Enter industry" />
                <AutoFilledField label="Company Size" value={companyFormData.size} confidence={enrichedData.company_size?.confidence} isEditing={editingFields.size} onEdit={() => handleCompanyFieldEdit('size')} onSave={(value) => handleCompanyFieldSave('size', value)} onCancel={() => handleCompanyFieldCancel('size')} Icon={Users} placeholder="Select company size" type="select" options={companySizeOptions} />
                <AutoFilledField label="Stage" value={companyFormData.stage} confidence={enrichedData.stage?.confidence} isEditing={editingFields.stage} onEdit={() => handleCompanyFieldEdit('stage')} onSave={(value) => handleCompanyFieldSave('stage', value)} onCancel={() => handleCompanyFieldCancel('stage')} Icon={Sparkles} placeholder="Business stage" />
              </div>
              <AutoFilledField label="Website" value={companyFormData.website} confidence={enrichedData.website?.confidence} isEditing={editingFields.website} onEdit={() => handleCompanyFieldEdit('website')} onSave={(value) => handleCompanyFieldSave('website', value)} onCancel={() => handleCompanyFieldCancel('website')} Icon={Globe} placeholder="https://company.com" />
            </motion.div>

            {/* Direct Company Correction Input */}
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 mt-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Is this the right company?</h3>
              <p className="text-gray-600 mb-4">We're creating recommendations for <span className="font-medium">{companyFormData.name || 'your company'}</span>.</p>
              
              <div className="space-y-4">
                <div className="flex items-center justify-center">
                  <Button onClick={handleConfirmCompany} disabled={!isValid} className="bg-teal-600 hover:bg-teal-700 text-white px-8">
                    <CheckCircle className="w-4 h-4 mr-2" /> Yes, this is correct
                  </Button>
                </div>
                
                <div className="border-t pt-4">
                  <Label htmlFor="alternativeDomain" className="text-sm font-medium text-gray-700 mb-2 block">
                    Search for a different company by entering their website:
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="alternativeDomain"
                      placeholder="e.g., microsoft.com or https://apple.com"
                      value={alternativeDomain}
                      onChange={(e) => setAlternativeDomain(e.target.value)}
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleAlternativeSearch} 
                      disabled={!alternativeDomain.trim() || isEnriching}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Search className="w-4 h-4 mr-2" />
                      {isEnriching ? 'Searching...' : 'Search'}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        <p className="text-sm text-gray-500 text-center mt-8">We'll gather more specifics about your business needs to provide relevant recommendations.</p>
      </div>
    </div>
  );
}