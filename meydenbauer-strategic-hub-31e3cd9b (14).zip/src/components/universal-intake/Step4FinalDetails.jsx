import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { ArrowRight, ArrowLeft, Loader2, Clock, Users, DollarSign, Upload, FileText, Lock, CheckCircle } from 'lucide-react';

const timeframes = ["🔥 Yesterday", "⚡ Within the next week or so", "📅 1-2 weeks", "🗓️ Within the next 30 days", "🔍 Just starting to explore"];
const decisionMakers = ["👑 I'm the only decision maker", "My partner or manager will need to approve", "Multiple other people are involved"];

export default function Step4FinalDetails({ formData, updateFormData, onSubmit, onPrevious, isLoading }) {
  const [localData, setLocalData] = useState(formData.finalDetails || {
    timeline: [],
    decision: [],
    budget: '',
    files: [],
    nda: false,
  });
  const [fileNames, setFileNames] = useState('');

  const handleToggle = (field, item) => {
    const current = localData[field] || [];
    const updated = current.includes(item) ? current.filter(i => i !== item) : [...current, item];
    handleChange(field, updated);
  };
  
  const handleChange = (field, value) => {
      const newData = {...localData, [field]: value};
      setLocalData(newData);
      updateFormData('finalDetails', {[field]: value});
  };

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    if (files.length > 0) {
      const names = files.map(file => file.name).join(', ');
      setFileNames(names);
      handleChange('files', files);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-50 mb-4">
          <FileText className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Final Details</h1>
        <p className="text-lg text-gray-600">Just a few more details to complete your profile.</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200 space-y-8">
        <div>
          <Label className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">When do you need help?</Label>
          <div className="space-y-3">
            {timeframes.map(item => (
              <div key={item} className="flex items-center space-x-3">
                <Checkbox id={`time_${item}`} checked={(localData.timeline || []).includes(item)} onCheckedChange={() => handleToggle('timeline', item)} />
                <Label htmlFor={`time_${item}`} className="font-normal">{item}</Label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <Label className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">Decision Process</Label>
          <div className="space-y-3">
            {decisionMakers.map(item => (
              <div key={item} className="flex items-center space-x-3">
                <Checkbox id={`decision_${item}`} checked={(localData.decision || []).includes(item)} onCheckedChange={() => handleToggle('decision', item)} />
                <Label htmlFor={`decision_${item}`} className="font-normal">{item}</Label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <Label htmlFor="budget" className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">Any target budget, rates or compensation we should target?</Label>
          <Input id="budget" value={localData.budget || ''} onChange={e => handleChange('budget', e.target.value)} placeholder="$50K" className="text-lg" />
        </div>
        
        <div>
          <Label className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
            Any relevant files, presentations or documents that will help us validate whether we can help you internally or try to refer you to someone in our network?
          </Label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-teal-500 transition-colors">
            <input 
              type="file" 
              className="hidden" 
              id="file-upload"
              onChange={handleFileUpload} 
              multiple 
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="mx-auto h-12 w-12 text-teal-500 mb-4"/>
              <p className="text-sm text-gray-600 mb-2">Click to upload files</p>
              <p className="text-xs text-gray-400">PDF, Word, PowerPoint, Excel, or Text files</p>
            </label>
            {fileNames && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800 font-medium">📎 {fileNames}</p>
              </div>
            )}
          </div>
        </div>

        <div>
          <Label className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
            <span className="text-teal-600">○</span> Non-Disclosure Agreement (Optional)
          </Label>
          <p className="text-gray-600 mb-4">For confidential discussions, you may optionally sign our NDA before submitting.</p>
          <div className="flex items-center space-x-3">
            <Checkbox id="nda" checked={localData.nda || false} onCheckedChange={checked => handleChange('nda', checked)} />
            <Label htmlFor="nda" className="font-medium">📋 Sign NDA (Optional)</Label>
          </div>
          <p className="text-xs text-gray-500 mt-2">Note: Signing the NDA is completely optional and not required to submit this assessment.</p>
        </div>

        <div className="mt-8 flex justify-between pt-8 border-t">
          <Button onClick={onPrevious} variant="outline" size="lg"><ArrowLeft className="w-4 h-4 mr-2" /> ← Back</Button>
          <Button onClick={onSubmit} disabled={isLoading} size="lg" className="bg-teal-600 hover:bg-teal-700 text-white">
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : '✓'} Complete Assessment
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}