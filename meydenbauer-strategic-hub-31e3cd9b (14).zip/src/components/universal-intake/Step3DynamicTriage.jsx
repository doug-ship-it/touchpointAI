import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowRight, ArrowLeft, Loader2, AlertTriangle, Check, Briefcase, Users, Lightbulb, TrendingUp, User, Target, Settings, DollarSign, Search, BarChart, Cog, Zap, BrainCircuit, Globe, UserPlus, UserCheck, Heart, Truck, CheckCircle, Code, Database, Smartphone, Shield, ClipboardList, Swords } from 'lucide-react';
import { cn } from '@/lib/utils';

// --- Static Data Definitions ---
const supportServices = [
  { title: "Fractional Leadership", description: "Access senior expertise for strategic guidance without full-time commitment." },
  { title: "Project-Based Consulting", description: "Define & execute specific projects with our certified thought leaders." },
  { title: "Executive Search", description: "Find the executive tier talent you need to drive company focus." },
  { title: "Team Augmentation", description: "Scale your team rapidly with skilled professionals that integrate seamlessly." },
  { title: "Strategic Advisory", description: "Get ongoing strategic vision guidance from experienced thought leaders." },
  { title: "Process Optimization", description: "Streamline operations and optimize processes to maximize efficiency." },
  { title: "Technology Implementation", description: "Seamlessly integrate new technologies to drive business performance." },
  { title: "Competitive Risk Management", description: "Mitigate business risks and manage competition with strategic tools." },
  { title: "Digital Transformation", description: "Modernize your business with digital-first approaches and emerging tech." },
  { title: "Market Expansion Analysis", description: "Analyze market trends and opportunities for strategic growth." },
  { title: "Financial Planning & Analysis", description: "Optimize financial performance with forward-looking insights." },
  { title: "Training & Development", description: "Upskill your team with customized leadership and skills development." }
];

const supportServiceKeywords = {
    'revenue|growth|sales|customer|market|gtm|financial|planning': ["Strategic Advisory", "Project-Based Consulting", "Market Expansion Analysis", "Financial Planning & Analysis", "Competitive Risk Management"],
    'talent|hiring|team|retention|executive|leadership|training|development': ["Executive Search", "Team Augmentation", "Fractional Leadership", "Training & Development"],
    'ai|tech|process|digital|operations|efficiency|implementation|optimization': ["Technology Implementation", "Process Optimization", "Digital Transformation", "Strategic Advisory"],
};

const getIconForItem = (itemText) => {
    const text = itemText.toLowerCase();
    if (text.includes('revenue') || text.includes('financial') || text.includes('profit') || text.includes('sales')) return DollarSign;
    if (text.includes('growth') || text.includes('market') || text.includes('expansion')) return TrendingUp;
    if (text.includes('customer') || text.includes('client') || text.includes('positioning')) return Target;
    if (text.includes('talent') || text.includes('hiring') || text.includes('team') || text.includes('retention')) return Users;
    if (text.includes('executive') || text.includes('leadership')) return User;
    if (text.includes('process') || text.includes('efficiency') || text.includes('operations')) return Cog;
    if (text.includes('tech') || text.includes('digital') || text.includes('data')) return Zap;
    if (text.includes('ai')) return BrainCircuit;
    if (text.includes('strategy') || text.includes('advisory')) return BarChart;
    if (text.includes('consulting') || text.includes('project')) return Briefcase;
    return Lightbulb; // Default icon
};


// --- Child Components ---
const ServiceCard = ({ service, isSelected, onClick }) => {
  const iconMap = {
    'Fractional Leadership': User, 'Project-Based Consulting': Target, 'Executive Search': Search,
    'Team Augmentation': Users, 'Strategic Advisory': BarChart, 'Process Optimization': Cog,
    'Technology Implementation': Settings, 'Competitive Risk Management': AlertTriangle,
    'Digital Transformation': Zap, 'Market Expansion Analysis': TrendingUp,
    'Financial Planning & Analysis': DollarSign, 'Training & Development': Lightbulb
  };
  const Icon = iconMap[service.title] || Target;
  
  return (
    <motion.div whileTap={{ scale: 0.97 }} className="h-full">
      <button type="button" onClick={onClick} className={cn("w-full h-full text-left p-4 rounded-xl border-2 transition-all duration-200", isSelected ? "bg-teal-50 border-teal-500 text-teal-800 shadow-md" : "bg-white border-gray-300 hover:border-gray-400")}>
        <div className="flex items-center justify-between mb-3">
          <div className={cn("p-2 rounded-lg", isSelected ? "bg-teal-100" : "bg-gray-100")}>
            <Icon className={cn("w-5 h-5", isSelected ? "text-teal-600" : "text-gray-600")} />
          </div>
          {isSelected && <Check className="w-4 h-4 text-teal-600" />}
        </div>
        <h4 className={cn("font-semibold text-sm mb-2", isSelected ? "text-teal-900" : "text-gray-900")}>{service.title}</h4>
        <p className={cn("text-xs leading-relaxed", isSelected ? "text-teal-700" : "text-gray-600")}>{service.description}</p>
      </button>
    </motion.div>
  );
};

const DynamicItemCard = ({ item, isSelected, onClick }) => {
    const Icon = getIconForItem(item);
    return (
        <motion.div whileTap={{ scale: 0.97 }} className="h-full">
            <button type="button" onClick={onClick} className={cn("w-full h-full text-left p-3 rounded-lg border-2 text-sm font-medium transition-all duration-200 flex items-center gap-3", isSelected ? "bg-teal-50 border-teal-500 text-teal-800 shadow-sm" : "bg-white border-gray-300 hover:border-gray-400")}>
                <Icon className={cn("w-4 h-4 flex-shrink-0", isSelected ? "text-teal-600" : "text-gray-500")} />
                <span className="flex-grow">{item}</span>
                <div className={cn("w-4 h-4 rounded-sm border-2 flex-shrink-0 flex items-center justify-center", isSelected ? "bg-teal-600 border-teal-600" : "border-gray-400")}>
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
            </button>
        </motion.div>
    );
};

// --- Main Component ---
export default function Step3DynamicTriage({ formData, updateFormData, onNext, onPrevious }) {
  const [triageOptions, setTriageOptions] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(formData.triage || { challenges: [], hiring: [], support: [], additionalDetails: '' });
  const [supportScores, setSupportScores] = useState({});

  useEffect(() => {
    const generateOptions = async () => {
      const { industry, size, name: companyName } = formData.company || {};
      if (!industry || !size) {
        setError("Company industry and size are required to generate personalized options.");
        setIsLoading(false);
        return;
      }

      const prompt = `You are a strategic business consultant AI. For a company named "${companyName}" in the "${industry}" industry with ${size} employees, generate a JSON object with two lists of common priorities.
      Use online data about the company's recent news, job openings, and market position to inform your suggestions. The items should be concise (2-5 words each).

      1.  **challenges**: A list of the top 8 most pressing business and operational challenges.
          -   First, generate a list of highly specific challenges for a company of this profile.
          -   Then, intelligently integrate tailored versions of these three universal themes: **Revenue Growth**, **Talent Management**, and **AI Integration**.
          -   The final list must be de-duplicated to avoid redundancy (e.g., if you generate "Acquiring New Customers", don't also add "Revenue Growth").
          -   Prioritize the final list based on what's most urgent for this company profile, placing the universal themes where they fit best.

      2.  **hiring**: A list of the top 8 immediate hiring priorities, reflecting current market trends and the company's likely needs.

      The final JSON output must be:
      {
        "challenges": ["Challenge 1", "Challenge 2", ...],
        "hiring": ["Hiring Priority 1", "Hiring Priority 2", ...]
      }`;

      try {
        const result = await InvokeLLM({
          prompt,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              challenges: { type: "array", items: { type: "string" } },
              hiring: { type: "array", items: { type: "string" } }
            },
            required: ["challenges", "hiring"]
          }
        });
        
        setTriageOptions({ ...result, support: supportServices });
      } catch (err) {
        console.error("Failed to generate triage options:", err);
        setError("Could not generate personalized options. Please proceed to the next step or go back to verify company info.");
      } finally {
        setIsLoading(false);
      }
    };
    generateOptions();
  }, [formData.company]);

  const handleToggle = (category, item) => {
    const currentSelection = selected[category] || [];
    const isNowSelected = !currentSelection.includes(item);
    
    const newSelection = isNowSelected
      ? [...currentSelection, item]
      : currentSelection.filter(i => i !== item);
    
    const newSelected = { ...selected, [category]: newSelection };
    setSelected(newSelected);
    updateFormData('triage', newSelected);
    
    // Update support scores if toggling challenges or hiring
    if(category === 'challenges' || category === 'hiring') {
        const newScores = { ...supportScores };
        const itemText = item.toLowerCase();
        
        for (const key in supportServiceKeywords) {
            const keywords = key.split('|');
            if (keywords.some(k => itemText.includes(k))) {
                supportServiceKeywords[key].forEach(serviceTitle => {
                    const currentScore = newScores[serviceTitle] || 0;
                    newScores[serviceTitle] = currentScore + (isNowSelected ? 1 : -1);
                });
            }
        }
        setSupportScores(newScores);
    }
  };

  const handleServiceToggle = (service) => {
    const currentSelection = selected.support || [];
    const newSelection = currentSelection.includes(service.title)
      ? currentSelection.filter(s => s !== service.title)
      : [...currentSelection, service.title];
    
    const newSelected = { ...selected, support: newSelection };
    setSelected(newSelected);
    updateFormData('triage', newSelected);
  };

  const handleAdditionalDetailsChange = (e) => {
    const value = e.target.value;
    const newSelected = { ...selected, additionalDetails: value };
    setSelected(newSelected);
    updateFormData('triage', newSelected);
  };
  
  const sortedSupportServices = useMemo(() => {
    return [...supportServices].sort((a, b) => {
        const scoreA = supportScores[a.title] || 0;
        const scoreB = supportScores[b.title] || 0;
        return scoreB - scoreA;
    });
  }, [supportScores]);

  const isValid = Object.values(selected || {}).some(arr => (Array.isArray(arr) ? arr.length > 0 : !!arr));

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Intake & Triage for {formData.company?.industry || 'Your Company'}</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">Let's pinpoint your priorities to accelerate practice growth and client acquisition.</p>
      </div>
      
      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div key="loader" className="flex flex-col items-center justify-center h-96">
              <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
              <p className="mt-4 text-gray-600">Generating personalized options for {formData.company?.name || 'your company'}...</p>
            </motion.div>
          ) : error ? (
            <motion.div key="error" className="flex flex-col items-center justify-center h-96 text-center">
              <AlertTriangle className="w-12 h-12 text-red-500" />
              <p className="mt-4 text-red-700 font-medium">{error}</p>
              <Button onClick={onPrevious} variant="outline" className="mt-4">Go Back to Company Info</Button>
            </motion.div>
          ) : (
            <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {triageOptions?.challenges && (
                <div className="mb-8">
                  <Label className="text-lg font-semibold text-gray-800 block mb-4">What are your most pressing business challenges? <span className="text-gray-500 text-sm">(Select all that apply)</span></Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {triageOptions.challenges.map((item, idx) => (
                      <DynamicItemCard 
                        key={idx} 
                        item={item} 
                        isSelected={(selected.challenges || []).includes(item)} 
                        onClick={() => handleToggle('challenges', item)}
                      />
                    ))}
                  </div>
                </div>
              )}
              
              {triageOptions?.hiring && (
                 <div className="mb-8">
                  <Label className="text-lg font-semibold text-gray-800 block mb-4">What are your immediate hiring priorities? <span className="text-gray-500 text-sm">(Select all that apply)</span></Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {triageOptions.hiring.map((item, idx) => (
                      <DynamicItemCard 
                        key={idx} 
                        item={item} 
                        isSelected={(selected.hiring || []).includes(item)} 
                        onClick={() => handleToggle('hiring', item)}
                      />
                    ))}
                  </div>
                </div>
              )}
              
              <div className="mb-8">
                <Label className="text-lg font-semibold text-gray-800 block mb-4">What type of support are you looking for? <span className="text-gray-500 text-sm">(Select all that apply)</span></Label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  {sortedSupportServices.map((service, idx) => (
                    <ServiceCard 
                      key={idx} 
                      service={service} 
                      isSelected={(selected.support || []).includes(service.title)} 
                      onClick={() => handleServiceToggle(service)}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-2 mt-8">
                <Label htmlFor="additionalDetails" className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">Additional Details & Specific Requirements <span className="text-gray-500 text-sm">(Optional)</span></Label>
                <Textarea 
                  id="additionalDetails" 
                  value={selected.additionalDetails || ''} 
                  onChange={handleAdditionalDetailsChange} 
                  placeholder="Please share any specific requirements, unique challenges, timeline considerations, or additional context that would help us provide the most relevant recommendations for your business..." 
                  rows={5} 
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-8 flex justify-between pt-8 border-t border-gray-200">
          <Button onClick={onPrevious} variant="outline" size="lg"><ArrowLeft className="w-4 h-4 mr-2" /> Back</Button>
          <Button onClick={onNext} disabled={!isValid && !error} size="lg" className="bg-teal-600 hover:bg-teal-700 text-white">Continue & Review <ArrowRight className="w-4 h-4 ml-2" /></Button>
        </div>
      </div>
    </div>
  );
}