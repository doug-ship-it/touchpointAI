import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, Calendar, Network, Building2, Brain, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function IntakeCompletion({ formData }) {
  const navigate = useNavigate();

  const handleNavigate = (url) => {
    navigate(createPageUrl(url));
  };

  const ctaOptions = [
    {
      number: "1",
      icon: Calendar,
      title: "Schedule a 15-Minute Call",
      description: "Get personalized insights and strategic recommendations with one of our Managing Partners.",
      buttonText: "Book a Call",
      action: () => window.open('https://calendly.com/dougsandstedt', '_blank'),
      color: "from-teal-500 to-blue-500"
    },
    {
      number: "2",
      icon: Network,
      title: "Network Intelligence Tool",
      description: "Find people within our network of 9K+ connections that we may be able to introduce you to.",
      buttonText: "Explore Network",
      action: () => handleNavigate('NetworkIntelligenceDeep'),
      color: "from-blue-500 to-purple-500"
    },
    {
      number: "3",
      icon: Building2,
      title: "Intelligent Vendor Network",
      description: "Browse our recommended partners and vendors we've worked with and recommend.",
      buttonText: "View Vendor Network",
      action: () => handleNavigate('VendorMarketplace'),
      color: "from-purple-500 to-pink-500"
    },
    {
      number: "4",
      icon: Brain,
      title: "ArchetypeDNA Assessment",
      description: "Complete our leadership and decision-making style assessment to uncover your unique strengths.",
      buttonText: "Discover Your Archetype",
      action: () => handleNavigate('ArchetypeDNALearning'),
      color: "from-pink-500 to-red-500"
    },
  ];

  return (
    <div className="max-w-4xl mx-auto text-center py-12 px-4">
        <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.2 }}
        >
            <CheckCircle className="mx-auto h-20 w-20 text-teal-500 mb-6" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Thank You!
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-12">
                Thanks for taking the time to share these insights. They've been shared with our internal team to help put together some relevant insights on how we might be able to help in the coming week.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {ctaOptions.map((option, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 + 0.3 }}
                >
                  <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 text-left h-full flex flex-col relative">
                    <div className="absolute -top-3 -left-3 w-8 h-8 bg-teal-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      {option.number}
                    </div>
                    <div className="flex items-center gap-4 mb-4 mt-2">
                      <div className={`p-3 rounded-xl bg-gradient-to-r ${option.color} flex items-center justify-center`}>
                        <option.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-lg font-bold text-gray-900 flex-grow">{option.title}</h3>
                    </div>
                    <p className="text-gray-600 mb-4 flex-grow text-sm">{option.description}</p>
                    <Button 
                      onClick={option.action} 
                      className="mt-auto bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700 text-white"
                      size="sm"
                    >
                      {option.buttonText} <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>

            <Button
                onClick={() => handleNavigate('Home')}
                variant="ghost"
                className="mt-12 text-gray-600 hover:text-teal-600"
            >
                Back to Home
            </Button>
        </motion.div>
    </div>
  );
}