import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import {
  Globe2,
  Users,
  Lock,
  Building2,
  MapPin,
  Loader2,
  ChevronDown,
  ChevronUp,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { shareContact, updateSharedContact } from './SharingService';
import { toast } from 'sonner';

export default function ShareContactDialog({ isOpen, onClose, contact, onShareComplete }) {
  const [privacyLevel, setPrivacyLevel] = useState('public');
  const [shareNotes, setShareNotes] = useState('');
  const [allowIntroRequests, setAllowIntroRequests] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen && contact) {
      // If contact is already shared, load existing settings
      if (contact.is_shared) {
        setPrivacyLevel(contact.share_privacy_level || 'public');
        setShareNotes(contact.share_notes || '');
        setAllowIntroRequests(contact.allow_intro_requests !== false);
      } else {
        // Reset to defaults for new share
        setPrivacyLevel('public');
        setShareNotes('');
        setAllowIntroRequests(true);
      }
      setError(null);
      setShowPreview(false);
    }
  }, [isOpen, contact]);

  const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';

  const handleSubmit = async () => {
    if (!contact) return;

    setIsProcessing(true);
    setError(null);

    try {
      const params = {
        contactId: contact.id,
        privacyLevel,
        shareNotes: shareNotes.trim(),
        allowIntroRequests
      };

      let result;
      if (contact.is_shared && contact.shared_connection_id) {
        // Update existing share
        result = await updateSharedContact({
          ...params,
          sharedConnectionId: contact.shared_connection_id
        });
        
        if (privacyLevel === 'private') {
          toast.success('Contact removed from network');
        } else {
          toast.success('Sharing settings updated successfully');
        }
      } else {
        // New share
        result = await shareContact(params);
        toast.success(`Contact shared successfully! Visible to approximately ${result.visibilityCount} people.`);
      }

      // Call onShareComplete with updated data for optimistic UI update
      onShareComplete({
        contactId: contact.id,
        isShared: privacyLevel !== 'private',
        sharedConnectionId: result.sharedConnectionId,
        privacyLevel: privacyLevel !== 'private' ? privacyLevel : null,
        shareNotes: privacyLevel !== 'private' ? shareNotes.trim() : null,
        allowIntroRequests: privacyLevel !== 'private' ? allowIntroRequests : false
      });
      
    } catch (err) {
      console.error('Share error:', err);
      setError(err.message || 'Failed to share contact. Please try again.');
      toast.error(err.message || 'Failed to share contact');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!contact) return null;

  const privacyOptions = [
    {
      value: 'public',
      title: 'Public',
      description: 'Anyone can discover this contact in the network directory',
      icon: Globe2,
      color: 'green'
    },
    {
      value: 'network_only',
      title: 'Network Only',
      description: 'Only people with mutual connections can see this contact',
      icon: Users,
      color: 'blue'
    }
  ];

  // Add private option if editing existing share
  if (contact.is_shared) {
    privacyOptions.push({
      value: 'private',
      title: 'Private',
      description: 'Remove this contact from Find Connections',
      icon: Lock,
      color: 'gray'
    });
  }

  const charCount = shareNotes.length;
  const maxChars = 500;
  const isOverLimit = charCount > maxChars;
  const isEditing = contact.is_shared === true;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {isEditing ? 'Update Sharing Settings' : `Share ${contact.connection_name} to Find Connections`}
          </DialogTitle>
          <DialogDescription>
            {isEditing 
              ? 'Modify how this contact appears in your network'
              : 'Make this connection discoverable to your network'
            }
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Section 1: Contact Preview Card */}
          <Card className="border-2 border-blue-100 bg-blue-50/50">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                  {getInitials(contact.connection_name)}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl font-bold text-gray-900 mb-1 truncate">
                    {contact.connection_name}
                  </h3>
                  <p className="text-gray-700 mb-2 truncate">
                    {contact.connection_title} {contact.connection_company && `at ${contact.connection_company}`}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {contact.enriched_location && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {contact.enriched_location}
                      </Badge>
                    )}
                    {contact.enriched_industry && (
                      <Badge variant="outline">
                        {contact.enriched_industry}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Privacy Level Selector */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Privacy Level</Label>
            <RadioGroup value={privacyLevel} onValueChange={setPrivacyLevel}>
              <div className="grid gap-3">
                {privacyOptions.map((option) => {
                  const Icon = option.icon;
                  const isSelected = privacyLevel === option.value;
                  
                  return (
                    <div 
                      key={option.value}
                      className={`flex items-start space-x-3 rounded-lg border-2 p-4 cursor-pointer transition-all ${
                        isSelected
                          ? option.color === 'green'
                            ? 'border-green-500 bg-green-50'
                            : option.color === 'blue'
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-500 bg-gray-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                      onClick={() => setPrivacyLevel(option.value)}
                    >
                      <RadioGroupItem value={option.value} id={option.value} className="mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Icon className={`h-4 w-4 ${
                            isSelected
                              ? option.color === 'green'
                                ? 'text-green-600'
                                : option.color === 'blue'
                                ? 'text-blue-600'
                                : 'text-gray-600'
                              : 'text-gray-400'
                          }`} />
                          <Label htmlFor={option.value} className="font-semibold cursor-pointer text-gray-900">
                            {option.title}
                          </Label>
                        </div>
                        <p className="text-sm text-gray-600">
                          {option.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </RadioGroup>
          </div>

          {/* Section 3: Share Notes Field */}
          {privacyLevel !== 'private' && (
            <div className="space-y-2">
              <Label htmlFor="shareNotes" className="text-base font-semibold">
                Why are you sharing this connection? <span className="text-gray-500 font-normal">(Optional)</span>
              </Label>
              <Textarea
                id="shareNotes"
                placeholder="e.g., Great product manager with expertise in B2B SaaS..."
                value={shareNotes}
                onChange={(e) => setShareNotes(e.target.value)}
                className={`min-h-[100px] resize-none ${isOverLimit ? 'border-red-500 focus:ring-red-500' : ''}`}
                maxLength={maxChars + 50}
              />
              <div className="flex justify-between items-center">
                <p className="text-xs text-gray-500">
                  This note helps others understand your connection's expertise and value
                </p>
                <span className={`text-xs font-medium ${isOverLimit ? 'text-red-600' : 'text-gray-500'}`}>
                  {charCount} / {maxChars}
                </span>
              </div>
            </div>
          )}

          {/* Section 4: Introduction Preferences */}
          {privacyLevel !== 'private' && (
            <Card className="border border-gray-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="allowIntroRequests"
                    checked={allowIntroRequests}
                    onCheckedChange={setAllowIntroRequests}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor="allowIntroRequests"
                      className="text-sm font-semibold cursor-pointer"
                    >
                      Allow others to request introductions through me
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">
                      You'll receive requests when others want to connect with this person
                    </p>
                    {!allowIntroRequests && (
                      <div className="flex items-start gap-2 mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded">
                        <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                        <p className="text-xs text-yellow-800">
                          Others can still see this contact but can't request introductions
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Section 5: Preview Section */}
          {privacyLevel !== 'private' && (
            <div>
              <button
                onClick={() => setShowPreview(!showPreview)}
                className="flex items-center justify-between w-full p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-gray-900">Preview in Find Connections</span>
                {showPreview ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>

              <AnimatePresence>
                {showPreview && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-3"
                  >
                    <Card className="border-2 border-dashed border-gray-300 relative">
                      <Badge className={`absolute top-3 right-3 ${
                        privacyLevel === 'public'
                          ? 'bg-green-100 text-green-800 border-green-300'
                          : 'bg-blue-100 text-blue-800 border-blue-300'
                      }`}>
                        {privacyLevel === 'public' ? (
                          <>
                            <Globe2 className="w-3 h-3 mr-1" />
                            Public
                          </>
                        ) : (
                          <>
                            <Users className="w-3 h-3 mr-1" />
                            Network Only
                          </>
                        )}
                      </Badge>
                      
                      <CardContent className="p-4 pt-10">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                            {getInitials(contact.connection_name)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-gray-900 truncate">
                              {contact.connection_name}
                            </h4>
                            <p className="text-sm text-gray-600 truncate">
                              {contact.connection_title}
                            </p>
                            {contact.connection_company && (
                              <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                                <Building2 className="w-3 h-3" />
                                {contact.connection_company}
                              </div>
                            )}
                            {shareNotes && (
                              <blockquote className="border-l-4 border-blue-300 pl-3 text-sm italic text-gray-700 mt-3 py-1 bg-blue-50/50">
                                {shareNotes}
                              </blockquote>
                            )}
                            <div className="flex items-center gap-2 text-xs text-gray-500 mt-3">
                              <span>Shared by You</span>
                              {!allowIntroRequests && (
                                <>
                                  <span>•</span>
                                  <span>Intros disabled</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isProcessing}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isProcessing || isOverLimit}
            className={
              privacyLevel === 'private'
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-blue-600 hover:bg-blue-700'
            }
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : privacyLevel === 'private' ? (
              'Remove from Network'
            ) : isEditing ? (
              'Update Sharing'
            ) : (
              'Share Contact'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}