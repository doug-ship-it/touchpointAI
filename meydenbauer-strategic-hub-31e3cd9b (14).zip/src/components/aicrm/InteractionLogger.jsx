import React, { useState } from 'react';
import { AICRMInteraction } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { PlusCircle, Loader2 } from 'lucide-react';

export default function InteractionLogger({ contactId, onInteractionAdded }) {
    const [notes, setNotes] = useState('');
    const [interactionType, setInteractionType] = useState('call');
    const [isLogging, setIsLogging] = useState(false);

    const handleLogInteraction = async () => {
        if (!notes.trim()) {
            toast.error("Please add some notes for the interaction.");
            return;
        }

        setIsLogging(true);
        try {
            const newInteraction = await AICRMInteraction.create({
                contact_id: contactId,
                interaction_type: interactionType,
                interaction_date: new Date().toISOString(),
                notes: notes,
            });
            toast.success("Interaction logged successfully!");
            setNotes('');
            onInteractionAdded(newInteraction);
        } catch (error) {
            console.error("Failed to log interaction:", error);
            toast.error("Failed to log interaction. Please try again.");
        } finally {
            setIsLogging(false);
        }
    };

    return (
        <div className="bg-white p-4 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-dark-gray mb-3">Log a new interaction</h4>
            <Textarea
                placeholder="Add notes about your call, meeting, email..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mb-3"
            />
            <div className="flex items-center justify-between">
                <Select value={interactionType} onValueChange={setInteractionType}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="call">Call</SelectItem>
                        <SelectItem value="meeting">Meeting</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="linkedin">LinkedIn</SelectItem>
                        <SelectItem value="text">Text</SelectItem>
                        <SelectItem value="in_person">In Person</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                </Select>
                <Button onClick={handleLogInteraction} disabled={isLogging}>
                    {isLogging ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                        <PlusCircle className="h-4 w-4 mr-2" />
                    )}
                    Log Interaction
                </Button>
            </div>
        </div>
    );
}