import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, Calendar, Clock, Users, TrendingDown, AlertCircle,
  CheckCircle, Plus, Edit, Trash2, MessageSquare, Mail,
  Phone, Linkedin, Coffee, Video, Gift
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { NetworkConnection } from '@/api/entities';
import { toast } from 'sonner';

export default function KeepInTouchReminders() {
  const [contacts, setContacts] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [upcomingReminders, setUpcomingReminders] = useState([]);
  const [overdueReminders, setOverdueReminders] = useState([]);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [reminderConfig, setReminderConfig] = useState({
    frequency: 'monthly',
    customDays: 30,
    method: 'email',
    notes: ''
  });

  const categorizeReminders = useCallback(() => {
    const now = new Date();
    const upcoming = [];
    const overdue = [];

    contacts.forEach(contact => {
      if (contact.reminder_next_contact) {
        const reminderDate = new Date(contact.reminder_next_contact);
        const daysDiff = Math.ceil((reminderDate - now) / (1000 * 60 * 60 * 24));
        
        if (daysDiff < 0) {
          overdue.push({ ...contact, daysDiff: Math.abs(daysDiff) });
        } else if (daysDiff <= 7) {
          upcoming.push({ ...contact, daysDiff });
        }
      } else if (contact.last_contact_date) {
        const lastContact = new Date(contact.last_contact_date);
        const daysSinceContact = Math.ceil((now - lastContact) / (1000 * 60 * 60 * 24));
        
        if (daysSinceContact > 90) {
          overdue.push({ ...contact, daysDiff: daysSinceContact, autoSuggested: true });
        }
      }
    });

    setUpcomingReminders(upcoming.sort((a, b) => a.daysDiff - b.daysDiff));
    setOverdueReminders(overdue.sort((a, b) => b.daysDiff - a.daysDiff));
  }, [contacts]);

  useEffect(() => {
    loadContacts();
  }, []);

  useEffect(() => {
    if (contacts.length > 0) {
      categorizeReminders();
    }
  }, [contacts, categorizeReminders]);

  const loadContacts = async () => {
    setIsLoading(true);
    try {
      const allContacts = await NetworkConnection.list('-updated_date');
      setContacts(allContacts);
    } catch (error) {
      console.error('Failed to load contacts:', error);
      toast.error('Failed to load contacts');
    } finally {
      setIsLoading(false);
    }
  };

  const frequencyOptions = [
    { value: 'weekly', label: 'Weekly', days: 7 },
    { value: 'biweekly', label: 'Every 2 Weeks', days: 14 },
    { value: 'monthly', label: 'Monthly', days: 30 },
    { value: 'quarterly', label: 'Quarterly', days: 90 },
    { value: 'biannual', label: 'Twice a Year', days: 180 },
    { value: 'annual', label: 'Annually', days: 365 },
    { value: 'custom', label: 'Custom', days: null }
  ];

  const contactMethods = [
    { value: 'email', label: 'Email', icon: Mail },
    { value: 'phone', label: 'Phone Call', icon: Phone },
    { value: 'linkedin', label: 'LinkedIn Message', icon: Linkedin },
    { value: 'coffee', label: 'Coffee/Lunch', icon: Coffee },
    { value: 'video', label: 'Video Call', icon: Video },
    { value: 'gift', label: 'Send Gift', icon: Gift }
  ];

  const handleSetReminder = (contact) => {
    setSelectedContact(contact);
    setShowReminderModal(true);
    
    if (contact.reminder_frequency) {
      setReminderConfig({
        frequency: contact.reminder_frequency,
        customDays: contact.reminder_custom_days || 30,
        method: contact.reminder_method || 'email',
        notes: contact.reminder_notes || ''
      });
    }
  };

  const saveReminder = async () => {
    if (!selectedContact) return;

    try {
      const days = reminderConfig.frequency === 'custom' 
        ? reminderConfig.customDays 
        : frequencyOptions.find(f => f.value === reminderConfig.frequency)?.days;

      const nextContactDate = new Date();
      nextContactDate.setDate(nextContactDate.getDate() + days);

      await NetworkConnection.update(selectedContact.id, {
        reminder_frequency: reminderConfig.frequency,
        reminder_custom_days: reminderConfig.customDays,
        reminder_method: reminderConfig.method,
        reminder_notes: reminderConfig.notes,
        reminder_next_contact: nextContactDate.toISOString(),
        reminder_set_at: new Date().toISOString()
      });

      toast.success('Reminder set successfully!');
      setShowReminderModal(false);
      setSelectedContact(null);
      setReminderConfig({
        frequency: 'monthly',
        customDays: 30,
        method: 'email',
        notes: ''
      });
      
      await loadContacts();
    } catch (error) {
      console.error('Failed to save reminder:', error);
      toast.error('Failed to save reminder');
    }
  };

  const handleCompleteReminder = async (contact) => {
    try {
      const updateData = {
        last_contact_date: new Date().toISOString()
      };

      if (contact.reminder_frequency) {
        const days = contact.reminder_frequency === 'custom' 
          ? contact.reminder_custom_days 
          : frequencyOptions.find(f => f.value === contact.reminder_frequency)?.days;
        
        const nextContactDate = new Date();
        nextContactDate.setDate(nextContactDate.getDate() + days);
        
        updateData.reminder_next_contact = nextContactDate.toISOString();
        updateData.reminder_last_completed = new Date().toISOString();
      }

      await NetworkConnection.update(contact.id, updateData);
      toast.success('Marked as completed!');
      await loadContacts();
    } catch (error) {
      console.error('Failed to complete reminder:', error);
      toast.error('Failed to update reminder');
    }
  };

  const reminderStats = {
    total: contacts.filter(c => c.reminder_frequency).length,
    upcoming: upcomingReminders.length,
    overdue: overdueReminders.length,
    today: upcomingReminders.filter(r => r.daysDiff === 0).length
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading reminders...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Bell className="w-5 h-5 text-blue-600" />
              <span className="text-3xl font-bold text-blue-600">{reminderStats.total}</span>
            </div>
            <p className="text-sm text-slate-600">Active Reminders</p>
          </CardContent>
        </Card>
        
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-5 h-5 text-green-600" />
              <span className="text-3xl font-bold text-green-600">{reminderStats.upcoming}</span>
            </div>
            <p className="text-sm text-slate-600">Upcoming (7 days)</p>
          </CardContent>
        </Card>
        
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-5 h-5 text-orange-600" />
              <span className="text-3xl font-bold text-orange-600">{reminderStats.overdue}</span>
            </div>
            <p className="text-sm text-slate-600">Overdue</p>
          </CardContent>
        </Card>
        
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Calendar className="w-5 h-5 text-purple-600" />
              <span className="text-3xl font-bold text-purple-600">{reminderStats.today}</span>
            </div>
            <p className="text-sm text-slate-600">Due Today</p>
          </CardContent>
        </Card>
      </div>

      {/* Overdue Reminders */}
      {overdueReminders.length > 0 && (
        <Card className="border-none shadow-xl border-l-4 border-l-orange-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <TrendingDown className="w-5 h-5" />
              Overdue Follow-ups ({overdueReminders.length})
            </CardTitle>
            <CardDescription>
              These contacts need your attention
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {overdueReminders.slice(0, 10).map((contact, idx) => (
                <motion.div
                  key={contact.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center justify-between p-4 bg-orange-50 rounded-lg border border-orange-200"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white font-semibold">
                      {contact.connection_name?.charAt(0) || '?'}
                    </div>
                    <div>
                      <h4 className="font-semibold">
                        {contact.connection_name}
                      </h4>
                      <p className="text-sm text-slate-600">
                        {contact.connection_title} at {contact.connection_company}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="destructive" className="text-xs">
                          {contact.daysDiff} days overdue
                        </Badge>
                        {contact.autoSuggested && (
                          <Badge variant="outline" className="text-xs">
                            Auto-suggested
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {contact.reminder_frequency ? (
                      <>
                        <Button 
                          size="sm" 
                          onClick={() => handleCompleteReminder(contact)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Done
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleSetReminder(contact)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <Button 
                        size="sm" 
                        onClick={() => handleSetReminder(contact)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Plus className="w-4 h-4 mr-1" />
                        Set Reminder
                      </Button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upcoming Reminders */}
      {upcomingReminders.length > 0 && (
        <Card className="border-none shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-green-600" />
              Upcoming Follow-ups (Next 7 Days)
            </CardTitle>
            <CardDescription>
              Stay ahead of your relationships
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingReminders.map((contact, idx) => (
                <motion.div
                  key={contact.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white font-semibold">
                      {contact.connection_name?.charAt(0) || '?'}
                    </div>
                    <div>
                      <h4 className="font-semibold">
                        {contact.connection_name}
                      </h4>
                      <p className="text-sm text-slate-600">
                        {contact.connection_title} at {contact.connection_company}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className="bg-green-100 text-green-700 text-xs">
                          {contact.daysDiff === 0 ? 'Today' : `In ${contact.daysDiff} days`}
                        </Badge>
                        {contact.reminder_method && (
                          <Badge variant="outline" className="text-xs">
                            via {contact.reminder_method}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      onClick={() => handleCompleteReminder(contact)}
                      variant="outline"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Complete
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => handleSetReminder(contact)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Contacts with Reminders */}
      <Card className="border-none shadow-xl">
        <CardHeader>
          <CardTitle>All Reminder Schedules</CardTitle>
          <CardDescription>
            Manage keep-in-touch cadences for all contacts
          </CardDescription>
        </CardHeader>
        <CardContent>
          {contacts.filter(c => c.reminder_frequency).length > 0 ? (
            <div className="space-y-2">
              {contacts.filter(c => c.reminder_frequency).slice(0, 15).map((contact, idx) => {
                const nextContact = contact.reminder_next_contact ? new Date(contact.reminder_next_contact) : new Date();
                const daysUntil = Math.ceil((nextContact - new Date()) / (1000 * 60 * 60 * 24));
                const frequency = frequencyOptions.find(f => f.value === contact.reminder_frequency);
                
                return (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-semibold text-sm">
                        {contact.connection_name?.charAt(0) || '?'}
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">
                          {contact.connection_name}
                        </h4>
                        <p className="text-xs text-slate-600">
                          Next: {nextContact.toLocaleDateString()} ({daysUntil} days)
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {frequency?.label || 'Custom'}
                      </Badge>
                      <Button size="sm" variant="ghost" onClick={() => handleSetReminder(contact)}>
                        <Edit className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              <Bell className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p>No reminders set yet</p>
              <p className="text-sm mt-2">Set up keep-in-touch reminders to maintain strong relationships</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reminder Modal */}
      <AnimatePresence>
        {showReminderModal && selectedContact && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={() => setShowReminderModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6"
            >
              <h3 className="text-2xl font-bold mb-4">
                Set Keep-in-Touch Reminder
              </h3>
              
              <div className="mb-4 p-3 bg-slate-50 rounded-lg">
                <div className="font-semibold">
                  {selectedContact.connection_name}
                </div>
                <div className="text-sm text-slate-600">
                  {selectedContact.connection_title} at {selectedContact.connection_company}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>Contact Frequency</Label>
                  <Select
                    value={reminderConfig.frequency}
                    onValueChange={(value) => setReminderConfig({ ...reminderConfig, frequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {frequencyOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {reminderConfig.frequency === 'custom' && (
                  <div>
                    <Label>Custom Days</Label>
                    <Input
                      type="number"
                      value={reminderConfig.customDays}
                      onChange={(e) => setReminderConfig({ ...reminderConfig, customDays: parseInt(e.target.value) })}
                      min="1"
                    />
                  </div>
                )}

                <div>
                  <Label>Preferred Contact Method</Label>
                  <Select
                    value={reminderConfig.method}
                    onValueChange={(value) => setReminderConfig({ ...reminderConfig, method: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {contactMethods.map(method => (
                        <SelectItem key={method.value} value={method.value}>
                          <div className="flex items-center gap-2">
                            <method.icon className="w-4 h-4" />
                            {method.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Notes (Optional)</Label>
                  <Textarea
                    value={reminderConfig.notes}
                    onChange={(e) => setReminderConfig({ ...reminderConfig, notes: e.target.value })}
                    placeholder="Add context about this relationship..."
                    rows={3}
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowReminderModal(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={saveReminder}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Save Reminder
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}