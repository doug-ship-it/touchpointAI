import React from 'react';
import { Home, Users, Bell, Settings, Database } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { name: 'Dashboard', id: 'dashboard', icon: Home },
  { name: 'Contacts', id: 'contacts', icon: Users },
  { name: 'Reminders', id: 'reminders', icon: Bell },
  { name: 'Network Hub', id: 'network-hub', icon: Database },
];

export default function Sidebar({ setView, activeView = 'contacts' }) {
  return (
    <aside className="w-64 flex-shrink-0 bg-gray-900 p-4 border-r border-gray-700">
      <div className="mb-6">
        <h2 className="text-lg font-bold text-yellow-400 mb-1">Executive CRM</h2>
        <p className="text-xs text-gray-400">Network Intelligence & Relationships</p>
      </div>
      
      <nav className="flex flex-col space-y-2">
        {navItems.map((item) => (
          <button
            key={item.name}
            onClick={() => setView(item.id)}
            className={cn(
              'group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-200',
              activeView === item.id
                ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                : 'text-gray-300 hover:bg-gray-800 hover:text-yellow-400'
            )}
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.name}
          </button>
        ))}
      </nav>
    </aside>
  );
}