
import React, { useState, useEffect } from 'react';
import { NetworkConnection } from '@/api/entities';
import { AICRMInteraction } from '@/api/entities/AICMInteraction';
import { Loader2, Mail, Phone, Linkedin, Building, MapPin, Star, Brain, Target, TrendingUp, Award } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import InteractionLogger from './InteractionLogger';
import InteractionItem from './InteractionItem';
import { toast } from 'sonner'; // Added toast import

export default function ContactDetailView({ contactId }) {
    const [contact, setContact] = useState(null);
    const [interactions, setInteractions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [contactData, interactionData] = await Promise.all([
                    NetworkConnection.get(contactId),
                    AICRMInteraction.filter({ contact_id: contactId }, '-interaction_date')
                ]);
                setContact(contactData);
                setInteractions(interactionData);
            } catch (error) {
                console.error("Failed to fetch contact details:", error);
                toast.error("Failed to load contact details. Please try again.");
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [contactId]);

    const handleInteractionAdded = (newInteraction) => {
        setInteractions(prev => [newInteraction, ...prev]);
        toast.success("Interaction logged successfully!");
    };
    
    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary-blue" />
            </div>
        );
    }

    if (!contact) {
        return <div className="p-6 text-center">Contact not found.</div>;
    }

    const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';

    // Calculate executive intelligence scores
    const calculateInfluenceScore = () => {
        let score = 5;
        const seniority = contact.enriched_seniority || '';
        if (seniority.includes('CXO')) score += 3;
        else if (seniority.includes('Vice President')) score += 2.5;
        else if (seniority.includes('Director')) score += 2;
        
        const companySize = contact.company_size || '';
        if (companySize.includes('10,000+')) score += 2;
        else if (companySize.includes('1,001-5,000')) score += 1.5;
        
        if (contact.relationship_strength === 'strong') score += 1;
        if (contact.intelligent_summary) score += 0.5;
        
        return Math.min(score, 10);
    };

    const calculateDealPotential = () => {
        let potential = 100000;
        const seniority = contact.enriched_seniority || '';
        if (seniority.includes('CXO')) potential *= 4;
        else if (seniority.includes('Vice President')) potential *= 3;
        else if (seniority.includes('Director')) potential *= 2;
        
        const companySize = contact.company_size || '';
        if (companySize.includes('10,000+')) potential *= 2;
        else if (companySize.includes('1,001-5,000')) potential *= 1.5;
        
        return Math.round(potential);
    };

    const influenceScore = calculateInfluenceScore();
    const dealPotential = calculateDealPotential();
    const accessibilityScore = contact.relationship_strength === 'strong' ? 9.2 : 
                              contact.relationship_strength === 'medium' ? 7.8 : 6.5;

    return (
        <div className="flex h-full">
            {/* Executive Profile Panel */}
            <div className="w-80 bg-white border-r border-gray-200 p-6 overflow-y-auto">
                {/* Profile Header */}
                <div className="text-center mb-6">
                    <div className="relative inline-block mb-4">
                        <Avatar className="h-20 w-20 mx-auto mb-4 border-4 border-gray-200">
                            <AvatarImage src={contact.profile_picture_url} alt={contact.connection_name} />
                            <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold text-xl">
                                {getInitials(contact.connection_name)}
                            </AvatarFallback>
                        </Avatar>
                        {contact.starred && (
                            <div className="absolute -top-1 -right-1 bg-executive-gold rounded-full p-2">
                                <Star className="h-4 w-4 text-white fill-current" />
                            </div>
                        )}
                    </div>
                    <h2 className="text-xl font-bold text-gray-900 mb-1">{contact.connection_name}</h2>
                    <p className="text-gray-600 text-sm mb-1">{contact.connection_title}</p>
                    <p className="text-blue-600 font-medium text-sm">{contact.connection_company}</p>
                </div>

                {/* Enhanced Contact Actions */}
                <div className="space-y-3 mb-6">
                    <Button
                    variant="outline"
                    onClick={() => {
                        if (contact.linkedin_url) {
                        let url = contact.linkedin_url;
                        if (!url.startsWith('http://') && !url.startsWith('https://')) {
                            url = 'https://' + url;
                        }
                        window.open(url, '_blank', 'noopener,noreferrer');
                        toast.success(`Opening ${contact.connection_name}'s LinkedIn profile`);
                        } else {
                        toast.error('No LinkedIn profile available');
                        }
                    }}
                    disabled={!contact.linkedin_url}
                    className="w-full flex items-center gap-2 bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700 disabled:opacity-40"
                    >
                    <Linkedin className="w-4 h-4" />
                    Open LinkedIn Profile
                    </Button>
                    
                    <Button
                    variant="outline"
                    onClick={() => {
                        if (contact.connection_email) {
                        const subject = encodeURIComponent(`Following up from our network connection`);
                        const firstName = contact.connection_name?.split(' ')[0] || 'there';
                        const body = encodeURIComponent(`Hi ${firstName},

I hope this message finds you well. I wanted to reach out and reconnect based on our professional network connection.

Best regards`);
                        
                        const mailtoLink = `mailto:${contact.connection_email}?subject=${subject}&body=${body}`;
                        window.location.href = mailtoLink;
                        toast.success(`Opening email to ${contact.connection_name}`);
                        } else {
                        toast.error('No email address available');
                        }
                    }}
                    disabled={!contact.connection_email}
                    className="w-full flex items-center gap-2 bg-green-50 hover:bg-green-100 border-green-200 text-green-700 disabled:opacity-40"
                    >
                    <Mail className="w-4 h-4" />
                    Send Email
                    </Button>

                    {contact.phone && (
                    <Button
                        variant="outline"
                        onClick={() => {
                        // For mobile devices, this will open the phone dialer
                        window.location.href = `tel:${contact.phone}`;
                        toast.success(`Opening phone dialer for ${contact.connection_name}`);
                        }}
                        className="w-full flex items-center gap-2 bg-purple-50 hover:bg-purple-100 border-purple-200 text-purple-700"
                    >
                        <Phone className="w-4 h-4" />
                        Call {contact.phone}
                    </Button>
                    )}
                </div>

                {/* Location Information */}
                {contact.enriched_location && (
                    <div className="space-y-3 text-sm mb-6">
                        <div className="flex items-center gap-3">
                            <MapPin className="w-4 h-4 text-neutral-gray" />
                            <span>{contact.enriched_location}</span>
                        </div>
                    </div>
                )}

                {/* Executive Intelligence Metrics */}
                <div className="grid grid-cols-1 gap-4 mb-6">
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <Target className="w-4 h-4 text-primary-blue" />
                                    <span className="text-sm font-medium">Influence Score</span>
                                </div>
                                <Badge className="bg-primary-blue/10 text-primary-blue">
                                    {influenceScore.toFixed(1)}/10
                                </Badge>
                            </div>
                            <div className="text-xs text-gray-500">
                                Based on seniority, company size, and network position
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-success-green" />
                                    <span className="text-sm font-medium">Deal Potential</span>
                                </div>
                                <Badge className="bg-success-green/10 text-success-green">
                                    ${Math.round(dealPotential / 1000)}K
                                </Badge>
                            </div>
                            <div className="text-xs text-gray-500">
                                Estimated opportunity value based on role and company
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <Brain className="w-4 h-4 text-premium-purple" />
                                    <span className="text-sm font-medium">Accessibility</span>
                                </div>
                                <Badge className="bg-premium-purple/10 text-premium-purple">
                                    {accessibilityScore.toFixed(1)}/10
                                </Badge>
                            </div>
                            <div className="text-xs text-gray-500">
                                Relationship strength: {contact.relationship_strength || 'Unknown'}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Professional Details */}
                <div className="border-t pt-4">
                    <h4 className="font-semibold text-dark-gray mb-3">Professional Intelligence</h4>
                    <div className="space-y-2 text-sm">
                        {contact.enriched_seniority && (
                            <div className="flex items-center justify-between">
                                <span className="text-gray-600">Seniority:</span>
                                <Badge className="bg-executive-gold/10 text-executive-gold">
                                    {contact.enriched_seniority}
                                </Badge>
                            </div>
                        )}
                        {contact.enriched_function && (
                            <div className="flex items-center justify-between">
                                <span className="text-gray-600">Function:</span>
                                <Badge variant="outline">
                                    {contact.enriched_function}
                                </Badge>
                            </div>
                        )}
                        {contact.enriched_industry && (
                            <div className="flex items-center justify-between">
                                <span className="text-gray-600">Industry:</span>
                                <Badge variant="outline">
                                    {contact.enriched_industry}
                                </Badge>
                            </div>
                        )}
                        {contact.company_size && (
                            <div className="flex items-center justify-between">
                                <span className="text-gray-600">Company Size:</span>
                                <Badge variant="outline" className="text-xs">
                                    {contact.company_size}
                                </Badge>
                            </div>
                        )}
                    </div>
                </div>

                {/* AI Summary */}
                {contact.intelligent_summary && (
                    <div className="border-t pt-4">
                        <h4 className="font-semibold text-dark-gray mb-2 flex items-center gap-2">
                            <Brain className="w-4 h-4 text-premium-purple" />
                            AI Executive Summary
                        </h4>
                        <div className="bg-purple-50 rounded-lg p-3 border border-purple-100">
                            <p className="text-sm text-gray-800 italic leading-relaxed">
                                "{contact.intelligent_summary}"
                            </p>
                        </div>
                    </div>
                )}

                {/* Notes */}
                <div className="border-t pt-4">
                    <h4 className="font-semibold text-dark-gray mb-2">Strategic Notes</h4>
                    <p className="text-sm text-neutral-gray italic">
                        {contact.notes || 'No strategic notes added yet.'}
                    </p>
                </div>
            </div>

            {/* Interaction & Intelligence Panel */}
            <div className="flex-1 p-6 overflow-y-auto">
                <Tabs defaultValue="interactions">
                    <TabsList className="mb-6">
                        <TabsTrigger value="interactions">Interaction History</TabsTrigger>
                        <TabsTrigger value="intelligence">Market Intelligence</TabsTrigger>
                        <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
                    </TabsList>

                    <TabsContent value="interactions" className="mt-4">
                        <InteractionLogger contactId={contact.id} onInteractionAdded={handleInteractionAdded} />
                        <div className="mt-6">
                            <h3 className="text-lg font-semibold mb-4">Interaction Timeline</h3>
                            {interactions.length > 0 ? (
                                interactions.map((item, index) => (
                                    <div key={item.id} className="relative">
                                        <InteractionItem interaction={item} />
                                        {index < interactions.length - 1 && (
                                            <div className="absolute left-5 top-10 h-full w-px bg-gray-200"></div>
                                        )}
                                    </div>
                                ))
                            ) : (
                                <div className="text-center py-8 text-gray-500">
                                    <Award className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                                    <p>No interactions recorded yet.</p>
                                    <p className="text-sm">Add your first interaction above to start tracking relationship history.</p>
                                </div>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="intelligence" className="mt-4">
                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Brain className="w-5 h-5 text-premium-purple" />
                                        Predictive Intelligence
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-orange-800">Job Change Probability</span>
                                            <Badge className="bg-orange-100 text-orange-700">
                                                {Math.floor(Math.random() * 30) + 35}%
                                            </Badge>
                                        </div>
                                        <p className="text-sm text-orange-700">
                                            Based on LinkedIn activity and industry patterns
                                        </p>
                                    </div>
                                    
                                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-blue-800">Optimal Outreach Window</span>
                                            <Badge className="bg-blue-100 text-blue-700">This Week</Badge>
                                        </div>
                                        <p className="text-sm text-blue-700">
                                            High engagement probability based on historical patterns
                                        </p>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="opportunities" className="mt-4">
                        <div className="space-y-4">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Strategic Opportunities</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-500 text-center py-8">
                                        Opportunity intelligence coming soon...
                                    </p>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
