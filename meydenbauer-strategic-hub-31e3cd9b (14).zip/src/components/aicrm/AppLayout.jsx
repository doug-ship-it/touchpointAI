import React, { useState } from 'react';
import ExecutiveHeader from './ExecutiveHeader';
import Sidebar from './Sidebar';
import ContactIntelligenceGrid from './ContactIntelligenceGrid';
import ContactDetailView from './ContactDetailView';
import IntelligenceDashboard from './IntelligenceDashboard';
import KeepInTouchReminders from './KeepInTouchReminders';
import NetworkIntelligenceHub from './NetworkIntelligenceHub';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AppLayout() {
  const [activeView, setActiveView] = useState('dashboard');
  const [selectedContactId, setSelectedContactId] = useState(null);
  const [contacts, setContacts] = useState([]);

  const handleSelectContact = (contactId) => {
    setSelectedContactId(contactId);
  };

  const handleBackToList = () => {
    setSelectedContactId(null);
  };

  const handleDashboardNavigation = (section) => {
    switch (section) {
      case 'high-influence':
        setActiveView('contacts');
        break;
      case 'pipeline':
        break;
      case 'job-alerts':
        break;
      case 'c-level':
        setActiveView('contacts');
        break;
      case 'ai-profiles':
        setActiveView('contacts');
        break;
      case 'relationship-health':
        break;
      default:
        break;
    }
  };

  const renderContent = () => {
    if (selectedContactId) {
      return <ContactDetailView contactId={selectedContactId} />;
    }

    switch (activeView) {
      case 'dashboard':
        return <IntelligenceDashboard contacts={contacts} onNavigate={handleDashboardNavigation} />;
      case 'contacts':
        return <ContactIntelligenceGrid onSelectContact={handleSelectContact} />;
      case 'reminders':
        return <KeepInTouchReminders />;
      case 'network-hub':
        return <NetworkIntelligenceHub />;
      default:
        return <IntelligenceDashboard contacts={contacts} onNavigate={handleDashboardNavigation} />;
    }
  };

  const getTitle = () => {
    if (selectedContactId) {
      return "Executive Intelligence Profile";
    }
    switch (activeView) {
      case 'dashboard':
        return 'Intelligence Command Center';
      case 'contacts':
        return 'Executive Network Intelligence';
      case 'reminders':
        return 'Keep-in-Touch Reminders';
      case 'network-hub':
        return 'Network Intelligence Hub';
      default:
        return 'Intelligence Command Center';
    }
  };

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-100 via-gray-50 to-white">
      <Sidebar setView={setActiveView} activeView={activeView} />
      <main className="flex-1 flex flex-col overflow-hidden">
        <ExecutiveHeader />
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {selectedContactId && (
                <Button variant="ghost" size="sm" onClick={handleBackToList}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Network
                </Button>
              )}
              <h1 className="text-xl font-bold text-gray-900">{getTitle()}</h1>
            </div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}