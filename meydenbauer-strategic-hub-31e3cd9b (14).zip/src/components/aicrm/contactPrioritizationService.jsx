/**
 * Contact Prioritization Service
 * Intelligent filtering and sorting for relationship management
 */

class ContactPrioritizationService {
  /**
   * Get top priority contacts based on multiple criteria
   */
  getPriorityContacts(contacts, filters = {}) {
    let filtered = [...contacts];

    // Apply filters
    if (filters.seniority?.length > 0) {
      filtered = filtered.filter(c => 
        filters.seniority.includes(c.enriched_seniority)
      );
    }

    if (filters.industry?.length > 0) {
      filtered = filtered.filter(c => 
        filters.industry.some(ind => 
          c.enriched_industry?.toLowerCase().includes(ind.toLowerCase())
        )
      );
    }

    if (filters.companySize?.length > 0) {
      filtered = filtered.filter(c => 
        filters.companySize.includes(c.company_size)
      );
    }

    if (filters.location?.length > 0) {
      filtered = filtered.filter(c => 
        filters.location.some(loc => 
          c.enriched_location?.toLowerCase().includes(loc.toLowerCase())
        )
      );
    }

    // Score and sort
    const scored = filtered.map(contact => ({
      ...contact,
      priority_score: this.calculatePriorityScore(contact)
    }));

    return scored.sort((a, b) => b.priority_score - a.priority_score);
  }

  /**
   * Calculate priority score (simplified engagement scoring)
   */
  calculatePriorityScore(contact) {
    let score = 50; // Base score

    // Seniority boost
    const seniority = contact.enriched_seniority?.toLowerCase() || '';
    if (seniority.includes('cxo') || seniority.includes('founder') || 
        seniority.includes('ceo') || seniority.includes('president')) {
      score += 30;
    } else if (seniority.includes('vp')) {
      score += 20;
    } else if (seniority.includes('director')) {
      score += 10;
    }

    // Industry boost (target industries)
    const industry = contact.enriched_industry?.toLowerCase() || '';
    const targetIndustries = [
      'software', 'technology', 'saas', 'information technology',
      'private equity', 'investment', 'venture capital',
      'real estate', 'commercial real estate'
    ];
    
    if (targetIndustries.some(target => industry.includes(target))) {
      score += 20;
    }

    // Company size boost (sweet spot)
    if (['51-200', '201-500', '501-1,000'].includes(contact.company_size)) {
      score += 15;
    }

    // Data completeness boost
    const hasLinkedIn = !!contact.linkedin_url;
    const hasEmail = !!(contact.connection_email || contact.email);
    const hasCompany = !!(contact.enriched_company || contact.connection_company);
    
    if (hasLinkedIn && hasEmail && hasCompany) {
      score += 10;
    }

    // Recency penalty (if last contact date available)
    if (contact.last_contact_date) {
      const daysSince = this._daysSince(contact.last_contact_date);
      if (daysSince > 180) score -= 20;
      else if (daysSince > 90) score -= 10;
      else if (daysSince < 30) score += 15;
    }

    return Math.max(0, Math.min(100, score));
  }

  /**
   * Categorize contacts into action buckets
   */
  categorizeByAction(contacts) {
    return {
      immediate_outreach: contacts.filter(c => {
        const score = this.calculatePriorityScore(c);
        const daysSince = c.last_contact_date ? this._daysSince(c.last_contact_date) : 999;
        return score >= 70 && daysSince > 90;
      }),
      
      executive_search_prospects: contacts.filter(c => {
        const seniority = c.enriched_seniority?.toLowerCase() || '';
        return (seniority.includes('cxo') || seniority.includes('vp')) &&
               ['51-200', '201-500', '501-1,000'].includes(c.company_size);
      }),
      
      consulting_targets: contacts.filter(c => {
        const industry = c.enriched_industry?.toLowerCase() || '';
        return (industry.includes('technology') || industry.includes('software')) &&
               ['51-200', '201-500'].includes(c.company_size);
      }),
      
      pe_network: contacts.filter(c => {
        const industry = c.enriched_industry?.toLowerCase() || '';
        return industry.includes('private equity') || 
               industry.includes('venture capital') ||
               industry.includes('investment');
      }),
      
      needs_enrichment: contacts.filter(c => 
        !c.enriched_industry || !c.enriched_seniority || !c.linkedin_url
      )
    };
  }

  /**
   * Generate next action recommendation
   */
  getNextAction(contact) {
    const score = this.calculatePriorityScore(contact);
    const seniority = contact.enriched_seniority?.toLowerCase() || '';
    const daysSince = contact.last_contact_date ? this._daysSince(contact.last_contact_date) : null;

    // High-value reconnection
    if (score >= 70 && daysSince && daysSince > 90) {
      return {
        action: 'Schedule Call',
        type: 'reconnect',
        urgency: 'high',
        template: 'executive_reconnect',
        reason: `High-value ${seniority}, no contact in ${Math.round(daysSince)} days`
      };
    }

    // Executive search opportunity
    if ((seniority.includes('cxo') || seniority.includes('vp')) && score >= 60) {
      return {
        action: 'Pitch Executive Search',
        type: 'sales',
        urgency: 'high',
        template: 'exec_search_intro',
        reason: 'C-level decision maker in target segment'
      };
    }

    // Consulting opportunity
    if (['51-200', '201-500'].includes(contact.company_size)) {
      return {
        action: 'Introduce RevOps Consulting',
        type: 'sales',
        urgency: 'medium',
        template: 'revops_intro',
        reason: 'Company size ideal for operational transformation'
      };
    }

    // General nurture
    if (score >= 40) {
      return {
        action: 'LinkedIn Message',
        type: 'nurture',
        urgency: 'low',
        template: 'relationship_nurture',
        reason: 'Maintain relationship warmth'
      };
    }

    // Enrichment needed
    return {
      action: 'Enrich Profile',
      type: 'data',
      urgency: 'low',
      template: null,
      reason: 'Insufficient data for targeting'
    };
  }

  /**
   * Get quick stats for dashboard
   */
  getQuickStats(contacts) {
    const categorized = this.categorizeByAction(contacts);
    
    return {
      total_contacts: contacts.length,
      immediate_outreach: categorized.immediate_outreach.length,
      executive_search: categorized.executive_search_prospects.length,
      consulting_targets: categorized.consulting_targets.length,
      pe_network: categorized.pe_network.length,
      needs_enrichment: categorized.needs_enrichment.length,
      avg_priority_score: contacts.length > 0
        ? Math.round(
            contacts.reduce((sum, c) => sum + this.calculatePriorityScore(c), 0) / 
            contacts.length
          )
        : 0
    };
  }

  _daysSince(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
}

export const contactPrioritizationService = new ContactPrioritizationService();

// Empty default export
export default function ContactPrioritizationServiceComponent() {
  return null;
}