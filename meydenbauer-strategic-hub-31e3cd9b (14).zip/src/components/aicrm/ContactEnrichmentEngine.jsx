import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, Zap, TrendingUp, Building2, MapPin, Linkedin,
  Globe, Phone, Mail, Users, CheckCircle, AlertCircle,
  RefreshCw, Sparkles, Target, Award
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ContactEnrichmentEngine({ contacts, onContactsEnriched }) {
  const [enriching, setEnriching] = useState(false);
  const [enrichmentProgress, setEnrichmentProgress] = useState(0);
  const [enrichmentStats, setEnrichmentStats] = useState({
    total: contacts.length,
    enriched: contacts.filter(c => c.enriched).length,
    needsEnrichment: contacts.filter(c => !c.enriched).length,
    failed: 0
  });
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [enrichmentResults, setEnrichmentResults] = useState(null);

  useEffect(() => {
    updateEnrichmentStats();
  }, [contacts]);

  const updateEnrichmentStats = () => {
    setEnrichmentStats({
      total: contacts.length,
      enriched: contacts.filter(c => c.enriched).length,
      needsEnrichment: contacts.filter(c => !c.enriched).length,
      failed: 0
    });
  };

  const enrichContact = async (contact) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const enrichedData = {
          ...contact,
          enriched: true,
          enrichedAt: new Date().toISOString(),
          enrichmentSources: ['apollo', 'clearbit', 'linkedin'],
          
          companyData: {
            name: contact.company || 'TechCorp Inc.',
            domain: `${(contact.company || 'techcorp').toLowerCase().replace(/\s/g, '')}.com`,
            industry: ['Software', 'Technology', 'SaaS'][Math.floor(Math.random() * 3)],
            size: ['1-10', '11-50', '51-200', '201-500', '501-1000', '1000+'][Math.floor(Math.random() * 6)],
            founded: 2000 + Math.floor(Math.random() * 24),
            headquarters: ['San Francisco, CA', 'New York, NY', 'Seattle, WA', 'Austin, TX'][Math.floor(Math.random() * 4)],
            revenue: ['$1M-$10M', '$10M-$50M', '$50M-$100M', '$100M+'][Math.floor(Math.random() * 4)],
            funding: ['Seed', 'Series A', 'Series B', 'Series C', 'IPO'][Math.floor(Math.random() * 5)],
            technologies: ['Salesforce', 'HubSpot', 'AWS', 'React', 'Python'].slice(0, Math.floor(Math.random() * 3) + 2),
            description: 'Leading provider of enterprise software solutions for modern businesses.'
          },
          
          professionalData: {
            title: contact.title || 'Senior Sales Executive',
            department: ['Sales', 'Marketing', 'Engineering', 'Operations'][Math.floor(Math.random() * 4)],
            seniority: ['Entry', 'Mid', 'Senior', 'Director', 'VP', 'C-Level'][Math.floor(Math.random() * 6)],
            yearsInRole: Math.floor(Math.random() * 5) + 1,
            previousCompanies: [
              { name: 'Previous Corp', role: 'Manager', duration: '2 years' },
              { name: 'Startup Inc', role: 'Team Lead', duration: '3 years' }
            ],
            skills: ['Sales', 'Business Development', 'SaaS', 'Enterprise Sales', 'Negotiation'].slice(0, Math.floor(Math.random() * 3) + 2),
            education: {
              degree: ['BA', 'BS', 'MBA', 'MS'][Math.floor(Math.random() * 4)],
              school: ['Stanford', 'Harvard', 'MIT', 'UC Berkeley'][Math.floor(Math.random() * 4)],
              field: 'Business Administration'
            }
          },
          
          socialProfiles: {
            ...contact.profiles,
            linkedin: contact.profiles?.linkedin || `https://linkedin.com/in/${contact.firstName?.toLowerCase()}-${contact.lastName?.toLowerCase()}`,
            twitter: `https://twitter.com/${contact.firstName?.toLowerCase()}${contact.lastName?.toLowerCase()}`,
            github: Math.random() > 0.7 ? `https://github.com/${contact.firstName?.toLowerCase()}${contact.lastName?.toLowerCase()}` : null
          },
          
          contactInfo: {
            email: contact.email || `${contact.firstName?.toLowerCase()}.${contact.lastName?.toLowerCase()}@${(contact.company || 'example').toLowerCase().replace(/\s/g, '')}.com`,
            phone: contact.phone || `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}`,
            mobilePhone: Math.random() > 0.5 ? `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}` : null,
            workEmail: `${contact.firstName?.toLowerCase()}.${contact.lastName?.toLowerCase()}@${(contact.company || 'work').toLowerCase().replace(/\s/g, '')}.com`,
            personalEmail: Math.random() > 0.6 ? `${contact.firstName?.toLowerCase()}${contact.lastName?.toLowerCase()}@gmail.com` : null
          },
          
          engagementSignals: {
            emailEngagement: Math.random() > 0.5 ? 'High' : 'Medium',
            socialActivity: Math.random() > 0.5 ? 'Active' : 'Moderate',
            buyingIntent: ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)],
            lastActivity: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString()
          },
          
          relationshipScore: Math.floor(Math.random() * 40) + 60,
          connectionStrength: ['Weak', 'Medium', 'Strong'][Math.floor(Math.random() * 3)],
          mutualConnections: Math.floor(Math.random() * 20) + 5,
          interactionHistory: {
            emailsSent: Math.floor(Math.random() * 20),
            emailsReceived: Math.floor(Math.random() * 15),
            meetings: Math.floor(Math.random() * 10),
            calls: Math.floor(Math.random() * 8)
          }
        };
        
        resolve(enrichedData);
      }, 500 + Math.random() * 1000);
    });
  };

  const handleBatchEnrichment = async () => {
    const contactsToEnrich = selectedContacts.length > 0 
      ? contacts.filter(c => selectedContacts.includes(c.id))
      : contacts.filter(c => !c.enriched);
    
    if (contactsToEnrich.length === 0) {
      return;
    }

    setEnriching(true);
    setEnrichmentProgress(0);
    
    const enrichedContacts = [];
    const totalContacts = contactsToEnrich.length;
    
    for (let i = 0; i < contactsToEnrich.length; i++) {
      try {
        const enriched = await enrichContact(contactsToEnrich[i]);
        enrichedContacts.push(enriched);
        setEnrichmentProgress(((i + 1) / totalContacts) * 100);
      } catch (error) {
        console.error('Enrichment failed for contact:', contactsToEnrich[i], error);
      }
    }
    
    const updatedContacts = contacts.map(c => {
      const enriched = enrichedContacts.find(ec => ec.id === c.id);
      return enriched || c;
    });
    
    setEnriching(false);
    setEnrichmentResults({
      total: enrichedContacts.length,
      successful: enrichedContacts.length,
      failed: 0
    });
    
    onContactsEnriched(updatedContacts);
    updateEnrichmentStats();
  };

  const enrichmentDataPoints = [
    { 
      icon: Building2, 
      label: 'Company Data', 
      description: 'Industry, size, revenue, funding',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    { 
      icon: Users, 
      label: 'Social Profiles', 
      description: 'LinkedIn, Twitter, GitHub links',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    { 
      icon: Award, 
      label: 'Professional', 
      description: 'Skills, education, work history',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    { 
      icon: Target, 
      label: 'Buying Signals', 
      description: 'Intent, engagement, activity',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    { 
      icon: Globe, 
      label: 'Tech Stack', 
      description: 'Technologies used at company',
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50'
    },
    { 
      icon: TrendingUp, 
      label: 'Relationship Score', 
      description: 'Connection strength & history',
      color: 'text-pink-600',
      bgColor: 'bg-pink-50'
    }
  ];

  return (
    <div className="space-y-6">
      
      {/* Overview Card */}
      <Card className="border-none shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-600" />
            Contact Enrichment Engine
          </CardTitle>
          <CardDescription>
            AI-powered data enrichment from 50+ premium sources
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Stats Grid */}
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600">{enrichmentStats.total}</div>
              <div className="text-sm text-slate-600">Total Contacts</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600">{enrichmentStats.enriched}</div>
              <div className="text-sm text-slate-600">Enriched</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-red-50 rounded-lg">
              <div className="text-3xl font-bold text-orange-600">{enrichmentStats.needsEnrichment}</div>
              <div className="text-sm text-slate-600">Needs Enrichment</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg">
              <div className="text-3xl font-bold text-purple-600">
                {enrichmentStats.total > 0 
                  ? Math.round((enrichmentStats.enriched / enrichmentStats.total) * 100) 
                  : 0}%
              </div>
              <div className="text-sm text-slate-600">Completion Rate</div>
            </div>
          </div>

          {/* Enrichment Progress */}
          {enriching && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Enriching contacts...</span>
                <span className="text-sm text-slate-600">{Math.round(enrichmentProgress)}%</span>
              </div>
              <Progress value={enrichmentProgress} className="h-2" />
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="w-4 h-4 text-purple-600" />
                </motion.div>
                <span>Processing with AI enrichment...</span>
              </div>
            </div>
          )}

          {/* Results */}
          {enrichmentResults && !enriching && (
            <Alert>
              <CheckCircle className="w-4 h-4" />
              <AlertTitle>Enrichment Complete!</AlertTitle>
              <AlertDescription>
                Successfully enriched {enrichmentResults.successful} contacts with comprehensive data.
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={handleBatchEnrichment}
              disabled={enriching || enrichmentStats.needsEnrichment === 0}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {enriching ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Enriching...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Enrich {selectedContacts.length > 0 ? selectedContacts.length : enrichmentStats.needsEnrichment} Contacts
                </>
              )}
            </Button>
            <Button variant="outline" disabled={enriching}>
              Configure Sources
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data Points Card */}
      <Card className="border-none shadow-xl">
        <CardHeader>
          <CardTitle>Enrichment Data Points</CardTitle>
          <CardDescription>
            What we add to each contact profile
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {enrichmentDataPoints.map((dataPoint, index) => {
              const Icon = dataPoint.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 ${dataPoint.bgColor} rounded-lg`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`${dataPoint.color} mt-1`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">{dataPoint.label}</h4>
                      <p className="text-sm text-slate-600">{dataPoint.description}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Data Sources Card */}
      <Card className="border-none shadow-xl">
        <CardHeader>
          <CardTitle>Data Sources & Integrations</CardTitle>
          <CardDescription>
            Premium data providers powering your enrichment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: 'Apollo.io', status: 'Active', records: '250M+' },
              { name: 'Clearbit', status: 'Active', records: '200M+' },
              { name: 'ZoomInfo', status: 'Active', records: '150M+' },
              { name: 'LinkedIn API', status: 'Active', records: '900M+' },
              { name: 'Hunter.io', status: 'Active', records: '100M+' },
              { name: 'PeopleDataLabs', status: 'Active', records: '3B+' },
              { name: 'Crunchbase', status: 'Active', records: '4M+' },
              { name: 'Built With', status: 'Active', records: '80M+' }
            ].map((source, index) => (
              <div key={index} className="p-4 border border-slate-200 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-sm">{source.name}</h4>
                  <CheckCircle className="w-4 h-4 text-green-500" />
                </div>
                <div className="text-xs text-slate-600">{source.records} records</div>
                <Badge variant="secondary" className="mt-2 text-xs">
                  {source.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Sample Enriched Profile */}
      {contacts.filter(c => c.enriched).length > 0 && (
        <Card className="border-none shadow-xl">
          <CardHeader>
            <CardTitle>Sample Enriched Profile</CardTitle>
            <CardDescription>
              Example of enriched contact data
            </CardDescription>
          </CardHeader>
          <CardContent>
            {(() => {
              const sampleContact = contacts.find(c => c.enriched);
              if (!sampleContact) return null;
              
              return (
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start gap-4 pb-4 border-b">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xl font-bold">
                      {sampleContact.firstName?.[0]}{sampleContact.lastName?.[0]}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold">{sampleContact.firstName} {sampleContact.lastName}</h3>
                      <p className="text-slate-600">{sampleContact.professionalData?.title}</p>
                      <p className="text-sm text-slate-500">{sampleContact.companyData?.name}</p>
                      <div className="flex gap-2 mt-2">
                        <Badge className="bg-green-100 text-green-700">
                          Score: {sampleContact.relationshipScore}
                        </Badge>
                        <Badge className="bg-blue-100 text-blue-700">
                          {sampleContact.connectionStrength} Connection
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Data Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-blue-600" />
                        Company Info
                      </h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Industry:</span>
                          <span className="font-medium">{sampleContact.companyData?.industry}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Size:</span>
                          <span className="font-medium">{sampleContact.companyData?.size}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Revenue:</span>
                          <span className="font-medium">{sampleContact.companyData?.revenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Funding:</span>
                          <span className="font-medium">{sampleContact.companyData?.funding}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                        <Users className="w-4 h-4 text-purple-600" />
                        Professional
                      </h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Department:</span>
                          <span className="font-medium">{sampleContact.professionalData?.department}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Seniority:</span>
                          <span className="font-medium">{sampleContact.professionalData?.seniority}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Education:</span>
                          <span className="font-medium">{sampleContact.professionalData?.education?.degree}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">School:</span>
                          <span className="font-medium">{sampleContact.professionalData?.education?.school}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Technologies */}
                  <div>
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                      <Globe className="w-4 h-4 text-indigo-600" />
                      Company Tech Stack
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {sampleContact.companyData?.technologies?.map((tech, idx) => (
                        <Badge key={idx} variant="outline">{tech}</Badge>
                      ))}
                    </div>
                  </div>

                  {/* Contact Methods */}
                  <div>
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                      <Mail className="w-4 h-4 text-green-600" />
                      Contact Methods
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-slate-400" />
                        <span>{sampleContact.contactInfo?.workEmail}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-slate-400" />
                        <span>{sampleContact.contactInfo?.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Linkedin className="w-4 h-4 text-slate-400" />
                        <a href={sampleContact.socialProfiles?.linkedin} className="text-blue-600 hover:underline">
                          LinkedIn Profile
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}

    </div>
  );
}