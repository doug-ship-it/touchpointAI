
/**
 * Apollo.io Contact Enrichment Service
 * Handles real-time enrichment with proper error handling, rate limiting, and retry logic
 */

const APOLLO_BASE_URL = 'https://api.apollo.io/v1';
const RATE_LIMIT_DELAY = 1000; // 1 second between requests (Apollo free tier: 60/min)
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;

class ApolloEnrichmentService {
  constructor() {
    this.requestQueue = [];
    this.processing = false;
    this.lastRequestTime = 0;
    this.apiKey = null;
  }

  /**
   * Test if Apollo API is configured and accessible
   */
  async testConnection() {
    try {
      // Try to get API key from window object (set by Vite at build time)
      const apiKey = window?.VITE_APOLLO_API_KEY;
      
      if (!apiKey) {
        console.warn('Apollo API key not found in window.VITE_APOLLO_API_KEY');
        return false;
      }

      this.apiKey = apiKey;

      // Test with a simple API call
      const response = await fetch(`${APOLLO_BASE_URL}/auth/health`, {
        method: 'GET',
        headers: {
          'X-Api-Key': apiKey
        }
      });

      return response.ok;
    } catch (error) {
      console.error('Apollo connection test failed:', error);
      return false;
    }
  }

  /**
   * Get API key safely
   */
  _getApiKey() {
    // Try multiple sources for the API key
    if (this.apiKey) {
      return this.apiKey;
    }

    // Check window object
    if (typeof window !== 'undefined' && window.VITE_APOLLO_API_KEY) {
      this.apiKey = window.VITE_APOLLO_API_KEY;
      return this.apiKey;
    }

    return null;
  }

  /**
   * Enrich a single contact using Apollo.io Person Enrichment API
   */
  async enrichContact(contact) {
    // Check session storage for access
    const hasAccess = sessionStorage.getItem('enrichment_access') === 'granted';
    
    if (!hasAccess) {
      throw new Error('Enrichment access denied. Please authenticate first.');
    }

    const searchParams = this._buildSearchParams(contact);
    
    if (!searchParams) {
      console.warn(`Cannot enrich contact ${contact.id}: insufficient data`);
      return null;
    }

    try {
      const enrichedData = await this._makeApolloRequest('/people/match', searchParams);
      
      if (enrichedData?.person) {
        return this._transformApolloData(enrichedData.person);
      }
      
      return null;
    } catch (error) {
      console.error(`Enrichment failed for contact ${contact.id}:`, error);
      return null;
    }
  }

  /**
   * Enrich multiple contacts with queue management and rate limiting
   */
  async enrichBulk(contacts, onProgress) {
    // Check session storage for access
    const hasAccess = sessionStorage.getItem('enrichment_access') === 'granted';
    
    if (!hasAccess) {
      throw new Error('Enrichment access denied. Please authenticate first.');
    }

    const results = [];
    const total = contacts.length;

    for (let i = 0; i < contacts.length; i++) {
      const contact = contacts[i];
      
      await this._respectRateLimit();
      
      const enrichedData = await this._enrichWithRetry(contact);
      
      results.push({
        contactId: contact.id,
        success: enrichedData !== null,
        data: enrichedData,
        error: enrichedData === null ? 'Enrichment failed or no data found' : null
      });

      if (onProgress) {
        onProgress(i + 1, total, contact, enrichedData);
      }

      if (i < contacts.length - 1) {
        await this._delay(RATE_LIMIT_DELAY);
      }
    }

    return results;
  }

  /**
   * Build search parameters from contact data
   */
  _buildSearchParams(contact) {
    // Priority 1: LinkedIn URL (most accurate)
    if (contact.linkedin_url) {
      return {
        linkedin_url: this._cleanLinkedInUrl(contact.linkedin_url)
      };
    }

    // Priority 2: Name + Company
    const name = contact.connection_name || contact.name || '';
    const company = contact.connection_company || contact.company || '';
    
    if (name && company) {
      const nameParts = name.trim().split(' ');
      const firstName = nameParts[0];
      const lastName = nameParts.slice(1).join(' ') || firstName;

      return {
        first_name: firstName,
        last_name: lastName,
        organization_name: company
      };
    }

    // Priority 3: Email (if available)
    if (contact.connection_email || contact.email) {
      return {
        email: contact.connection_email || contact.email
      };
    }

    return null;
  }

  /**
   * Clean LinkedIn URL to standard format
   */
  _cleanLinkedInUrl(url) {
    return url.split('?')[0].replace(/\/$/, '');
  }

  /**
   * Make Apollo API request with proper headers and error handling
   */
  async _makeApolloRequest(endpoint, params, retryCount = 0) {
    const apiKey = this._getApiKey();
    
    if (!apiKey) {
      throw new Error('Apollo API key not configured. Please contact administrator.');
    }

    try {
      const response = await fetch(`${APOLLO_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'X-Api-Key': apiKey
        },
        body: JSON.stringify(params)
      });

      if (!response.ok) {
        // Handle rate limiting (429)
        if (response.status === 429 && retryCount < MAX_RETRIES) {
          console.warn('Rate limit hit, retrying after delay...');
          await this._delay(RETRY_DELAY * (retryCount + 1));
          return this._makeApolloRequest(endpoint, params, retryCount + 1);
        }

        const errorData = await response.json().catch(() => ({}));
        throw new Error(`Apollo API error ${response.status}: ${errorData.message || response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      if (retryCount < MAX_RETRIES && error.message.includes('fetch')) {
        console.warn(`Request failed, retry ${retryCount + 1}/${MAX_RETRIES}:`, error.message);
        await this._delay(RETRY_DELAY);
        return this._makeApolloRequest(endpoint, params, retryCount + 1);
      }
      throw error;
    }
  }

  /**
   * Transform Apollo person data to our NetworkConnection fields
   */
  _transformApolloData(person) {
    return {
      enriched_industry: person.organization?.industry || person.organization?.industry_tag_id || null,
      enriched_seniority: person.seniority || this._deriveSeniority(person.title) || null,
      enriched_function: person.functions?.[0] || null,
      enriched_location: person.city && person.state 
        ? `${person.city}, ${person.state}` 
        : person.city || person.state || null,
      company_size: person.organization?.estimated_num_employees 
        ? this._formatCompanySize(person.organization.estimated_num_employees)
        : null,
      enriched_title: person.title || null,
      enriched_company: person.organization?.name || null,
      enriched_email: person.email || null,
      enriched_phone: person.phone_numbers?.[0]?.sanitized_number || null,
      twitter_url: person.twitter_url || null,
      intelligent_summary: this._generateIntelligentSummary(person),
      enrichment_source: 'apollo',
      enrichment_date: new Date().toISOString()
    };
  }

  /**
   * Derive seniority from title if not provided
   */
  _deriveSeniority(title) {
    if (!title) return null;
    
    const lowerTitle = title.toLowerCase();
    
    if (lowerTitle.includes('ceo') || lowerTitle.includes('founder') || 
        lowerTitle.includes('president') || lowerTitle.includes('chief')) {
      return 'CXO';
    }
    if (lowerTitle.includes('vp') || lowerTitle.includes('vice president')) {
      return 'VP';
    }
    if (lowerTitle.includes('director')) {
      return 'Director';
    }
    if (lowerTitle.includes('manager') || lowerTitle.includes('head')) {
      return 'Manager';
    }
    
    return 'Individual Contributor';
  }

  /**
   * Format company size into standardized ranges
   */
  _formatCompanySize(empCount) {
    if (empCount <= 10) return '1-10';
    if (empCount <= 50) return '11-50';
    if (empCount <= 200) return '51-200';
    if (empCount <= 500) return '201-500';
    if (empCount <= 1000) return '501-1,000';
    if (empCount <= 5000) return '1,001-5,000';
    if (empCount <= 10000) return '5,001-10,000';
    return '10,000+';
  }

  /**
   * Generate intelligent summary from Apollo data
   */
  _generateIntelligentSummary(person) {
    const parts = [];
    
    if (person.title && person.organization?.name) {
      parts.push(`${person.title} at ${person.organization.name}`);
    }
    
    if (person.seniority) {
      parts.push(`${person.seniority} level`);
    }
    
    if (person.organization?.industry) {
      parts.push(`in ${person.organization.industry}`);
    }
    
    if (person.city && person.state) {
      parts.push(`located in ${person.city}, ${person.state}`);
    }
    
    return parts.join(' • ') || null;
  }

  /**
   * Enrich with retry logic
   */
  async _enrichWithRetry(contact) {
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        return await this.enrichContact(contact);
      } catch (error) {
        if (attempt === MAX_RETRIES - 1) {
          console.error(`Failed to enrich contact ${contact.id} after ${MAX_RETRIES} attempts`);
          return null;
        }
        await this._delay(RETRY_DELAY * (attempt + 1));
      }
    }
    return null;
  }

  /**
   * Rate limiting helper
   */
  async _respectRateLimit() {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < RATE_LIMIT_DELAY) {
      await this._delay(RATE_LIMIT_DELAY - timeSinceLastRequest);
    }
    
    this.lastRequestTime = Date.now();
  }

  /**
   * Delay helper
   */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const apolloEnrichmentService = new ApolloEnrichmentService();

// Empty default export to make this a valid React component file
export default function ApolloEnrichmentServiceComponent() {
  return null;
}
