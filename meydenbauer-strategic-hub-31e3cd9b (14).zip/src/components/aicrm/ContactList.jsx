
import React, { useState, useEffect } from 'react';
import { AICRMContact } from '@/api/entities';
import ContactCard from './ContactCard';
import { Input } from '@/components/ui/input';
import { Loader2, Users } from 'lucide-react';

export default function ContactList({ onSelectContact }) {
  const [contacts, setContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchContacts = async () => {
      setIsLoading(true);
      try {
        const allContacts = await AICRMContact.list();
        setContacts(allContacts);
      } catch (error) {
        console.error("Failed to fetch contacts:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchContacts();
  }, []);

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.company?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full p-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary-blue" />
      </div>
    );
  }

  if (contacts.length === 0) {
    return (
      <div className="p-6 text-center">
        <div className="max-w-md mx-auto">
          <div className="text-center text-gray-700 bg-white p-8 rounded-xl shadow-lg border">
            <Users className="mx-auto h-16 w-16 text-[var(--primary-teal)] mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No Contacts Yet</h3>
            <p className="text-gray-600 mb-6">
              Import your contacts from any platform to get started with AI-powered CRM.
            </p>
            <div className="text-left text-sm bg-gray-50 p-4 rounded-lg border">
              <p><strong>Supported formats:</strong></p>
              <ul className="list-disc list-inside mt-2 space-y-1 text-xs text-gray-600">
                <li>CSV, Excel, PDF files</li>
                <li>LinkedIn connection exports</li>
                <li>CRM data exports</li>
                <li>Any structured contact data</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 h-full overflow-y-auto">
      <div className="mb-6">
        <Input
          placeholder="Search contacts..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredContacts.map(contact => (
          <div key={contact.id} onClick={() => onSelectContact(contact.id)}>
            <ContactCard contact={contact} />
          </div>
        ))}
      </div>
    </div>
  );
}
