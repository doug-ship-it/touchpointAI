/**
 * Engagement Scoring Service
 * Calculates relationship strength and engagement potential
 * Scoring methodology based on McKinsey relationship intelligence frameworks
 */

// Add a dummy password variable for demonstration purposes.
// In a production environment, this should be securely managed (e.g., environment variables, secret management service).
const ENRICHMENT_PASSWORD = "secure_enrichment_key_123";

class EngagementScoringService {
  /**
   * Calculate comprehensive engagement score (0-100)
   * Higher scores = higher priority for outreach
   */
  calculateEngagementScore(contact) {
    // Scoring doesn't need password protection - it's just calculation
    let score = 0;
    const weights = {
      recency: 25,        // When did we last interact?
      frequency: 20,      // How often do we interact?
      seniority: 20,      // Decision-making authority
      firmographics: 15,  // Company fit for services
      dataCompleteness: 10, // Profile richness
      networkValue: 10    // Referral potential
    };

    // Recency Score (0-25 points)
    score += this._calculateRecencyScore(contact) * (weights.recency / 100);

    // Frequency Score (0-20 points)
    score += this._calculateFrequencyScore(contact) * (weights.frequency / 100);

    // Seniority Score (0-20 points)
    score += this._calculateSeniorityScore(contact) * (weights.seniority / 100);

    // Firmographics Score (0-15 points)
    score += this._calculateFirmographicsScore(contact) * (weights.firmographics / 100);

    // Data Completeness Score (0-10 points)
    score += this._calculateCompletenessScore(contact) * (weights.dataCompleteness / 100);

    // Network Value Score (0-10 points)
    score += this._calculateNetworkValueScore(contact) * (weights.networkValue / 100);

    return Math.round(score);
  }

  /**
   * Recency: How recently did we interact?
   * 0-30 days = 100 points, 31-90 days = 70, 91-180 = 40, 180+ = 10
   */
  _calculateRecencyScore(contact) {
    if (!contact.last_contact_date) return 10; // No interaction = minimal score

    const daysSinceContact = this._daysSince(contact.last_contact_date);
    
    if (daysSinceContact <= 30) return 100;
    if (daysSinceContact <= 90) return 70;
    if (daysSinceContact <= 180) return 40;
    return 10;
  }

  /**
   * Frequency: How often do we interact?
   * Based on total_interactions field
   */
  _calculateFrequencyScore(contact) {
    const interactions = contact.total_interactions || 0;
    
    if (interactions >= 20) return 100;
    if (interactions >= 10) return 75;
    if (interactions >= 5) return 50;
    if (interactions >= 2) return 25;
    return 0;
  }

  /**
   * Seniority: Decision-making authority
   * CXO = 100, VP = 80, Director = 60, Manager = 40, IC = 20
   */
  _calculateSeniorityScore(contact) {
    const seniority = (contact.enriched_seniority || '').toLowerCase();
    
    if (seniority.includes('cxo') || seniority.includes('founder') || 
        seniority.includes('ceo') || seniority.includes('president')) {
      return 100;
    }
    if (seniority.includes('vp') || seniority.includes('vice president')) {
      return 80;
    }
    if (seniority.includes('director')) {
      return 60;
    }
    if (seniority.includes('manager') || seniority.includes('head')) {
      return 40;
    }
    return 20;
  }

  /**
   * Firmographics: Company fit for Meydenbauer services
   * PE-backed, high-growth tech, 50-1000 employees = ideal
   */
  _calculateFirmographicsScore(contact) {
    let score = 0;

    // Company size (0-50 points)
    const companySize = contact.company_size || '';
    if (['51-200', '201-500', '501-1,000'].includes(companySize)) {
      score += 50; // Sweet spot for consulting
    } else if (['11-50', '1,001-5,000'].includes(companySize)) {
      score += 30; // Acceptable range
    } else {
      score += 10; // Too small or too large
    }

    // Industry alignment (0-50 points)
    const industry = (contact.enriched_industry || '').toLowerCase();
    const targetIndustries = [
      'software', 'technology', 'saas', 'information technology',
      'private equity', 'investment', 'venture capital',
      'real estate', 'commercial real estate'
    ];
    
    const isTargetIndustry = targetIndustries.some(target => 
      industry.includes(target)
    );
    
    score += isTargetIndustry ? 50 : 20;

    return score;
  }

  /**
   * Data Completeness: Profile richness
   * More data = better targeting capability
   */
  _calculateCompletenessScore(contact) {
    let filledFields = 0;
    const totalFields = 8;

    if (contact.linkedin_url) filledFields++;
    if (contact.connection_email || contact.email) filledFields++;
    if (contact.enriched_title || contact.connection_title) filledFields++;
    if (contact.enriched_company || contact.connection_company) filledFields++;
    if (contact.enriched_industry) filledFields++;
    if (contact.enriched_location) filledFields++;
    if (contact.company_size) filledFields++;
    if (contact.phone) filledFields++;

    return (filledFields / totalFields) * 100;
  }

  /**
   * Network Value: Referral potential
   * Based on number of connections, industry influence
   */
  _calculateNetworkValueScore(contact) {
    let score = 50; // Base score

    // Boost for CXO/Founder (likely well-connected)
    const seniority = (contact.enriched_seniority || '').toLowerCase();
    if (seniority.includes('cxo') || seniority.includes('founder')) {
      score += 30;
    }

    // Boost for PE/VC (high referral potential)
    const industry = (contact.enriched_industry || '').toLowerCase();
    if (industry.includes('private equity') || industry.includes('venture')) {
      score += 20;
    }

    return Math.min(100, score);
  }

  /**
   * Generate engagement tier classification
   */
  getEngagementTier(score) {
    if (score >= 80) return { tier: 'Hot', color: 'red', priority: 1 };
    if (score >= 60) return { tier: 'Warm', color: 'orange', priority: 2 };
    if (score >= 40) return { tier: 'Lukewarm', color: 'yellow', priority: 3 };
    if (score >= 20) return { tier: 'Cold', color: 'blue', priority: 4 };
    return { tier: 'Inactive', color: 'gray', priority: 5 };
  }

  /**
   * Generate actionable recommendations
   */
  generateRecommendations(contact, score) {
    const recommendations = [];
    const tier = this.getEngagementTier(score);

    // Recency-based recommendations
    const daysSinceContact = contact.last_contact_date 
      ? this._daysSince(contact.last_contact_date)
      : null;

    if (!daysSinceContact || daysSinceContact > 90) {
      recommendations.push({
        type: 'reconnect',
        urgency: 'high',
        action: 'Schedule reconnection call',
        reason: daysSinceContact > 180 ? 'No contact in 6+ months' : 'Relationship cooling'
      });
    }

    // Seniority-based recommendations
    if (score >= 70 && (contact.enriched_seniority || '').includes('CXO')) {
      recommendations.push({
        type: 'executive_search',
        urgency: 'high',
        action: 'Pitch executive search services',
        reason: 'C-level decision maker in target segment'
      });
    }

    // Firmographics-based recommendations
    if (contact.company_size && ['51-200', '201-500'].includes(contact.company_size)) {
      recommendations.push({
        type: 'consulting',
        urgency: 'medium',
        action: 'Introduce RevOps consulting',
        reason: 'Company size ideal for operational transformation'
      });
    }

    // Data quality recommendations
    if (score < 50 && !(contact.connection_email || contact.email)) {
      recommendations.push({
        type: 'data_enrichment',
        urgency: 'low',
        action: 'Run Apollo enrichment', // This suggests an enrichment process
        reason: 'Missing contact information'
      });
    }

    return recommendations;
  }

  /**
   * Perform actual data enrichment on a contact object.
   * This method is password protected and represents a 'data enrichment feature'.
   *
   * @param {Object} contact The contact object to potentially enrich.
   * @param {string} password The password to authorize the enrichment operation.
   * @returns {Object} A new contact object with simulated enriched data, or the original if no enrichment is applied.
   * @throws {Error} If the provided password does not match the enrichment key.
   */
  performDataEnrichment(contact, password) {
    if (password !== ENRICHMENT_PASSWORD) {
      throw new Error('Unauthorized: Incorrect password for data enrichment features.');
    }

    // This is a placeholder for actual data enrichment logic.
    // In a real application, this would involve calling external APIs (e.g., Apollo, Clearbit, ZoomInfo).
    // For demonstration, we'll simulate adding or updating some enriched fields.
    const enrichedContact = { ...contact }; // Create a shallow copy

    if (!enrichedContact.enriched_title && contact.connection_title) {
      enrichedContact.enriched_title = `Enriched: ${contact.connection_title}`;
    }
    if (!enrichedContact.enriched_seniority) {
      enrichedContact.enriched_seniority = 'Enriched IC'; // Default if not present
    }
    if (!enrichedContact.enriched_industry) {
      enrichedContact.enriched_industry = 'Enriched Technology Services';
    }
    if (!enrichedContact.company_size) {
      enrichedContact.company_size = '201-500'; // Assume an ideal size
    }
    if (!enrichedContact.linkedin_url && contact.name) {
        enrichedContact.linkedin_url = `https://linkedin.com/search?q=${encodeURIComponent(contact.name)}`;
    }
    
    console.log(`Contact ${contact.name || contact.id || 'unknown'} successfully processed for enrichment.`);
    return enrichedContact;
  }

  /**
   * Helper: Calculate days since date
   */
  _daysSince(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
}

export const engagementScoringService = new EngagementScoringService();

// Empty default export to make this a valid React component file
export default function EngagementScoringServiceComponent() {
  return null;
}