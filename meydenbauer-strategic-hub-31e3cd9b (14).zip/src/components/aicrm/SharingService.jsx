import { User } from '@/api/entities';
import { NetworkConnection } from '@/api/entities';

/**
 * Share a contact to the Find Connections network
 */
export async function shareContact(params) {
  const {
    contactId,
    privacyLevel,
    shareNotes,
    allowIntroRequests
  } = params;

  try {
    const user = await User.me();
    
    // Update the contact with sharing information
    const updatedContact = await NetworkConnection.update(contactId, {
      is_shared: true,
      share_privacy_level: privacyLevel,
      share_notes: shareNotes || null,
      allow_intro_requests: allowIntroRequests,
      share_date: new Date().toISOString(),
      shared_by_user_email: user.email,
      shared_connection_id: contactId
    });

    // Estimate visibility count based on privacy level
    let visibilityCount = 0;
    if (privacyLevel === 'public') {
      visibilityCount = Math.floor(Math.random() * 500) + 100; // 100-600
    } else if (privacyLevel === 'network_only') {
      visibilityCount = Math.floor(Math.random() * 100) + 20; // 20-120
    }

    return {
      success: true,
      sharedConnectionId: updatedContact.id,
      visibilityCount,
      message: 'Contact shared successfully'
    };
  } catch (error) {
    console.error('Error sharing contact:', error);
    throw new Error(error.message || 'Failed to share contact');
  }
}

/**
 * Update an existing shared contact
 */
export async function updateSharedContact(params) {
  const {
    contactId,
    sharedConnectionId,
    privacyLevel,
    shareNotes,
    allowIntroRequests
  } = params;

  try {
    const user = await User.me();

    // If privacy level is set to private, remove from sharing
    if (privacyLevel === 'private') {
      return await unshareContact({ contactId, sharedConnectionId });
    }

    // Update the contact with new sharing information
    const updatedContact = await NetworkConnection.update(contactId, {
      is_shared: true,
      share_privacy_level: privacyLevel,
      share_notes: shareNotes || null,
      allow_intro_requests: allowIntroRequests,
      share_updated_date: new Date().toISOString()
    });

    return {
      success: true,
      sharedConnectionId: updatedContact.id,
      message: 'Sharing settings updated successfully'
    };
  } catch (error) {
    console.error('Error updating shared contact:', error);
    throw new Error(error.message || 'Failed to update shared contact');
  }
}

/**
 * Remove a contact from sharing (unshare)
 */
export async function unshareContact(params) {
  const { contactId, sharedConnectionId } = params;

  try {
    const user = await User.me();

    // Update the contact to remove sharing
    const updatedContact = await NetworkConnection.update(contactId, {
      is_shared: false,
      share_privacy_level: null,
      share_notes: null,
      allow_intro_requests: false,
      share_removed_date: new Date().toISOString()
    });

    return {
      success: true,
      message: 'Contact removed from network successfully'
    };
  } catch (error) {
    console.error('Error unsharing contact:', error);
    throw new Error(error.message || 'Failed to unshare contact');
  }
}

// Empty default export to make this a valid component file
export default function SharingService() {
  return null;
}