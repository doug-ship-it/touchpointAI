import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  Users, 
  AlertTriangle, 
  Crown, 
  Brain,
  DollarSign,
  Activity,
  ChevronRight,
  RefreshCw,
  Eye,
  MessageCircle,
  Calendar,
  Bell
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const IntelligenceMetric = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  color, 
  trend, 
  confidence, 
  lastUpdated,
  onClick,
  onQuickAction,
  preview 
}) => {
  const [showPreview, setShowPreview] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      className="relative"
      onMouseEnter={() => setShowPreview(true)}
      onMouseLeave={() => setShowPreview(false)}
    >
      <Card 
        className={`cursor-pointer transition-all duration-300 hover:shadow-xl border-l-4 ${color} relative overflow-hidden`}
        onClick={onClick}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-gray-50/50" />
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
          <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
          <Icon className={`h-5 w-5 ${color.replace('border-l-', 'text-')}`} />
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="text-2xl font-bold text-gray-900 mb-1">{value}</div>
          <p className="text-xs text-gray-500 mb-2">{subtitle}</p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {trend && (
                <Badge variant="outline" className="text-xs">
                  {trend > 0 ? '↗' : '↘'} {Math.abs(trend)}%
                </Badge>
              )}
              <Badge variant="secondary" className="text-xs">
                {confidence}% confidence
              </Badge>
            </div>
            <ChevronRight className="h-4 w-4 text-gray-400" />
          </div>
          
          <div className="text-xs text-gray-400 mt-2">
            Updated {lastUpdated}
          </div>
        </CardContent>

        {showPreview && preview && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute inset-0 bg-white/95 backdrop-blur-sm p-4 z-20 flex flex-col justify-center"
          >
            <h4 className="font-semibold text-gray-900 mb-2">Quick Preview</h4>
            <div className="text-sm text-gray-700 space-y-1">
              {preview.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span>{item.label}:</span>
                  <span className="font-medium">{item.value}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-3">
              {onQuickAction && (
                <Button size="sm" variant="outline" className="text-xs" onClick={onQuickAction}>
                  Quick Action
                </Button>
              )}
              <Button size="sm" className="text-xs">
                View Details
              </Button>
            </div>
          </motion.div>
        )}
      </Card>
    </motion.div>
  );
};

export default function IntelligenceDashboard({ contacts, onNavigate }) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const metrics = React.useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    let overdueCount = 0;
    let upcomingWeekCount = 0;
    let todayCount = 0;

    contacts.forEach(contact => {
      if (contact.reminder_next_contact) {
        const reminderDate = new Date(contact.reminder_next_contact);
        const startOfReminderDate = new Date(reminderDate.getFullYear(), reminderDate.getMonth(), reminderDate.getDate());
        
        const timeDiff = startOfReminderDate.getTime() - startOfToday.getTime();
        const daysDiff = timeDiff / (1000 * 60 * 60 * 24);
        
        if (daysDiff < 0) overdueCount++;
        else if (daysDiff === 0) todayCount++;
        else if (daysDiff > 0 && daysDiff <= 7) upcomingWeekCount++;
      } else if (contact.last_contact_date) {
        const lastContact = new Date(contact.last_contact_date);
        const startOfLastContact = new Date(lastContact.getFullYear(), lastContact.getMonth(), lastContact.getDate());
        const daysSinceContact = (startOfToday.getTime() - startOfLastContact.getTime()) / (1000 * 60 * 60 * 24);
        if (daysSinceContact > 90) overdueCount++;
      }
    });
    
    const highInfluenceExecs = contacts.filter(c => c.influence_score >= 8.5);
    const totalPipeline = contacts.reduce((sum, c) => sum + (c.deal_potential || 0), 0);
    const jobChangeAlerts = contacts.filter(c => (c.job_change_probability || 0) >= 40);
    const cLevelExecs = contacts.filter(c => 
      (c.enriched_seniority && (c.enriched_seniority.includes('CXO') || c.enriched_seniority.includes('CEO'))) ||
      (c.connection_title && /\b(ceo|cfo|cto|cmo|chief|founder|president)\b/i.test(c.connection_title))
    );
    const aiEnhancedProfiles = contacts.filter(c => 
      c.intelligent_summary && c.intelligent_summary.length > 50
    );
    const avgRelationshipHealth = contacts.length > 0 
      ? contacts.reduce((sum, c) => sum + (c.accessibility_score || 5), 0) / contacts.length 
      : 0;

    return {
      highInfluence: {
        count: highInfluenceExecs.length,
        contacts: highInfluenceExecs.slice(0, 3),
        trend: 12,
        confidence: 87
      },
      pipeline: {
        value: totalPipeline,
        formatted: `$${(totalPipeline / 1000000).toFixed(1)}M`,
        trend: 8,
        confidence: 76
      },
      jobAlerts: {
        count: jobChangeAlerts.length,
        highPriority: jobChangeAlerts.filter(c => c.job_change_probability >= 60).length,
        trend: -5,
        confidence: 82
      },
      cLevel: {
        count: cLevelExecs.length,
        contacts: cLevelExecs.slice(0, 2),
        trend: 25,
        confidence: 95
      },
      aiProfiles: {
        count: aiEnhancedProfiles.length,
        percentage: Math.round((aiEnhancedProfiles.length / contacts.length) * 100),
        trend: 15,
        confidence: 91
      },
      relationshipHealth: {
        score: avgRelationshipHealth.toFixed(1),
        status: avgRelationshipHealth >= 7 ? 'Excellent' : avgRelationshipHealth >= 5 ? 'Good' : 'Needs Attention',
        trend: 3,
        confidence: 89
      },
      reminders: {
        overdue: overdueCount,
        upcomingWeek: upcomingWeekCount,
        today: todayCount
      }
    };
  }, [contacts]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setLastRefresh(new Date());
    setIsRefreshing(false);
    toast.success('Intelligence data refreshed successfully');
  };

  const formatTimeAgo = (date) => {
    const minutes = Math.floor((new Date() - date) / (1000 * 60));
    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Intelligence Command Center</h2>
          <p className="text-gray-600">Real-time business intelligence and relationship insights</p>
        </div>
        <Button 
          onClick={handleRefresh} 
          disabled={isRefreshing}
          variant="outline"
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Refreshing...' : 'Refresh Data'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <IntelligenceMetric
          title="High-Influence Executives"
          value={metrics.highInfluence.count}
          subtitle="Network decision makers with high ROI potential"
          icon={Crown}
          color="border-l-yellow-500"
          trend={metrics.highInfluence.trend}
          confidence={metrics.highInfluence.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('high-influence')}
          preview={[
            { label: 'Avg Influence Score', value: '8.7/10' },
            { label: 'C-Level Percentage', value: '78%' },
            { label: 'Pipeline Contribution', value: '$2.4M' }
          ]}
          onQuickAction={() => toast.info('Opening executive outreach templates...')}
        />

        <IntelligenceMetric
          title="Total Pipeline Value"
          value={metrics.pipeline.formatted}
          subtitle="Weighted opportunities across all relationships"
          icon={DollarSign}
          color="border-l-green-500"
          trend={metrics.pipeline.trend}
          confidence={metrics.pipeline.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('pipeline')}
          preview={[
            { label: 'Hot Deals (>80%)', value: '$1.2M' },
            { label: 'Warm Prospects', value: '$3.8M' },
            { label: 'Q4 Forecast', value: '$2.1M' }
          ]}
          onQuickAction={() => toast.info('Opening pipeline review dashboard...')}
        />

        <IntelligenceMetric
          title="Job Change Alerts"
          value={metrics.jobAlerts.count}
          subtitle={`${metrics.jobAlerts.highPriority} high-priority transitions detected`}
          icon={AlertTriangle}
          color="border-l-orange-500"
          trend={metrics.jobAlerts.trend}
          confidence={metrics.jobAlerts.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('job-alerts')}
          preview={[
            { label: 'C-Level Moves', value: '8' },
            { label: 'New Companies', value: '12' },
            { label: 'Opportunity Score', value: '7.3/10' }
          ]}
          onQuickAction={() => toast.info('Sending congratulatory messages...')}
        />

        <IntelligenceMetric
          title="Keep-in-Touch Reminders"
          value={metrics.reminders.overdue + metrics.reminders.upcomingWeek + metrics.reminders.today}
          subtitle={`${metrics.reminders.overdue} overdue, ${metrics.reminders.today} due today`}
          icon={Bell}
          color="border-l-indigo-500"
          trend={metrics.reminders.overdue > 5 ? -10 : 5}
          confidence={95}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('reminders')}
          preview={[
            { label: 'Overdue Follow-ups', value: metrics.reminders.overdue },
            { label: 'Due This Week', value: metrics.reminders.upcomingWeek },
            { label: 'Due Today', value: metrics.reminders.today }
          ]}
          onQuickAction={() => toast.info('Opening reminder dashboard...')}
        />

        <IntelligenceMetric
          title="C-Level Executives"
          value={metrics.cLevel.count}
          subtitle="Top decision makers in your network"
          icon={Users}
          color="border-l-purple-500"
          trend={metrics.cLevel.trend}
          confidence={metrics.cLevel.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('c-level')}
          preview={[
            { label: 'Fortune 500', value: '4 execs' },
            { label: 'Startups', value: '8 founders' },
            { label: 'Avg Company Size', value: '2.4K employees' }
          ]}
          onQuickAction={() => toast.info('Scheduling executive briefings...')}
        />

        <IntelligenceMetric
          title="AI-Enhanced Profiles"
          value={metrics.aiProfiles.count}
          subtitle={`${metrics.aiProfiles.percentage}% of network has AI insights`}
          icon={Brain}
          color="border-l-blue-500"
          trend={metrics.aiProfiles.trend}
          confidence={metrics.aiProfiles.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('ai-profiles')}
          preview={[
            { label: 'Communication Styles', value: '156 analyzed' },
            { label: 'Business Priorities', value: '134 identified' },
            { label: 'Engagement Strategies', value: '89 generated' }
          ]}
          onQuickAction={() => toast.info('Running AI enhancement batch...')}
        />

        <IntelligenceMetric
          title="Relationship Health"
          value={metrics.relationshipHealth.score}
          subtitle={`Network status: ${metrics.relationshipHealth.status}`}
          icon={Activity}
          color="border-l-teal-500"
          trend={metrics.relationshipHealth.trend}
          confidence={metrics.relationshipHealth.confidence}
          lastUpdated={formatTimeAgo(lastRefresh)}
          onClick={() => onNavigate('relationship-health')}
          preview={[
            { label: 'Strong Relationships', value: '67' },
            { label: 'Need Attention', value: '23' },
            { label: 'Response Rate', value: '78%' }
          ]}
          onQuickAction={() => toast.info('Scheduling relationship maintenance...')}
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Live Intelligence Alerts
            </CardTitle>
            <Badge variant="secondary">{metrics.jobAlerts.count + 8} active</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg"
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <div>
                  <p className="font-medium text-gray-900">Sarah Chen moved to TechCorp as CTO</p>
                  <p className="text-sm text-gray-600">High-priority contact • Strong relationship • $500K+ opportunity</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  Congratulate
                </Button>
                <Button size="sm">
                  <Eye className="h-4 w-4 mr-1" />
                  Analyze
                </Button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg"
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                <div>
                  <p className="font-medium text-gray-900">InnovateCorp raised $50M Series B</p>
                  <p className="text-sm text-gray-600">3 contacts at this company • Medium opportunity</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <Calendar className="h-4 w-4 mr-1" />
                  Schedule
                </Button>
                <Button size="sm">
                  <Eye className="h-4 w-4 mr-1" />
                  Review
                </Button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg"
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <div>
                  <p className="font-medium text-gray-900">Michael Rodriguez engaged with your content</p>
                  <p className="text-sm text-gray-600">High engagement score • Follow-up recommended</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  Follow Up
                </Button>
                <Button size="sm">
                  <Eye className="h-4 w-4 mr-1" />
                  Details
                </Button>
              </div>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Action Commands</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
              <MessageCircle className="h-6 w-6 mb-2 text-blue-500" />
              <span className="text-sm">Batch Outreach</span>
            </Button>
            <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
              <Calendar className="h-6 w-6 mb-2 text-green-500" />
              <span className="text-sm">Schedule Meetings</span>
            </Button>
            <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
              <Brain className="h-6 w-6 mb-2 text-purple-500" />
              <span className="text-sm">AI Insights</span>
            </Button>
            <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
              <TrendingUp className="h-6 w-6 mb-2 text-orange-500" />
              <span className="text-sm">Pipeline Review</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}