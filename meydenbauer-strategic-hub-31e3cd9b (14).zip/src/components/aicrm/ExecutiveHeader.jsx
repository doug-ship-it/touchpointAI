import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign, Users, Brain, Target, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { NetworkConnection } from '@/api/entities';

export default function ExecutiveHeader() {
  const [networkStats, setNetworkStats] = useState({
    totalContacts: 0,
    cxoContacts: 0,
    enrichedContacts: 0,
    strongRelationships: 0,
    estimatedPipeline: 0,
    networkHealthScore: 0
  });

  useEffect(() => {
    const calculateNetworkStats = async () => {
      try {
        const contacts = await NetworkConnection.list();
        
        // More accurate CXO identification
        const cxoContacts = contacts.filter(c => {
          const title = c.connection_title?.toLowerCase() || '';
          const seniority = c.enriched_seniority?.toLowerCase() || '';
          return (
            seniority.includes('cxo') || 
            seniority.includes('ceo') ||
            seniority.includes('cfo') ||
            seniority.includes('cto') ||
            seniority.includes('cmo') ||
            title.includes('ceo') ||
            title.includes('cfo') ||
            title.includes('cto') ||
            title.includes('cmo') ||
            title.includes('chief') ||
            seniority.includes('founder') ||
            seniority.includes('owner')
          );
        }).length;
        
        const enrichedContacts = contacts.filter(c => c.intelligent_summary?.length > 0).length;
        const strongRelationships = contacts.filter(c => c.relationship_strength === 'strong').length;
        
        // More realistic pipeline calculation
        const estimatedPipeline = contacts.reduce((total, contact) => {
          let value = 25000; // More realistic base value
          
          // Seniority multiplier (more conservative)
          const seniority = contact.enriched_seniority?.toLowerCase() || '';
          const title = contact.connection_title?.toLowerCase() || '';
          
          if (seniority.includes('cxo') || title.includes('ceo') || title.includes('cfo')) {
            value *= 2.5;
          } else if (seniority.includes('vice president') || title.includes('vp')) {
            value *= 2;
          } else if (seniority.includes('director') || title.includes('director')) {
            value *= 1.5;
          }
          
          // Company size multiplier (more conservative)
          const companySize = contact.company_size || '';
          if (companySize.includes('10,000+')) {
            value *= 1.8;
          } else if (companySize.includes('1,001-5,000')) {
            value *= 1.4;
          } else if (companySize.includes('501-1,000')) {
            value *= 1.2;
          }
          
          // Relationship strength multiplier
          if (contact.relationship_strength === 'strong') {
            value *= 1.3;
          } else if (contact.relationship_strength === 'medium') {
            value *= 1.1;
          }
          
          return total + value;
        }, 0);

        // Calculate network health score based on various factors
        const totalContacts = contacts.length;
        let healthScore = 50; // Base score
        
        if (totalContacts > 0) {
          const enrichmentRate = (enrichedContacts / totalContacts) * 100;
          const strongRelationshipRate = (strongRelationships / totalContacts) * 100;
          const cxoRate = (cxoContacts / totalContacts) * 100;
          
          // Factor in enrichment rate (0-25 points)
          healthScore += Math.min(enrichmentRate / 4, 25);
          
          // Factor in relationship quality (0-15 points)
          healthScore += Math.min(strongRelationshipRate * 3, 15);
          
          // Factor in executive connections (0-10 points)
          healthScore += Math.min(cxoRate * 2, 10);
        }

        setNetworkStats({
          totalContacts,
          cxoContacts,
          enrichedContacts,
          strongRelationships,
          estimatedPipeline: Math.round(estimatedPipeline / 1000000 * 10) / 10, // Convert to millions, round to 1 decimal
          networkHealthScore: Math.min(Math.round(healthScore), 100)
        });
      } catch (error) {
        console.error('Failed to calculate network stats:', error);
        // Set default values on error
        setNetworkStats({
          totalContacts: 0,
          cxoContacts: 0,
          enrichedContacts: 0,
          strongRelationships: 0,
          estimatedPipeline: 0,
          networkHealthScore: 0
        });
      }
    };

    calculateNetworkStats();
  }, []);

  const getHealthScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getHealthScoreTrend = (score) => {
    if (score >= 80) return '+5%';
    if (score >= 60) return '+2%';
    return '-1%';
  };

  const metrics = [
    {
      title: 'Network Health Score',
      value: networkStats.networkHealthScore.toString(),
      trend: getHealthScoreTrend(networkStats.networkHealthScore),
      trendUp: networkStats.networkHealthScore >= 60,
      icon: Target,
      color: getHealthScoreColor(networkStats.networkHealthScore),
      bgColor: 'bg-green-50',
      description: `${networkStats.totalContacts} total connections`
    },
    {
      title: 'Active Pipeline',
      value: `$${networkStats.estimatedPipeline}M`,
      trend: `${networkStats.cxoContacts} C-Level`,
      trendUp: true,
      icon: DollarSign,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-50',
      description: 'Estimated relationship value'
    },
    {
      title: 'Executive Contacts',
      value: networkStats.cxoContacts.toString(),
      trend: 'CXO Level',
      trendUp: true,
      icon: Users,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-50',
      description: 'Decision makers & founders'
    },
    {
      title: 'Strong Relationships',
      value: networkStats.strongRelationships.toString(),
      trend: `${networkStats.totalContacts > 0 ? Math.round((networkStats.strongRelationships / networkStats.totalContacts) * 100) : 0}%`,
      trendUp: networkStats.strongRelationships > 0,
      icon: TrendingUp,
      color: 'text-green-400',
      bgColor: 'bg-green-50',
      description: 'High-trust connections'
    },
    {
      title: 'AI-Enhanced Profiles',
      value: networkStats.enrichedContacts.toString(),
      trend: 'Intelligence Ready',
      trendUp: networkStats.enrichedContacts > 0,
      icon: Brain,
      color: 'text-purple-400',
      bgColor: 'bg-purple-50',
      description: 'Profiles with AI summaries'
    }
  ];

  return (
    <div className="bg-gradient-to-r from-gray-900 via-black to-gray-900 text-white py-6 px-6 shadow-2xl border-b-4 border-yellow-500">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold mb-1 text-yellow-400" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              GTM + RevOps Engine
            </h1>
            <p className="text-gray-300 text-sm">
              Executive Relationship Intelligence • Real-Time Network Analytics • Revenue-Driven Insights
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500">
              Live Data Connected
            </Badge>
            <Badge className="bg-green-500/20 text-green-400 border-green-500">
              {networkStats.enrichedContacts} AI-Enhanced
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-300">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className={`p-2 rounded-lg bg-gray-700/50`}>
                      <metric.icon className={`w-5 h-5 ${metric.color}`} />
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      {metric.trendUp ? (
                        <TrendingUp className="w-3 h-3 text-green-400" />
                      ) : (
                        <AlertTriangle className="w-3 h-3 text-yellow-400" />
                      )}
                      <span className="text-gray-300">{metric.trend}</span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-yellow-400 mb-1">
                    {metric.value}
                  </div>
                  <div className="text-xs text-gray-400 leading-tight">
                    {metric.description}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}