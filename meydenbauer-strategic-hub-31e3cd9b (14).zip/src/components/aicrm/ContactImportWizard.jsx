import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Linkedin, Mail, Facebook, Instagram, Cloud, Upload,
  CheckCircle, ArrowRight, ArrowLeft, X, FileText, Users,
  AlertCircle, Download, RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

export default function ContactImportWizard({ 
  platforms, 
  syncStatus, 
  onImportComplete, 
  onClose,
  onSyncStatusUpdate 
}) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [importMethod, setImportMethod] = useState('oauth');
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importResults, setImportResults] = useState(null);
  const [importErrors, setImportErrors] = useState([]);

  const steps = [
    { number: 1, title: 'Select Platforms', description: 'Choose where to import from' },
    { number: 2, title: 'Connect & Import', description: 'Authorize and import contacts' },
    { number: 3, title: 'Review & Confirm', description: 'Preview and finalize import' }
  ];

  const togglePlatform = (platformId) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };

  const handleFileUpload = (platformId, event) => {
    const file = event.target.files[0];
    if (file) {
      setUploadedFiles(prev => ({
        ...prev,
        [platformId]: file
      }));
    }
  };

  const simulateOAuthFlow = async (platformId) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, platform: platformId });
      }, 1500);
    });
  };

  const parseContactFile = (file, platform) => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const mockContacts = generateMockContacts(platform, 25);
        resolve(mockContacts);
      };
      reader.readAsText(file);
    });
  };

  const generateMockContacts = (platform, count) => {
    const firstNames = ['John', 'Jane', 'Michael', 'Sarah', 'David', 'Emma', 'Robert', 'Lisa', 'James', 'Maria'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    const companies = ['Microsoft', 'Google', 'Amazon', 'Apple', 'Meta', 'Salesforce', 'Oracle', 'Adobe', 'IBM', 'Intel'];
    const titles = ['Sales Executive', 'Account Manager', 'VP Sales', 'Director', 'Senior Manager', 'Business Development Manager'];

    return Array.from({ length: count }, (_, i) => ({
      id: `${platform}-${Date.now()}-${i}`,
      firstName: firstNames[Math.floor(Math.random() * firstNames.length)],
      lastName: lastNames[Math.floor(Math.random() * lastNames.length)],
      email: `user${i}@example.com`,
      phone: `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}`,
      company: companies[Math.floor(Math.random() * companies.length)],
      title: titles[Math.floor(Math.random() * titles.length)],
      sources: [platform],
      profiles: {
        [platform]: `https://${platform}.com/profile/${i}`
      },
      importedAt: new Date().toISOString(),
      enriched: false
    }));
  };

  const handleImport = async () => {
    setImporting(true);
    setImportProgress(0);
    setImportErrors([]);
    
    let allImportedContacts = [];
    const totalPlatforms = selectedPlatforms.length;
    
    for (let i = 0; i < selectedPlatforms.length; i++) {
      const platformId = selectedPlatforms[i];
      const platform = platforms.find(p => p.id === platformId);
      
      try {
        setImportProgress(((i + 0.5) / totalPlatforms) * 100);
        
        let contacts;
        if (importMethod === 'oauth') {
          const authResult = await simulateOAuthFlow(platformId);
          if (authResult.success) {
            contacts = generateMockContacts(platformId, Math.floor(Math.random() * 50) + 10);
            
            const newSyncStatus = {
              ...syncStatus,
              [platformId]: {
                connected: true,
                lastSync: new Date().toISOString(),
                count: contacts.length
              }
            };
            onSyncStatusUpdate(newSyncStatus);
          }
        } else if (uploadedFiles[platformId]) {
          contacts = await parseContactFile(uploadedFiles[platformId], platformId);
        }
        
        if (contacts && contacts.length > 0) {
          allImportedContacts = [...allImportedContacts, ...contacts];
        }
        
        setImportProgress(((i + 1) / totalPlatforms) * 100);
        
      } catch (error) {
        setImportErrors(prev => [...prev, {
          platform: platform.name,
          error: error.message || 'Failed to import contacts'
        }]);
      }
    }
    
    setImporting(false);
    setImportResults({
      total: allImportedContacts.length,
      byPlatform: selectedPlatforms.reduce((acc, platformId) => {
        const platformContacts = allImportedContacts.filter(c => c.sources.includes(platformId));
        acc[platformId] = platformContacts.length;
        return acc;
      }, {}),
      contacts: allImportedContacts
    });
    
    setCurrentStep(3);
  };

  const handleFinishImport = () => {
    if (importResults && importResults.contacts) {
      onImportComplete(importResults.contacts);
    }
    if (onClose) {
      onClose();
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Import Contacts
          </h2>
          <p className="text-slate-600 mt-1">
            Connect your platforms to build your relationship database
          </p>
        </div>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        )}
      </div>

      {/* Step Indicator */}
      <div className="flex items-center justify-between mb-8">
        {steps.map((step, index) => (
          <React.Fragment key={step.number}>
            <div className="flex items-center gap-3">
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center font-semibold
                ${currentStep >= step.number 
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white' 
                  : 'bg-slate-200 text-slate-500'}
              `}>
                {currentStep > step.number ? (
                  <CheckCircle className="w-6 h-6" />
                ) : (
                  step.number
                )}
              </div>
              <div>
                <div className="font-semibold">{step.title}</div>
                <div className="text-sm text-slate-600">{step.description}</div>
              </div>
            </div>
            {index < steps.length - 1 && (
              <div className={`
                flex-1 h-1 mx-4
                ${currentStep > step.number ? 'bg-gradient-to-r from-blue-600 to-indigo-600' : 'bg-slate-200'}
              `} />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1: Select Platforms */}
      {currentStep === 1 && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <Card>
            <CardHeader>
              <CardTitle>Choose Import Method</CardTitle>
              <CardDescription>
                Select how you want to import your contacts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setImportMethod('oauth')}
                  className={`
                    p-6 border-2 rounded-lg text-left transition-all
                    ${importMethod === 'oauth' 
                      ? 'border-blue-600 bg-blue-50' 
                      : 'border-slate-200 hover:border-blue-300'}
                  `}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <RefreshCw className="w-6 h-6 text-blue-600" />
                    <h3 className="font-semibold text-lg">OAuth Sync</h3>
                  </div>
                  <p className="text-sm text-slate-600">
                    Connect directly to platforms for automatic sync and updates
                  </p>
                  <div className="mt-3 text-xs text-green-600 font-semibold">
                    ✓ Auto-updates • ✓ Job change alerts • ✓ Most features
                  </div>
                </button>

                <button
                  onClick={() => setImportMethod('file')}
                  className={`
                    p-6 border-2 rounded-lg text-left transition-all
                    ${importMethod === 'file' 
                      ? 'border-blue-600 bg-blue-50' 
                      : 'border-slate-200 hover:border-blue-300'}
                  `}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Upload className="w-6 h-6 text-blue-600" />
                    <h3 className="font-semibold text-lg">File Upload</h3>
                  </div>
                  <p className="text-sm text-slate-600">
                    Upload CSV, VCF, or exported contact files
                  </p>
                  <div className="mt-3 text-xs text-slate-500">
                    One-time import • No ongoing sync
                  </div>
                </button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Select Platforms</CardTitle>
              <CardDescription>
                Choose which platforms to import contacts from
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {platforms.map((platform) => {
                  const Icon = platform.icon;
                  const isSelected = selectedPlatforms.includes(platform.id);
                  const isConnected = syncStatus[platform.id]?.connected;
                  
                  return (
                    <div
                      key={platform.id}
                      onClick={() => togglePlatform(platform.id)}
                      className={`
                        p-4 border-2 rounded-lg cursor-pointer transition-all
                        ${isSelected 
                          ? 'border-blue-600 bg-blue-50' 
                          : 'border-slate-200 hover:border-blue-300'}
                      `}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`${platform.color} p-2 rounded-lg`}>
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold">{platform.name}</h4>
                            <p className="text-xs text-slate-600">{platform.description}</p>
                          </div>
                        </div>
                        <Checkbox checked={isSelected} />
                      </div>
                      
                      {isConnected && (
                        <div className="flex items-center gap-2 text-xs text-green-600">
                          <CheckCircle className="w-3 h-3" />
                          <span>
                            Already connected ({syncStatus[platform.id].count} contacts)
                          </span>
                        </div>
                      )}
                      
                      {importMethod === 'file' && isSelected && (
                        <div className="mt-3">
                          <Label htmlFor={`file-${platform.id}`} className="cursor-pointer">
                            <div className="flex items-center gap-2 p-2 bg-white border border-slate-200 rounded text-sm hover:bg-slate-50">
                              <FileText className="w-4 h-4" />
                              {uploadedFiles[platform.id] ? (
                                <span className="text-green-600">
                                  {uploadedFiles[platform.id].name}
                                </span>
                              ) : (
                                <span className="text-slate-600">Upload file...</span>
                              )}
                            </div>
                          </Label>
                          <input
                            id={`file-${platform.id}`}
                            type="file"
                            accept=".csv,.vcf,.json"
                            onChange={(e) => handleFileUpload(platform.id, e)}
                            className="hidden"
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3">
            <Button
              onClick={() => setCurrentStep(2)}
              disabled={selectedPlatforms.length === 0}
              className="bg-gradient-to-r from-blue-600 to-indigo-600"
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </motion.div>
      )}

      {/* Step 2: Connect & Import */}
      {currentStep === 2 && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <Card>
            <CardHeader>
              <CardTitle>Import Contacts</CardTitle>
              <CardDescription>
                {importing 
                  ? 'Importing your contacts...' 
                  : `Ready to import from ${selectedPlatforms.length} platform(s)`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {!importing && importResults === null && (
                <>
                  <Alert>
                    <AlertCircle className="w-4 h-4" />
                    <AlertTitle>Before you start</AlertTitle>
                    <AlertDescription>
                      Make sure you're logged into the platforms you want to import from in this browser.
                      We'll never store your passwords or share your data with third parties.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    <h4 className="font-semibold">Selected Platforms:</h4>
                    {selectedPlatforms.map(platformId => {
                      const platform = platforms.find(p => p.id === platformId);
                      const Icon = platform.icon;
                      return (
                        <div key={platformId} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                          <div className={`${platform.color} p-2 rounded`}>
                            <Icon className="w-4 h-4 text-white" />
                          </div>
                          <span className="font-medium">{platform.name}</span>
                          {uploadedFiles[platformId] && (
                            <span className="text-sm text-slate-600">
                              ({uploadedFiles[platformId].name})
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              {importing && (
                <div className="space-y-4">
                  <div className="text-center py-8">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="inline-block"
                    >
                      <RefreshCw className="w-12 h-12 text-blue-600" />
                    </motion.div>
                    <p className="mt-4 text-lg font-semibold">Importing contacts...</p>
                    <p className="text-sm text-slate-600">This may take a few moments</p>
                  </div>
                  <Progress value={importProgress} className="h-2" />
                  <p className="text-center text-sm text-slate-600">
                    {Math.round(importProgress)}% complete
                  </p>
                </div>
              )}

              {importErrors.length > 0 && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertTitle>Import Errors</AlertTitle>
                  <AlertDescription>
                    <ul className="list-disc list-inside">
                      {importErrors.map((error, idx) => (
                        <li key={idx}>{error.platform}: {error.error}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-between gap-3">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(1)}
              disabled={importing}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button
              onClick={handleImport}
              disabled={importing}
              className="bg-gradient-to-r from-blue-600 to-indigo-600"
            >
              {importing ? 'Importing...' : 'Start Import'}
              <Upload className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </motion.div>
      )}

      {/* Step 3: Review & Confirm */}
      {currentStep === 3 && importResults && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-6 h-6 text-green-500" />
                Import Complete!
              </CardTitle>
              <CardDescription>
                Successfully imported {importResults.total} contacts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(importResults.byPlatform).map(([platformId, count]) => {
                  const platform = platforms.find(p => p.id === platformId);
                  const Icon = platform.icon;
                  return (
                    <div key={platformId} className="text-center p-4 bg-slate-50 rounded-lg">
                      <div className={`${platform.color} w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-blue-600">{count}</div>
                      <div className="text-sm text-slate-600">{platform.name}</div>
                    </div>
                  );
                })}
              </div>

              <Alert>
                <Users className="w-4 h-4" />
                <AlertTitle>What's Next?</AlertTitle>
                <AlertDescription>
                  Your contacts are now in your AICRM. We'll automatically:
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Enrich profiles with additional data</li>
                    <li>Deduplicate and merge similar contacts</li>
                    <li>Track job changes and updates</li>
                    <li>Set up keep-in-touch reminders</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <div className="border-t pt-6">
                <h4 className="font-semibold mb-3">Preview of Imported Contacts</h4>
                <div className="space-y-2">
                  {importResults.contacts.slice(0, 5).map((contact, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-3 bg-white border rounded-lg">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-semibold">
                        {contact.firstName?.[0]}{contact.lastName?.[0]}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">
                          {contact.firstName} {contact.lastName}
                        </div>
                        <div className="text-sm text-slate-600">
                          {contact.title} at {contact.company}
                        </div>
                      </div>
                      <div className="text-xs text-slate-500">
                        from {contact.sources[0]}
                      </div>
                    </div>
                  ))}
                  {importResults.contacts.length > 5 && (
                    <div className="text-center text-sm text-slate-600 py-2">
                      and {importResults.contacts.length - 5} more...
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3">
            <Button
              onClick={handleFinishImport}
              className="bg-gradient-to-r from-blue-600 to-indigo-600"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Finish & View Contacts
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
}