import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, Upload, Brain, Calendar, MessageSquare, 
  Linkedin, Mail, Facebook, Instagram, Cloud, Download,
  Search, Filter, Tag, TrendingUp, Bell, Settings,
  UserPlus, RefreshCw, CheckCircle, AlertCircle, Zap
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import ContactImportWizard from './ContactImportWizard';
import ContactEnrichmentEngine from './ContactEnrichmentEngine';
import ContactDetailView from './ContactDetailView';

export default function NetworkIntelligenceHub() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [showImportWizard, setShowImportWizard] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [syncStatus, setSyncStatus] = useState({
    linkedin: { connected: false, lastSync: null, count: 0 },
    gmail: { connected: false, lastSync: null, count: 0 },
    outlook: { connected: false, lastSync: null, count: 0 },
    google: { connected: false, lastSync: null, count: 0 },
    icloud: { connected: false, lastSync: null, count: 0 },
    facebook: { connected: false, lastSync: null, count: 0 },
    instagram: { connected: false, lastSync: null, count: 0 }
  });

  const [stats, setStats] = useState({
    totalContacts: 0,
    enrichedContacts: 0,
    pendingFollowUps: 0,
    activeRelationships: 0,
    recentInteractions: 0,
    titleChanges: 0
  });

  const calculateStats = useCallback(() => {
    setStats({
      totalContacts: contacts.length,
      enrichedContacts: contacts.filter(c => c.enriched).length,
      pendingFollowUps: contacts.filter(c => c.needsFollowUp).length,
      activeRelationships: contacts.filter(c => c.lastInteraction && 
        (Date.now() - new Date(c.lastInteraction).getTime()) < 30 * 24 * 60 * 60 * 1000
      ).length,
      recentInteractions: contacts.filter(c => c.lastInteraction &&
        (Date.now() - new Date(c.lastInteraction).getTime()) < 7 * 24 * 60 * 60 * 1000
      ).length,
      titleChanges: contacts.filter(c => c.titleChanged).length
    });
  }, [contacts]);

  useEffect(() => {
    loadContactsFromStorage();
    loadSyncStatus();
  }, []);

  useEffect(() => {
    calculateStats();
  }, [contacts, calculateStats]);

  const loadContactsFromStorage = () => {
    const savedContacts = localStorage.getItem('aicrm_contacts');
    if (savedContacts) {
      setContacts(JSON.parse(savedContacts));
    }
  };

  const loadSyncStatus = () => {
    const savedStatus = localStorage.getItem('aicrm_sync_status');
    if (savedStatus) {
      setSyncStatus(JSON.parse(savedStatus));
    }
  };

  const handleImportComplete = (importedContacts) => {
    const mergedContacts = mergeAndDeduplicateContacts([...contacts, ...importedContacts]);
    setContacts(mergedContacts);
    localStorage.setItem('aicrm_contacts', JSON.stringify(mergedContacts));
    setShowImportWizard(false);
  };

  const mergeAndDeduplicateContacts = (contactList) => {
    const contactMap = new Map();
    
    contactList.forEach(contact => {
      const key = contact.email || contact.phone || `${contact.firstName}_${contact.lastName}`;
      
      if (contactMap.has(key)) {
        const existing = contactMap.get(key);
        contactMap.set(key, {
          ...existing,
          ...contact,
          sources: [...(existing.sources || []), ...(contact.sources || [])],
          profiles: { ...(existing.profiles || {}), ...(contact.profiles || {}) }
        });
      } else {
        contactMap.set(key, contact);
      }
    });

    return Array.from(contactMap.values());
  };

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = searchQuery === '' || 
      contact.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesSearch;
  });

  const platforms = [
    { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-600', description: 'Import connections & track job changes' },
    { id: 'gmail', name: 'Gmail', icon: Mail, color: 'bg-red-600', description: 'Sync contacts & email history' },
    { id: 'outlook', name: 'Outlook', icon: Mail, color: 'bg-blue-500', description: 'Import Outlook contacts' },
    { id: 'google', name: 'Google Contacts', icon: Users, color: 'bg-green-600', description: 'Sync Google address book' },
    { id: 'icloud', name: 'iCloud', icon: Cloud, color: 'bg-gray-600', description: 'Import iCloud contacts' },
    { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-blue-700', description: 'Connect Facebook friends' },
    { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'bg-pink-600', description: 'Import Instagram connections' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Network Intelligence Hub
            </h1>
            <p className="text-slate-600 mt-2">
              Enterprise-Grade Personal CRM • Powered by Meydenbauer Strategic Hub
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowImportWizard(true)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import Contacts
            </Button>
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </motion.div>

        {/* Stats Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4"
        >
          {[
            { label: 'Total Contacts', value: stats.totalContacts, icon: Users, color: 'blue' },
            { label: 'Enriched', value: stats.enrichedContacts, icon: Brain, color: 'purple' },
            { label: 'Follow-ups', value: stats.pendingFollowUps, icon: Bell, color: 'orange' },
            { label: 'Active (30d)', value: stats.activeRelationships, icon: TrendingUp, color: 'green' },
            { label: 'Recent (7d)', value: stats.recentInteractions, icon: MessageSquare, color: 'indigo' },
            { label: 'Job Changes', value: stats.titleChanges, icon: RefreshCw, color: 'red' }
          ].map((stat, index) => (
            <Card key={index} className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
                  <span className={`text-2xl font-bold text-${stat.color}-600`}>
                    {stat.value}
                  </span>
                </div>
                <p className="text-sm text-slate-600">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid bg-white/80 backdrop-blur-sm shadow-lg">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="contacts">
              Contacts
            </TabsTrigger>
            <TabsTrigger value="import">
              Import & Sync
            </TabsTrigger>
            <TabsTrigger value="intelligence">
              AI Enrichment
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <Card className="border-none shadow-xl">
              <CardHeader>
                <CardTitle>Welcome to Network Intelligence Hub</CardTitle>
                <CardDescription>
                  Manage your professional relationships with enterprise-grade tools
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Import contacts from LinkedIn, Gmail, and other platforms to unlock powerful relationship intelligence.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contacts Tab */}
          <TabsContent value="contacts" className="space-y-6">
            <Card className="border-none shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Contact Database</CardTitle>
                    <CardDescription>
                      {filteredContacts.length} of {contacts.length} contacts
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add Contact
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 mb-6">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search contacts by name, email, or company..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filters
                  </Button>
                </div>

                <div className="space-y-2">
                  {filteredContacts.length > 0 ? (
                    filteredContacts.slice(0, 10).map((contact, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="p-4 bg-white border border-slate-200 rounded-lg hover:shadow-lg transition-all cursor-pointer"
                        onClick={() => setSelectedContact(contact)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-semibold">
                              {contact.firstName?.[0]}{contact.lastName?.[0]}
                            </div>
                            <div>
                              <h4 className="font-semibold">
                                {contact.firstName} {contact.lastName}
                              </h4>
                              <p className="text-sm text-slate-600">
                                {contact.title} {contact.company && `at ${contact.company}`}
                              </p>
                              <div className="flex gap-2 mt-1">
                                {contact.sources?.map((source, sidx) => (
                                  <Badge key={sidx} variant="secondary" className="text-xs">
                                    {source}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {contact.enriched && (
                              <Badge className="bg-purple-100 text-purple-700">
                                <Brain className="w-3 h-3 mr-1" />
                                Enriched
                              </Badge>
                            )}
                            {contact.profiles?.linkedin && (
                              <Button size="sm" variant="ghost">
                                <Linkedin className="w-4 h-4" />
                              </Button>
                            )}
                            {contact.email && (
                              <Button size="sm" variant="ghost">
                                <Mail className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="text-center py-12 text-slate-500">
                      <Users className="w-16 h-16 mx-auto mb-4 opacity-30" />
                      <p className="text-lg font-semibold mb-2">No contacts yet</p>
                      <p className="mb-4">Get started by importing contacts from your platforms</p>
                      <Button 
                        onClick={() => setShowImportWizard(true)}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Import Contacts
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Import & Sync Tab */}
          <TabsContent value="import" className="space-y-6">
            <ContactImportWizard
              platforms={platforms}
              syncStatus={syncStatus}
              onImportComplete={handleImportComplete}
              onSyncStatusUpdate={(newStatus) => {
                setSyncStatus(newStatus);
                localStorage.setItem('aicrm_sync_status', JSON.stringify(newStatus));
              }}
            />
          </TabsContent>

          {/* Intelligence Tab */}
          <TabsContent value="intelligence" className="space-y-6">
            <ContactEnrichmentEngine
              contacts={contacts}
              onContactsEnriched={(enrichedContacts) => {
                setContacts(enrichedContacts);
                localStorage.setItem('aicrm_contacts', JSON.stringify(enrichedContacts));
              }}
            />
          </TabsContent>
        </Tabs>

        {/* Import Wizard Modal */}
        <AnimatePresence>
          {showImportWizard && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6"
              onClick={() => setShowImportWizard(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              >
                <ContactImportWizard
                  platforms={platforms}
                  syncStatus={syncStatus}
                  onImportComplete={handleImportComplete}
                  onClose={() => setShowImportWizard(false)}
                  onSyncStatusUpdate={(newStatus) => {
                    setSyncStatus(newStatus);
                    localStorage.setItem('aicrm_sync_status', JSON.stringify(newStatus));
                  }}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Contact Detail Modal */}
        <AnimatePresence>
          {selectedContact && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6"
              onClick={() => setSelectedContact(null)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              >
                <ContactDetailView
                  contact={selectedContact}
                  onClose={() => setSelectedContact(null)}
                  onUpdate={(updatedContact) => {
                    const updated = contacts.map(c => 
                      c.id === updatedContact.id ? updatedContact : c
                    );
                    setContacts(updated);
                    localStorage.setItem('aicrm_contacts', JSON.stringify(updated));
                    setSelectedContact(updatedContact);
                  }}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}