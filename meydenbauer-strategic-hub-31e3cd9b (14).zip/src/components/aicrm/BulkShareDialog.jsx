
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Globe2,
  Users,
  Loader2,
  AlertCircle,
  CheckCircle,
  XCircle,
  X
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { shareContact } from './SharingService';
import { toast } from 'sonner';

export default function BulkShareDialog({ isOpen, onClose, selectedContacts, onShareComplete }) {
  const [privacyLevel, setPrivacyLevel] = useState('public');
  const [shareNotes, setShareNotes] = useState('');
  const [allowIntroRequests, setAllowIntroRequests] = useState(true);
  const [confirmBulkShare, setConfirmBulkShare] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentContact, setCurrentContact] = useState('');
  const [results, setResults] = useState({
    successful: 0,
    updated: 0,
    failed: 0,
    failures: []
  });

  const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';

  const handleSubmit = async () => {
    if (!confirmBulkShare) {
      toast.error('Please confirm bulk share by checking the checkbox');
      return;
    }

    setIsProcessing(true);
    setShowResults(false);
    setProgress(0);

    const processResults = {
      successful: 0,
      updated: 0,
      failed: 0,
      failures: []
    };

    for (let i = 0; i < selectedContacts.length; i++) {
      const contact = selectedContacts[i];
      setCurrentContact(contact.connection_name);
      setProgress(((i + 1) / selectedContacts.length) * 100);

      try {
        await shareContact({
          contactId: contact.id,
          privacyLevel,
          shareNotes: shareNotes.trim(),
          allowIntroRequests
        });

        if (contact.is_shared) {
          processResults.updated++;
        } else {
          processResults.successful++;
        }
      } catch (error) {
        processResults.failed++;
        processResults.failures.push({
          name: contact.connection_name,
          reason: error.message || 'Unknown error'
        });
      }

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    setResults(processResults);
    setIsProcessing(false);
    setShowResults(true);

    if (processResults.failed === 0) {
      toast.success(`Successfully shared ${processResults.successful + processResults.updated} contacts!`);
    } else {
      toast.warning(`Shared ${processResults.successful + processResults.updated} contacts, ${processResults.failed} failed`);
    }
  };

  const handleClose = () => {
    if (isProcessing) {
      if (!confirm('Sharing is in progress. Are you sure you want to cancel?')) {
        return;
      }
    }
    
    // Reset state
    setPrivacyLevel('public');
    setShareNotes('');
    setAllowIntroRequests(true);
    setConfirmBulkShare(false);
    setIsProcessing(false);
    setShowResults(false);
    setProgress(0);
    setCurrentContact('');
    setResults({ successful: 0, updated: 0, failed: 0, failures: [] });
    
    onClose();
  };

  const handleComplete = () => {
    onShareComplete();
    handleClose();
  };

  const contactCount = selectedContacts?.length || 0;
  const charCount = shareNotes.length;
  const maxChars = 500;
  const isOverLimit = charCount > maxChars;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            Share {contactCount} Contacts to Find Connections
          </DialogTitle>
          <DialogDescription>
            Apply the same sharing settings to all selected contacts
          </DialogDescription>
        </DialogHeader>

        {!showResults ? (
          <div className="space-y-6 py-4">
            {/* Contact List Preview */}
            <Card className="border-2 border-blue-100">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900">Selected Contacts</h3>
                  <Badge variant="secondary">{contactCount} contacts</Badge>
                </div>
                <div className="max-h-[200px] overflow-y-auto space-y-2">
                  {selectedContacts.map((contact) => (
                    <div key={contact.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
                        {getInitials(contact.connection_name)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {contact.connection_name}
                        </p>
                        <p className="text-xs text-gray-600 truncate">
                          {contact.connection_company}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                {contactCount > 50 && (
                  <div className="flex items-start gap-2 mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded">
                    <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-yellow-800">
                      Consider sharing in smaller batches for better control
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Privacy Level */}
            <div>
              <Label className="text-base font-semibold mb-3 block">Privacy Level</Label>
              <RadioGroup value={privacyLevel} onValueChange={setPrivacyLevel}>
                <div className="space-y-3">
                  <div>
                    <RadioGroupItem value="public" id="bulk-public" className="peer sr-only" />
                    <Label
                      htmlFor="bulk-public"
                      className={`flex items-start gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        privacyLevel === 'public'
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <Globe2 className={`w-5 h-5 mt-0.5 ${privacyLevel === 'public' ? 'text-green-600' : 'text-gray-400'}`} />
                      <div className="flex-1">
                        <div className="font-semibold text-gray-900 mb-1">Public</div>
                        <div className="text-sm text-gray-600">
                          Anyone can discover these contacts in the network directory
                        </div>
                      </div>
                    </Label>
                  </div>

                  <div>
                    <RadioGroupItem value="network_only" id="bulk-network" className="peer sr-only" />
                    <Label
                      htmlFor="bulk-network"
                      className={`flex items-start gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        privacyLevel === 'network_only'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      <Users className={`w-5 h-5 mt-0.5 ${privacyLevel === 'network_only' ? 'text-blue-600' : 'text-gray-400'}`} />
                      <div className="flex-1">
                        <div className="font-semibold text-gray-900 mb-1">Network Only</div>
                        <div className="text-sm text-gray-600">
                          Only people with mutual connections can see these contacts
                        </div>
                      </div>
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            {/* Bulk Share Notes */}
            <div>
              <Label htmlFor="bulkShareNotes" className="text-base font-semibold mb-2 block">
                Add notes for all contacts (Optional)
              </Label>
              <Textarea
                id="bulkShareNotes"
                placeholder="These notes will apply to all selected contacts..."
                value={shareNotes}
                onChange={(e) => setShareNotes(e.target.value)}
                className={`min-h-[80px] ${isOverLimit ? 'border-red-500' : ''}`}
                maxLength={maxChars + 50}
              />
              <div className="flex justify-between items-center mt-2">
                <span className={`text-xs font-medium ${isOverLimit ? 'text-red-600' : 'text-gray-500'}`}>
                  {charCount} / {maxChars}
                </span>
              </div>
            </div>

            {/* Introduction Preferences */}
            <Card className="border border-gray-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="bulkAllowIntroRequests"
                    checked={allowIntroRequests}
                    onCheckedChange={setAllowIntroRequests}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor="bulkAllowIntroRequests"
                      className="text-sm font-semibold cursor-pointer"
                    >
                      Allow introduction requests for all contacts
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">
                      Applied to all selected contacts
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Confirmation Checkbox */}
            <Card className="border-2 border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="confirmBulkShare"
                    checked={confirmBulkShare}
                    onCheckedChange={setConfirmBulkShare}
                  />
                  <Label
                    htmlFor="confirmBulkShare"
                    className="text-sm font-semibold cursor-pointer"
                  >
                    I confirm I want to share all {contactCount} contacts with these settings
                  </Label>
                </div>
              </CardContent>
            </Card>

            {/* Processing Progress */}
            <AnimatePresence>
              {isProcessing && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <Card className="border-2 border-blue-200 bg-blue-50">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-gray-900">
                            Sharing contacts...
                          </span>
                          <span className="text-sm text-gray-600">
                            {Math.round(progress)}%
                          </span>
                        </div>
                        <Progress value={progress} className="h-2" />
                        <p className="text-sm text-gray-600">
                          Currently processing: {currentContact}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ) : (
          /* Results Display */
          <div className="space-y-6 py-4">
            <Card className="border-2 border-green-200 bg-green-50">
              <CardContent className="p-6">
                <div className="text-center">
                  <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Bulk Share Complete
                  </h3>
                  <div className="grid grid-cols-3 gap-4 mt-6">
                    <div>
                      <div className="text-3xl font-bold text-green-600">
                        {results.successful}
                      </div>
                      <div className="text-sm text-gray-600">New Shares</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-blue-600">
                        {results.updated}
                      </div>
                      <div className="text-sm text-gray-600">Updated</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-red-600">
                        {results.failed}
                      </div>
                      <div className="text-sm text-gray-600">Failed</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Failed Contacts List */}
            {results.failures.length > 0 && (
              <Card className="border-2 border-red-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <XCircle className="w-5 h-5 text-red-600" />
                    <h4 className="font-semibold text-gray-900">
                      Failed Contacts ({results.failures.length})
                    </h4>
                  </div>
                  <div className="max-h-[200px] overflow-y-auto space-y-2">
                    {results.failures.map((failure, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 bg-red-50 rounded">
                        <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900">
                            {failure.name}
                          </p>
                          <p className="text-xs text-red-600">
                            {failure.reason}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        <DialogFooter>
          {!showResults ? (
            <>
              <Button variant="outline" onClick={handleClose} disabled={isProcessing}>
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isProcessing || !confirmBulkShare || isOverLimit}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  `Share ${contactCount} Contacts`
                )}
              </Button>
            </>
          ) : (
            <Button onClick={handleComplete} className="bg-blue-600 hover:bg-blue-700">
              Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
