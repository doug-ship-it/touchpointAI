
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Search, Filter, Grid, List, Mail, Phone, Linkedin,
  MapPin, Building2, Edit, Trash2, MoreHorizontal, Star,
  Share2, Check, Globe2, Sparkles // Added Sparkles icon
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast'; // Assuming use-toast is available for toast notifications
import ShareContactDialog from '../ShareContactDialog';
import BulkShareDialog from '../BulkShareDialog';
import AdvancedFilters from '../../network/AdvancedFilters';
import PersonalizedMessageModal from '../../network/PersonalizedMessageModal'; // New import

export default function UnifiedContactsTab({ 
  contactsPromise, // Changed from contacts
  selectedContacts = [], 
  onSelectedContactsChange = () => {},
  onContactUpdate,
  onContactDelete,
  searchQuery = '',
  onSearchChange = () => {},
  filters = {},
  onFiltersChange = () => {},
  viewMode = 'grid',
  onViewModeChange = () => {},
  onRefresh = () => {},
  userSegments = [], // New prop
  onSegmentUpdate = () => {}, // New prop
  onContactSelect = () => {} // New prop with default
}) {
  const [contacts, setContacts] = useState([]); // New state for contacts
  const [loading, setLoading] = useState(true); // New state for loading
  // const [showFilters, setShowFilters] = useState(false); // This state was unused and has been removed
  const [localSearchQuery, setLocalSearchQuery] = useState(searchQuery);
  const [localSelectedContacts, setLocalSelectedContacts] = useState(selectedContacts);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [bulkShareDialogOpen, setBulkShareDialogOpen] = useState(false);
  const [contactToShare, setContactToShare] = useState(null);
  const [shareFilter, setShareFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState({ key: null, direction: null });
  const [advancedFilters, setAdvancedFilters] = useState({
    companySizes: [],
    seniorityLevels: [],
    industries: []
  });
  const [messageModalContact, setMessageModalContact] = useState(null); // New state for message modal

  // Load contacts from promise
  useEffect(() => {
    const loadContacts = async () => {
      setLoading(true);
      try {
        const data = await contactsPromise;
        setContacts(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error('Error loading contacts:', error);
        setContacts([]);
      } finally {
        setLoading(false);
      }
    };

    loadContacts();
  }, [contactsPromise]);

  const safeToLowerCase = (value) => {
    if (!value || typeof value !== 'string') return '';
    return value.toLowerCase();
  };

  const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';

  const getLastContactColor = (date) => {
    if (!date) return 'text-gray-500';
    const daysSince = Math.floor((new Date() - new Date(date)) / (1000 * 60 * 60 * 24));
    if (daysSince <= 7) return 'text-green-600';
    if (daysSince <= 30) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getLastContactText = (date) => {
    if (!date) return 'Never contacted';
    const daysSince = Math.floor((new Date() - new Date(date)) / (1000 * 60 * 60 * 24));
    if (daysSince === 0) return 'Today';
    if (daysSince === 1) return 'Yesterday';
    return `${daysSince} days ago`;
  };

  const handleOpenShareDialog = (contact) => {
    setContactToShare(contact);
    setShareDialogOpen(true);
  };

  const handleShareComplete = async (shareResult) => {
    // Optimistically update the contact in the UI
    if (shareResult && shareResult.contactId) {
      // This will trigger a re-render with updated contact data
      if (onContactUpdate) {
        await onContactUpdate(shareResult.contactId, {
          is_shared: shareResult.isShared,
          share_privacy_level: shareResult.privacyLevel,
          share_notes: shareResult.shareNotes,
          allow_intro_requests: shareResult.allowIntroRequests,
          shared_connection_id: shareResult.sharedConnectionId
        });
      }
    }
    
    setShareDialogOpen(false);
    setContactToShare(null);
    await onRefresh();
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const toggleContactSelection = (contactId) => {
    const newSelection = localSelectedContacts.includes(contactId)
      ? localSelectedContacts.filter(id => id !== contactId)
      : [...localSelectedContacts, contactId];
    
    setLocalSelectedContacts(newSelection);
    onSelectedContactsChange(newSelection);
  };

  const toggleSelectAll = () => {
    if (localSelectedContacts.length === filteredContacts.length) {
      setLocalSelectedContacts([]);
      onSelectedContactsChange([]);
    } else {
      const allIds = filteredContacts.map(c => c.id);
      setLocalSelectedContacts(allIds);
      onSelectedContactsChange(allIds);
    }
  };

  const clearSelection = () => {
    setLocalSelectedContacts([]);
    onSelectedContactsChange([]);
  };

  // Apply all filters
  let filteredContacts = contacts.filter(contact => {
    const query = safeToLowerCase(localSearchQuery);
    const matchesSearch = query === '' || 
      safeToLowerCase(contact.connection_name).includes(query) ||
      safeToLowerCase(contact.connection_company).includes(query) ||
      safeToLowerCase(contact.connection_email).includes(query);
    
    let matchesShareFilter = true;
    if (shareFilter === 'shared_only') {
      matchesShareFilter = contact.is_shared === true;
    } else if (shareFilter === 'not_shared') {
      matchesShareFilter = !contact.is_shared;
    } else if (shareFilter === 'public_shared') {
      matchesShareFilter = contact.is_shared && contact.share_privacy_level === 'public';
    } else if (shareFilter === 'network_only_shared') {
      matchesShareFilter = contact.is_shared && contact.share_privacy_level === 'network_only';
    }

    // Apply advanced filters
    let matchesAdvancedFilters = true;
    
    if (advancedFilters.companySizes?.length > 0) {
      matchesAdvancedFilters = matchesAdvancedFilters && 
        advancedFilters.companySizes.includes(contact.company_size);
    }
    
    if (advancedFilters.seniorityLevels?.length > 0) {
      matchesAdvancedFilters = matchesAdvancedFilters &&
        advancedFilters.seniorityLevels.some(level => {
          const contactSeniority = safeToLowerCase(contact.enriched_seniority);
          const contactTitle = safeToLowerCase(contact.connection_title);
          const filterLevel = safeToLowerCase(level);
          return contactSeniority.includes(filterLevel) || contactTitle.includes(filterLevel);
        });
    }
    
    if (advancedFilters.industries?.length > 0) {
      matchesAdvancedFilters = matchesAdvancedFilters &&
        advancedFilters.industries.some(industry => 
          safeToLowerCase(contact.enriched_industry).includes(safeToLowerCase(industry))
        );
    }
    
    return matchesSearch && matchesShareFilter && matchesAdvancedFilters;
  });

  // Apply sorting
  if (sortConfig.key === 'sharedStatus') {
    filteredContacts = [...filteredContacts].sort((a, b) => {
      const aShared = a.is_shared ? 1 : 0;
      const bShared = b.is_shared ? 1 : 0;
      return sortConfig.direction === 'asc' 
        ? aShared - bShared 
        : bShared - aShared;
    });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Bulk Actions Toolbar */}
      <AnimatePresence>
        {localSelectedContacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <span className="font-medium text-blue-900">
                {localSelectedContacts.length} contact{localSelectedContacts.length > 1 ? 's' : ''} selected
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={clearSelection}
              >
                Clear selection
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={() => setBulkShareDialogOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Bulk Share
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search and Filters */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search contacts, companies, or emails..."
                value={localSearchQuery}
                onChange={(e) => {
                  setLocalSearchQuery(e.target.value);
                  onSearchChange(e.target.value);
                }}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Select value={shareFilter} onValueChange={setShareFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Share Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Contacts</SelectItem>
                  <SelectItem value="shared_only">Shared Only</SelectItem>
                  <SelectItem value="not_shared">Not Shared</SelectItem>
                  <SelectItem value="public_shared">Public Shared</SelectItem>
                  <SelectItem value="network_only_shared">Network Only</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex border border-slate-200 rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => onViewModeChange('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => onViewModeChange('list')}
                  className="rounded-l-none"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Filters - Always Visible */}
      <AdvancedFilters
        filters={advancedFilters}
        onFiltersChange={setAdvancedFilters}
      />

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600">
          <span className="font-semibold text-gray-900">{filteredContacts.length.toLocaleString()}</span> contacts found
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => toggleSelectAll()}
        >
          {localSelectedContacts.length === filteredContacts.length ? 'Deselect All' : 'Select All'}
        </Button>
      </div>

      {/* Contacts Grid/List */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-4'}>
        <AnimatePresence>
          {filteredContacts.map((contact, index) => (
            <motion.div
              key={contact.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.02 }}
            >
              <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={localSelectedContacts.includes(contact.id)}
                        onCheckedChange={() => toggleContactSelection(contact.id)}
                        onClick={(e) => e.stopPropagation()}
                      />
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {getInitials(contact.connection_name)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {contact.connection_name}
                        </h3>
                        <p className="text-sm text-gray-600">{contact.connection_title}</p>
                      </div>
                    </div>
                    <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2 mb-4">
                    {contact.connection_company && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Building2 className="w-4 h-4" />
                        <span>{contact.connection_company}</span>
                      </div>
                    )}
                    {contact.enriched_location && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>{contact.enriched_location}</span>
                      </div>
                    )}
                  </div>

                  {/* Shared Status Badge */}
                  {contact.is_shared && (
                    <div className="mb-4">
                      <Badge className={
                        contact.share_privacy_level === 'public'
                          ? 'bg-green-100 text-green-800 border-green-200'
                          : 'bg-blue-100 text-blue-800 border-blue-200'
                      }>
                        <Globe2 className="w-3 h-3 mr-1" />
                        Shared {contact.share_privacy_level === 'public' ? '(Public)' : '(Network Only)'}
                      </Badge>
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-xs font-medium ${getLastContactColor(contact.last_contact_date)}`}>
                      {getLastContactText(contact.last_contact_date)}
                    </span>
                    {contact.relationship_score && (
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm text-gray-600">{contact.relationship_score}/10</span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons - Updated Colors to Blue Theme */}
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      View
                    </Button>
                    <Button 
                      variant={contact.is_shared ? "default" : "outline"}
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenShareDialog(contact);
                      }}
                      className={contact.is_shared ? "bg-green-600 hover:bg-green-700" : ""}
                      title={contact.is_shared ? "Already shared - click to edit" : "Share to Find Connections"}
                    >
                      {contact.is_shared ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span className="hidden sm:inline ml-1">Shared</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-4 h-4" />
                          <span className="hidden sm:inline ml-1">Share</span>
                        </>
                      )}
                    </Button>
                    
                    {/* AI Message Button - Blue Theme */}
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setMessageModalContact(contact);
                      }}
                      className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                      title="Generate AI Message"
                    >
                      <Sparkles className="w-4 h-4" />
                    </Button>

                    {/* Email Button - Conditional */}
                    {(contact.connection_email || contact.email) ? (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        asChild
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <a href={`mailto:${contact.connection_email || contact.email}`} onClick={(e) => e.stopPropagation()}>
                          <Mail className="w-4 h-4" />
                        </a>
                      </Button>
                    ) : (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-blue-600 hover:bg-blue-50 text-xs"
                        title="Enrich this contact with Apollo.io for $0.25"
                        onClick={(e) => {
                          e.stopPropagation();
                          // TODO: Implement Apollo enrichment
                          toast({
                            title: 'Enrichment Feature',
                            description: 'Contact enrichment with Apollo.io is coming soon!',
                            variant: 'default',
                          });
                        }}
                      >
                        Enrich $.25
                      </Button>
                    )}

                    {/* LinkedIn Button - Conditional */}
                    {contact.linkedin_url && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        asChild
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <a href={contact.linkedin_url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                          <Linkedin className="w-4 h-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredContacts.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <p className="text-gray-500 text-lg mb-2">No contacts found</p>
            <p className="text-gray-400 text-sm">Try adjusting your search or filters</p>
          </CardContent>
        </Card>
      )}

      {/* Share Contact Dialog */}
      <ShareContactDialog
        isOpen={shareDialogOpen}
        onClose={() => {
          setShareDialogOpen(false);
          setContactToShare(null);
        }}
        contact={contactToShare}
        onShareComplete={handleShareComplete}
      />

      {/* Bulk Share Dialog */}
      <BulkShareDialog
        isOpen={bulkShareDialogOpen}
        onClose={() => setBulkShareDialogOpen(false)}
        selectedContacts={localSelectedContacts.map(id => contacts.find(c => c.id === id)).filter(Boolean)}
        onShareComplete={async () => {
          setBulkShareDialogOpen(false);
          clearSelection();
          await onRefresh();
        }}
      />

      {/* Personalized Message Modal */}
      {messageModalContact && (
        <PersonalizedMessageModal
          isOpen={!!messageModalContact}
          onClose={() => setMessageModalContact(null)}
          contact={messageModalContact}
          triggerSource="command_center"
        />
      )}
    </div>
  );
}
