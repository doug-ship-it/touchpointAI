import React, { useState, useEffect, useMemo } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { 
  DollarSign, 
  TrendingUp, 
  Target, 
  Calendar,
  Plus,
  MoreVertical,
  User,
  Building2,
  Clock,
  Percent
} from 'lucide-react';
import { format } from 'date-fns';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CRMDeal } from '@/api/entities';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

const PIPELINE_STAGES = [
  { id: 'discovery', name: 'Discovery', color: 'bg-slate-500' },
  { id: 'qualification', name: 'Qualification', color: 'bg-blue-500' },
  { id: 'proposal', name: 'Proposal', color: 'bg-purple-500' },
  { id: 'negotiation', name: 'Negotiation', color: 'bg-amber-500' },
  { id: 'closed_won', name: 'Closed Won', color: 'bg-emerald-500' },
  { id: 'closed_lost', name: 'Closed Lost', color: 'bg-red-500' }
];

const DEAL_TYPE_COLORS = {
  'Executive Search': 'bg-indigo-100 text-indigo-800 border-indigo-300',
  'Consulting': 'bg-purple-100 text-purple-800 border-purple-300',
  'Software Development': 'bg-blue-100 text-blue-800 border-blue-300',
  'Digital Operations': 'bg-emerald-100 text-emerald-800 border-emerald-300',
  'TouchpointAI': 'bg-amber-100 text-amber-800 border-amber-300'
};

export default function DealPipelineTab() {
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDealType, setSelectedDealType] = useState('all');
  const [draggingDealId, setDraggingDealId] = useState(null);

  // Metrics calculation
  const metrics = useMemo(() => {
    const activePipeline = deals.filter(d => d.stage !== 'closed_lost');
    
    const totalPipelineValue = activePipeline.reduce((sum, deal) => 
      sum + (deal.estimated_value || 0), 0
    );
    
    const weightedPipelineValue = activePipeline.reduce((sum, deal) => {
      const probability = deal.probability || 0;
      return sum + ((deal.estimated_value || 0) * probability / 100);
    }, 0);

    const closedWonDeals = deals.filter(d => d.stage === 'closed_won');
    const closedLostDeals = deals.filter(d => d.stage === 'closed_lost');
    const forecastedRevenue = closedWonDeals.reduce((sum, deal) => 
      sum + (deal.estimated_value || 0), 0
    );

    const totalClosed = closedWonDeals.length + closedLostDeals.length;
    const winRate = totalClosed > 0 
      ? Math.round((closedWonDeals.length / totalClosed) * 100) 
      : 0;

    return {
      totalPipelineValue,
      weightedPipelineValue,
      dealCount: activePipeline.length,
      avgDealSize: activePipeline.length > 0 ? totalPipelineValue / activePipeline.length : 0,
      forecastedRevenue,
      winRate
    };
  }, [deals]);

  // Load deals
  useEffect(() => {
    const fetchDeals = async () => {
      setLoading(true);
      try {
        const allDeals = await CRMDeal.list('-updated_date');
        setDeals(allDeals || []);
      } catch (error) {
        console.error('Failed to load deals:', error);
        toast.error('Failed to load deals');
        setDeals([]);
      } finally {
        setLoading(false);
      }
    };

    fetchDeals();
  }, []);

  // Filter deals by type
  const filteredDeals = useMemo(() => {
    if (selectedDealType === 'all') return deals;
    return deals.filter(deal => deal.deal_type === selectedDealType);
  }, [deals, selectedDealType]);

  // Group deals by stage
  const dealsByStage = useMemo(() => {
    const grouped = {};
    PIPELINE_STAGES.forEach(stage => {
      grouped[stage.id] = filteredDeals.filter(d => d.stage === stage.id);
    });
    return grouped;
  }, [filteredDeals]);

  // Calculate stage totals
  const stageTotals = useMemo(() => {
    const totals = {};
    PIPELINE_STAGES.forEach(stage => {
      const stageDeals = dealsByStage[stage.id] || [];
      totals[stage.id] = stageDeals.reduce((sum, deal) => 
        sum + (deal.estimated_value || 0), 0
      );
    });
    return totals;
  }, [dealsByStage]);

  const handleDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    setDraggingDealId(null);

    if (!destination || destination.droppableId === source.droppableId) {
      return;
    }

    const dealId = draggableId;
    const newStage = destination.droppableId;
    const oldDeal = deals.find(d => d.id === dealId);

    if (!oldDeal) return;

    // Optimistic update
    const updatedDeals = deals.map(d => 
      d.id === dealId 
        ? { ...d, stage: newStage, stage_changed_at: new Date().toISOString() }
        : d
    );
    setDeals(updatedDeals);

    try {
      await CRMDeal.update(dealId, { 
        stage: newStage,
        stage_changed_at: new Date().toISOString()
      });
      
      toast.success(`Deal moved to ${PIPELINE_STAGES.find(s => s.id === newStage)?.name}`);
    } catch (error) {
      console.error('Failed to update deal stage:', error);
      setDeals(deals); // Revert on error
      toast.error('Failed to update deal stage');
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading pipeline...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Deal Pipeline</h2>
          <p className="text-gray-600 mt-1">
            Team CRM & Revenue Management
          </p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={selectedDealType}
            onChange={(e) => setSelectedDealType(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          >
            <option value="all">All Deal Types</option>
            <option value="Executive Search">Executive Search</option>
            <option value="Consulting">Strategic Consulting</option>
            <option value="Software Development">Software Development</option>
            <option value="Digital Operations">Digital Operations</option>
            <option value="TouchpointAI">TouchpointAI</option>
          </select>
          <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
            <Plus className="w-4 h-4 mr-2" />
            New Deal
          </Button>
        </div>
      </div>

      {/* Metrics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Pipeline Value */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <DollarSign className="w-5 h-5 text-indigo-600" />
              </div>
              <span className="text-xs font-medium text-gray-500">TOTAL PIPELINE</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(metrics.totalPipelineValue)}
            </div>
            <p className="text-xs text-gray-600 mt-1">
              {metrics.dealCount} active deals
            </p>
          </CardContent>
        </Card>

        {/* Weighted Pipeline */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-purple-50 rounded-lg">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <span className="text-xs font-medium text-gray-500">WEIGHTED VALUE</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(metrics.weightedPipelineValue)}
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Probability-adjusted
            </p>
          </CardContent>
        </Card>

        {/* Closed Won Revenue */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-emerald-50 rounded-lg">
                <Target className="w-5 h-5 text-emerald-600" />
              </div>
              <span className="text-xs font-medium text-gray-500">CLOSED WON</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(metrics.forecastedRevenue)}
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Actual revenue
            </p>
          </CardContent>
        </Card>

        {/* Average Deal Size */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-amber-50 rounded-lg">
                <Calendar className="w-4 h-4 text-amber-600" />
              </div>
              <span className="text-xs font-medium text-gray-500">AVG DEAL SIZE</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(metrics.avgDealSize)}
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Per opportunity
            </p>
          </CardContent>
        </Card>

        {/* Win Rate */}
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Percent className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-xs font-medium text-gray-500">WIN RATE</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {metrics.winRate}%
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Historical close rate
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Pipeline Board */}
      <DragDropContext 
        onDragEnd={handleDragEnd}
        onDragStart={(start) => setDraggingDealId(start.draggableId)}
      >
        <div className="flex gap-4 overflow-x-auto pb-4">
          {PIPELINE_STAGES.map(stage => {
            const stageDeals = dealsByStage[stage.id] || [];
            const stageValue = stageTotals[stage.id] || 0;

            return (
              <div key={stage.id} className="flex-shrink-0 w-80">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                  {/* Stage Header */}
                  <div className={`${stage.color} text-white p-4`}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-sm uppercase tracking-wide">
                        {stage.name}
                      </h3>
                      <Badge variant="secondary" className="bg-white/20 text-white border-none">
                        {stageDeals.length}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold">
                      {formatCurrency(stageValue)}
                    </div>
                  </div>

                  {/* Droppable Area */}
                  <Droppable droppableId={stage.id}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`p-3 min-h-[400px] space-y-3 transition-colors ${
                          snapshot.isDraggingOver ? 'bg-indigo-50' : 'bg-gray-50'
                        }`}
                      >
                        <AnimatePresence>
                          {stageDeals.map((deal, index) => (
                            <Draggable key={deal.id} draggableId={deal.id} index={index}>
                              {(provided, snapshot) => (
                                <motion.div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  initial={{ opacity: 0, y: 20 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, scale: 0.9 }}
                                  className={`bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-all cursor-move ${
                                    snapshot.isDragging ? 'shadow-lg ring-2 ring-indigo-400 rotate-2' : ''
                                  }`}
                                >
                                  {/* Deal Card Content */}
                                  <div className="flex items-start justify-between mb-3">
                                    <h4 className="font-semibold text-gray-900 text-sm leading-tight flex-1 pr-2">
                                      {deal.deal_name}
                                    </h4>
                                    <button className="text-gray-400 hover:text-gray-600 flex-shrink-0">
                                      <MoreVertical className="w-4 h-4" />
                                    </button>
                                  </div>

                                  <div className="space-y-2 mb-3">
                                    <div className="flex items-center gap-2 text-xs text-gray-600">
                                      <Building2 className="w-3 h-3" />
                                      <span className="font-medium">{deal.company}</span>
                                    </div>
                                    <Badge 
                                      className={`text-xs px-2 py-1 ${
                                        DEAL_TYPE_COLORS[deal.deal_type] || 'bg-gray-100 text-gray-800'
                                      }`}
                                    >
                                      {deal.deal_type}
                                    </Badge>
                                  </div>

                                  <div className="space-y-2 border-t border-gray-100 pt-3">
                                    <div className="flex items-center justify-between">
                                      <span className="text-xs text-gray-500">Value</span>
                                      <span className="text-sm font-bold text-gray-900">
                                        {formatCurrency(deal.estimated_value || 0)}
                                      </span>
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                      <span className="text-xs text-gray-500">Probability</span>
                                      <span className="text-sm font-semibold text-indigo-600">
                                        {deal.probability || 0}%
                                      </span>
                                    </div>

                                    {deal.expected_close_date && (
                                      <div className="flex items-center justify-between">
                                        <span className="text-xs text-gray-500 flex items-center gap-1">
                                          <Clock className="w-3 h-3" />
                                          Close Date
                                        </span>
                                        <span className="text-xs font-medium text-gray-700">
                                          {format(new Date(deal.expected_close_date), 'MMM dd, yyyy')}
                                        </span>
                                      </div>
                                    )}

                                    {deal.deal_owner_email && (
                                      <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                                        <User className="w-3 h-3 text-gray-400" />
                                        <span className="text-xs text-gray-600 truncate">
                                          {deal.deal_owner_email}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                </motion.div>
                              )}
                            </Draggable>
                          ))}
                        </AnimatePresence>
                        {provided.placeholder}

                        {/* Add Deal Button */}
                        <button className="w-full p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-indigo-400 hover:text-indigo-600 hover:bg-indigo-50 transition-all text-sm font-medium flex items-center justify-center gap-2">
                          <Plus className="w-4 h-4" />
                          Add Deal
                        </button>
                      </div>
                    )}
                  </Droppable>
                </div>
              </div>
            );
          })}
        </div>
      </DragDropContext>

      {/* Empty State */}
      {deals.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <DollarSign className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No deals yet</h3>
          <p className="text-gray-600 mb-6">
            Start tracking your revenue opportunities by creating your first deal.
          </p>
          <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Create First Deal
          </Button>
        </div>
      )}
    </div>
  );
}