import React from 'react';
import KeepInTouchReminders from '../KeepInTouchReminders';

export default function UnifiedRemindersTab({ contacts, onReminderUpdate, onContactSelect }) {
  return (
    <div className="space-y-6">
      <KeepInTouchReminders />
    </div>
  );
}