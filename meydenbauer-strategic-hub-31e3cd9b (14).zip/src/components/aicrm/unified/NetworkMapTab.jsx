import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, ZoomIn, ZoomOut, Maximize2, Download,
  Filter, Users, Building2, TrendingUp
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function NetworkMapTab({ contacts, onContactSelect }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [colorBy, setColorBy] = useState('company');
  const [selectedNode, setSelectedNode] = useState(null);
  const [zoom, setZoom] = useState(1);
  const canvasRef = useRef(null);

  // Process contacts into network data
  const processNetworkData = () => {
    const companies = {};
    const nodes = [];
    const links = [];

    contacts.forEach((contact, index) => {
      const company = contact.connection_company || 'Unknown';
      
      if (!companies[company]) {
        companies[company] = [];
      }
      companies[company].push(contact);

      nodes.push({
        id: contact.id,
        name: contact.connection_name,
        company: company,
        title: contact.connection_title,
        relationship_strength: contact.relationship_strength || 'medium',
        relationship_score: contact.relationship_score || 5,
        x: Math.random() * 800,
        y: Math.random() * 600
      });
    });

    // Create links between contacts at same company
    Object.values(companies).forEach(companyContacts => {
      if (companyContacts.length > 1) {
        for (let i = 0; i < companyContacts.length - 1; i++) {
          for (let j = i + 1; j < companyContacts.length; j++) {
            links.push({
              source: companyContacts[i].id,
              target: companyContacts[j].id,
              strength: 'company'
            });
          }
        }
      }
    });

    return { nodes, links, companies: Object.keys(companies) };
  };

  const { nodes, links, companies } = processNetworkData();

  const getNodeColor = (node) => {
    if (colorBy === 'company') {
      const companyIndex = companies.indexOf(node.company);
      const colors = [
        '#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6',
        '#ec4899', '#14b8a6', '#f97316', '#6366f1', '#84cc16'
      ];
      return colors[companyIndex % colors.length];
    } else if (colorBy === 'relationship') {
      return node.relationship_strength === 'strong' ? '#10b981' :
             node.relationship_strength === 'medium' ? '#f59e0b' : '#ef4444';
    }
    return '#6b7280';
  };

  const getNodeSize = (node) => {
    return 20 + (node.relationship_score || 5) * 2;
  };

  const filteredNodes = searchQuery
    ? nodes.filter(n => 
        n.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.company.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : nodes;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Network Visualization
          </CardTitle>
          <CardDescription>
            Visual map of your relationship network
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search contacts or companies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Color By */}
            <Select value={colorBy} onValueChange={setColorBy}>
              <SelectTrigger>
                <SelectValue placeholder="Color by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="company">By Company</SelectItem>
                <SelectItem value="relationship">By Relationship Strength</SelectItem>
                <SelectItem value="score">By Score</SelectItem>
              </SelectContent>
            </Select>

            {/* Zoom Controls */}
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => setZoom(z => Math.min(z + 0.2, 3))}>
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => setZoom(z => Math.max(z - 0.2, 0.5))}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Maximize2 className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Network Canvas */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="relative bg-white rounded-lg border-2 border-gray-200" style={{ height: '600px' }}>
            <svg ref={canvasRef} className="w-full h-full">
              {/* Draw links */}
              <g>
                {links.map((link, index) => {
                  const sourceNode = nodes.find(n => n.id === link.source);
                  const targetNode = nodes.find(n => n.id === link.target);
                  if (!sourceNode || !targetNode) return null;

                  return (
                    <line
                      key={`link-${index}`}
                      x1={sourceNode.x}
                      y1={sourceNode.y}
                      x2={targetNode.x}
                      y2={targetNode.y}
                      stroke="#e5e7eb"
                      strokeWidth="1"
                      opacity="0.6"
                    />
                  );
                })}
              </g>

              {/* Draw nodes */}
              <g>
                {filteredNodes.map((node) => (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y}) scale(${zoom})`}
                    onClick={() => {
                      setSelectedNode(node);
                      onContactSelect(contacts.find(c => c.id === node.id));
                    }}
                    className="cursor-pointer"
                  >
                    <circle
                      r={getNodeSize(node) / 2}
                      fill={getNodeColor(node)}
                      stroke="white"
                      strokeWidth="2"
                      className="hover:opacity-80 transition-opacity"
                    />
                    <text
                      y="30"
                      textAnchor="middle"
                      fontSize="12"
                      fill="#374151"
                      className="pointer-events-none"
                    >
                      {node.name.split(' ')[0]}
                    </text>
                  </g>
                ))}
              </g>
            </svg>

            {/* Legend */}
            <div className="absolute bottom-4 right-4 bg-white p-4 rounded-lg shadow-lg border">
              <h4 className="font-semibold text-sm mb-2">Legend</h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span>Strong Relationship</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <span>Medium Relationship</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span>Weak Relationship</span>
                </div>
              </div>
            </div>
          </div>

          {/* Node Details */}
          {selectedNode && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-lg">{selectedNode.name}</h3>
                  <p className="text-gray-600">{selectedNode.title}</p>
                  <p className="text-sm text-gray-500">{selectedNode.company}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={selectedNode.relationship_strength === 'strong' ? 'default' : 'secondary'}>
                      {selectedNode.relationship_strength}
                    </Badge>
                    <span className="text-sm text-gray-600">Score: {selectedNode.relationship_score}/10</span>
                  </div>
                </div>
                <Button size="sm" variant="outline">
                  View Full Profile
                </Button>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Network Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Network</p>
                <p className="text-2xl font-bold">{nodes.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Building2 className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Companies</p>
                <p className="text-2xl font-bold">{companies.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Connections</p>
                <p className="text-2xl font-bold">{links.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}