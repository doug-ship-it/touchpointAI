
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Zap, CheckCircle, Clock, AlertCircle, Sparkles, XCircle,
  TrendingUp, Building2, MapPin, Briefcase, Play, Pause,
  AlertTriangle, RefreshCw, CheckCheck, Lock
} from 'lucide-react';
import { toast } from 'sonner';
import { apolloEnrichmentService } from '../apolloEnrichmentService';
import { NetworkConnection } from '@/api/entities';
import EnrichmentPasswordModal, { useEnrichmentAccess } from '../../network/EnrichmentPasswordModal';

export default function UnifiedEnrichmentTab({ contacts, selectedContacts, onEnrichmentComplete }) {
  const [enriching, setEnriching] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [enrichmentProgress, setEnrichmentProgress] = useState(0);
  const [currentContact, setCurrentContact] = useState(null);
  const [enrichmentStats, setEnrichmentStats] = useState({
    total: 0,
    completed: 0,
    successful: 0,
    failed: 0,
    skipped: 0
  });
  const [apiConnected, setApiConnected] = useState(null);
  const [enrichmentResults, setEnrichmentResults] = useState([]);

  const {
    hasAccess,
    showPasswordModal,
    setShowPasswordModal,
    requestAccess,
    grantAccess
  } = useEnrichmentAccess();

  const enrichedCount = contacts.filter(c => 
    c.enriched_industry && c.enriched_seniority && c.enrichment_source === 'apollo'
  ).length;
  const needsEnrichment = contacts.filter(c => 
    !c.enriched_industry || !c.enriched_seniority
  ).length;
  const enrichmentPercentage = contacts.length > 0 
    ? Math.round((enrichedCount / contacts.length) * 100)
    : 0;

  useEffect(() => {
    const testConnection = async () => {
      const connected = await apolloEnrichmentService.testConnection();
      setApiConnected(connected);
      if (!connected) {
        toast.error('Apollo API connection failed. Check your API key configuration.');
      }
    };
    
    testConnection();
  }, []);

  const handleBulkEnrichClick = () => {
    if (!requestAccess()) {
      return;
    }
    handleBulkEnrich();
  };

  const handleBulkEnrich = async () => {
    if (apiConnected === false) {
      toast.error('Apollo API is not connected. Please check your configuration.');
      return;
    }

    const contactsToEnrich = selectedContacts && selectedContacts.length > 0
      ? contacts.filter(c => selectedContacts.includes(c.id))
      : contacts.filter(c => !c.enriched_industry || !c.enriched_seniority);

    if (contactsToEnrich.length === 0) {
      toast.info('No contacts need enrichment');
      return;
    }

    setEnriching(true);
    setIsPaused(false);
    setEnrichmentProgress(0);
    setEnrichmentStats({
      total: contactsToEnrich.length,
      completed: 0,
      successful: 0,
      failed: 0,
      skipped: 0
    });
    setEnrichmentResults([]);

    try {
      await apolloEnrichmentService.enrichBulk(
        contactsToEnrich,
        async (current, total, contact, enrichedData) => {
          const progress = Math.round((current / total) * 100);
          setEnrichmentProgress(progress);
          setCurrentContact(contact);

          setEnrichmentStats(prev => ({
            ...prev,
            completed: current,
            successful: enrichedData ? prev.successful + 1 : prev.successful,
            failed: !enrichedData ? prev.failed + 1 : prev.failed
          }));

          if (enrichedData) {
            try {
              await NetworkConnection.update(contact.id, enrichedData);
              
              setEnrichmentResults(prev => [...prev, {
                contactId: contact.id,
                contactName: contact.connection_name || contact.name,
                success: true,
                data: enrichedData
              }]);
            } catch (updateError) {
              console.error(`Failed to update contact ${contact.id}:`, updateError);
              setEnrichmentStats(prev => ({
                ...prev,
                failed: prev.failed + 1,
                successful: prev.successful - 1
              }));
              
              setEnrichmentResults(prev => [...prev, {
                contactId: contact.id,
                contactName: contact.connection_name || contact.name,
                success: false,
                error: 'Database update failed'
              }]);
            }
          } else {
            setEnrichmentResults(prev => [...prev, {
              contactId: contact.id,
              contactName: contact.connection_name || contact.name,
              success: false,
              error: 'No data found'
            }]);
          }

          while (isPaused) {
            await new Promise(resolve => setTimeout(resolve, 500));
          }
        }
      );

      toast.success(
        `Enrichment completed! ${enrichmentStats.successful} contacts updated successfully.`,
        { duration: 5000 }
      );

      if (onEnrichmentComplete) {
        onEnrichmentComplete();
      }

    } catch (error) {
      console.error('Bulk enrichment error:', error);
      toast.error(`Enrichment failed: ${error.message}`);
    } finally {
      setEnriching(false);
      setCurrentContact(null);
    }
  };

  const togglePause = () => {
    setIsPaused(!isPaused);
    toast.info(isPaused ? 'Enrichment resumed' : 'Enrichment paused');
  };

  return (
    <>
      <div className="space-y-6">
        {apiConnected === false && (
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-900">
              <strong>Apollo API Connection Failed</strong>
              <p className="text-sm mt-1">
                Check that your VITE_APOLLO_API_KEY environment variable is set correctly.
              </p>
            </AlertDescription>
          </Alert>
        )}

        {/* Enrichment Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <span className="text-3xl font-bold text-gray-900">{enrichedCount}</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">Enriched Contacts</p>
              <p className="text-xs text-gray-500 mt-1">{enrichmentPercentage}% of total</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-orange-50 rounded-lg">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
                <span className="text-3xl font-bold text-gray-900">{needsEnrichment}</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">Needs Enrichment</p>
              <p className="text-xs text-gray-500 mt-1">Ready to process</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <Sparkles className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-3xl font-bold text-gray-900">{contacts.length}</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">Total Contacts</p>
              <p className="text-xs text-gray-500 mt-1">In your network</p>
            </CardContent>
          </Card>
        </div>

        {/* Active Enrichment Progress */}
        <AnimatePresence>
          {enriching && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-gray-900 text-lg">
                        {isPaused ? 'Enrichment Paused' : 'Enriching Contacts...'}
                      </h3>
                      {currentContact && (
                        <p className="text-sm text-gray-600 mt-1">
                          Processing: {currentContact.connection_name || currentContact.name}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={togglePause}
                      className="gap-2"
                    >
                      {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                      {isPaused ? 'Resume' : 'Pause'}
                    </Button>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>{enrichmentStats.completed} / {enrichmentStats.total} contacts</span>
                      <span className="font-semibold">{enrichmentProgress}%</span>
                    </div>
                    <Progress value={enrichmentProgress} className="h-2" />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-white rounded-lg">
                      <CheckCheck className="w-5 h-5 text-green-600 mx-auto mb-1" />
                      <p className="text-2xl font-bold text-gray-900">{enrichmentStats.successful}</p>
                      <p className="text-xs text-gray-600">Successful</p>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg">
                      <XCircle className="w-5 h-5 text-red-600 mx-auto mb-1" />
                      <p className="text-2xl font-bold text-gray-900">{enrichmentStats.failed}</p>
                      <p className="text-xs text-gray-600">Failed</p>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg">
                      <RefreshCw className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                      <p className="text-2xl font-bold text-gray-900">
                        {enrichmentStats.total - enrichmentStats.completed}
                      </p>
                      <p className="text-xs text-gray-600">Remaining</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Enrichment Control Card */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardContent className="p-8">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold text-gray-900">
                    Apollo.io Contact Enrichment
                  </h2>
                  {hasAccess ? (
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  ) : (
                    <Badge className="bg-gray-100 text-gray-600 flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Locked
                    </Badge>
                  )}
                </div>
                <p className="text-gray-600 mb-4">
                  Automatically enhance your contacts with real-time professional data from Apollo.io's database of 275M+ contacts
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <Badge variant="secondary" className="bg-white">
                    <Building2 className="w-3 h-3 mr-1" />
                    Company Data
                  </Badge>
                  <Badge variant="secondary" className="bg-white">
                    <Briefcase className="w-3 h-3 mr-1" />
                    Job Titles & Seniority
                  </Badge>
                  <Badge variant="secondary" className="bg-white">
                    <MapPin className="w-3 h-3 mr-1" />
                    Locations
                  </Badge>
                  <Badge variant="secondary" className="bg-white">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Company Size
                  </Badge>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <div className={`w-2 h-2 rounded-full ${apiConnected ? 'bg-green-500' : apiConnected === false ? 'bg-red-500' : 'bg-yellow-500'}`} />
                  <span className="text-sm text-gray-600">
                    {apiConnected === null ? 'Testing connection...' : apiConnected ? 'Apollo API Connected' : 'API Disconnected'}
                  </span>
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={handleBulkEnrichClick}
                    disabled={enriching || needsEnrichment === 0 || apiConnected === false}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    {!hasAccess && <Lock className="w-4 h-4 mr-2" />}
                    <Zap className="w-4 h-4 mr-2" />
                    {enriching ? 'Enriching...' : hasAccess ? `Enrich ${needsEnrichment} Contacts` : 'Unlock to Enrich'}
                  </Button>

                  {enrichmentResults.length > 0 && (
                    <Button 
                      variant="outline"
                      onClick={() => setEnrichmentResults([])}
                    >
                      Clear Results
                    </Button>
                  )}
                </div>
              </div>
              <Sparkles className="w-16 h-16 text-blue-300" />
            </div>
          </CardContent>
        </Card>

        {/* Enrichment Results */}
        {enrichmentResults.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Enrichment Results</CardTitle>
              <CardDescription>
                Detailed results from the last enrichment batch
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {enrichmentResults.map((result, index) => (
                  <div 
                    key={index}
                    className={`p-3 rounded-lg border ${
                      result.success 
                        ? 'bg-green-50 border-green-200' 
                        : 'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {result.success ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-600" />
                        )}
                        <div>
                          <p className="font-medium text-gray-900">
                            {result.contactName}
                          </p>
                          {result.success && result.data?.intelligent_summary && (
                            <p className="text-sm text-gray-600">
                              {result.data.intelligent_summary}
                            </p>
                          )}
                          {!result.success && result.error && (
                            <p className="text-sm text-red-600">
                              {result.error}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* What Gets Enriched */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>What Gets Enriched</CardTitle>
            <CardDescription>Comprehensive data enhancement powered by Apollo.io</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">Professional Information</p>
                <p className="text-sm text-gray-600">Current title, company, and seniority level verified from Apollo's 275M contact database</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">Company Data</p>
                <p className="text-sm text-gray-600">Company size, industry classification, and firmographic details</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">Contact Information</p>
                <p className="text-sm text-gray-600">Verified email addresses and phone numbers when available</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">Location & Social Profiles</p>
                <p className="text-sm text-gray-600">Geographic location and LinkedIn/Twitter profile verification</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <EnrichmentPasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onSuccess={grantAccess}
        featureName="Apollo.io Contact Enrichment"
      />
    </>
  );
}
