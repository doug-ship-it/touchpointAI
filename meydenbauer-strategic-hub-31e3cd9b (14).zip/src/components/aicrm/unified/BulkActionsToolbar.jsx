import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Tag, Download, Trash2, Zap, Mail, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BulkActionsToolbar({ selectedContacts, onAction, onClearSelection }) {
  if (!selectedContacts || selectedContacts.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-white border-2 border-blue-200 rounded-2xl shadow-2xl px-6 py-4 backdrop-blur-xl"
        style={{ maxWidth: 'calc(100vw - 2rem)' }}
      >
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
              {selectedContacts.length}
            </div>
            <span className="text-sm font-semibold text-slate-700">
              {selectedContacts.length} contact{selectedContacts.length !== 1 ? 's' : ''} selected
            </span>
          </div>
          
          <div className="h-6 w-px bg-slate-200" />
          
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction('tag')}
              className="flex items-center gap-2 hover:bg-blue-50 hover:border-blue-300"
            >
              <Tag className="h-4 w-4" />
              <span className="hidden sm:inline">Tag</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction('enrich')}
              className="flex items-center gap-2 hover:bg-purple-50 hover:border-purple-300"
            >
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Enrich</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction('email')}
              className="flex items-center gap-2 hover:bg-green-50 hover:border-green-300"
            >
              <Mail className="h-4 w-4" />
              <span className="hidden sm:inline">Email</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction('export')}
              className="flex items-center gap-2 hover:bg-indigo-50 hover:border-indigo-300"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Export</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction('delete')}
              className="flex items-center gap-2 hover:bg-red-50 hover:border-red-300 text-red-600"
            >
              <Trash2 className="h-4 w-4" />
              <span className="hidden sm:inline">Delete</span>
            </Button>
          </div>
          
          <div className="h-6 w-px bg-slate-200" />
          
          <button
            onClick={onClearSelection}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}