import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Upload, Linkedin, Mail, Cloud, FileText, 
  CheckCircle, ArrowRight, Facebook, Instagram
} from 'lucide-react';

export default function UnifiedImportTab({ onImportComplete, onFileSelect }) {
  const [importMethod, setImportMethod] = useState(null);

  const importMethods = [
    {
      id: 'csv',
      name: 'CSV / Excel File',
      icon: FileText,
      description: 'Upload LinkedIn connections export or custom CSV',
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600',
      action: onFileSelect
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      icon: Linkedin,
      description: 'Import connections from LinkedIn',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      comingSoon: true
    },
    {
      id: 'gmail',
      name: 'Gmail',
      icon: Mail,
      description: 'Sync contacts from Gmail',
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-50',
      textColor: 'text-red-600',
      comingSoon: true
    },
    {
      id: 'outlook',
      name: 'Outlook',
      icon: Mail,
      description: 'Sync contacts from Outlook',
      color: 'from-blue-500 to-indigo-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      comingSoon: true
    },
    {
      id: 'google',
      name: 'Google Contacts',
      icon: Cloud,
      description: 'Import from Google Contacts',
      color: 'from-yellow-500 to-orange-600',
      bgColor: 'bg-yellow-50',
      textColor: 'text-yellow-600',
      comingSoon: true
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: Facebook,
      description: 'Import friends from Facebook',
      color: 'from-blue-600 to-blue-700',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      comingSoon: true
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
        <CardContent className="p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Import Your Network
          </h2>
          <p className="text-gray-600">
            Connect your platforms to automatically import and sync your professional network
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {importMethods.map((method, index) => (
          <motion.div
            key={method.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className={`border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer ${method.comingSoon ? 'opacity-60' : ''}`}>
              <CardContent className="p-6">
                <div className={`w-12 h-12 ${method.bgColor} rounded-xl flex items-center justify-center mb-4`}>
                  <method.icon className={`w-6 h-6 ${method.textColor}`} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  {method.name}
                  {method.comingSoon && (
                    <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full">
                      Coming Soon
                    </span>
                  )}
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  {method.description}
                </p>
                {!method.comingSoon && method.action && (
                  <Button 
                    onClick={method.action}
                    className={`w-full bg-gradient-to-r ${method.color} hover:opacity-90`}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Import Now
                  </Button>
                )}
                {method.comingSoon && (
                  <Button variant="outline" className="w-full" disabled>
                    Coming Soon
                  </Button>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Import Guidelines</CardTitle>
          <CardDescription>Best practices for importing your contacts</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-gray-900">CSV Format</p>
              <p className="text-sm text-gray-600">
                Ensure your CSV includes columns for Name, Email, Company, and Title
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-gray-900">Duplicate Detection</p>
              <p className="text-sm text-gray-600">
                Our system automatically detects and merges duplicate contacts
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-gray-900">Automatic Enrichment</p>
              <p className="text-sm text-gray-600">
                New contacts are automatically enriched with additional data
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}