import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, TrendingUp, Calendar, DollarSign, 
  Activity, BarChart3, ArrowUp, ArrowDown,
  Bell, Zap
} from 'lucide-react';

export default function UnifiedStatsBar({ stats, contacts }) {
  const statCards = [
    {
      title: 'Total Contacts',
      value: stats.totalContacts.toLocaleString(),
      icon: Users,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      growth: stats.monthConnections,
      growthLabel: 'this month'
    },
    {
      title: 'Active Relationships',
      value: stats.activeRelationships.toLocaleString(),
      icon: Activity,
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600',
      percentage: stats.totalContacts > 0 
        ? Math.round((stats.activeRelationships / stats.totalContacts) * 100) 
        : 0,
      percentageLabel: 'of network'
    },
    {
      title: 'Pending Follow-ups',
      value: stats.pendingFollowUps.toLocaleString(),
      icon: Bell,
      color: 'from-orange-500 to-red-600',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600',
      urgent: stats.pendingFollowUps > 10,
      urgentLabel: stats.pendingFollowUps > 10 ? 'Needs attention' : 'On track'
    },
    {
      title: 'This Month',
      value: `+${stats.monthConnections}`,
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600',
      trend: stats.monthConnections > 5 ? 'up' : 'stable',
      trendLabel: 'new connections'
    },
    {
      title: 'Response Rate',
      value: `${stats.responseRate}%`,
      icon: BarChart3,
      color: 'from-indigo-500 to-blue-600',
      bgColor: 'bg-indigo-50',
      textColor: 'text-indigo-600',
      performance: stats.responseRate >= 70 ? 'excellent' : stats.responseRate >= 50 ? 'good' : 'needs improvement',
      performanceLabel: stats.responseRate >= 70 ? 'Excellent' : stats.responseRate >= 50 ? 'Good' : 'Improve'
    },
    {
      title: 'Pipeline Value',
      value: `$${(stats.pipelineValue / 1000000).toFixed(1)}M`,
      icon: DollarSign,
      color: 'from-emerald-500 to-green-600',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-600',
      subtitle: 'Estimated opportunity value',
      avgValue: stats.totalContacts > 0 
        ? Math.round(stats.pipelineValue / stats.totalContacts).toLocaleString() 
        : 0,
      avgLabel: 'avg per contact'
    }
  ];

  return (
    <div className="mt-6 grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {statCards.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="group"
        >
          <div className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-xl transition-all duration-300 cursor-pointer relative overflow-hidden">
            {/* Background Gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
            
            {/* Content */}
            <div className="relative">
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 ${stat.bgColor} rounded-lg group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon className={`w-5 h-5 ${stat.textColor}`} />
                </div>
                {stat.growth && (
                  <div className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                    <ArrowUp className="w-3 h-3" />
                    <span className="font-medium">{stat.growth}</span>
                  </div>
                )}
                {stat.urgent && (
                  <div className="flex items-center gap-1 text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded-full animate-pulse">
                    <Bell className="w-3 h-3" />
                  </div>
                )}
              </div>
              
              <div className="text-2xl font-bold text-slate-900 mb-1">
                {stat.value}
              </div>
              
              <div className="text-xs text-slate-600 font-medium mb-2">
                {stat.title}
              </div>
              
              {/* Secondary Info */}
              <div className="text-xs text-slate-500">
                {stat.growthLabel && (
                  <span>{stat.growthLabel}</span>
                )}
                {stat.percentage !== undefined && (
                  <span>{stat.percentage}% {stat.percentageLabel}</span>
                )}
                {stat.urgentLabel && (
                  <span className={stat.urgent ? 'text-orange-600 font-medium' : 'text-green-600'}>
                    {stat.urgentLabel}
                  </span>
                )}
                {stat.trendLabel && (
                  <span>{stat.trendLabel}</span>
                )}
                {stat.performanceLabel && (
                  <span className={
                    stat.performance === 'excellent' ? 'text-green-600 font-medium' : 
                    stat.performance === 'good' ? 'text-blue-600' : 'text-orange-600'
                  }>
                    {stat.performanceLabel}
                  </span>
                )}
                {stat.avgValue && (
                  <span>${stat.avgValue} {stat.avgLabel}</span>
                )}
                {stat.subtitle && (
                  <span className="block text-slate-400">{stat.subtitle}</span>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}