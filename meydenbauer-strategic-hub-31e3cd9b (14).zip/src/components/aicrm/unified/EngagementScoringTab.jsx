import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Flame, TrendingUp, Calculator, Target, Zap,
  Users, Calendar, Phone, Mail, Award
} from 'lucide-react';
import { toast } from 'sonner';
import { engagementScoringService } from '../engagementScoringService';
import { NetworkConnection } from '@/api/entities';

export default function EngagementScoringTab({ contacts, onScoreUpdate }) {
  const [scoring, setScoring] = useState(false);
  const [progress, setProgress] = useState(0);
  const [scoredContacts, setScoredContacts] = useState([]);

  // Calculate tier distribution
  const tierCounts = contacts.reduce((acc, c) => {
    const tier = c.engagement_tier || 'Unscored';
    acc[tier] = (acc[tier] || 0) + 1;
    return acc;
  }, {});

  const unscoredCount = contacts.filter(c => !c.engagement_score).length;
  const scoredContactsList = contacts.filter(c => c.engagement_score);
  const avgScore = scoredContactsList.length > 0
    ? Math.round(
        scoredContactsList.reduce((sum, c) => sum + (c.engagement_score || 0), 0) / 
        scoredContactsList.length
      )
    : 0;

  const handleBulkScore = async () => {
    const contactsToScore = contacts.filter(c => !c.engagement_score);

    if (contactsToScore.length === 0) {
      toast.info('All contacts already scored');
      return;
    }

    setScoring(true);
    setProgress(0);
    setScoredContacts([]);

    try {
      for (let i = 0; i < contactsToScore.length; i++) {
        const contact = contactsToScore[i];
        
        // Calculate engagement score
        const score = engagementScoringService.calculateEngagementScore(contact);
        const tier = engagementScoringService.getEngagementTier(score);
        const recommendations = engagementScoringService.generateRecommendations(contact, score);

        // Update contact
        await NetworkConnection.update(contact.id, {
          engagement_score: score,
          engagement_tier: tier.tier,
          engagement_priority: tier.priority,
          next_action: recommendations[0]?.action || null
        });

        setScoredContacts(prev => [...prev, {
          id: contact.id,
          name: contact.connection_name || contact.name,
          score,
          tier: tier.tier
        }]);

        setProgress(Math.round(((i + 1) / contactsToScore.length) * 100));
      }

      toast.success(`Scored ${contactsToScore.length} contacts!`);
      
      if (onScoreUpdate) {
        onScoreUpdate();
      }

    } catch (error) {
      console.error('Scoring error:', error);
      toast.error('Scoring failed: ' + error.message);
    } finally {
      setScoring(false);
    }
  };

  const getTierColor = (tier) => {
    switch (tier) {
      case 'Hot': return 'bg-red-100 text-red-800 border-red-300';
      case 'Warm': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'Lukewarm': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Cold': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Flame className="w-8 h-8 text-red-500" />
              <span className="text-3xl font-bold">{tierCounts.Hot || 0}</span>
            </div>
            <p className="text-sm font-medium text-gray-600">Hot Leads</p>
            <p className="text-xs text-gray-500">Score 80-100</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-orange-500" />
              <span className="text-3xl font-bold">{tierCounts.Warm || 0}</span>
            </div>
            <p className="text-sm font-medium text-gray-600">Warm Leads</p>
            <p className="text-xs text-gray-500">Score 60-79</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Award className="w-8 h-8 text-blue-500" />
              <span className="text-3xl font-bold">{avgScore}</span>
            </div>
            <p className="text-sm font-medium text-gray-600">Average Score</p>
            <p className="text-xs text-gray-500">Network health</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Calculator className="w-8 h-8 text-purple-500" />
              <span className="text-3xl font-bold">{unscoredCount}</span>
            </div>
            <p className="text-sm font-medium text-gray-600">Unscored</p>
            <p className="text-xs text-gray-500">Need scoring</p>
          </CardContent>
        </Card>
      </div>

      {/* Scoring Progress */}
      <AnimatePresence>
        {scoring && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-blue-50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-2">
                  Calculating Engagement Scores...
                </h3>
                <Progress value={progress} className="h-2 mb-4" />
                <p className="text-sm text-gray-600">
                  {scoredContacts.length} contacts scored
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Control Card */}
      <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-indigo-50">
        <CardContent className="p-8">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Relationship Intelligence Scoring
              </h2>
              <p className="text-gray-600 mb-4">
                AI-powered engagement scoring based on McKinsey relationship intelligence frameworks
              </p>
              
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="flex items-center gap-2 text-sm">
                  <Target className="w-4 h-4 text-purple-600" />
                  <span>Recency Analysis</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-purple-600" />
                  <span>Seniority Weighting</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-purple-600" />
                  <span>Interaction Frequency</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="w-4 h-4 text-purple-600" />
                  <span>Firmographic Fit</span>
                </div>
              </div>

              <Button 
                onClick={handleBulkScore}
                disabled={scoring || unscoredCount === 0}
                className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              >
                <Calculator className="w-4 h-4 mr-2" />
                {scoring ? 'Scoring...' : `Score ${unscoredCount} Contacts`}
              </Button>
            </div>
            <Target className="w-16 h-16 text-purple-300" />
          </div>
        </CardContent>
      </Card>

      {/* Scoring Methodology */}
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Scoring Methodology</CardTitle>
          <CardDescription>How engagement scores are calculated (0-100 scale)</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Recency</span>
              <Badge variant="secondary">25%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              Last contact: 0-30 days = 100pts, 31-90 = 70pts, 91-180 = 40pts, 180+ = 10pts
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Frequency</span>
              <Badge variant="secondary">20%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              Total interactions: 20+ = 100pts, 10-19 = 75pts, 5-9 = 50pts, 2-4 = 25pts
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Seniority</span>
              <Badge variant="secondary">20%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              CXO/Founder = 100pts, VP = 80pts, Director = 60pts, Manager = 40pts, IC = 20pts
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Firmographics</span>
              <Badge variant="secondary">15%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              Target industries + ideal company size (50-1000 employees) = higher scores
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Data Completeness</span>
              <Badge variant="secondary">10%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              Profile richness: LinkedIn, email, title, company, industry, location, size, phone
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Network Value</span>
              <Badge variant="secondary">10%</Badge>
            </div>
            <p className="text-sm text-gray-600">
              Referral potential based on role, industry influence, and connection strength
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Top Scored Contacts */}
      {scoredContacts.length > 0 && (
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Recently Scored Contacts</CardTitle>
            <CardDescription>Latest engagement score calculations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {scoredContacts.slice(-10).reverse().map((contact) => (
                <div 
                  key={contact.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div>
                    <p className="font-medium text-gray-900">{contact.name}</p>
                    <p className="text-sm text-gray-600">Score: {contact.score}/100</p>
                  </div>
                  <Badge className={getTierColor(contact.tier)}>
                    {contact.tier}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}