import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Download, TrendingUp, Users, Target, BarChart3,
  Calendar, Mail, Phone, Linkedin
} from 'lucide-react';

export default function UnifiedAnalyticsTab({ contacts, stats, onExport }) {
  // Calculate industry distribution with null checks
  const industryData = contacts.reduce((acc, contact) => {
    const industry = contact.enriched_industry || 'Unknown';
    acc[industry] = (acc[industry] || 0) + 1;
    return acc;
  }, {});

  const topIndustries = Object.entries(industryData)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // Calculate monthly growth
  const monthlyGrowth = Array.from({ length: 6 }, (_, i) => {
    const month = new Date();
    month.setMonth(month.getMonth() - (5 - i));
    const monthName = month.toLocaleDateString('en-US', { month: 'short' });
    
    const count = contacts.filter(c => {
      if (!c.created_date) return false;
      const createdDate = new Date(c.created_date);
      return createdDate.getMonth() === month.getMonth() && 
             createdDate.getFullYear() === month.getFullYear();
    }).length;
    
    return { label: monthName, value: count };
  });

  return (
    <div className="space-y-6">
      {/* Export Action */}
      <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Network Analytics
              </h2>
              <p className="text-gray-600">
                Comprehensive insights into your professional network
              </p>
            </div>
            <Button 
              onClick={onExport}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {stats.totalContacts}
            </p>
            <p className="text-sm text-gray-600">Total Contacts</p>
            <p className="text-xs text-green-600 mt-2">
              +{stats.monthConnections} this month
            </p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-green-50 rounded-lg">
                <Target className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {stats.responseRate}%
            </p>
            <p className="text-sm text-gray-600">Response Rate</p>
            <p className="text-xs text-gray-500 mt-2">
              Last 7 days
            </p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-purple-50 rounded-lg">
                <Calendar className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {stats.activeRelationships}
            </p>
            <p className="text-sm text-gray-600">Active Relationships</p>
            <p className="text-xs text-gray-500 mt-2">
              Contacted in 30 days
            </p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-orange-50 rounded-lg">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {stats.averageRelationshipScore}
            </p>
            <p className="text-sm text-gray-600">Avg. Relationship Score</p>
            <p className="text-xs text-gray-500 mt-2">
              Out of 10
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Network Growth */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Network Growth</CardTitle>
            <CardDescription>Contacts added over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-end justify-between gap-2">
              {monthlyGrowth.map((item, index) => {
                const maxValue = Math.max(...monthlyGrowth.map(d => d.value));
                const height = maxValue > 0 ? (item.value / maxValue) * 100 : 0;
                
                return (
                  <motion.div
                    key={index}
                    initial={{ height: 0 }}
                    animate={{ height: `${height}%` }}
                    transition={{ delay: index * 0.1 }}
                    className="flex-1 bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-md min-h-[4px] relative group"
                  >
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                      {item.value} contacts
                    </div>
                    <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs text-gray-600 whitespace-nowrap">
                      {item.label}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Top Industries */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Top Industries</CardTitle>
            <CardDescription>Network distribution by industry</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topIndustries.map(([industry, count], index) => {
                const percentage = Math.round((count / contacts.length) * 100);
                
                return (
                  <div key={industry}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">
                        {industry}
                      </span>
                      <span className="text-sm text-gray-600">
                        {count} ({percentage}%)
                      </span>
                    </div>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${percentage}%` }}
                      transition={{ delay: index * 0.1 }}
                      className="h-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full"
                    />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}