
import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox'; // New import
import { 
  Target, Phone, Mail, Briefcase, Search, Filter, 
  ExternalLink, Users, DollarSign, Building2, MapPin, Trash2, X // New icons
} from 'lucide-react';
import { contactPrioritizationService } from '../contactPrioritizationService';

// Changed props: contactsPromise -> contacts, added onDeleteContacts
// The 'contacts' prop is expected to be an array of objects like { contact: TContact, priority_score: number }
export default function PriorityDashboardTab({ contacts: priorityItems, onContactClick, segmentFilter, userSegments, onDeleteContacts }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState([]); // New state for selection

  // Removed internal `contacts` state and `loading` state as `priorityItems` is now a direct prop
  // Also removed the useEffect that loaded contacts from a promise, as contacts are now passed directly.

  // Extract raw contact objects for services that expect them
  const rawContacts = useMemo(() => priorityItems?.map(item => item.contact) || [], [priorityItems]);

  // Calculate stats and categorize using raw contact data
  const stats = useMemo(() => {
    if (!rawContacts || rawContacts.length === 0) {
      return {
        immediate_outreach: 0,
        executive_search: 0,
        consulting_targets: 0,
        pe_network: 0
      };
    }
    return contactPrioritizationService.getQuickStats(rawContacts);
  }, [rawContacts]);

  const categorized = useMemo(() => 
    contactPrioritizationService.categorizeByAction(rawContacts),
    [rawContacts]
  );
  
  // The 'priorityItems' prop itself represents the priority contacts data, including scores
  const priorityContactsData = useMemo(() => 
    priorityItems,
    [priorityItems]
  );

  // Filter contacts based on category and search
  const displayedContacts = useMemo(() => {
    let filteredData = selectedCategory === 'all' 
      ? priorityContactsData 
      : priorityContactsData.filter(p => (categorized[selectedCategory] || []).some(c => c.id === p.contact.id)); // Filter by category using contact.id

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filteredData = filteredData.filter(p => {
        const c = p.contact; // Access the actual contact object within the priority item
        return c.connection_name?.toLowerCase().includes(term) ||
          c.connection_company?.toLowerCase().includes(term) ||
          c.enriched_title?.toLowerCase().includes(term) ||
          c.connection_title?.toLowerCase().includes(term);
      });
    }

    return filteredData.slice(0, 50); // Top 50
  }, [priorityContactsData, categorized, selectedCategory, searchTerm]);
  
  // Handlers for contact selection
  const handleSelectContact = (contactId) => {
    setSelectedContacts(prev => 
      prev.includes(contactId) 
        ? prev.filter(id => id !== contactId)
        : [...prev, contactId]
    );
  };
  
  const handleSelectAll = () => {
    if (selectedContacts.length === displayedContacts.length && displayedContacts.length > 0) {
      setSelectedContacts([]);
    } else {
      setSelectedContacts(displayedContacts.map(p => p.contact.id)); // Map to the actual contact ID
    }
  };

  const handleDeleteSelected = () => {
    onDeleteContacts(selectedContacts);
    setSelectedContacts([]); // Clear selection after deletion
  };

  const categories = [
    { id: 'all', label: 'All Priority', count: priorityContactsData.length, icon: Target }, // Updated count for 'All Priority'
    { id: 'immediate_outreach', label: 'Immediate Outreach', count: stats.immediate_outreach, icon: Phone },
    { id: 'executive_search_prospects', label: 'Exec Search', count: stats.executive_search, icon: Users },
    { id: 'consulting_targets', label: 'Consulting', count: stats.consulting_targets, icon: Briefcase },
    { id: 'pe_network', label: 'PE Network', count: stats.pe_network, icon: DollarSign }
  ];

  const getUrgencyColor = (urgency) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'medium': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  const getPriorityColor = (score) => {
    if (score >= 80) return 'bg-red-500';
    if (score >= 60) return 'bg-orange-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  // Removed the `if (loading)` block as the component now expects `priorityItems` as a direct prop
  // and the parent component should handle its loading state.

  return (
    <div className="space-y-6">
      {/* Bulk Actions Toolbar */}
      <AnimatePresence>
        {selectedContacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="sticky top-24 z-20 bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-4">
              <span className="font-medium text-blue-900">
                {selectedContacts.length} contact{selectedContacts.length > 1 ? 's' : ''} selected
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedContacts([])}
                className="text-blue-700 hover:bg-blue-100"
              >
                <X className="w-4 h-4 mr-1" />
                Clear
              </Button>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDeleteSelected}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Remove from Priority
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Phone className="w-8 h-8 text-red-500" />
              <span className="text-2xl font-bold">{stats.immediate_outreach}</span>
            </div>
            <p className="text-sm font-medium text-gray-600 mt-2">Immediate Outreach</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Users className="w-8 h-8 text-purple-500" />
              <span className="text-2xl font-bold">{stats.executive_search}</span>
            </div>
            <p className="text-sm font-medium text-gray-600 mt-2">Exec Search Prospects</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Briefcase className="w-8 h-8 text-blue-500" />
              <span className="text-2xl font-bold">{stats.consulting_targets}</span>
            </div>
            <p className="text-sm font-medium text-gray-600 mt-2">Consulting Targets</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <DollarSign className="w-8 h-8 text-green-500" />
              <span className="text-2xl font-bold">{stats.pe_network}</span>
            </div>
            <p className="text-sm font-medium text-gray-600 mt-2">PE Network</p>
          </CardContent>
        </Card>
      </div>

      {/* Category Filters */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(cat.id)}
                className="gap-2"
              >
                <cat.icon className="w-4 h-4" />
                {cat.label}
                <Badge variant="secondary" className="ml-1">
                  {cat.count}
                </Badge>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Search Bar and Select All */}
      <div className="flex justify-between items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder="Search priority contacts..." // Updated placeholder
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="hidden md:flex">
          <Filter className="w-4 h-4 mr-2" />
          Filters
        </Button>
        {/* Select All Checkbox */}
        {displayedContacts.length > 0 && ( // Only show if there are contacts to select
          <div className="flex items-center gap-2">
            <Checkbox
              id="select-all-priority"
              checked={selectedContacts.length === displayedContacts.length && displayedContacts.length > 0}
              onCheckedChange={handleSelectAll}
            />
            <label htmlFor="select-all-priority" className="text-sm font-medium text-gray-700 cursor-pointer">
              Select All
            </label>
          </div>
        )}
      </div>

      {/* Priority Contact Cards */}
      <div className="grid grid-cols-1 gap-4">
        <AnimatePresence>
          {displayedContacts.map((priorityItem) => { // Iterate over priorityItem objects
            const contact = priorityItem.contact; // Access the nested contact object
            const nextAction = contactPrioritizationService.getNextAction(contact);
            // priorityScore is now directly available from priorityItem.priority_score

            return (
              <motion.div
                key={contact.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                whileHover={{ scale: 1.01 }}
                transition={{ duration: 0.2 }}
                onClick={onContactClick ? () => onContactClick(contact) : undefined}
                className={onContactClick ? "cursor-pointer" : ""}
              >
                <Card className="border-none shadow-lg hover:shadow-xl transition-shadow relative"> {/* Added relative for checkbox positioning */}
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      {/* Selection Checkbox */}
                      <div className="absolute top-4 left-4 z-10">
                        <Checkbox
                          checked={selectedContacts.includes(contact.id)}
                          onCheckedChange={() => handleSelectContact(contact.id)}
                          onClick={(e) => e.stopPropagation()} // Prevent card click from triggering when checkbox is clicked
                          className="w-5 h-5"
                        />
                      </div>
                      
                      {/* Left: Contact Info */}
                      <div className="flex-1 ml-8"> {/* Added ml-8 to create space for the checkbox */}
                        <div className="flex items-start gap-4">
                          {/* Priority Indicator */}
                          <div className="flex flex-col items-center gap-1 min-w-[60px]">
                            <div className={`w-12 h-12 rounded-full ${getPriorityColor(priorityItem.priority_score)} flex items-center justify-center text-white font-bold`}>
                              {priorityItem.priority_score} {/* Use score from priorityItem */}
                            </div>
                            <span className="text-xs text-gray-500">Score</span>
                          </div>

                          {/* Contact Details */}
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-gray-900 mb-1">
                              {contact.connection_name || contact.name}
                            </h3>
                            
                            {(contact.enriched_title || contact.connection_title) && (
                              <p className="text-sm text-gray-600 mb-2">
                                {contact.enriched_title || contact.connection_title}
                              </p>
                            )}

                            <div className="flex flex-wrap gap-2 mb-3">
                              {(contact.enriched_company || contact.connection_company) && (
                                <Badge variant="secondary" className="gap-1">
                                  <Building2 className="w-3 h-3" />
                                  {contact.enriched_company || contact.connection_company}
                                </Badge>
                              )}
                              
                              {contact.enriched_seniority && (
                                <Badge variant="secondary">
                                  {contact.enriched_seniority}
                                </Badge>
                              )}

                              {contact.company_size && (
                                <Badge variant="secondary">
                                  {contact.company_size} employees
                                </Badge>
                              )}

                              {contact.enriched_location && (
                                <Badge variant="secondary" className="gap-1">
                                  <MapPin className="w-3 h-3" />
                                  {contact.enriched_location}
                                </Badge>
                              )}
                            </div>

                            {contact.intelligent_summary && (
                              <p className="text-sm text-gray-600 mb-3">
                                {contact.intelligent_summary}
                              </p>
                            )}

                            {/* Next Action */}
                            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border ${getUrgencyColor(nextAction.urgency)}`}>
                              <Target className="w-4 h-4" />
                              <span className="text-sm font-medium">
                                {nextAction.action}
                              </span>
                            </div>
                            {nextAction.reason && (
                              <p className="text-xs text-gray-500 mt-2">
                                {nextAction.reason}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Action Buttons */}
                      <div className="flex flex-col gap-2 ml-4">
                        {contact.linkedin_url && (
                          <Button
                            size="sm"
                            variant="outline"
                            asChild
                            className="gap-2"
                          >
                            <a 
                              href={contact.linkedin_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()} // Prevent card click from triggering
                            >
                              <ExternalLink className="w-4 h-4" />
                              LinkedIn
                            </a>
                          </Button>
                        )}

                        {(contact.connection_email || contact.email) && (
                          <Button
                            size="sm"
                            variant="outline"
                            asChild
                            className="gap-2"
                          >
                            <a 
                              href={`mailto:${contact.connection_email || contact.email}`}
                              onClick={(e) => e.stopPropagation()} // Prevent card click from triggering
                            >
                              <Mail className="w-4 h-4" />
                              Email
                            </a>
                          </Button>
                        )}

                        {(contact.enriched_phone || contact.phone) && (
                          <Button
                            size="sm"
                            variant="outline"
                            asChild
                            className="gap-2"
                          >
                            <a 
                              href={`tel:${contact.enriched_phone || contact.phone}`}
                              onClick={(e) => e.stopPropagation()} // Prevent card click from triggering
                            >
                              <Phone className="w-4 h-4" />
                              Call
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {displayedContacts.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <Target className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No contacts found
            </h3>
            <p className="text-gray-600">
              Try adjusting your filters or search criteria.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
