import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, Users, Calendar, Mail, Phone, Linkedin,
  ArrowRight, Clock, Star, AlertCircle
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function UnifiedOverviewTab({ user, contacts, stats, onTabChange, onContactUpdate }) {
  // Get priority actions - contacts to reach out to
  const priorityActions = contacts
    .filter(contact => {
      if (!contact.last_contact_date) return true;
      const daysSince = Math.floor((new Date() - new Date(contact.last_contact_date)) / (1000 * 60 * 60 * 24));
      return daysSince > 30;
    })
    .sort((a, b) => {
      const aScore = (a.relationship_strength === 'strong' ? 3 : a.relationship_strength === 'medium' ? 2 : 1);
      const bScore = (b.relationship_strength === 'strong' ? 3 : b.relationship_strength === 'medium' ? 2 : 1);
      return bScore - aScore;
    })
    .slice(0, 5);

  // Recent activity (simplified - would come from interactions in real implementation)
  const recentActivity = contacts
    .filter(contact => contact.last_contact_date)
    .sort((a, b) => new Date(b.last_contact_date) - new Date(a.last_contact_date))
    .slice(0, 10)
    .map(contact => ({
      type: 'email',
      contact: contact,
      description: `Contacted ${contact.connection_name}`,
      timestamp: contact.last_contact_date
    }));

  const getInitials = (name) => name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??';

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="border-none shadow-lg bg-gradient-to-br from-[var(--primary-teal)] to-[var(--secondary-teal)] text-white">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold mb-2">
              Welcome back, {user?.full_name?.split(' ')[0] || 'there'}!
            </h2>
            <p className="text-white/90 text-lg">
              You have {stats.pendingFollowUps} contacts to reach out to today
            </p>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Priority Actions */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-none shadow-lg h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-500" />
                Priority Contacts (Top 5)
              </CardTitle>
              <CardDescription>People you should reach out to</CardDescription>
            </CardHeader>
            <CardContent>
              {priorityActions.length === 0 ? (
                <p className="text-gray-500 text-center py-8">All caught up! 🎉</p>
              ) : (
                <div className="space-y-3">
                  {priorityActions.map((contact, index) => {
                    const daysSince = contact.last_contact_date 
                      ? Math.floor((new Date() - new Date(contact.last_contact_date)) / (1000 * 60 * 60 * 24))
                      : null;
                    
                    return (
                      <motion.div
                        key={contact.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            {getInitials(contact.connection_name)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{contact.connection_name}</p>
                            <p className="text-sm text-gray-600">{contact.connection_company}</p>
                            {daysSince && (
                              <p className="text-xs text-orange-600 mt-1">
                                {daysSince} days since last contact
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                            <Mail className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                            <Linkedin className="w-4 h-4" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => onTabChange('reminders')}
              >
                View All Reminders
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-none shadow-lg h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-500" />
                Recent Activity
              </CardTitle>
              <CardDescription>Latest interactions with your network</CardDescription>
            </CardHeader>
            <CardContent>
              {recentActivity.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No recent activity</p>
              ) : (
                <div className="space-y-3">
                  {recentActivity.slice(0, 5).map((activity, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Mail className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900 truncate">
                          {activity.description}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(activity.timestamp).toLocaleDateString()}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => onTabChange('contacts')}
              >
                View All Contacts
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active Relationships</p>
                <p className="text-3xl font-bold text-gray-900">{stats.activeRelationships}</p>
              </div>
              <Users className="w-10 h-10 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">This Month</p>
                <p className="text-3xl font-bold text-gray-900">+{stats.monthConnections}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Avg. Relationship Score</p>
                <p className="text-3xl font-bold text-gray-900">{stats.averageRelationshipScore}/10</p>
              </div>
              <Star className="w-10 h-10 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}