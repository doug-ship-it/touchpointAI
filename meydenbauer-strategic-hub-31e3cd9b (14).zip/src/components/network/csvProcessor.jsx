// CSV Data Loader for Network Intelligence
// This module loads and processes the CSV data dynamically

// More robust CSV parsing function
function parseCSVLineRobust(line) {
  // Handle encoding issues and clean the line
  const cleanLine = line
    .replace(/[^\x00-\x7F]/g, '') // Remove non-ASCII characters that might cause issues
    .replace(/\r/g, '') // Remove carriage returns
    .trim();
  
  if (!cleanLine) return [];
  
  const result = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < cleanLine.length; i++) {
    const char = cleanLine[i];
    // This logic correctly handles quotes that are not at the beginning/end of a field
    if (char === '"' && (i === 0 || cleanLine[i-1] === ',' || cleanLine[i+1] === ',' || i === cleanLine.length - 1)) {
        if (inQuotes && current.endsWith('"')) {
            current = current.slice(0, -1);
        } else {
            inQuotes = !inQuotes;
            continue;
        }
    }

    if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

// Function to process CSV data into structured format
export function processCSVData(csvText) {
  const lines = csvText.trim().split('\n').filter(line => line.trim()); // Filter out empty lines
  const headers = parseCSVLineRobust(lines[0]);
  
  const contacts = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue; // Skip empty lines
    
    try {
      const values = parseCSVLineRobust(line);
      
      if (values.length < headers.length) {
        continue;
      }
      
      const contact = {};
      
      headers.forEach((header, j) => {
        const key = header.toLowerCase().replace(/\s+/g, '_');
        contact[key] = values[j] || '';
      });
      
      if (!contact.first_name && !contact.last_name) {
        continue;
      }
      
      // Add computed fields and normalize data
      contact.id = `contact_${contacts.length}_${Math.random()}`;
      contact.first_name = contact.first_name?.trim();
      contact.last_name = contact.last_name?.trim();
      contact.full_name = contact.full_name?.trim() || `${contact.first_name} ${contact.last_name}`;
      contact.linkedin_url = contact.url;
      
      contact.function = extractFunctionFromPosition(contact.position);
      
      contact.company_size = normalizeCompanySize(contact.company_size) || 'Unknown';
      contact.industry = contact.industry?.trim() || 'Unknown';
      contact.seniority = normalizeSeniority(contact.seniority) || 'Unknown';
      
      contact.company = contact.company?.trim() || 'Unknown';
      contact.position = contact.position?.trim() || 'Unknown';
      
      contacts.push(contact);
    } catch (error) {
      console.warn(`Error processing line ${i}:`, error, line.substring(0, 100));
      continue;
    }
  }
  
  return contacts;
}

// Extract function from position title
function extractFunctionFromPosition(position) {
  if (!position) return 'Other';
  
  const positionLower = position.toLowerCase();
  
  if (positionLower.includes('ceo') || positionLower.includes('cto') || positionLower.includes('cfo') || positionLower.includes('coo')) {
    return 'Strategy';
  }
  if (positionLower.includes('sales') || positionLower.includes('revenue')) {
    return 'Sales';
  }
  if (positionLower.includes('marketing') || positionLower.includes('brand')) {
    return 'Marketing';
  }
  if (positionLower.includes('engineer') || positionLower.includes('developer') || positionLower.includes('technical')) {
    return 'Engineering';
  }
  if (positionLower.includes('product') || positionLower.includes('pm')) {
    return 'Product Management';
  }
  if (positionLower.includes('finance') || positionLower.includes('accounting')) {
    return 'Finance';
  }
  if (positionLower.includes('hr') || positionLower.includes('human resources') || positionLower.includes('talent')) {
    return 'Human Resources';
  }
  if (positionLower.includes('operations') || positionLower.includes('ops')) {
    return 'Operations';
  }
  if (positionLower.includes('business development') || positionLower.includes('biz dev')) {
    return 'Business Development';
  }
  if (positionLower.includes('consultant') || positionLower.includes('consulting')) {
    return 'Consulting';
  }
  if (positionLower.includes('legal') || positionLower.includes('counsel')) {
    return 'Legal';
  }
  if (positionLower.includes('it') || positionLower.includes('information technology')) {
    return 'Information Technology';
  }
  
  return 'Other';
}

// Normalize company size
function normalizeCompanySize(size) {
  if (!size) return 'Unknown';
  
  const sizeLower = size.toLowerCase();
  if (sizeLower.includes('1-10') || sizeLower.includes('1 to 10')) return '1-10';
  if (sizeLower.includes('11-50') || sizeLower.includes('11 to 50')) return '11-50';
  if (sizeLower.includes('51-200') || sizeLower.includes('51 to 200')) return '51-200';
  if (sizeLower.includes('201-500') || sizeLower.includes('201 to 500')) return '201-500';
  if (sizeLower.includes('501-1,000') || sizeLower.includes('501 to 1,000')) return '501-1,000';
  if (sizeLower.includes('1,001-5,000') || sizeLower.includes('1,001 to 5,000')) return '1,001-5,000';
  if (sizeLower.includes('5,001-10,000') || sizeLower.includes('5,001 to 10,000')) return '5,001-10,000';
  if (sizeLower.includes('10,000+') || sizeLower.includes('10000+')) return '10,000+';
  
  return size;
}

// Normalize seniority
function normalizeSeniority(seniority) {
  if (!seniority) return 'Unknown';
  
  const seniorityLower = seniority.toLowerCase();
  if (seniorityLower.includes('cxo') || seniorityLower.includes('ceo') || seniorityLower.includes('cto') || seniorityLower.includes('cfo')) {
    return 'CxO';
  }
  if (seniorityLower.includes('owner') || seniorityLower.includes('partner')) {
    return 'Owner/Partner';
  }
  if (seniorityLower.includes('vice president') || seniorityLower.includes('vp')) {
    return 'Vice President';
  }
  if (seniorityLower.includes('director')) {
    return 'Director';
  }
  if (seniorityLower.includes('manager') && seniorityLower.includes('experienced')) {
    return 'Experienced Manager';
  }
  if (seniorityLower.includes('manager') && seniorityLower.includes('entry')) {
    return 'Entry Level Manager';
  }
  if (seniorityLower.includes('senior')) {
    return 'Senior';
  }
  if (seniorityLower.includes('entry') || seniorityLower.includes('junior')) {
    return 'Entry Level';
  }
  if (seniorityLower.includes('training') || seniorityLower.includes('intern')) {
    return 'In Training';
  }
  if (seniorityLower.includes('strategic')) {
    return 'Strategic';
  }
  
  return seniority;
}

// Function to extract unique values for filters
export function extractFilterValues(contacts) {
  const companySizes = [...new Set(contacts.map(c => c.company_size))].filter(Boolean).sort();
  const industries = [...new Set(contacts.map(c => c.industry))].filter(Boolean).sort();
  const functions = [...new Set(contacts.map(c => c.function))].filter(Boolean).sort();
  const seniorities = [...new Set(contacts.map(c => c.seniority))].filter(Boolean).sort();
  
  return {
    companySizes,
    industries,
    functions,
    seniorities
  };
}

// Search function with advanced filtering
export function searchContacts(contacts, query, filters = {}) {
  let results = [...contacts];
  
  // Text search across multiple fields
  if (query && query.trim()) {
    const searchTerms = query.toLowerCase().split(/\s+/).filter(term => term.length > 0);
    results = results.filter(contact => {
      const searchableText = [
        contact.first_name,
        contact.last_name,
        contact.company,
        contact.position,
        contact.industry,
        contact.function,
        contact.seniority,
        contact.full_name
      ].join(' ').toLowerCase();
      
      return searchTerms.every(term => searchableText.includes(term));
    });
  }
  
  // Apply filters - handle both single values and arrays
  const filterKeys = Object.keys(filters);
  if (filterKeys.length > 0) {
    results = results.filter(contact => {
      return filterKeys.every(key => {
        if (key === 'searchTerm') return true; // Handled by query param
        const filterValues = Array.isArray(filters[key]) ? filters[key] : [filters[key]];
        if (filterValues.length === 0) return true;
        return filterValues.includes(contact[key]);
      });
    });
  }
  
  return results;
}