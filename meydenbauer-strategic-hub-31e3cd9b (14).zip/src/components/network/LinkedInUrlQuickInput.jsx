import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Link as LinkIcon, Zap, X, CheckCircle, AlertCircle, Loader2, User, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { findAndEnrichContact } from '@/api/functions';

const LINKEDIN_URL_REGEX = /linkedin\.com\/(in|sales\/lead)\/([a-zA-Z0-9_-]+)/i;

export default function LinkedInUrlQuickInput({ 
  onGenerate, 
  existingContacts = [],
  className 
}) {
  const [input, setInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [foundContact, setFoundContact] = useState(null);
  const [searchResults, setSearchResults] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const inputRef = useRef(null);

  // Keyboard shortcut: "/" to focus input
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
        e.preventDefault();
        inputRef.current?.focus();
      }
      
      if (e.key === 'Escape') {
        setInput('');
        setShowResults(false);
        inputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleSearch = async () => {
    if (!input.trim()) return;
    
    setIsSearching(true);
    setSearchError(null);
    setFoundContact(null);
    setSearchResults(null);
    setShowResults(false);
    
    try {
      const { data } = await findAndEnrichContact({ input: input.trim() });
      
      if (!data.success) {
        setSearchError(data.error || 'Search failed');
        setShowResults(true);
        toast.error(data.error || 'Search failed');
        return;
      }
      
      // Handle single contact found
      if (data.contact) {
        setFoundContact(data.contact);
        setShowResults(true);
        toast.success(`Found: ${data.contact.connection_name}`);
        
        // Auto-trigger message generation
        if (onGenerate) {
          onGenerate(null, data.contact);
        }
      }
      
      // Handle multiple search results
      if (data.searchResults && data.searchResults.length > 0) {
        setSearchResults(data.searchResults);
        setShowResults(true);
        toast.info(`Found ${data.searchResults.length} matching contacts`);
      }
      
    } catch (error) {
      const errorMessage = error.message || 'Failed to search contact';
      setSearchError(errorMessage);
      setShowResults(true);
      toast.error(errorMessage);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (contact) => {
    setFoundContact(contact);
    setSearchResults(null);
    
    if (onGenerate) {
      onGenerate(null, contact);
    }
  };

  const handleClear = () => {
    setInput('');
    setShowResults(false);
    setFoundContact(null);
    setSearchResults(null);
    setSearchError(null);
  };

  const isValidLinkedInUrl = LINKEDIN_URL_REGEX.test(input);

  return (
    <div className={cn("relative", className)}>
      <div className="relative">
        {/* Main Input */}
        <div className={cn(
          "relative flex items-center gap-2 bg-white rounded-2xl shadow-lg border-2 transition-all duration-200",
          searchError ? "border-red-500" : isValidLinkedInUrl ? "border-blue-500 shadow-blue-200" : "border-gray-200 hover:border-blue-400"
        )}>
          <div className="absolute left-4 pointer-events-none">
            {isValidLinkedInUrl ? (
              <LinkIcon className="w-5 h-5 text-blue-600" />
            ) : (
              <Search className="w-5 h-5 text-gray-400" />
            )}
          </div>
          
          <Input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              setSearchError(null);
            }}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="🔗 Paste LinkedIn URL or search by name..."
            className="flex-1 pl-12 pr-32 py-6 text-base border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            disabled={isSearching}
          />

          {/* Status Indicators */}
          <div className="absolute right-2 flex items-center gap-2">
            {input && !isSearching && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClear}
                className="h-8 w-8 rounded-full hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
            
            <Button
              onClick={handleSearch}
              disabled={!input.trim() || isSearching}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl px-4 py-2 h-10"
            >
              {isSearching ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Find Contact
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Keyboard Shortcut Hint */}
        {!input && (
          <div className="absolute right-24 top-1/2 -translate-y-1/2 pointer-events-none">
            <kbd className="px-2 py-1 text-xs bg-gray-100 border border-gray-300 rounded">
              Press / to focus
            </kbd>
          </div>
        )}
      </div>

      {/* Error Alert */}
      {searchError && showResults && (
        <Alert variant="destructive" className="mt-4">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{searchError}</AlertDescription>
        </Alert>
      )}

      {/* Success Message */}
      {foundContact && showResults && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4"
        >
          <Alert className="border-green-500 bg-green-50">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <AlertDescription className="text-green-800">
              <strong>Found:</strong> {foundContact.connection_name} • {foundContact.connection_title || foundContact.enriched_title} at {foundContact.connection_company || foundContact.enriched_company}
            </AlertDescription>
          </Alert>
        </motion.div>
      )}

      {/* Multiple Search Results */}
      <AnimatePresence>
        {showResults && searchResults && searchResults.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mt-6"
          >
            <Card>
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">
                  Found {searchResults.length} matching contact{searchResults.length > 1 ? 's' : ''} - select one:
                </h4>
                
                <div className="space-y-2">
                  {searchResults.map((contact) => (
                    <button
                      key={contact.id}
                      onClick={() => handleSelectSearchResult(contact)}
                      className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-blue-50 transition-colors border border-gray-200 hover:border-blue-300"
                    >
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                        {contact.first_name?.[0]}{contact.last_name?.[0]}
                      </div>
                      
                      <div className="flex-1 text-left min-w-0">
                        <div className="font-semibold text-gray-900">{contact.connection_name}</div>
                        <div className="text-sm text-gray-600">
                          {contact.connection_title} {contact.connection_company && `at ${contact.connection_company}`}
                        </div>
                      </div>
                      
                      <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}