import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Globe, 
  Mail,
  Send,
  X
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export default function VendorCard({ vendor, user, onInquiry }) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleInquirySubmit = () => {
    if (onInquiry) {
      onInquiry(vendor, message);
      setIsDialogOpen(false);
      setMessage('');
    }
  };

  const handleWebsiteClick = () => {
    if (vendor.website) {
      window.open(vendor.website, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex h-full"
    >
      <Card className="w-full flex flex-col bg-white border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300 rounded-xl">
        <CardHeader className="pb-4 flex-shrink-0">
          {/* Logo Section */}
          <div className="flex justify-center mb-4 h-16 items-center">
            {vendor.logo_url ? (
              <img 
                src={vendor.logo_url} 
                alt={`${vendor.name} logo`}
                className="h-12 max-w-[180px] object-contain"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextElementSibling.style.display = 'flex';
                }}
              />
            ) : null}
            <div 
              className="h-12 w-12 bg-gradient-to-r from-teal-500 to-blue-500 rounded-lg flex items-center justify-center"
              style={{ display: vendor.logo_url ? 'none' : 'flex' }}
            >
              <span className="text-white font-bold text-lg">
                {vendor.name?.charAt(0) || 'V'}
              </span>
            </div>
          </div>

          {/* Company Name */}
          <h3 className="text-xl font-bold text-gray-900 text-center mb-2 line-clamp-2">
            {vendor.name}
          </h3>

          {/* Category Badge */}
          <div className="flex justify-center mb-3">
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              {vendor.category}
            </Badge>
          </div>

          {/* Location */}
          {(vendor.headquarters?.city || vendor.region) && (
            <div className="flex items-center justify-center gap-1 text-sm text-gray-500">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span className="text-center">
                {vendor.headquarters?.city || vendor.region.replace(/_/g, ' ')}
              </span>
            </div>
          )}
        </CardHeader>

        <CardContent className="pt-0 flex-grow flex flex-col">
          {/* Description */}
          <p className="text-gray-600 text-sm leading-relaxed mb-4 flex-grow line-clamp-4">
            {vendor.description}
          </p>

          {/* Technologies/Specializations */}
          {vendor.validatedTechnologyStack?.specializations && vendor.validatedTechnologyStack.specializations.length > 0 && (
            <div className="mb-6">
              <div className="flex flex-wrap gap-2 justify-center">
                {vendor.validatedTechnologyStack.specializations.slice(0, 3).map((spec, index) => (
                  <Badge key={index} variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                    {spec}
                  </Badge>
                ))}
                {vendor.validatedTechnologyStack.specializations.length > 3 && (
                  <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                    +{vendor.validatedTechnologyStack.specializations.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons - Fixed at bottom */}
          <div className="flex items-center gap-2 mt-auto pt-4">
            {vendor.websiteUrl && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => window.open(vendor.websiteUrl, '_blank', 'noopener,noreferrer')}
                className="flex-1 border-gray-300 hover:border-gray-400"
              >
                <Globe className="w-4 h-4 mr-2" />
                Website
              </Button>
            )}
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  size="sm" 
                  className="flex-1 bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white"
                  disabled={user && user.credits < 1}
                >
                  <Mail className="w-4 h-4 mr-2" />
                  {user && user.credits < 1 ? 'No Credits' : 'Inquire'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Request Introduction to {vendor.name}</DialogTitle>
                  <DialogDescription>
                    A partner from Meydenbauer will facilitate the introduction. This will use one of your inquiry credits.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="message" className="text-right">
                      Message
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="Include a brief message about your needs (optional)"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="col-span-3"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                  <Button onClick={handleInquirySubmit}>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Inquiry
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}