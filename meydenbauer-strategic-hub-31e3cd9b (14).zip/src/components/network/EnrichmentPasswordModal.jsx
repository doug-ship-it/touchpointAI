import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Lock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const ADMIN_PASSWORD = "mbai2024";

export default function EnrichmentPasswordModal({ isOpen, onClose, onSuccess, featureName = "AI Enrichment" }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (password === ADMIN_PASSWORD) {
      toast.success(`Access Granted! ${featureName} features are now available for this session.`);
      onSuccess();
      onClose();
      setPassword('');
      setError('');
    } else {
      setError('Incorrect password. Access denied.');
      toast.error('Incorrect password');
    }
  };

  const handleClose = () => {
    setPassword('');
    setError('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center">
              <Lock className="w-8 h-8 text-white" />
            </div>
          </div>
          <DialogTitle className="text-center text-2xl">Protected Feature</DialogTitle>
          <DialogDescription className="text-center">
            {featureName} requires admin authentication. Please enter the password to continue.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              type="password"
              placeholder="Enter admin password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              className={error ? 'border-red-500' : ''}
              autoFocus
            />
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 mt-2 text-sm text-red-600"
              >
                <AlertCircle className="w-4 h-4" />
                {error}
              </motion.div>
            )}
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
            >
              Unlock Feature
            </Button>
          </div>
        </form>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-xs text-blue-900">
            <strong>Note:</strong> AI enrichment features consume API credits and should only be used by authorized users. Access is granted per session and will expire when you close the browser.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Custom hook for enrichment access management
export function useEnrichmentAccess() {
  const [hasAccess, setHasAccess] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  const requestAccess = () => {
    if (hasAccess) {
      return true;
    }
    setShowPasswordModal(true);
    return false;
  };

  const grantAccess = () => {
    setHasAccess(true);
    // Store in sessionStorage so it persists during the session
    sessionStorage.setItem('enrichment_access', 'granted');
  };

  const checkStoredAccess = () => {
    const stored = sessionStorage.getItem('enrichment_access');
    if (stored === 'granted') {
      setHasAccess(true);
    }
  };

  React.useEffect(() => {
    checkStoredAccess();
  }, []);

  return {
    hasAccess,
    showPasswordModal,
    setShowPasswordModal,
    requestAccess,
    grantAccess
  };
}