import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, CheckCircle, AlertCircle, RefreshCw, FileUp, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

export default function EnhancedUploadButton({ onFileSelect, className = "" }) {
  const [state, setState] = useState('idle'); // idle, hover, loading, success, error
  const [progress, setProgress] = useState(0);
  const [dragActive, setDragActive] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const fileInputRef = useRef(null);

  const handleFileSelection = useCallback(async (file) => {
    if (!file) return;
    
    setState('loading');
    setProgress(0);
    setErrorMessage('');
    
    // Simulate progress for better UX
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 100);

    try {
      // File validation
      const validExtensions = ['csv', 'txt', 'pdf', 'xlsx', 'xls', 'tsv', 'json', 'ods'];
      const fileExtension = file.name.split('.').pop().toLowerCase();
      
      if (!validExtensions.includes(fileExtension)) {
        throw new Error('Unsupported file format. Please use CSV, Excel, PDF, TXT, TSV, JSON, or ODS files.');
      }
      
      if (file.size > 50 * 1024 * 1024) {
        throw new Error('File size must be under 50MB.');
      }

      setProgress(100);
      setTimeout(() => {
        setState('success');
        onFileSelect(file);
        
        // Reset to idle after success message
        setTimeout(() => {
          setState('idle');
          setProgress(0);
        }, 2000);
      }, 500);

    } catch (error) {
      clearInterval(progressInterval);
      setState('error');
      setErrorMessage(error.message);
      setProgress(0);
    }
  }, [onFileSelect]);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  }, [handleFileSelection]);

  const handleRetry = useCallback(() => {
    setState('idle');
    setErrorMessage('');
    fileInputRef.current?.click();
  }, []);

  const handleClick = useCallback(() => {
    if (state === 'error') {
      handleRetry();
    } else if (state === 'idle') {
      fileInputRef.current?.click();
    }
  }, [state, handleRetry]);

  const getButtonContent = () => {
    switch (state) {
      case 'loading':
        return (
          <div className="flex items-center gap-3">
            <RefreshCw className="w-5 h-5 animate-spin" />
            <div className="flex flex-col items-start gap-1">
              <span className="font-medium">Processing...</span>
              <div className="w-32">
                <Progress value={progress} className="h-1" />
              </div>
              <span className="text-xs text-white/80">{progress}% complete</span>
            </div>
          </div>
        );
      case 'success':
        return (
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-300" />
            <span className="font-medium">Upload Successful!</span>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-300" />
            <span className="font-medium">Retry Upload</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            <span className="font-medium">Upload Connections</span>
          </div>
        );
    }
  };

  const getButtonStyles = () => {
    const baseStyles = "upload-button relative overflow-hidden transition-all duration-200 ease-out";
    
    switch (state) {
      case 'loading':
        return `${baseStyles} bg-gradient-to-r from-blue-500 to-purple-600 text-white cursor-wait`;
      case 'success':
        return `${baseStyles} bg-gradient-to-r from-green-500 to-emerald-600 text-white`;
      case 'error':
        return `${baseStyles} bg-gradient-to-r from-red-500 to-pink-600 text-white hover:from-red-600 hover:to-pink-700`;
      default:
        return `${baseStyles} bg-gradient-to-r from-[var(--primary-teal)] to-[var(--secondary-teal)] text-white hover:from-[var(--secondary-teal)] hover:to-[var(--primary-teal)]`;
    }
  };

  return (
    <div className={`relative ${className}`}>
      <style>{`
        .upload-button {
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .upload-button:hover:not(.cursor-wait) {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }
        .upload-button.idle {
          animation: subtle-pulse 3s ease-in-out infinite;
        }
        @keyframes subtle-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.01); }
        }
      `}</style>

      {/* Drag and Drop Zone */}
      <motion.div
        className={`
          border-2 border-dashed rounded-xl p-6 text-center transition-all duration-300
          ${dragActive 
            ? 'border-[var(--primary-teal)] bg-[var(--light-teal)]/20 scale-105' 
            : 'border-gray-300 hover:border-[var(--primary-teal)]/50'
          }
        `}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        whileHover={{ scale: dragActive ? 1.05 : 1.02 }}
        transition={{ duration: 0.2 }}
      >
        <motion.div
          initial={false}
          animate={{ scale: dragActive ? 1.1 : 1 }}
          transition={{ duration: 0.2 }}
        >
          <FileUp className={`w-12 h-12 mx-auto mb-4 ${dragActive ? 'text-[var(--primary-teal)]' : 'text-gray-400'}`} />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Drop files here or click to browse
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Supports CSV, Excel, PDF, TXT, TSV, JSON, and ODS files up to 50MB
          </p>
        </motion.div>

        <motion.div
          whileHover={{ scale: state === 'loading' ? 1 : 1.05 }}
          whileTap={{ scale: state === 'loading' ? 1 : 0.95 }}
        >
          <Button
            onClick={handleClick}
            disabled={state === 'loading'}
            className={`${getButtonStyles()} ${state === 'idle' ? 'idle' : ''} px-6 py-3 min-w-[200px]`}
          >
            {getButtonContent()}
          </Button>
        </motion.div>

        {/* Error Message */}
        <AnimatePresence>
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mt-3 text-sm text-red-600 bg-red-50 rounded-lg p-2"
            >
              {errorMessage}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Smart Features Info */}
        <div className="mt-4 text-xs text-gray-500 space-y-1">
          <div className="flex items-center justify-center gap-4">
            <span>✓ Smart duplicate detection</span>
            <span>✓ Real-time validation</span>
            <span>✓ Batch processing</span>
          </div>
        </div>
      </motion.div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,.txt,.pdf,.xlsx,.xls,.tsv,.json,.ods"
        onChange={(e) => handleFileSelection(e.target.files[0])}
        className="hidden"
      />
    </div>
  );
}