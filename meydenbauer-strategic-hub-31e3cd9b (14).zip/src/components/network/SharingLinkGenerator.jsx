import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Share2, X, Users, Lock, Copy, Eye, Settings, Calendar, Link2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';

export default function SharingLinkGenerator({ isOpen, onClose, contacts, onLinkCreated }) {
  const [linkSettings, setLinkSettings] = useState({
    title: '',
    description: '',
    expiresIn: '30', // days
    allowEnrichment: true,
    requirePassword: false,
    password: '',
    selectedContacts: new Set(),
    sharedFields: {
      name: true,
      title: true,
      company: true,
      email: false,
      phone: false,
      linkedin: true,
      notes: false
    }
  });

  const [generatedLink, setGeneratedLink] = useState(null);
  const [step, setStep] = useState(1); // 1: settings, 2: contact selection, 3: generated

  const handleContactToggle = (contactId) => {
    const newSelected = new Set(linkSettings.selectedContacts);
    if (newSelected.has(contactId)) {
      newSelected.delete(contactId);
    } else {
      newSelected.add(contactId);
    }
    setLinkSettings(prev => ({ ...prev, selectedContacts: newSelected }));
  };

  const handleFieldToggle = (field) => {
    setLinkSettings(prev => ({
      ...prev,
      sharedFields: {
        ...prev.sharedFields,
        [field]: !prev.sharedFields[field]
      }
    }));
  };

  const generateLink = async () => {
    // Simulate API call to generate sharing link
    const linkId = Math.random().toString(36).substring(2, 15);
    const link = {
      id: linkId,
      url: `https://touchpoint.ai/shared/${linkId}`,
      title: linkSettings.title,
      contactCount: linkSettings.selectedContacts.size,
      expiresAt: new Date(Date.now() + parseInt(linkSettings.expiresIn) * 24 * 60 * 60 * 1000).toLocaleDateString(),
      settings: linkSettings
    };

    setGeneratedLink(link);
    setStep(3);

    // Notify parent component
    if (onLinkCreated) {
      onLinkCreated(link);
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('Link copied to clipboard!');
    } catch (err) {
      toast.error('Failed to copy link');
    }
  };

  const resetForm = () => {
    setStep(1);
    setGeneratedLink(null);
    setLinkSettings({
      title: '',
      description: '',
      expiresIn: '30',
      allowEnrichment: true,
      requirePassword: false,
      password: '',
      selectedContacts: new Set(),
      sharedFields: {
        name: true,
        title: true,
        company: true,
        email: false,
        phone: false,
        linkedin: true,
        notes: false
      }
    });
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && handleClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-4xl max-h-[90vh] overflow-auto"
        >
          <Card className="bg-white">
            <CardHeader className="flex flex-row items-center justify-between border-b">
              <CardTitle className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-[var(--primary-teal)]" />
                Create Sharing Link
                <Badge variant="outline" className="ml-2">Step {step} of 3</Badge>
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={handleClose}>
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>

            <CardContent className="p-6">
              {step === 1 && (
                <div className="space-y-6">
                  <Alert className="border-blue-200 bg-blue-50">
                    <Lock className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      Create secure sharing links to collaborate with trusted partners while maintaining full control over your data.
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="title">Link Title</Label>
                        <Input
                          id="title"
                          placeholder="e.g., Q4 Strategic Partnerships"
                          value={linkSettings.title}
                          onChange={(e) => setLinkSettings(prev => ({ ...prev, title: e.target.value }))}
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="description">Description (Optional)</Label>
                        <Input
                          id="description"
                          placeholder="Brief description of the collaboration purpose"
                          value={linkSettings.description}
                          onChange={(e) => setLinkSettings(prev => ({ ...prev, description: e.target.value }))}
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="expires">Link Expires In</Label>
                        <Select
                          value={linkSettings.expiresIn}
                          onValueChange={(value) => setLinkSettings(prev => ({ ...prev, expiresIn: value }))}
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="7">7 days</SelectItem>
                            <SelectItem value="14">14 days</SelectItem>
                            <SelectItem value="30">30 days</SelectItem>
                            <SelectItem value="90">90 days</SelectItem>
                            <SelectItem value="never">Never</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Allow Contact Enrichment</Label>
                          <p className="text-sm text-gray-600">Let collaborators add notes and insights</p>
                        </div>
                        <Switch
                          checked={linkSettings.allowEnrichment}
                          onCheckedChange={(checked) => setLinkSettings(prev => ({ ...prev, allowEnrichment: checked }))}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Require Password</Label>
                          <p className="text-sm text-gray-600">Add an extra layer of security</p>
                        </div>
                        <Switch
                          checked={linkSettings.requirePassword}
                          onCheckedChange={(checked) => setLinkSettings(prev => ({ ...prev, requirePassword: checked }))}
                        />
                      </div>

                      {linkSettings.requirePassword && (
                        <div>
                          <Label htmlFor="password">Password</Label>
                          <Input
                            id="password"
                            type="password"
                            placeholder="Enter password"
                            value={linkSettings.password}
                            onChange={(e) => setLinkSettings(prev => ({ ...prev, password: e.target.value }))}
                            className="mt-1"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label className="text-base font-semibold">Data Fields to Share</Label>
                    <p className="text-sm text-gray-600 mb-3">Select which contact information will be visible to collaborators</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {Object.entries(linkSettings.sharedFields).map(([field, enabled]) => (
                        <div key={field} className="flex items-center space-x-2">
                          <Checkbox
                            id={field}
                            checked={enabled}
                            onCheckedChange={() => handleFieldToggle(field)}
                          />
                          <Label htmlFor={field} className="capitalize text-sm">
                            {field === 'linkedin' ? 'LinkedIn URL' : field}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-end gap-3">
                    <Button variant="outline" onClick={handleClose}>
                      Cancel
                    </Button>
                    <Button
                      onClick={() => setStep(2)}
                      disabled={!linkSettings.title.trim()}
                      className="bg-[var(--primary-teal)] hover:bg-[var(--secondary-teal)]"
                    >
                      Select Contacts
                    </Button>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">Select Contacts to Share</h3>
                      <p className="text-gray-600">Choose which contacts will be visible through this sharing link</p>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">
                      {linkSettings.selectedContacts.size} selected
                    </Badge>
                  </div>

                  <div className="max-h-96 overflow-y-auto border rounded-lg">
                    <div className="divide-y">
                      {contacts.slice(0, 50).map((contact) => (
                        <div
                          key={contact.id}
                          className="flex items-center justify-between p-3 hover:bg-gray-50"
                        >
                          <div className="flex items-center gap-3">
                            <Checkbox
                              checked={linkSettings.selectedContacts.has(contact.id)}
                              onCheckedChange={() => handleContactToggle(contact.id)}
                            />
                            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                              {contact.connection_name?.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium">{contact.connection_name}</div>
                              <div className="text-sm text-gray-600">
                                {contact.connection_title} at {contact.connection_company}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button variant="outline" onClick={() => setStep(1)}>
                      Back
                    </Button>
                    <Button
                      onClick={generateLink}
                      disabled={linkSettings.selectedContacts.size === 0}
                      className="bg-[var(--primary-teal)] hover:bg-[var(--secondary-teal)]"
                    >
                      Generate Link
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && generatedLink && (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Link2 className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-green-700 mb-2">Sharing Link Created!</h3>
                    <p className="text-gray-600">
                      Your secure collaboration link is ready to share with trusted partners.
                    </p>
                  </div>

                  <Card className="bg-gray-50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <Label className="font-semibold">Sharing Link</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(generatedLink.url)}
                        >
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </Button>
                      </div>
                      <div className="bg-white p-3 rounded border font-mono text-sm break-all">
                        {generatedLink.url}
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                      <div className="font-semibold text-blue-800">{generatedLink.contactCount}</div>
                      <div className="text-sm text-blue-600">Contacts Shared</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Calendar className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                      <div className="font-semibold text-purple-800">{generatedLink.expiresAt}</div>
                      <div className="text-sm text-purple-600">Expires On</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Eye className="w-6 h-6 text-green-600 mx-auto mb-2" />
                      <div className="font-semibold text-green-800">0</div>
                      <div className="text-sm text-green-600">Views So Far</div>
                    </div>
                  </div>

                  <Alert className="border-amber-200 bg-amber-50">
                    <Settings className="w-4 h-4 text-amber-600" />
                    <AlertDescription className="text-amber-800">
                      <strong>Remember:</strong> You can revoke access to this link at any time from your dashboard. 
                      Collaborators will lose access immediately when revoked.
                    </AlertDescription>
                  </Alert>

                  <div className="flex justify-center gap-3">
                    <Button variant="outline" onClick={() => copyToClipboard(generatedLink.url)}>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Link
                    </Button>
                    <Button onClick={handleClose} className="bg-[var(--primary-teal)] hover:bg-[var(--secondary-teal)]">
                      Done
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}