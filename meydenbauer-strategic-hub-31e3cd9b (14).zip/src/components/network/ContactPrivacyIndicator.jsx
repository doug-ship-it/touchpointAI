import React from 'react';
import { Lock, Users, Share2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function ContactPrivacyIndicator({ contact, sharingStatus }) {
  const getPrivacyStatus = () => {
    if (sharingStatus?.isShared) {
      return {
        icon: Users,
        text: 'Shared',
        color: 'bg-blue-100 text-blue-800 border-blue-200',
        iconColor: 'text-blue-600'
      };
    }
    return {
      icon: Lock,
      text: 'Private',
      color: 'bg-gray-100 text-gray-800 border-gray-200',
      iconColor: 'text-gray-600'
    };
  };

  const status = getPrivacyStatus();
  const Icon = status.icon;

  return (
    <Badge className={`${status.color} flex items-center gap-1`}>
      <Icon className={`w-3 h-3 ${status.iconColor}`} />
      <span className="text-xs">{status.text}</span>
      {sharingStatus?.collaboratorCount > 0 && (
        <span className="text-xs ml-1">({sharingStatus.collaboratorCount})</span>
      )}
    </Badge>
  );
}