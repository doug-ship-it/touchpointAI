import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Search } from 'lucide-react';
import { cn } from '@/lib/utils';

const COMPANY_SIZES = [
  { value: '1-10', label: '1-10 employees (Startup/Solo)' },
  { value: '11-50', label: '11-50 employees (Small Startup)' },
  { value: '51-200', label: '51-200 employees (Growing Company)' },
  { value: '201-500', label: '201-500 employees (Mid-Size Company)' },
  { value: '501-1,000', label: '501-1,000 employees (Large Company)' },
  { value: '1,001-5,000', label: '1,001-5,000 employees (Enterprise)' },
  { value: '5,001-10,000', label: '5,001-10,000 employees (Large Enterprise)' },
  { value: '10,000+', label: '10,000+ employees (Fortune 500/Global Enterprise)' }
];

const SENIORITY_LEVELS = [
  'Owner/Partner',
  'CXO',
  'Vice President',
  'Director',
  'Experienced Manager',
  'Entry Level Manager',
  'Strategic',
  'Senior',
  'Entry Level',
  'In Training'
];

const INDUSTRIES = [
  'Accommodation Services',
  'Accounting',
  'Administrative and Support Services',
  'Advertising Services',
  'Appliances, Electrical, and Electronics Manufacturing',
  'Banking',
  'Business Consulting and Services',
  'Chemical Manufacturing',
  'Computers and Electronics Manufacturing',
  'Construction',
  'Consumer Services',
  'Credit Intermediation',
  'Design Services',
  'Education',
  'Education Administration Programs',
  'Entertainment Providers',
  'Equipment Rental Services',
  'Financial Services',
  'Food and Beverage Manufacturing',
  'Food and Beverage Services',
  'Government Administration',
  'Health and Human Services',
  'Higher Education',
  'Hospitality',
  'Hospitals and Health Care',
  'Industrial Machinery Manufacturing',
  'Information and Media',
  'Insurance',
  'IT Services and IT Consulting',
  'Legal Services',
  'Machinery Manufacturing',
  'Manufacturing',
  'Media and Telecommunications',
  'Medical Practices',
  'Motor Vehicle Manufacturing',
  'Oil and Gas',
  'Oil, Gas, and Mining',
  'Primary and Secondary Education',
  'Professional Services',
  'Real Estate',
  'Recreational Facilities',
  'Research Services',
  'Restaurants',
  'Retail',
  'Software Development',
  'Technology',
  'Technology, Information and Internet',
  'Telecommunications',
  'Transportation Equipment Manufacturing',
  'Transportation, Logistics, Supply Chain and Storage',
  'Wellness and Fitness Services',
  'Wholesale'
].sort();

export default function AdvancedFilters({ filters, onFiltersChange }) {
  const [industrySearch, setIndustrySearch] = useState('');
  const [expandedSections, setExpandedSections] = useState({
    companySize: true,
    seniority: true,
    industry: true
  });

  const filteredIndustries = INDUSTRIES.filter(industry =>
    industry.toLowerCase().includes(industrySearch.toLowerCase())
  );

  const handleCompanySizeToggle = (size) => {
    const currentSizes = filters.companySizes || [];
    const newSizes = currentSizes.includes(size)
      ? currentSizes.filter(s => s !== size)
      : [...currentSizes, size];
    onFiltersChange({ ...filters, companySizes: newSizes });
  };

  const handleSeniorityToggle = (level) => {
    const currentLevels = filters.seniorityLevels || [];
    const newLevels = currentLevels.includes(level)
      ? currentLevels.filter(l => l !== level)
      : [...currentLevels, level];
    onFiltersChange({ ...filters, seniorityLevels: newLevels });
  };

  const handleIndustryToggle = (industry) => {
    const currentIndustries = filters.industries || [];
    const newIndustries = currentIndustries.includes(industry)
      ? currentIndustries.filter(i => i !== industry)
      : [...currentIndustries, industry];
    onFiltersChange({ ...filters, industries: newIndustries });
  };

  const handleSelectAllCompanySizes = () => {
    const allSizes = COMPANY_SIZES.map(s => s.value);
    onFiltersChange({ ...filters, companySizes: allSizes });
  };

  const handleSelectAllSeniority = () => {
    onFiltersChange({ ...filters, seniorityLevels: [...SENIORITY_LEVELS] });
  };

  const handleSelectAllIndustries = () => {
    onFiltersChange({ ...filters, industries: [...INDUSTRIES] });
  };

  const handleClearCompanySizes = () => {
    onFiltersChange({ ...filters, companySizes: [] });
  };

  const handleClearSeniority = () => {
    onFiltersChange({ ...filters, seniorityLevels: [] });
  };

  const handleClearIndustries = () => {
    onFiltersChange({ ...filters, industries: [] });
  };

  const handleClearAll = () => {
    onFiltersChange({
      companySizes: [],
      seniorityLevels: [],
      industries: []
    });
    setIndustrySearch('');
  };

  const totalActiveFilters = 
    (filters.companySizes?.length || 0) +
    (filters.seniorityLevels?.length || 0) +
    (filters.industries?.length || 0);

  return (
    <div className="space-y-6">
      {/* Clear All Filters Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-gray-900">Filters</h2>
          {totalActiveFilters > 0 && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              {totalActiveFilters} active
            </Badge>
          )}
        </div>
        {totalActiveFilters > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearAll}
            className="text-gray-600 hover:text-gray-900"
          >
            <X className="w-4 h-4 mr-2" />
            Clear All Filters
          </Button>
        )}
      </div>

      {/* Active Filter Chips */}
      {totalActiveFilters > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap gap-2"
        >
          {filters.companySizes?.length > 0 && (
            <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200 px-3 py-1">
              Company Size: {filters.companySizes.length} selected
              <button
                onClick={handleClearCompanySizes}
                className="ml-2 hover:bg-blue-100 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
          {filters.seniorityLevels?.length > 0 && (
            <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200 px-3 py-1">
              Seniority: {filters.seniorityLevels.length} selected
              <button
                onClick={handleClearSeniority}
                className="ml-2 hover:bg-purple-100 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
          {filters.industries?.length > 0 && (
            <Badge variant="secondary" className="bg-green-50 text-green-700 border-green-200 px-3 py-1">
              Industry: {filters.industries.length} selected
              <button
                onClick={handleClearIndustries}
                className="ml-2 hover:bg-green-100 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
        </motion.div>
      )}

      {/* Filter Sections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Company Size Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  Company Size
                  {filters.companySizes?.length > 0 && (
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                      {filters.companySizes.length}
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSelectAllCompanySizes}
                    className="h-7 text-xs"
                  >
                    All
                  </Button>
                  {filters.companySizes?.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearCompanySizes}
                      className="h-7 text-xs"
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
              {COMPANY_SIZES.map(({ value, label }) => (
                <div key={value} className="flex items-start space-x-2">
                  <Checkbox
                    id={`company-size-${value}`}
                    checked={filters.companySizes?.includes(value)}
                    onCheckedChange={() => handleCompanySizeToggle(value)}
                  />
                  <Label
                    htmlFor={`company-size-${value}`}
                    className="text-sm font-normal leading-tight cursor-pointer hover:text-blue-600 transition-colors"
                  >
                    {label}
                  </Label>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Seniority Level Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, delay: 0.1 }}
        >
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  Seniority Level
                  {filters.seniorityLevels?.length > 0 && (
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      {filters.seniorityLevels.length}
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSelectAllSeniority}
                    className="h-7 text-xs"
                  >
                    All
                  </Button>
                  {filters.seniorityLevels?.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearSeniority}
                      className="h-7 text-xs"
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
              {SENIORITY_LEVELS.map((level) => (
                <div key={level} className="flex items-start space-x-2">
                  <Checkbox
                    id={`seniority-${level}`}
                    checked={filters.seniorityLevels?.includes(level)}
                    onCheckedChange={() => handleSeniorityToggle(level)}
                  />
                  <Label
                    htmlFor={`seniority-${level}`}
                    className="text-sm font-normal leading-tight cursor-pointer hover:text-purple-600 transition-colors"
                  >
                    {level}
                  </Label>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Industry Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, delay: 0.2 }}
        >
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  Industry
                  {filters.industries?.length > 0 && (
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      {filters.industries.length}
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSelectAllIndustries}
                    className="h-7 text-xs"
                  >
                    All
                  </Button>
                  {filters.industries?.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearIndustries}
                      className="h-7 text-xs"
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Industry Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search industries..."
                  value={industrySearch}
                  onChange={(e) => setIndustrySearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Selected Industries as Badges */}
              {filters.industries?.length > 0 && (
                <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto p-2 bg-gray-50 rounded-md">
                  {filters.industries.map((industry) => (
                    <Badge
                      key={industry}
                      variant="secondary"
                      className="bg-green-100 text-green-800 border-green-200"
                    >
                      {industry}
                      <button
                        onClick={() => handleIndustryToggle(industry)}
                        className="ml-1 hover:bg-green-200 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              {/* Industry Checkboxes */}
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {filteredIndustries.map((industry) => (
                  <div key={industry} className="flex items-start space-x-2">
                    <Checkbox
                      id={`industry-${industry}`}
                      checked={filters.industries?.includes(industry)}
                      onCheckedChange={() => handleIndustryToggle(industry)}
                    />
                    <Label
                      htmlFor={`industry-${industry}`}
                      className="text-sm font-normal leading-tight cursor-pointer hover:text-green-600 transition-colors"
                    >
                      {industry}
                    </Label>
                  </div>
                ))}
                {filteredIndustries.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No industries found
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}