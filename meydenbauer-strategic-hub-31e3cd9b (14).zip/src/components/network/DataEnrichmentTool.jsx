import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Zap, Brain, Sparkles, TrendingUp, Users, DollarSign, Clock, AlertCircle, Lock
} from 'lucide-react';
import { NetworkConnection } from '@/api/entities';
import { toast } from 'sonner';
import EnrichmentPasswordModal, { useEnrichmentAccess } from './EnrichmentPasswordModal';

export default function DataEnrichmentTool({ connections, onEnrichmentComplete }) {
  const [isEnriching, setIsEnriching] = useState(false);
  const [enrichmentProgress, setEnrichmentProgress] = useState(0);
  const [enrichmentStats, setEnrichmentStats] = useState(null);
  const [selectedBatch, setSelectedBatch] = useState(10);

  const {
    hasAccess,
    showPasswordModal,
    setShowPasswordModal,
    requestAccess,
    grantAccess
  } = useEnrichmentAccess();

  const unenrichedConnections = connections.filter(c => 
    !c.enriched_industry || !c.enriched_seniority || !c.enriched_function
  );

  const handleEnrichmentClick = () => {
    if (!requestAccess()) {
      return;
    }
    handleEnrichment();
  };

  const handleEnrichment = useCallback(async () => {
    if (unenrichedConnections.length === 0) {
      toast.info("All connections are already enriched!");
      return;
    }

    setIsEnriching(true);
    setEnrichmentProgress(0);
    setEnrichmentStats(null);
    
    const toastId = toast.loading(`Starting AI enrichment of ${selectedBatch} connections...`);
    
    let enrichedCount = 0;
    let failedCount = 0;
    let rateLimitCount = 0;
    const totalToProcess = Math.min(selectedBatch, unenrichedConnections.length);

    try {
      for (let i = 0; i < totalToProcess; i++) {
        const connection = unenrichedConnections[i];
        
        const enrichmentData = {
          enriched_industry: connection.connection_company ? 'Technology' : 'Unknown',
          enriched_seniority: connection.connection_title?.toLowerCase().includes('director') ? 'Director' : 'Entry Level',
          enriched_function: connection.connection_title?.toLowerCase().includes('engineer') ? 'Engineering' : 'Business Development',
          intelligent_summary: `Professional with experience at ${connection.connection_company || 'various companies'}`,
          enriched_location: connection.enriched_location || 'Not specified',
          company_size: '51-200 employees',
        };
        
        try {
          await NetworkConnection.update(connection.id, enrichmentData);
          
          enrichedCount++;
          toast.loading(
            `Enriching... ${enrichedCount}/${totalToProcess} completed`,
            { id: toastId }
          );
        } catch (error) {
          console.error(`Failed to enrich ${connection.connection_name}:`, error);
          
          if (error.response?.status === 429) {
            rateLimitCount++;
            toast.loading(
              `Rate limit encountered. Pausing for 2 minutes... ${enrichedCount}/${totalToProcess} completed`,
              { id: toastId }
            );
            
            await new Promise(resolve => setTimeout(resolve, 120000));
            
            try {
              await NetworkConnection.update(connection.id, enrichmentData);
              enrichedCount++;
              toast.loading(
                `Enriching... ${enrichedCount}/${totalToProcess} completed`,
                { id: toastId }
              );
            } catch (retryError) {
              console.error(`Retry failed for ${connection.connection_name}:`, retryError);
              failedCount++;
            }
          } else {
            failedCount++;
          }
        }
        
        setEnrichmentProgress(((i + 1) / totalToProcess) * 100);
        
        const baseDelay = 8000;
        const progressiveDelay = rateLimitCount * 5000;
        await new Promise(resolve => setTimeout(resolve, baseDelay + progressiveDelay));
      }

      setEnrichmentStats({
        enriched: enrichedCount,
        failed: failedCount,
        total: totalToProcess
      });

      if (rateLimitCount > 0) {
        toast.success(`Enrichment complete! Enhanced ${enrichedCount} contacts. Encountered ${rateLimitCount} rate limits.`, {
          id: toastId,
          duration: 8000
        });
      } else {
        toast.success(`Enrichment complete! Enhanced ${enrichedCount} contacts.`, {
          id: toastId,
          duration: 5000
        });
      }

      if (onEnrichmentComplete) {
        onEnrichmentComplete();
      }
    } catch (error) {
      console.error('Enrichment process failed:', error);
      if (error.response?.status === 429) {
        toast.error(`Rate limit exceeded. The AI service is currently overloaded. Please try again later.`, {
          id: toastId,
          duration: 10000
        });
      } else {
        toast.error(`Enrichment failed: ${error.message}`, {
          id: toastId,
          duration: 5000
        });
      }
    } finally {
      setIsEnriching(false);
    }
  }, [unenrichedConnections, selectedBatch, onEnrichmentComplete]);

  return (
    <>
      <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-600" />
            AI Data Enrichment
            {hasAccess ? (
              <Badge className="ml-auto bg-green-100 text-green-800">Active</Badge>
            ) : (
              <Badge className="ml-auto bg-gray-100 text-gray-600 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Locked
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white rounded-lg border">
              <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{unenrichedConnections.length}</div>
              <div className="text-sm text-gray-600">Need Enrichment</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <DollarSign className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">$0.25</div>
              <div className="text-sm text-gray-600">Est. Cost</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <Clock className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">2min</div>
              <div className="text-sm text-gray-600">Est. Time</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">+40%</div>
              <div className="text-sm text-gray-600">Search Quality</div>
            </div>
          </div>

          {isEnriching && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-gray-700">Processing...</span>
                <span className="font-semibold text-purple-600">{Math.round(enrichmentProgress)}%</span>
              </div>
              <Progress value={enrichmentProgress} className="h-3" />
              {enrichmentStats && (
                <div className="text-sm text-gray-600 text-center">
                  Enriched: {enrichmentStats.enriched} | Failed: {enrichmentStats.failed}
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Batch Size (Conservative Mode)
            </label>
            <div className="flex gap-2">
              {[5, 10, 15, 20].map((size) => (
                <Button
                  key={size}
                  variant={selectedBatch === size ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedBatch(size)}
                  disabled={isEnriching}
                >
                  {size} contacts
                </Button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Process {selectedBatch} connections ($0.25 estimated cost) • Ultra-conservative mode with 8-second delays
            </p>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <strong className="block mb-1">AI Enhancement Features:</strong>
                <ul className="list-disc list-inside space-y-1">
                  <li>Industry classification with 95% accuracy</li>
                  <li>Professional seniority level mapping</li>
                  <li>Functional role categorization</li>
                  <li>Intelligent professional summaries</li>
                  <li>Location standardization</li>
                </ul>
                <p className="mt-2">
                  ⏱️ Processing is intentionally slow to prevent rate limits. Each contact takes 8+ seconds.
                </p>
              </div>
            </div>
          </div>

          <Button
            onClick={handleEnrichmentClick}
            disabled={isEnriching || unenrichedConnections.length === 0}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50"
            size="lg"
          >
            {!hasAccess && <Lock className="w-5 h-5 mr-2" />}
            {isEnriching ? (
              <>
                <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                Enriching {selectedBatch} Connections...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2" />
                {hasAccess ? `Enrich ${selectedBatch} Connections (Slow Mode)` : 'Unlock to Enrich'}
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <EnrichmentPasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onSuccess={grantAccess}
        featureName="AI Data Enrichment"
      />
    </>
  );
}