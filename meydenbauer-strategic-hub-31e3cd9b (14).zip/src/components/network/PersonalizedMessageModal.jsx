
import React, { useState, useEffect, useCallback } from 'react';
import {
  X, Copy, RefreshCw, Loader2,
  Sparkles, Check, Linkedin
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { User } from '@/api/entities';

export default function PersonalizedMessageModal({ isOpen, onClose, contact, triggerSource = 'find_connections' }) {
  // New state management based on the outline
  const [message, setMessage] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [alternatives, setAlternatives] = useState([]);
  const [selectedVersion, setSelectedVersion] = useState(0);
  const [isCopied, setIsCopied] = useState(false);
  const [generationError, setGenerationError] = useState(null);

  // New `resetModal` function
  const resetModal = useCallback(() => {
    setMessage('');
    setAlternatives([]);
    setSelectedVersion(0);
    setIsCopied(false);
    setGenerationError(null);
  }, []);

  // New `generateInitialMessage` function
  const generateInitialMessage = useCallback(async () => {
    if (!contact) return;

    setIsGenerating(true);
    setGenerationError(null);

    try {
      const currentUser = await User.me();
      
      // Dynamically import the service from the correct path
      const { linkedInMessageGenerator } = await import('@/components/services/linkedInMessageGenerator.js');
      
      const result = await linkedInMessageGenerator.generateMessage(
        {
          first_name: contact.first_name || contact.connection_name?.split(' ')[0] || 'there',
          role: contact.enriched_title || contact.connection_title,
          company: contact.enriched_company || contact.connection_company,
          recent_activity: null // TODO: Add activity tracking
        },
        {
          first_name: currentUser.full_name?.split(' ')[0] || 'there',
          specialty: currentUser.job_title || 'professional networking'
        },
        triggerSource
      );

      setMessage(result.message);
      setAlternatives([result]);
      setSelectedVersion(0); // Ensure the first generated version is selected

    } catch (error) {
      console.error('[PersonalizedMessageModal] Generation error:', error);
      setGenerationError(error.message || 'Failed to generate message');
      toast.error('Failed to generate message. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  }, [contact, triggerSource]);

  // New `generateMoreVersions` function
  const generateMoreVersions = useCallback(async () => {
    setIsGenerating(true);
    setGenerationError(null); // Clear any previous errors

    try {
      const currentUser = await User.me();
      // Dynamically import the service from the correct path
      const { linkedInMessageGenerator } = await import('@/components/services/linkedInMessageGenerator.js');
      
      const newAlternatives = await linkedInMessageGenerator.generateAlternatives(
        {
          first_name: contact.first_name || contact.connection_name?.split(' ')[0] || 'there',
          role: contact.enriched_title || contact.connection_title,
          company: contact.enriched_company || contact.connection_company,
          recent_activity: null
        },
        {
          first_name: currentUser.full_name?.split(' ')[0] || 'there',
          specialty: currentUser.job_title || 'professional networking'
        },
        2 // As per outline, generate 2 more alternatives
      );

      setAlternatives(prev => [...prev, ...newAlternatives]);
      // Optional: Automatically select the first new alternative
      // if (newAlternatives.length > 0) {
      //   setMessage(newAlternatives[0].message);
      //   setSelectedVersion(alternatives.length);
      // }

    } catch (error) {
      console.error('[PersonalizedMessageModal] Failed to generate alternatives:', error);
      setGenerationError(error.message || 'Failed to generate alternative messages');
      toast.error('Failed to generate alternative messages');
    } finally {
      setIsGenerating(false);
    }
  }, [contact]);

  // `useEffect` to handle modal open/close and contact changes
  useEffect(() => {
    if (isOpen && contact) {
      generateInitialMessage();
    } else {
      resetModal();
    }
  }, [isOpen, contact, generateInitialMessage, resetModal]);

  // New `handleCopy` function
  const handleCopy = useCallback(() => {
    if (message) {
      navigator.clipboard.writeText(message);
      setIsCopied(true);
      toast.success('Message copied to clipboard');
      setTimeout(() => setIsCopied(false), 2000);
    }
  }, [message]);

  // New `handleSelectVersion` function
  const handleSelectVersion = useCallback((index) => {
    setSelectedVersion(index);
    setMessage(alternatives[index].message);
    setIsCopied(false); // Reset copied status when switching versions
  }, [alternatives]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0"> {/* Removed default padding to allow custom header/body padding */}
        {/* Custom Header Section */}
        <div className={cn("sticky top-0 bg-gradient-to-r from-purple-500 to-pink-600 text-white border-b border-white/20 z-10 px-6 py-4 rounded-t-lg")}>
          <DialogHeader className="flex flex-row items-center justify-between space-y-0">
            <DialogTitle className="flex items-center gap-2 text-xl font-bold text-white">
              <Sparkles className="w-5 h-5" />
              AI-Generated LinkedIn Message
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="flex-shrink-0 hover:bg-white/20 text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </DialogHeader>
          <DialogDescription className="text-sm text-white/90 mt-1">
            Personalized message for {contact.connection_name || 'your connection'}
          </DialogDescription>
        </div>

        {/* Modal Body */}
        <div className="px-6 py-6 space-y-4">
          {/* Contact Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                {(contact.connection_name || 'U').charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-gray-900">{contact.connection_name}</p>
                <p className="text-sm text-gray-600">
                  {contact.enriched_title || contact.connection_title || 'Professional'} at {contact.enriched_company || contact.connection_company || 'Company'}
                </p>
              </div>
            </div>
          </div>

          {/* Message Display/Generation Status */}
          {isGenerating ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-3" />
                <p className="text-gray-600">Generating personalized message...</p>
              </div>
            </div>
          ) : generationError ? (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{generationError}</p>
              <Button onClick={generateInitialMessage} variant="outline" className="mt-3" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </div>
          ) : (
            <>
              <div className="relative">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[150px] pr-20"
                  placeholder="Your personalized message will appear here..."
                />
                <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                  {message.length}/600 chars {/* Assuming 600 characters is the LinkedIn limit */}
                </div>
              </div>

              {/* Alternative Versions */}
              {alternatives.length > 1 && (
                <div>
                  <Label className="text-sm font-medium mb-2 block">Alternative Versions:</Label>
                  <div className="flex gap-2 flex-wrap">
                    {alternatives.map((alt, index) => (
                      <Button
                        key={index}
                        variant={selectedVersion === index ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => handleSelectVersion(index)}
                        className={selectedVersion === index ? "bg-blue-600 hover:bg-blue-700 text-white" : ""}
                      >
                        Version {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3">
                <Button
                  onClick={handleCopy}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  disabled={!message}
                >
                  {isCopied ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Message
                    </>
                  )}
                </Button>
                
                {contact.linkedin_url && (
                  <Button
                    variant="outline"
                    asChild
                    className="flex-1"
                  >
                    <a href={contact.linkedin_url} target="_blank" rel="noopener noreferrer">
                      <Linkedin className="w-4 h-4 mr-2" />
                      Open LinkedIn
                    </a>
                  </Button>
                )}
              </div>

              <Button
                variant="ghost"
                onClick={generateMoreVersions}
                disabled={isGenerating}
                className="w-full text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                size="sm"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Generate More Versions
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
