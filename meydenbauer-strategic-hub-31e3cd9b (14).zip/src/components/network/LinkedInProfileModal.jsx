import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Linkedin, Calendar, Send, User, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { User as UserEntity } from '@/api/entities';
import { analyzeLinkedInProfile } from '@/api/functions';
import TechStackConfirmationModal from './TechStackConfirmationModal';
import { toast } from 'sonner';

export default function LinkedInProfileModal({ isOpen, onClose, onAnalysisComplete }) {
  const [linkedinUrl, setLinkedinUrl] = useState('https://www.linkedin.com/in/');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [showTechStackModal, setShowTechStackModal] = useState(false);
  const [techStackData, setTechStackData] = useState(null);
  const [isHighConfidence, setIsHighConfidence] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const fetchUser = async () => {
        try {
          const user = await UserEntity.me();
          setCurrentUser(user);
          if (user.linkedin_url) {
            setLinkedinUrl(user.linkedin_url);
          }
        } catch (e) {
          console.warn("User not logged in, cannot fetch profile.");
        }
      };
      fetchUser();
    }
  }, [isOpen]);

  // Auto-trigger tech stack confirmation after 60 seconds of activity
  useEffect(() => {
    if (isSubmitted && !showTechStackModal) {
      const timer = setTimeout(() => {
        if (techStackData) {
          setShowTechStackModal(true);
        }
      }, 60000); // 60 seconds

      return () => clearTimeout(timer);
    }
  }, [isSubmitted, techStackData, showTechStackModal]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!linkedinUrl || linkedinUrl === 'https://www.linkedin.com/in/') {
      toast.error("Please complete your LinkedIn profile URL.");
      return;
    }
    setIsSubmitting(true);
    
    try {
      // Update user profile first
      await UserEntity.updateMyUserData({ linkedin_url: linkedinUrl });
      
      // Analyze LinkedIn profile for ICP and tech stack
      const analysisResponse = await analyzeLinkedInProfile({ linkedin_url: linkedinUrl });
      
      if (analysisResponse.data.success) {
        setTechStackData(analysisResponse.data.tech_stack_data);
        setIsHighConfidence(analysisResponse.data.tech_stack_confidence >= 90);
        setIsSubmitted(true);
        
        toast.success("Profile analyzed successfully! Building your personalized experience...");
        
        if (onAnalysisComplete) {
          onAnalysisComplete(analysisResponse.data);
        }
        
        // For high confidence, show tech stack confirmation immediately
        if (analysisResponse.data.tech_stack_confidence >= 90) {
          setTimeout(() => setShowTechStackModal(true), 2000);
        }
        
      } else {
        throw new Error(analysisResponse.data.error || 'Analysis failed');
      }
    } catch (error) {
      console.error("Failed to analyze LinkedIn profile:", error);
      toast.error("Failed to analyze profile. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTechStackConfirm = async (confirmedTechStack) => {
    try {
      // Update tech stack with confirmed selections
      // This would call another backend function to update the UserTechStack entity
      toast.success("Tech stack confirmed! Your experience is now personalized.");
      setShowTechStackModal(false);
      handleClose();
    } catch (error) {
      console.error("Failed to confirm tech stack:", error);
      toast.error("Failed to save tech stack preferences.");
    }
  };

  const handleClose = () => {
    onClose();
    // Reset state after closing animation
    setTimeout(() => {
      setIsSubmitted(false);
      setShowTechStackModal(false);
      setTechStackData(null);
      if (!currentUser?.linkedin_url) {
        setLinkedinUrl('https://www.linkedin.com/in/');
      }
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <>
      <TechStackConfirmationModal
        isOpen={showTechStackModal}
        onClose={() => setShowTechStackModal(false)}
        techStackData={techStackData}
        isHighConfidence={isHighConfidence}
        onConfirm={handleTechStackConfirm}
      />
      
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="w-full max-w-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <Card className="shadow-2xl border-0 overflow-hidden">
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" onClick={handleClose}>
                <X className="w-5 h-5" />
              </Button>
              <CardHeader className="p-8 text-center">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-4 text-white">
                  <User className="w-8 h-8" />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Optimize Your Experience</CardTitle>
                <CardDescription className="text-gray-600 mt-2">
                  Our Agentic AI analyzes your LinkedIn profile to improve suggested connections and buyer intent insights.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                {isSubmitted ? (
                  <div className="text-center space-y-4 py-8">
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1, transition: { type: 'spring', stiffness: 260, damping: 20 } }}>
                      <CheckCircle className="w-20 h-20 mx-auto text-green-500" />
                    </motion.div>
                    <h3 className="text-xl font-bold text-gray-800">Analysis Complete!</h3>
                    <p className="text-gray-600">
                      {isHighConfidence 
                        ? "High-confidence tech stack detected. Confirmation dialog will appear shortly."
                        : "Building your personalized profile. Tech stack confirmation will appear in 60 seconds."
                      }
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <div className="relative">
                        <Linkedin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input
                          type="text"
                          placeholder="https://www.linkedin.com/in/your-profile"
                          value={linkedinUrl}
                          onChange={(e) => setLinkedinUrl(e.target.value)}
                          className="pl-10 h-12 text-base"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="link"
                        className="text-blue-600 h-auto p-0 mt-2 text-sm"
                        onClick={() => window.open('https://www.linkedin.com/me/profile-views/', '_blank', 'noopener,noreferrer')}
                      >
                        Access LinkedIn to procure your profile URL by navigating to your personal profile page.
                      </Button>
                    </div>

                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 text-sm text-yellow-800">
                      <strong>Disclaimer:</strong> Submitting your LinkedIn profile will only tailor your experience; it won't activate "Upload connections" or similar features.
                    </div>

                    <Button type="submit" disabled={isSubmitting} className="w-full h-12 text-base bg-gradient-to-r from-blue-500 to-purple-600 hover:opacity-90">
                      {isSubmitting ? <Loader2 className="animate-spin" /> : 'Analyze Profile & Personalize Experience'}
                    </Button>

                    <div className="flex flex-col sm:flex-row items-center gap-4 mt-4">
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full flex items-center gap-2"
                        onClick={() => window.open('https://www.linkedin.com/in/dougsandstedt/', '_blank', 'noopener,noreferrer')}
                      >
                        <Send className="w-4 h-4" />
                        Send a LinkedIn Message to Doug
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full flex items-center gap-2"
                        onClick={() => window.open('https://calendly.com/dougsandstedt', '_blank', 'noopener,noreferrer')}
                      >
                        <Calendar className="w-4 h-4" />
                        Book a call with our Leadership
                      </Button>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    </>
  );
}