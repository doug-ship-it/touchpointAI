import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Sparkles, TrendingUp, Users, DollarSign, Clock, AlertCircle, Lock, CheckCircle, XCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { apolloBatchEnrich } from '@/api/functions';
import EnrichmentPasswordModal, { useEnrichmentAccess } from './EnrichmentPasswordModal';

export default function ApolloEnrichmentTool({ contacts, onEnrichmentComplete }) {
  const [isEnriching, setIsEnriching] = useState(false);
  const [enrichmentProgress, setEnrichmentProgress] = useState(0);
  const [enrichmentStats, setEnrichmentStats] = useState(null);
  const [selectedBatch, setSelectedBatch] = useState(10);

  const {
    hasAccess,
    showPasswordModal,
    setShowPasswordModal,
    requestAccess,
    grantAccess
  } = useEnrichmentAccess();

  // Filter contacts that need enrichment
  const needsEnrichment = contacts.filter(c => {
    if (!c.enrichment_date) return true;
    if (c.enrichment_source !== 'apollo') return true;
    
    const enrichmentDate = new Date(c.enrichment_date);
    const daysSince = (new Date() - enrichmentDate) / (1000 * 60 * 60 * 24);
    return daysSince > 30; // Re-enrich if older than 30 days
  });

  const handleEnrichmentClick = () => {
    if (!requestAccess()) {
      return;
    }
    handleEnrichment();
  };

  const handleEnrichment = async () => {
    if (needsEnrichment.length === 0) {
      toast.info("All contacts are already enriched with Apollo.io data!");
      return;
    }

    setIsEnriching(true);
    setEnrichmentProgress(0);
    setEnrichmentStats(null);
    
    const toastId = toast.loading(`Starting Apollo.io enrichment of ${selectedBatch} contacts...`);
    
    try {
      const contactIds = needsEnrichment.slice(0, selectedBatch).map(c => c.id);
      
      const { data } = await apolloBatchEnrich({
        contactIds,
        batchSize: selectedBatch
      });

      if (data.success) {
        setEnrichmentStats(data.results);
        
        toast.success(
          `Enrichment complete! ${data.results.enriched} contacts updated.`,
          { id: toastId, duration: 5000 }
        );

        if (onEnrichmentComplete) {
          onEnrichmentComplete();
        }
      } else {
        toast.error(`Enrichment failed: ${data.error}`, { id: toastId });
      }

    } catch (error) {
      console.error('Enrichment error:', error);
      toast.error(`Enrichment failed: ${error.message}`, { id: toastId });
    } finally {
      setIsEnriching(false);
      setEnrichmentProgress(100);
    }
  };

  return (
    <>
      <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-600" />
            Apollo.io Professional Enrichment
            {hasAccess ? (
              <Badge className="ml-auto bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                Active
              </Badge>
            ) : (
              <Badge className="ml-auto bg-gray-100 text-gray-600 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Locked
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white rounded-lg border">
              <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{needsEnrichment.length}</div>
              <div className="text-sm text-gray-600">Need Enrichment</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <DollarSign className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">$0.10</div>
              <div className="text-sm text-gray-600">Per Contact</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <Clock className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{selectedBatch * 2}s</div>
              <div className="text-sm text-gray-600">Est. Time</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">95%</div>
              <div className="text-sm text-gray-600">Match Rate</div>
            </div>
          </div>

          {/* Progress Bar */}
          {isEnriching && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-gray-700">Enriching contacts...</span>
                <span className="font-semibold text-purple-600">{Math.round(enrichmentProgress)}%</span>
              </div>
              <Progress value={enrichmentProgress} className="h-3" />
              {enrichmentStats && (
                <div className="text-sm text-gray-600 text-center flex items-center justify-center gap-4">
                  <span className="flex items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    {enrichmentStats.enriched} enriched
                  </span>
                  <span className="flex items-center gap-1">
                    <XCircle className="w-4 h-4 text-red-600" />
                    {enrichmentStats.failed} failed
                  </span>
                  <span className="flex items-center gap-1">
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                    {enrichmentStats.skipped} skipped
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Batch Size Selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Batch Size
            </label>
            <div className="flex gap-2">
              {[5, 10, 15, 20, 25].map((size) => (
                <Button
                  key={size}
                  variant={selectedBatch === size ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedBatch(size)}
                  disabled={isEnriching}
                >
                  {size} contacts
                </Button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Enrich {selectedBatch} contacts (${(selectedBatch * 0.10).toFixed(2)} estimated cost) • 2s per contact
            </p>
          </div>

          {/* Features List */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <strong className="block mb-2">Apollo.io Premium Data Includes:</strong>
                <ul className="list-disc list-inside space-y-1">
                  <li>Verified professional email addresses (95% accuracy)</li>
                  <li>Direct dial phone numbers</li>
                  <li>Current job titles and company information</li>
                  <li>Seniority levels and functional roles</li>
                  <li>Company size, industry, and technology stack</li>
                  <li>LinkedIn profile URLs</li>
                  <li>Employment history (last 3 positions)</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Enrich Button */}
          <Button
            onClick={handleEnrichmentClick}
            disabled={isEnriching || needsEnrichment.length === 0}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50"
            size="lg"
          >
            {!hasAccess && <Lock className="w-5 h-5 mr-2" />}
            {isEnriching ? (
              <>
                <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                Enriching {selectedBatch} Contacts...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                {hasAccess ? `Enrich ${selectedBatch} Contacts with Apollo.io` : 'Unlock Apollo.io Enrichment'}
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <EnrichmentPasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onSuccess={grantAccess}
        featureName="Apollo.io Contact Enrichment"
      />
    </>
  );
}