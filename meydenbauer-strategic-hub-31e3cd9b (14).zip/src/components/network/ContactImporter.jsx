import React, { useState, useCallback } from 'react';
import { Upload, CheckCircle, AlertCircle, Loader, Info } from 'lucide-react';
import { NetworkConnection } from '@/api/entities';
import { User } from '@/api/entities';
import { toast } from 'sonner';

const FIELD_MAPPINGS = {
  linkedin: {
    firstName: ['First Name', 'first_name', 'firstName'],
    lastName: ['Last Name', 'last_name', 'lastName'],
    email: ['Email Address', 'email', 'Email'],
    company: ['Company', 'company', 'Organization'],
    title: ['Position', 'title', 'Job Title'],
    linkedinUrl: ['URL', 'Profile URL', 'linkedin_url'],
    location: ['Location', 'location'],
  },
  google: {
    firstName: ['Given Name', 'first_name', 'First Name'],
    lastName: ['Family Name', 'last_name', 'Last Name'],
    email: ['E-mail Address', 'Email', 'Primary Email'],
    phone: ['Phone Number', 'Primary Phone', 'Mobile'],
    company: ['Organization', 'Company'],
    title: ['Job Title', 'Title'],
    location: ['Address', 'Home Address'],
  },
  generic: {
    firstName: ['first', 'firstname', 'first name', 'given', 'fname'],
    lastName: ['last', 'lastname', 'last name', 'family', 'surname', 'lname'],
    email: ['email', 'e-mail', 'mail', 'email address'],
    phone: ['phone', 'mobile', 'cell', 'telephone', 'number'],
    company: ['company', 'organization', 'org', 'employer'],
    title: ['title', 'job title', 'position', 'role'],
    location: ['location', 'address', 'city', 'country'],
  }
};

// Native CSV parser function
function parseCSV(text) {
  const lines = text.split('\n').filter(line => line.trim());
  if (lines.length === 0) return { headers: [], data: [] };

  // Parse a single CSV line, handling quoted fields
  const parseLine = (line) => {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  // Parse headers
  const headers = parseLine(lines[0]);

  // Parse data rows
  const data = [];
  for (let i = 1; i < lines.length; i++) {
    const values = parseLine(lines[i]);
    if (values.length === headers.length) {
      const row = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      data.push(row);
    }
  }

  return { headers, data };
}

export default function ContactImporter({ onImportComplete }) {
  const [importing, setImporting] = useState(false);
  const [importStats, setImportStats] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isDragging, setIsDragging] = useState(false);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error('Failed to load user:', error);
      }
    };
    loadUser();
  }, []);

  const detectSourceType = useCallback((headers) => {
    const headerLower = headers.map(h => h.toLowerCase());
    
    if (headerLower.some(h => h.includes('profile url') || h.includes('linkedin'))) {
      return 'linkedin';
    }
    if (headerLower.some(h => h.includes('given name') && h.includes('family name'))) {
      return 'google';
    }
    return 'generic';
  }, []);

  const findMatchingField = useCallback((headers, possibleNames) => {
    const headerLower = headers.map(h => h.toLowerCase());
    const possibleLower = possibleNames.map(p => p.toLowerCase());
    
    for (const possible of possibleLower) {
      const index = headerLower.findIndex(h => 
        h === possible || h.includes(possible) || possible.includes(h)
      );
      if (index !== -1) return headers[index];
    }
    return null;
  }, []);

  const normalizeContact = useCallback((rawContact, fieldMap, headers) => {
    const normalized = {
      user_email: currentUser?.email,
      source: 'csv',
      import_date: new Date().toISOString(),
      connection_since: new Date().toISOString(),
    };

    let firstName = '';
    let lastName = '';

    Object.keys(fieldMap).forEach(targetField => {
      const possibleHeaders = fieldMap[targetField];
      const matchedHeader = findMatchingField(headers, possibleHeaders);
      
      if (matchedHeader && rawContact[matchedHeader]) {
        const value = rawContact[matchedHeader].trim();
        
        if (targetField === 'firstName') {
          firstName = value;
          normalized.first_name = value;
        } else if (targetField === 'lastName') {
          lastName = value;
          normalized.last_name = value;
        } else if (targetField === 'email') {
          normalized.connection_email = value;
        } else if (targetField === 'phone') {
          normalized.phone = value.replace(/[^0-9+]/g, '');
        } else if (targetField === 'company') {
          normalized.connection_company = value;
        } else if (targetField === 'title') {
          normalized.connection_title = value;
        } else if (targetField === 'location') {
          normalized.enriched_location = value;
        } else if (targetField === 'linkedinUrl') {
          normalized.linkedin_url = value;
        }
      }
    });

    if (firstName || lastName) {
      normalized.connection_name = `${firstName} ${lastName}`.trim();
    }

    return normalized;
  }, [currentUser, findMatchingField]);

  const processFile = async (file) => {
    if (!currentUser) {
      toast.error('Please log in to import contacts');
      return;
    }

    setImporting(true);
    setImportStats(null);

    try {
      const text = await file.text();
      const { headers, data } = parseCSV(text);

      if (!data || data.length === 0) {
        toast.error('CSV file is empty or invalid');
        setImporting(false);
        return;
      }

      const sourceType = detectSourceType(headers);
      const fieldMap = FIELD_MAPPINGS[sourceType];

      toast.info(`Detected ${sourceType} format. Processing ${data.length} contacts...`);

      const normalizedContacts = data
        .map((row) => normalizeContact(row, fieldMap, headers))
        .filter((contact) => contact.connection_name || contact.connection_email);

      if (normalizedContacts.length === 0) {
        toast.error('No valid contacts found in CSV');
        setImporting(false);
        return;
      }

      // Client-side deduplication
      const seen = new Set();
      const deduplicated = normalizedContacts.filter((contact) => {
        if (!contact.connection_email) return true;
        
        const emailKey = contact.connection_email.toLowerCase();
        if (seen.has(emailKey)) {
          return false;
        }
        seen.add(emailKey);
        return true;
      });

      const stats = {
        total: data.length,
        successful: 0,
        failed: 0,
        duplicatesInBatch: normalizedContacts.length - deduplicated.length,
        duplicatesInDatabase: 0
      };

      const createdContacts = [];
      for (const contact of deduplicated) {
        try {
          const created = await NetworkConnection.create(contact);
          createdContacts.push(created);
          stats.successful++;
        } catch (error) {
          console.error('Failed to create contact:', error);
          stats.failed++;
          
          if (error.message && error.message.includes('duplicate')) {
            stats.duplicatesInDatabase++;
          }
        }
      }

      setImportStats(stats);
      setImporting(false);

      const totalDuplicates = stats.duplicatesInBatch + stats.duplicatesInDatabase;
      toast.success(`Successfully imported ${stats.successful} contacts! (${totalDuplicates} duplicates skipped)`);
      
      if (onImportComplete) {
        onImportComplete(createdContacts);
      }
    } catch (error) {
      console.error('CSV parsing error:', error);
      toast.error(`Failed to parse CSV file: ${error.message}`);
      setImporting(false);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
        processFile(file);
      } else {
        toast.error('Please upload a CSV file');
      }
    }
  };

  const handleFileSelect = (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      processFile(files[0]);
    }
  };

  return (
    <div className="space-y-6">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all
          ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400 bg-white'}
          ${importing ? 'opacity-50 pointer-events-none' : ''}
        `}
      >
        <input
          type="file"
          accept=".csv"
          onChange={handleFileSelect}
          disabled={importing}
          className="hidden"
          id="csv-file-input"
        />
        <label htmlFor="csv-file-input" className="cursor-pointer">
          <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="text-lg font-medium text-gray-700 mb-2">
            {importing ? 'Processing...' : 'Drop your contact CSV file here or click to browse'}
          </p>
          <p className="text-sm text-gray-500">
            Supports: LinkedIn CSV, Google Contacts, or any generic CSV
          </p>
        </label>
      </div>

      {importing && (
        <div className="flex items-center justify-center space-x-3 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <Loader className="w-5 h-5 animate-spin text-blue-600" />
          <span className="text-blue-700 font-medium">Importing contacts...</span>
        </div>
      )}

      {importStats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">{importStats.total}</div>
            <div className="text-sm text-gray-600">Total Records</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">
              <CheckCircle className="w-8 h-8 mx-auto mb-1" />
              {importStats.successful}
            </div>
            <div className="text-sm text-gray-600">Successfully Imported</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-600">{importStats.duplicatesInBatch + importStats.duplicatesInDatabase}</div>
            <div className="text-sm text-gray-600">Duplicates Skipped</div>
            <div className="text-xs text-gray-500 mt-1">
              ({importStats.duplicatesInBatch} in CSV, {importStats.duplicatesInDatabase} in database)
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600">{importStats.failed - importStats.duplicatesInDatabase}</div>
            <div className="text-sm text-gray-600">Failed</div>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-200">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-3">How to Export Your Contacts:</h3>
            <div className="space-y-3 text-sm text-gray-700">
              <div>
                <strong className="text-gray-900">LinkedIn:</strong> Settings → Data Privacy → Get a copy of your data → Request archive → Download "Connections.csv"
              </div>
              <div>
                <strong className="text-gray-900">Google Contacts:</strong> contacts.google.com → Export → Google CSV format
              </div>
              <div>
                <strong className="text-gray-900">Generic CSV:</strong> Must include at least name or email columns
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}