import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Users, Building2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

// Debounce hook for search/filter optimization
function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

export default function NetworkVisualization({ contacts, onContactSelect }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [selectedCompanySize, setSelectedCompanySize] = useState('all');
  const [viewMode, setViewMode] = useState('grid'); // grid or clusters

  // Debounce search query for better performance
  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  // Extract unique industries and company sizes - memoized
  const industries = useMemo(() => {
    const unique = new Set(contacts.map(c => c.enriched_industry).filter(Boolean));
    return ['all', ...Array.from(unique)].sort();
  }, [contacts]);

  const companySizes = useMemo(() => {
    const unique = new Set(contacts.map(c => c.company_size).filter(Boolean));
    return ['all', ...Array.from(unique)].sort();
  }, [contacts]);

  // Filter contacts - memoized with debounced search
  const filteredContacts = useMemo(() => {
    return contacts.filter(contact => {
      const matchesSearch = !debouncedSearchQuery || 
        contact.connection_name?.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
        contact.connection_company?.toLowerCase().includes(debouncedSearchQuery.toLowerCase());
      
      const matchesIndustry = selectedIndustry === 'all' || 
        contact.enriched_industry === selectedIndustry;
      
      const matchesSize = selectedCompanySize === 'all' || 
        contact.company_size === selectedCompanySize;
      
      return matchesSearch && matchesIndustry && matchesSize;
    });
  }, [contacts, debouncedSearchQuery, selectedIndustry, selectedCompanySize]);

  // Group contacts by company for cluster view - memoized
  const contactClusters = useMemo(() => {
    const clusters = {};
    filteredContacts.forEach(contact => {
      const company = contact.connection_company || 'Unknown';
      if (!clusters[company]) {
        clusters[company] = [];
      }
      clusters[company].push(contact);
    });
    return Object.entries(clusters)
      .map(([company, contacts]) => ({ company, contacts, count: contacts.length }))
      .sort((a, b) => b.count - a.count);
  }, [filteredContacts]);

  // Memoized helper functions
  const getInitials = useCallback((name) => {
    if (!name) return '??';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }, []);

  const getNodeColor = useCallback((contact) => {
    const seniority = contact.enriched_seniority?.toLowerCase() || '';
    if (seniority.includes('cxo') || seniority.includes('ceo')) return 'bg-purple-500';
    if (seniority.includes('vp')) return 'bg-blue-500';
    if (seniority.includes('director')) return 'bg-green-500';
    if (seniority.includes('manager')) return 'bg-yellow-500';
    return 'bg-gray-400';
  }, []);

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search contacts or companies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Industry Filter */}
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
              {industries.map(industry => (
                <option key={industry} value={industry}>
                  {industry === 'all' ? 'All Industries' : industry}
                </option>
              ))}
            </select>

            {/* Company Size Filter */}
            <select
              value={selectedCompanySize}
              onChange={(e) => setSelectedCompanySize(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
              {companySizes.map(size => (
                <option key={size} value={size}>
                  {size === 'all' ? 'All Sizes' : size}
                </option>
              ))}
            </select>

            {/* View Mode Toggle */}
            <div className="flex border border-gray-300 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-none"
              >
                <Users className="w-4 h-4 mr-2" />
                Grid
              </Button>
              <Button
                variant={viewMode === 'clusters' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('clusters')}
                className="rounded-none"
              >
                <Building2 className="w-4 h-4 mr-2" />
                Clusters
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-6 mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                <span className="font-semibold text-gray-900">{filteredContacts.length}</span> contacts
              </span>
            </div>
            {viewMode === 'clusters' && (
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">
                  <span className="font-semibold text-gray-900">{contactClusters.length}</span> companies
                </span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredContacts.map((contact, index) => (
            <motion.div
              key={contact.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.02 }}
              onClick={() => onContactSelect(contact)}
              className="cursor-pointer group"
            >
              <Card className="hover:shadow-lg transition-all duration-200 border-none overflow-hidden">
                <CardContent className="p-4">
                  {/* Avatar */}
                  <div className="relative mb-3">
                    <div className={`w-16 h-16 ${getNodeColor(contact)} rounded-full flex items-center justify-center text-white font-bold text-lg mx-auto group-hover:scale-110 transition-transform`}>
                      {getInitials(contact.connection_name)}
                    </div>
                    {contact.linkedin_url && (
                      <div className="absolute bottom-0 right-1/4 w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-bold">in</span>
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <h3 className="font-semibold text-gray-900 text-sm text-center mb-1 truncate">
                    {contact.connection_name}
                  </h3>
                  {contact.connection_title && (
                    <p className="text-xs text-gray-600 text-center truncate mb-1">
                      {contact.connection_title}
                    </p>
                  )}
                  {contact.connection_company && (
                    <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
                      <Building2 className="w-3 h-3" />
                      <span className="truncate">{contact.connection_company}</span>
                    </div>
                  )}

                  {/* Tags */}
                  {contact.enriched_industry && (
                    <div className="mt-2 flex justify-center">
                      <Badge variant="secondary" className="text-xs truncate max-w-full">
                        {contact.enriched_industry}
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Cluster View */}
      {viewMode === 'clusters' && (
        <div className="space-y-4">
          {contactClusters.map((cluster, index) => (
            <motion.div
              key={cluster.company}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="border-none shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4 text-white">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                        <Building2 className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{cluster.company}</h3>
                        <p className="text-sm text-blue-100">{cluster.count} contacts</p>
                      </div>
                    </div>
                  </div>
                </div>

                <CardContent className="p-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    {cluster.contacts.map((contact) => (
                      <div
                        key={contact.id}
                        onClick={() => onContactSelect(contact)}
                        className="flex flex-col items-center cursor-pointer group"
                      >
                        <div className={`w-12 h-12 ${getNodeColor(contact)} rounded-full flex items-center justify-center text-white font-bold text-sm group-hover:scale-110 transition-transform mb-2`}>
                          {getInitials(contact.connection_name)}
                        </div>
                        <p className="text-xs font-medium text-gray-900 text-center truncate w-full">
                          {contact.connection_name.split(' ')[0]}
                        </p>
                        {contact.connection_title && (
                          <p className="text-xs text-gray-500 text-center truncate w-full">
                            {contact.connection_title.split(' ')[0]}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {filteredContacts.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No contacts found</h3>
            <p className="text-gray-600">
              Try adjusting your search or filters
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}