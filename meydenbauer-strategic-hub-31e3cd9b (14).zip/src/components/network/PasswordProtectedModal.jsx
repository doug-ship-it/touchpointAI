import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, X, Shield, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function PasswordProtectedModal({ 
  isOpen, 
  onClose, 
  onSuccess, 
  title,
  description,
  actionType 
}) {
  const [password, setPassword] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');

  const ADMIN_PASSWORD = "mbai2024";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsVerifying(true);
    setError('');

    // Simulate a slight delay for better UX and security feel
    await new Promise(resolve => setTimeout(resolve, 500));

    if (password === ADMIN_PASSWORD) {
      onSuccess();
      onClose();
    } else {
      setError('Incorrect password. Access denied.');
    }
    setIsVerifying(false);
  };

  useEffect(() => {
    if (!isOpen) {
      setPassword('');
      setError('');
    }
  }, [isOpen]);
  
  if (!isOpen) return null;

  const getIcon = () => {
    const iconClass = "w-8 h-8 text-white";
    if (actionType === 'deletion') return <AlertTriangle className={iconClass} />;
    if (actionType === 'enrichment') return <Shield className={iconClass} />;
    return <Lock className={iconClass} />;
  };

  const getThemeColor = () => {
    if (actionType === 'deletion') return 'from-red-500 to-orange-500';
    if (actionType === 'enrichment') return 'from-blue-500 to-indigo-500';
    return 'from-gray-500 to-gray-600';
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.9, y: 20, opacity: 0 }}
          className="w-full max-w-md"
          onClick={(e) => e.stopPropagation()}
        >
          <Card className="shadow-2xl border-0 overflow-hidden">
            <div className={`h-2 bg-gradient-to-r ${getThemeColor()}`} />
            <CardHeader className="text-center">
                <div className="flex justify-end">
                    <Button variant="ghost" size="icon" className="absolute top-4 right-4" onClick={onClose}>
                        <X className="w-5 h-5 text-gray-400" />
                    </Button>
                </div>
              <div className={`w-16 h-16 mx-auto bg-gradient-to-br ${getThemeColor()} rounded-full flex items-center justify-center -mt-10 mb-4`}>
                {getIcon()}
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">{title}</CardTitle>
              <CardDescription className="text-gray-600">{description}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  type="password"
                  placeholder="Enter Admin Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-center text-lg h-12"
                  autoFocus
                  disabled={isVerifying}
                />
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <Button
                  type="submit"
                  size="lg"
                  className={`w-full bg-gradient-to-r ${getThemeColor()} text-white shadow-lg text-base`}
                  disabled={isVerifying || !password}
                >
                  {isVerifying ? <Loader2 className="w-5 h-5 animate-spin" /> : "Confirm & Proceed"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}