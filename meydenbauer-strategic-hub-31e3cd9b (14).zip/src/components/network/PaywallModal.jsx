import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Zap, Crown, Building, Calendar, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const tiers = [
  {
    name: 'Professional',
    price: '$49',
    inquiries: '5',
    features: [
      '5 vendor introduction credits',
      '2 executive search requests',
      'Priority email support',
      'Network intelligence access'
    ],
    icon: Zap
  },
  {
    name: 'Enterprise',
    price: '$149',
    inquiries: 'Unlimited',
    features: [
      'Unlimited vendor introductions',
      'Priority placement for searches',
      'Dedicated account manager',
      'Custom integration options',
      'Quarterly strategy sessions'
    ],
    icon: Crown,
    featured: true
  }
];

export default function PaywallModal({ open, onOpenChange }) {
  const handleUpgrade = (tier) => {
    // TODO: Implement Stripe payment integration
    console.log(`Upgrade to ${tier.name}`);
  };

  const handleScheduleCall = () => {
    window.open('https://calendly.com/dougsandstedt/15-minute-call', '_blank', 'noopener,noreferrer');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl bg-white p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-8 text-white">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold mb-2">
              Unlock Our Premium Vendor Network
            </DialogTitle>
            <DialogDescription className="text-blue-100 text-lg">
              You've used your free inquiry credits. Upgrade to get direct introductions to our vetted technology partners and accelerate your business growth.
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="p-8">
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {tiers.map((tier, index) => (
              <motion.div
                key={tier.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`relative p-6 rounded-xl border-2 ${
                  tier.featured 
                    ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg' 
                    : 'border-gray-200 bg-white'
                }`}
              >
                {tier.featured && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-1 rounded-full text-sm font-semibold shadow-md">
                    RECOMMENDED
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-xl ${tier.featured ? 'bg-blue-600' : 'bg-gray-100'}`}>
                      <tier.icon className={`h-6 w-6 ${tier.featured ? 'text-white' : 'text-blue-600'}`} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{tier.name}</h3>
                      <p className="text-sm text-gray-600">
                        {tier.inquiries} vendor inquiries
                      </p>
                    </div>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-gray-900">{tier.price}</span>
                    <span className="text-gray-600">/ month</span>
                  </div>

                  <ul className="space-y-3">
                    {tier.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full h-12 text-base ${
                      tier.featured 
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg' 
                        : 'bg-gray-900 hover:bg-gray-800 text-white'
                    }`}
                    onClick={() => handleUpgrade(tier)}
                  >
                    Upgrade to {tier.name}
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="space-y-4">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white text-gray-500 font-medium">OR</span>
              </div>
            </div>

            <Button 
              variant="outline" 
              className="w-full h-14 text-base border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-semibold"
              onClick={handleScheduleCall}
            >
              <Calendar className="h-5 w-5 mr-2" />
              Schedule a Free 15-Minute Consultation
            </Button>

            <p className="text-center text-sm text-gray-600">
              Not sure which plan is right for you? Book a call with our team to discuss your needs.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}