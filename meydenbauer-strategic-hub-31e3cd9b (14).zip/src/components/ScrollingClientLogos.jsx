import React from 'react';
import { motion } from 'framer-motion';

const logos = [
  { name: "Anker", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Anker_logo.svg/663px-Anker_logo.svg.png" },
  { name: "Microsoft", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Microsoft_logo_%282012%29.svg/512px-Microsoft_logo_%282012%29.svg.png" },
  { name: "Amazon", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/603px-Amazon_logo.svg.png" },
  { name: "Google", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/640px-Google_2015_logo.svg.png" },
  { name: "Intapp", logo: "https://assets-global.website-files.com/5e2c5644bcbe5c/logo-intapp-primary.svg" },
  { name: "DxD Capital", logo: "https://images.crunchbase.com/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/v1397755353/47c5e5c7a40b7b4c2a8e0d7" },
  { name: "The Surrogacy Foundation", logo: "https://static.wixstatic.com/media/41c8c5_f8c8b8a6f5c44b5f9d7c0e2a3b1f4d6e~mv2.png" },
  { name: "HubSpot", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/HubSpot_Logo.svg/512px-HubSpot_Logo.svg.png" },
  { name: "MaiProperty", logo: "https://maiproperty.com/wp-content/uploads/2023/01/mai-property-logo.png" },
  { name: "Yesh Tikva", logo: "https://yeshtikva.org/wp-content/uploads/2022/logo-yt.png" },
  { name: "Hegemony AI", logo: "https://hegemony.ai/assets/images/logo-dark.svg" },
  { name: "Ape Beverages", logo: "https://apebeverages.com/wp-content/uploads/2023/ape-logo-horizontal.png" },
  { name: "Nordic Partners", logo: "https://nordic-partners.com/assets/images/nordic-logo.svg" },
  { name: "Smart Asset Capital", logo: "https://smartasset.com/wp-content/themes/smartasset/dist/images/logo.svg" },
  { name: "Seamless Turf", logo: "https://seamlessturf.com/wp-content/uploads/2023/seamless-logo.png" },
  { name: "Salesrobot", logo: "https://salesrobot.co/images/logo-dark.svg" },
  { name: "Intersight.AI", logo: "https://intersight.ai/wp-content/uploads/2023/intersight-logo.png" },
  { name: "Social Current", logo: "https://socialcurrent.io/assets/images/social-current-logo.svg" },
  { name: "Olsen Anderson", logo: "https://olsenanderson.com/wp-content/uploads/2023/oa-logo.png" },
  { name: "Computools", logo: "https://computools.com/wp-content/uploads/2020/10/Computools-Logo.png" },
  { name: "Acolyte Health", logo: "https://acolytehealth.com/wp-content/uploads/2023/acolyte-logo.svg" },
  { name: "Lyris Health", logo: "https://lyrishealth.com/assets/images/lyris-logo.png" },
  { name: "Quantumobile", logo: "https://quantumobile.com/wp-content/uploads/2023/quantum-logo.svg" },
  { name: "Empire Strategists", logo: "https://empirestrategists.com/assets/images/empire-logo.png" }
];

const ScrollingClientLogos = () => {
  // Create seamless loop by doubling the array
  const duplicatedLogos = [...logos, ...logos];
  
  // Calculate total width for smooth animation
  const logoWidth = 200; // Width per logo including margin
  const totalWidth = logos.length * logoWidth;

  const marqueeVariants = {
    animate: {
      x: [0, -totalWidth],
      transition: {
        x: {
          repeat: Infinity,
          repeatType: "loop",
          duration: 30, // Consistent speed
          ease: "linear",
        },
      },
    },
  };

  const LogoImage = ({ logo, name, index }) => (
    <motion.div
      key={`${name}-${index}`}
      className="flex-shrink-0 mx-8 flex items-center justify-center"
      style={{ width: `${logoWidth - 64}px`, height: '80px' }}
      initial={{ opacity: 0.7 }}
      whileHover={{ 
        opacity: 1,
        scale: 1.05,
        transition: { duration: 0.2 }
      }}
    >
      <img
        src={logo}
        alt={`${name} logo`}
        className="max-w-full max-h-full object-contain filter grayscale hover:grayscale-0 brightness-0 invert transition-all duration-300"
        onError={(e) => {
          // Fallback to text version if image fails to load
          e.target.style.display = 'none';
          const fallback = e.target.parentNode.querySelector('.fallback');
          if (fallback) fallback.style.display = 'flex';
        }}
      />
      <div 
        className="fallback hidden items-center justify-center bg-gray-800 rounded-lg px-4 py-2 text-sm font-medium text-gray-400 text-center"
        style={{ width: '140px', height: '60px' }}
      >
        {name}
      </div>
    </motion.div>
  );

  return (
    <div className="w-full bg-gray-900 py-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Scrolling Logos */}
        <div className="relative">
          {/* Gradient overlays for smooth edges */}
          <div className="absolute left-0 top-0 w-20 h-full bg-gradient-to-r from-gray-900 to-transparent z-10" />
          <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-gray-900 to-transparent z-10" />
          
          {/* Logo container */}
          <div className="flex overflow-hidden">
            <motion.div
              className="flex items-center"
              style={{ width: `${totalWidth * 2}px` }}
              variants={marqueeVariants}
              animate="animate"
            >
              {duplicatedLogos.map((logo, index) => (
                <LogoImage 
                  key={`${logo.name}-${index}`}
                  logo={logo.logo} 
                  name={logo.name} 
                  index={index}
                />
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScrollingClientLogos;