
import React from 'react';
import { Tag, Check, Target } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ICON_MAP } from './IndustryTemplates'; // Assuming IndustryTemplates contains the ICON_MAP

export default function ContactAssignmentDropdown({ 
  userSegments, 
  contactSegments,
  onAssign,
  onRemove,
  trigger
}) {
  const isAssigned = (segmentId) => {
    return contactSegments?.some(cs => cs.segment_id === segmentId);
  };

  const defaultTrigger = (
    <Button variant="ghost" size="sm" className="gap-2">
      <Tag className="w-4 h-4" />
      Assign Priority
    </Button>
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {trigger || defaultTrigger}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="px-2 py-1.5 text-xs font-semibold text-gray-500">
          Priority Buckets
        </div>
        <DropdownMenuSeparator />
        
        {userSegments && userSegments.length > 0 ? (
          userSegments.map((segment) => {
            const Icon = ICON_MAP[segment.icon_name] || Target;
            const assigned = isAssigned(segment.id);
            
            return (
              <DropdownMenuItem
                key={segment.id}
                onClick={() => assigned ? onRemove(segment.id) : onAssign(segment.id)}
                className="gap-2"
              >
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${segment.color || '#3B82F6'}15` }}
                >
                  <Icon 
                    className="w-4 h-4"
                    style={{ color: segment.color || '#3B82F6' }}
                  />
                </div>
                <span className="flex-1">{segment.segment_name}</span>
                {assigned && <Check className="w-4 h-4 text-green-600" />}
              </DropdownMenuItem>
            );
          })
        ) : (
          <div className="px-2 py-6 text-center text-sm text-gray-500">
            No priority buckets configured
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
