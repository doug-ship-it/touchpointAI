import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, GripVertical, Trash2, Plus, Target } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { DragDropContext, Draggable } from '@hello-pangea/dnd';
import { StrictModeDroppable } from '@/components/ui/StrictModeDroppable';
import { toast } from 'sonner';
import { PrioritySegment } from '@/api/entities';
import { ContactSegment } from '@/api/entities';

export default function SegmentManagerModal({ isOpen, onClose, onUpdate }) {
  const [segments, setSegments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [segmentCounts, setSegmentCounts] = useState({});

  useEffect(() => {
    if (isOpen) {
      loadSegments();
    }
  }, [isOpen]);

  const loadSegments = async () => {
    setLoading(true);
    try {
      const data = await PrioritySegment.list('segment_order');
      setSegments(data || []);

      // Load contact counts for each segment
      const counts = {};
      for (const segment of data || []) {
        const contacts = await ContactSegment.filter({ segment_id: segment.id });
        counts[segment.id] = contacts.length;
      }
      setSegmentCounts(counts);
    } catch (error) {
      console.error('Error loading segments:', error);
      toast.error('Failed to load segments');
    } finally {
      setLoading(false);
    }
  };

  const handleDragEnd = async (result) => {
    if (!result.destination) return;

    const items = Array.from(segments);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Update order in state
    const updatedItems = items.map((item, index) => ({
      ...item,
      segment_order: index + 1
    }));
    setSegments(updatedItems);

    // Save to database
    try {
      for (const item of updatedItems) {
        await PrioritySegment.update(item.id, {
          segment_order: item.segment_order
        });
      }
      toast.success('Segment order updated');
      onUpdate?.();
    } catch (error) {
      console.error('Error updating order:', error);
      toast.error('Failed to update order');
      // Reload on error
      loadSegments();
    }
  };

  const handleUpdateName = async (segmentId, newName) => {
    if (!newName.trim()) {
      toast.error('Segment name cannot be empty');
      return;
    }

    try {
      await PrioritySegment.update(segmentId, {
        segment_name: newName.trim()
      });
      
      setSegments(segments.map(s => 
        s.id === segmentId ? { ...s, segment_name: newName.trim() } : s
      ));
      
      toast.success('Segment renamed');
      onUpdate?.();
    } catch (error) {
      console.error('Error updating segment:', error);
      toast.error('Failed to update segment');
    }
  };

  const handleDelete = async (segmentId) => {
    try {
      // Delete all contact assignments
      const assignments = await ContactSegment.filter({ segment_id: segmentId });
      for (const assignment of assignments) {
        await ContactSegment.delete(assignment.id);
      }

      // Delete the segment
      await PrioritySegment.delete(segmentId);
      
      setSegments(segments.filter(s => s.id !== segmentId));
      setDeleteConfirm(null);
      
      toast.success('Segment deleted');
      onUpdate?.();
    } catch (error) {
      console.error('Error deleting segment:', error);
      toast.error('Failed to delete segment');
    }
  };

  const handleAddNew = async () => {
    if (segments.length >= 4) {
      toast.error('Maximum 4 segments allowed');
      return;
    }

    try {
      const newSegment = await PrioritySegment.create({
        segment_name: `Segment ${segments.length + 1}`,
        segment_order: segments.length + 1,
        icon_name: 'Target',
        is_active: true
      });

      setSegments([...segments, newSegment]);
      toast.success('New segment added');
      onUpdate?.();
    } catch (error) {
      console.error('Error adding segment:', error);
      toast.error('Failed to add segment');
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <div className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Manage Priority Segments</h2>
                <p className="text-sm text-gray-600 mt-1">Drag to reorder, click to edit, or delete segments</p>
              </div>
            </div>

            {/* Segments List */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full" />
              </div>
            ) : (
              <div className="space-y-4">
                <DragDropContext onDragEnd={handleDragEnd}>
                  <StrictModeDroppable droppableId="segments">
                    {(provided) => (
                      <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                        {segments.map((segment, index) => (
                          <Draggable key={segment.id} draggableId={segment.id} index={index}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                className={`flex items-center gap-3 p-4 bg-white border-2 rounded-xl transition-all ${
                                  snapshot.isDragging ? 'border-blue-500 shadow-lg' : 'border-gray-200'
                                }`}
                              >
                                <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
                                  <GripVertical className="w-5 h-5 text-gray-400" />
                                </div>

                                <Target className="w-5 h-5 text-blue-600 flex-shrink-0" />

                                <Input
                                  value={segment.segment_name}
                                  onChange={(e) => {
                                    const newSegments = [...segments];
                                    newSegments[index] = { ...segment, segment_name: e.target.value };
                                    setSegments(newSegments);
                                  }}
                                  onBlur={(e) => handleUpdateName(segment.id, e.target.value)}
                                  maxLength={50}
                                  className="flex-1 border-0 focus-visible:ring-1 focus-visible:ring-blue-500"
                                />

                                <Badge variant="secondary" className="flex-shrink-0">
                                  {segmentCounts[segment.id] || 0} contacts
                                </Badge>

                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => setDeleteConfirm(segment)}
                                  className="flex-shrink-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </StrictModeDroppable>
                </DragDropContext>

                {segments.length < 4 && (
                  <Button
                    variant="outline"
                    onClick={handleAddNew}
                    className="w-full border-2 border-dashed hover:border-blue-500 hover:bg-blue-50"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Segment
                  </Button>
                )}
              </div>
            )}

            <div className="flex justify-end pt-6">
              <Button onClick={onClose}>Done</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleteConfirm?.segment_name}"?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the segment but keep all contacts. You can reassign contacts to other segments later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleDelete(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Segment
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}