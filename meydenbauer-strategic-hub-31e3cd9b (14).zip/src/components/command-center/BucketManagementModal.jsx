
import React, { useState } from 'react';
import { X, Plus, Save, Trash2, GripVertical, Target } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { AVAILABLE_ICONS, AVAILABLE_COLORS, ICON_MAP } from './IndustryTemplates';
import { cn } from '@/lib/utils';

export default function BucketManagementModal({ 
  isOpen, 
  onClose, 
  bucket, 
  onSave, 
  onDelete 
}) {
  const [formData, setFormData] = useState({
    segment_name: bucket?.segment_name || '',
    icon_name: bucket?.icon_name || 'Target',
    color: bucket?.color || '#3B82F6',
    segment_order: bucket?.segment_order || 1
  });

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleSave = () => {
    if (!formData.segment_name.trim()) {
      return;
    }
    
    onSave({
      ...bucket,
      ...formData,
      segment_name: formData.segment_name.trim()
    });
  };

  const handleDelete = () => {
    if (bucket?.id) {
      onDelete(bucket.id);
    }
  };

  const IconComponent = ICON_MAP[formData.icon_name] || Target;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {bucket?.id ? 'Edit Priority Bucket' : 'Create Priority Bucket'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Bucket Name */}
          <div>
            <Label className="text-sm font-medium mb-2 block">
              Bucket Name <span className="text-red-500">*</span>
            </Label>
            <Input
              placeholder="e.g., Hot Leads, VIP Clients"
              maxLength={50}
              value={formData.segment_name}
              onChange={(e) => setFormData({ ...formData, segment_name: e.target.value })}
              className="w-full"
            />
            <p className="text-xs text-gray-500 mt-1">
              {formData.segment_name.length}/50 characters
            </p>
          </div>

          {/* Icon Picker */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Icon</Label>
            <div className="grid grid-cols-8 gap-2">
              {AVAILABLE_ICONS.map((iconName) => {
                const Icon = ICON_MAP[iconName];
                if (!Icon) return null;
                
                return (
                  <button
                    key={iconName}
                    type="button"
                    onClick={() => setFormData({ ...formData, icon_name: iconName })}
                    className={cn(
                      "p-2 rounded-lg border-2 transition-all hover:scale-110",
                      formData.icon_name === iconName
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                    )}
                  >
                    <Icon className="w-5 h-5 text-gray-700" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Color Picker */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Color</Label>
            <div className="grid grid-cols-7 gap-2">
              {AVAILABLE_COLORS.map((color) => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, color: color.value })}
                  className={cn(
                    "w-10 h-10 rounded-lg border-2 transition-all hover:scale-110",
                    formData.color === color.value
                      ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
                      : "border-gray-200"
                  )}
                  style={{ backgroundColor: color.value }}
                  title={color.name}
                />
              ))}
            </div>
          </div>

          {/* Preview */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Preview</Label>
            <div className="border-2 border-gray-200 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ 
                    backgroundColor: `${formData.color}15`,
                  }}
                >
                  <IconComponent 
                    className="w-6 h-6"
                    style={{ color: formData.color }}
                  />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">
                    {formData.segment_name || 'Bucket Name'}
                  </p>
                  <p className="text-sm text-gray-500">0 contacts</p>
                </div>
              </div>
            </div>
          </div>

          {/* Delete Section */}
          {bucket?.id && (
            <div>
              {!showDeleteConfirm ? (
                <Button
                  variant="outline"
                  className="w-full border-red-200 text-red-600 hover:bg-red-50"
                  onClick={() => setShowDeleteConfirm(true)}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Bucket
                </Button>
              ) : (
                <Alert className="border-red-200 bg-red-50">
                  <AlertTitle className="text-red-900">Delete this bucket?</AlertTitle>
                  <AlertDescription className="text-red-700 mb-3">
                    Contacts will remain in your network but lose this priority assignment.
                  </AlertDescription>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowDeleteConfirm(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={handleDelete}
                    >
                      Delete
                    </Button>
                  </div>
                </Alert>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!formData.segment_name.trim()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Bucket
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
