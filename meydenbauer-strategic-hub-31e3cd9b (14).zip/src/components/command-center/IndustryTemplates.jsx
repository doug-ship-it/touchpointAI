
import {
  Target, Star, Users, Briefcase, TrendingUp, DollarSign,
  Building2, Phone, Mail, Handshake, Crown, Flame,
  Zap, Heart, Award, Flag, Bookmark, Shield,
  Search, Clock, Share2, Network, UserCheck, Lightbulb
} from 'lucide-react';

/**
 * Industry-specific priority bucket templates
 * Used during onboarding to provide relevant starter buckets
 */

export const INDUSTRY_TEMPLATES = {
  "Sales Leader": {
    label: "Sales & Business Development",
    icon: "TrendingUp",
    buckets: [
      { name: "Hot Pipeline", icon: "Flame", color: "#EF4444", order: 1 },
      { name: "Active Clients", icon: "Briefcase", color: "#10B981", order: 2 },
      { name: "Warm Prospects", icon: "Target", color: "#F59E0B", order: 3 },
      { name: "Champion Network", icon: "Star", color: "#8B5CF6", order: 4 }
    ]
  },
  
  "Founder / CEO": {
    label: "Executive & Leadership",
    icon: "Crown",
    buckets: [
      { name: "Investor Network", icon: "DollarSign", color: "#10B981", order: 1 },
      { name: "Strategic Partners", icon: "Handshake", color: "#3B82F6", order: 2 },
      { name: "Key Customers", icon: "Star", color: "#F59E0B", order: 3 },
      { name: "Advisor Circle", icon: "Users", color: "#8B5CF6", order: 4 }
    ]
  },
  
  "Business Development": {
    label: "Business Development",
    icon: "Target",
    buckets: [
      { name: "Warm Prospects", icon: "Target", color: "#F59E0B", order: 1 },
      { name: "Decision Makers", icon: "UserCheck", color: "#EF4444", order: 2 },
      { name: "Strategic Partners", icon: "Handshake", color: "#3B82F6", order: 3 },
      { name: "Referral Sources", icon: "Share2", color: "#10B981", order: 4 }
    ]
  },
  
  "Consultant": {
    label: "Consulting & Advisory",
    icon: "Lightbulb",
    buckets: [
      { name: "Active Clients", icon: "Briefcase", color: "#10B981", order: 1 },
      { name: "Prospect Pipeline", icon: "TrendingUp", color: "#F59E0B", order: 2 },
      { name: "Referral Partners", icon: "Users", color: "#3B82F6", order: 3 },
      { name: "Industry Contacts", icon: "Network", color: "#8B5CF6", order: 4 }
    ]
  },
  
  "Investor": {
    label: "Investment & Private Equity",
    icon: "DollarSign",
    buckets: [
      { name: "Portfolio Companies", icon: "Building2", color: "#10B981", order: 1 },
      { name: "LP Network", icon: "Users", color: "#3B82F6", order: 2 },
      { name: "Deal Pipeline", icon: "TrendingUp", color: "#F59E0B", order: 3 },
      { name: "Industry Experts", icon: "Star", color: "#8B5CF6", order: 4 }
    ]
  },
  
  "Recruiter": {
    label: "Recruiting & Talent",
    icon: "Users",
    buckets: [
      { name: "Active Searches", icon: "Search", color: "#EF4444", order: 1 },
      { name: "Client Companies", icon: "Building2", color: "#3B82F6", order: 2 },
      { name: "Candidate Pipeline", icon: "Users", color: "#10B981", order: 3 },
      { name: "Referral Partners", icon: "Share2", color: "#F59E0B", order: 4 }
    ]
  },
  
  "Other": {
    label: "Universal Template",
    icon: "LayoutGrid", // This icon is not in the imported list, but it's part of the existing data structure.
    buckets: [
      { name: "High Priority", icon: "Star", color: "#EF4444", order: 1 },
      { name: "Active Relationships", icon: "Users", color: "#10B981", order: 2 },
      { name: "Warm Connections", icon: "Target", color: "#F59E0B", order: 3 },
      { name: "Long-term Nurture", icon: "Clock", color: "#8B5CF6", order: 4 }
    ]
  }
};

export const AVAILABLE_ICONS = [
  'Target', 'Star', 'Users', 'Briefcase', 'TrendingUp', 'DollarSign',
  'Building2', 'Phone', 'Mail', 'Handshake', 'Crown', 'Flame',
  'Zap', 'Heart', 'Award', 'Flag', 'Bookmark', 'Shield',
  'Search', 'Clock', 'Share2', 'Network', 'UserCheck', 'Lightbulb'
];

export const AVAILABLE_COLORS = [
  { name: 'Red', value: '#EF4444' },
  { name: 'Orange', value: '#F59E0B' },
  { name: 'Amber', value: '#F59E0B' },
  { name: 'Yellow', value: '#EAB308' },
  { name: 'Green', value: '#10B981' },
  { name: 'Emerald', value: '#10B981' },
  { name: 'Teal', value: '#14B8A6' },
  { name: 'Cyan', value: '#06B6D4' },
  { name: 'Blue', value: '#3B82F6' },
  { name: 'Indigo', value: '#6366F1' },
  { name: 'Purple', value: '#8B5CF6' },
  { name: 'Pink', value: '#EC4899' },
  { name: 'Rose', value: '#F43F5E' },
  { name: 'Gray', value: '#6B7280' }
];

export function getTemplateForRole(role) {
  return INDUSTRY_TEMPLATES[role] || INDUSTRY_TEMPLATES["Other"];
}

// Create a reliable map for dynamic icon rendering
export const ICON_MAP = {
  Target, Star, Users, Briefcase, TrendingUp, DollarSign,
  Building2, Phone, Mail, Handshake, Crown, Flame,
  Zap, Heart, Award, Flag, Bookmark, Shield,
  Search, Clock, Share2, Network, UserCheck, Lightbulb
  // Note: 'LayoutGrid' used in INDUSTRY_TEMPLATES['Other'] is not included in the lucide-react import
  // and thus not available in ICON_MAP unless explicitly imported and added.
};
