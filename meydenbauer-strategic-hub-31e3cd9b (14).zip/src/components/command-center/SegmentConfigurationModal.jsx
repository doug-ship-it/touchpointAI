import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Target, Sparkles, ChevronRight } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { PrioritySegment } from '@/api/entities';
import { User } from '@/api/entities';
import { INDUSTRY_TEMPLATES, getTemplateForRole } from './IndustryTemplates';

export default function SegmentConfigurationModal({ isOpen, onClose, onComplete }) {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('');
  const [segments, setSegments] = useState(['', '', '', '']);
  const [isSaving, setIsSaving] = useState(false);

  const getPlaceholder = (index) => {
    if (!role) return `Segment ${index + 1}`;
    const template = getTemplateForRole(role);
    return template.buckets[index]?.name || `Segment ${index + 1}`;
  };

  const handleSegmentChange = (index, value) => {
    const newSegments = [...segments];
    newSegments[index] = value;
    setSegments(newSegments);
  };

  const loadTemplate = () => {
    if (!role) return;
    const template = getTemplateForRole(role);
    const templateNames = template.buckets.map(b => b.name);
    setSegments(templateNames);
  };

  const handleSave = async () => {
    setIsSaving(true);
    
    try {
      const user = await User.me();
      const template = getTemplateForRole(role);
      
      // Filter out empty segments
      const validSegments = segments
        .map((name, index) => ({ 
          name: name.trim(), 
          order: index + 1,
          templateBucket: template.buckets[index]
        }))
        .filter(s => s.name.length > 0);

      if (validSegments.length === 0) {
        toast.error('Please configure at least one segment');
        setIsSaving(false);
        return;
      }

      // Create priority segments with template styling
      for (const segment of validSegments) {
        await PrioritySegment.create({
          user_id: user.id,
          segment_name: segment.name,
          segment_order: segment.order,
          icon_name: segment.templateBucket?.icon || 'Target',
          color: segment.templateBucket?.color || '#3B82F6',
          is_active: true
        });
      }

      // Update user profile
      await User.updateMyUserData({
        primary_role: role,
        onboarding_segments_completed: true
      });

      toast.success('Priority segments configured successfully!');
      onComplete?.();
      onClose();
    } catch (error) {
      console.error('Error saving segments:', error);
      toast.error('Failed to save segments. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSkip = async () => {
    try {
      await User.updateMyUserData({
        onboarding_segments_completed: true
      });
      onClose();
    } catch (error) {
      console.error('Error skipping setup:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <div className="p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Customize Your Priority Segments</h2>
                <p className="text-gray-600">Organize your network into categories that match your workflow</p>
              </div>
            </div>

            {/* Progress Indicator */}
            <div className="flex items-center gap-2">
              <div className={`h-1 flex-1 rounded-full ${step >= 1 ? 'bg-blue-600' : 'bg-gray-200'}`} />
              <div className={`h-1 flex-1 rounded-full ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`} />
            </div>
          </div>

          {/* Step 1: Role Selection */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div>
                <Label className="text-base font-semibold mb-3 block">What's your primary role?</Label>
                <Select value={role} onValueChange={(value) => {
                  setRole(value);
                  // Auto-load template when role selected
                  const template = getTemplateForRole(value);
                  const templateNames = template.buckets.map(b => b.name);
                  setSegments(templateNames);
                }}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Select your role..." />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.keys(INDUSTRY_TEMPLATES).map(key => (
                      <SelectItem key={key} value={key}>
                        {INDUSTRY_TEMPLATES[key].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {role && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-900 mb-1">
                        Suggested segments for {INDUSTRY_TEMPLATES[role].label}:
                      </p>
                      <ul className="text-sm text-blue-800 space-y-1">
                        {getTemplateForRole(role).buckets.map((bucket, idx) => (
                          <li key={idx}>• {bucket.name}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-between pt-4">
                <Button variant="ghost" onClick={handleSkip}>
                  Skip for Now
                </Button>
                <Button 
                  onClick={() => setStep(2)} 
                  disabled={!role}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  Continue
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Segment Names */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Name Your Priority Segments</h3>
                <p className="text-sm text-gray-600 mb-4">These will appear as filters in your Command Center (1-4 segments)</p>

                <div className="space-y-3">
                  {[0, 1, 2, 3].map((index) => (
                    <div key={index}>
                      <Label className="text-sm text-gray-700 mb-1.5 block">
                        Segment {index + 1} {index === 0 && <span className="text-red-500">*</span>}
                      </Label>
                      <Input
                        value={segments[index]}
                        onChange={(e) => handleSegmentChange(index, e.target.value)}
                        placeholder={getPlaceholder(index)}
                        maxLength={50}
                        className="h-11"
                      />
                    </div>
                  ))}
                </div>

                <p className="text-xs text-gray-500 mt-3">
                  <span className="text-red-500">*</span> At least one segment is required. Leave others blank if not needed.
                </p>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button 
                  onClick={handleSave} 
                  disabled={isSaving || !segments[0].trim()}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  {isSaving ? 'Saving...' : 'Save & Continue'}
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}