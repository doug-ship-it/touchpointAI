
import React, { useState } from 'react';
import { Shield, Lock, Users, ArrowRight, Check, Mail, User, Building, Upload, FileText, AlertCircle, Download, Zap, Target, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';
import { User as UserEntity } from '@/api/entities';
import { NetworkConnection } from '@/api/entities';

export function FindConnectionsHero() {
  return (
    <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <Badge className="bg-blue-500/30 text-white border-white/30 backdrop-blur-sm px-4 py-1">
              <Shield className="h-3 w-3 mr-2" />
              SOC 2 Type II Certified • Enterprise-Grade Security
            </Badge>

            <div className="space-y-4">
              <h1 className="text-5xl font-bold leading-tight">
                Transform Your Network Into Your Competitive Advantage
              </h1>

              <p className="text-xl text-blue-100 leading-relaxed">
                Upload your contacts, discover hidden connections, and leverage relationship
                intelligence with AI-powered insights. <strong className="text-white">Your data stays completely private</strong>—you
                control exactly who sees it.
              </p>
            </div>

            <div className="space-y-4 bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center mt-0.5">
                  <Check className="h-4 w-4 text-green-900" />
                </div>
                <span className="text-lg">14-day free trial • No credit card required • Cancel anytime</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center mt-0.5">
                  <Check className="h-4 w-4 text-green-900" />
                </div>
                <span className="text-lg">Bank-level AES-256 encryption • GDPR compliant • SOC 2 certified</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center mt-0.5">
                  <Check className="h-4 w-4 text-green-900" />
                </div>
                <span className="text-lg">You own your data • Export anytime • Delete instantly</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-4 pt-4">
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-blue-50 shadow-xl text-lg px-8 py-6 h-auto"
                onClick={() => document.getElementById('trial-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Start Free Trial
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/10 text-lg px-8 py-6 h-auto backdrop-blur-sm"
                onClick={() => document.getElementById('upload-section')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Upload className="h-5 w-5 mr-2" />
                Upload Contacts
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white shadow-2xl">
              <CardContent className="p-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                    <Lock className="h-7 w-7" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-xl mb-2">Your Data, Your Control</h3>
                    <p className="text-blue-100 leading-relaxed">
                      Granular privacy controls let you decide exactly who can see your network.
                      <strong className="text-white"> Default: private to you only.</strong> No one else can access
                      your contacts without your explicit permission.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                    <Shield className="h-7 w-7" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-xl mb-2">Enterprise Security Standards</h3>
                    <p className="text-blue-100 leading-relaxed">
                      SOC 2 Type II certified, GDPR compliant, encrypted at rest and in transit.
                      Regular penetration testing. Trusted by PE firms and Fortune 500 companies.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                    <Users className="h-7 w-7" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-xl mb-2">Join 9,000+ Executives</h3>
                    <p className="text-blue-100 leading-relaxed">
                      Industry leaders from PE-backed companies and high-growth firms leverage
                      our relationship intelligence platform for competitive advantage.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Target className="h-6 w-6 text-green-300" />
                  <div>
                    <p className="font-semibold text-lg">500% Increase</p>
                    <p className="text-sm text-blue-100">in qualified prospects</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-6 w-6 text-green-300" />
                  <div>
                    <p className="font-semibold text-lg">75% Conversion</p>
                    <p className="text-sm text-blue-100">meeting acceptance rate</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TrialSignupForm() {
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    company: '',
    agreeToTerms: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Call backend function for server-side validation
      const response = await fetch('/api/trialSignup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: formData.email,
          firstName: formData.firstName,
          lastName: formData.lastName,
          company: formData.company
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Also update user data if they're logged in
        try {
          await UserEntity.updateMyUserData({
            company_name: formData.company,
            subscription_tier: 'professional',
            lead_score: 80,
            engagement_level: 'hot'
          });
        } catch (error) {
          console.warn('User not logged in or update failed for client-side user entity. Trial will be linked after login or via backend.', error);
        }

        setSubmitSuccess(true);
        toast.success('Welcome to Touchpoint OS! Check your email for setup instructions.');

        setTimeout(() => {
          window.location.href = '/CommandCenter?trial=started&firstTime=true';
        }, 2000);
      } else {
        throw new Error(data.error || 'Signup failed');
      }
    } catch (error) {
      console.error('Trial signup error:', error);
      toast.error(error.message || 'There was an error starting your trial. Please contact support.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitSuccess) {
    return (
      <div id="trial-form" className="max-w-2xl mx-auto py-16 px-4">
        <Card className="border-2 border-green-200 bg-green-50 shadow-xl">
          <CardContent className="p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto">
              <Check className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900">Welcome to Touchpoint OS!</h3>
            <p className="text-lg text-gray-700">
              Your 14-day free trial has started. Check your email for setup instructions.
            </p>
            <p className="text-sm text-gray-600">Redirecting to your dashboard...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div id="trial-form" className="max-w-2xl mx-auto py-16 px-4">
      <Card className="border-2 border-blue-200 shadow-2xl">
        <CardHeader className="text-center space-y-3 pb-6">
          <CardTitle className="text-4xl font-bold">Start Your 14-Day Free Trial</CardTitle>
          <CardDescription className="text-lg text-gray-600">
            No credit card required • Full access to all features • Cancel anytime
          </CardDescription>
        </CardHeader>

        <CardContent className="px-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="firstName" className="text-sm font-medium">First Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="firstName"
                    placeholder="John"
                    className="pl-10 h-11"
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName" className="text-sm font-medium">Last Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    className="pl-10 h-11"
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">Work Email *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="john@company.com"
                  className="pl-10 h-11"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
              <p className="text-xs text-gray-500">We'll send your login credentials here</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="company" className="text-sm font-medium">Company *</Label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="company"
                  placeholder="Acme Inc."
                  className="pl-10 h-11"
                  value={formData.company}
                  onChange={(e) => setFormData({...formData, company: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="terms"
                  checked={formData.agreeToTerms}
                  onCheckedChange={(checked) => setFormData({...formData, agreeToTerms: checked})}
                  required
                  className="mt-1"
                />
                <label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed cursor-pointer">
                  I agree to the{' '}
                  <a href="/terms" target="_blank" className="text-blue-600 hover:underline font-medium">Terms of Service</a>
                  {' '}and{' '}
                  <a href="/privacy" target="_blank" className="text-blue-600 hover:underline font-medium">Privacy Policy</a>.
                  I understand my data will be encrypted and private by default.
                </label>
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6 h-auto shadow-lg"
              disabled={isSubmitting || !formData.agreeToTerms}
            >
              {isSubmitting ? (
                <>
                  <Zap className="h-5 w-5 mr-2 animate-pulse" />
                  Starting Your Trial...
                </>
              ) : (
                <>
                  Start My Free Trial
                  <ArrowRight className="h-5 w-5 ml-2" />
                </>
              )}
            </Button>
          </form>
        </CardContent>

        <CardFooter className="flex-col space-y-3 pt-6 pb-8">
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span>Instant access</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span>No credit card</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span>Cancel anytime</span>
            </div>
          </div>
          <p className="text-center text-sm text-gray-600">
            Your trial starts immediately. Setup instructions sent to your email within 2 minutes.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}

export function SecureContactUpload() {
  const [file, setFile] = useState(null);
  const [privacySetting, setPrivacySetting] = useState('private');
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.name.match(/\.(csv|xlsx|xls)$/i)) {
        setFile(droppedFile);
      } else {
        toast.error('Please upload a CSV or Excel file');
      }
    }
  };

  const handleFileUpload = async () => {
    if (!file) {
      toast.error('Please select a file to upload');
      return;
    }

    setUploading(true);
    toast.loading('Processing your contacts...', { id: 'upload' });

    try {
      // Use backend function for production-ready upload
      const formData = new FormData();
      formData.append('file', file);
      formData.append('privacySetting', privacySetting);

      const response = await fetch('/api/uploadContacts', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (response.ok && data.success) {
        toast.success(`Successfully imported ${data.contactsAdded} contacts`, { id: 'upload' });

        if (data.contactsSkipped > 0) {
          toast.info(`${data.contactsSkipped} contacts skipped due to validation errors`);
        }

        if (data.duplicatesSkipped > 0) {
          toast.info(`${data.duplicatesSkipped} duplicate contacts skipped`);
        }

        setUploadSuccess(true);

        setTimeout(() => {
          window.location.href = `/CommandCenter?uploaded=${data.contactsAdded}&firstTime=true`;
        }, 2000);
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Upload failed. Please try again.', { id: 'upload' });
    } finally {
      setUploading(false);
    }
  };

  if (uploadSuccess) {
    return (
      <div id="upload-section" className="max-w-4xl mx-auto py-16 px-4">
        <Card className="border-2 border-green-200 bg-green-50 shadow-xl">
          <CardContent className="p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto">
              <Check className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900">Upload Complete!</h3>
            <p className="text-lg text-gray-700">
              Your contacts are now being processed. This usually takes 30-60 seconds.
            </p>
            <p className="text-sm text-gray-600">Redirecting to your Command Center...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div id="upload-section" className="max-w-4xl mx-auto py-16 px-4">
      <div className="text-center mb-12 space-y-4">
        <h2 className="text-4xl font-bold text-gray-900">
          Upload Your Contacts Securely
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Import from CSV, Excel, LinkedIn, or your CRM. Your data is encrypted end-to-end and private by default.
        </p>
      </div>

      <Card className="border-2 border-gray-200 shadow-xl">
        <CardContent className="p-8 space-y-8">
          <div
            className={`border-3 border-dashed rounded-xl p-16 text-center transition-all ${
              file
                ? 'border-blue-500 bg-blue-50'
                : dragActive
                ? 'border-blue-400 bg-blue-50'
                : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />

            <label htmlFor="file-upload" className="cursor-pointer block">
              {file ? (
                <>
                  <FileText className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                  <p className="text-xl font-semibold text-gray-900 mb-2">
                    {file.name}
                  </p>
                  <p className="text-sm text-gray-600 mb-4">
                    {(file.size / 1024 / 1024).toFixed(2)} MB • Ready to upload
                  </p>
                  <Button variant="outline" size="lg" type="button">
                    Choose Different File
                  </Button>
                </>
              ) : (
                <>
                  <Upload className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-xl font-semibold text-gray-700 mb-2">
                    Drop your contact file here or click to browse
                  </p>
                  <p className="text-sm text-gray-500 mb-4">
                    Supports CSV, Excel (.xlsx, .xls) • Maximum 50,000 contacts per file
                  </p>
                  <Button size="lg" variant="outline" type="button">
                    <Upload className="h-5 w-5 mr-2" />
                    Choose File
                  </Button>
                </>
              )}
            </label>
          </div>

          <Alert className="border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>Supported formats:</strong> CSV must include columns for name, email, company.
              Excel files should have headers in the first row. We'll automatically map your columns
              during import.
            </AlertDescription>
          </Alert>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="h-6 w-6 text-blue-600" />
              <h3 className="font-semibold text-lg text-gray-900">Privacy & Sharing Settings</h3>
            </div>

            <RadioGroup value={privacySetting} onValueChange={setPrivacySetting}>
              <div className="space-y-3">
                <div className="flex items-start space-x-4 p-5 bg-white rounded-xl border-2 border-blue-500 shadow-sm">
                  <RadioGroupItem value="private" id="private" className="mt-1" />
                  <div className="flex-1">
                    <Label htmlFor="private" className="font-semibold text-base cursor-pointer flex items-center gap-2 mb-2">
                      <Lock className="h-5 w-5 text-blue-600" />
                      Private (Recommended)
                      <Badge className="bg-blue-100 text-blue-700 text-xs">Default</Badge>
                    </Label>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      <strong>Only you</strong> can see your contacts. Perfect for personal networks and confidential
                      relationships. No one else in your organization or on the platform can access this data.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4 p-5 bg-white rounded-xl border-2 border-gray-200 hover:border-gray-300 transition-colors">
                  <RadioGroupItem value="team" id="team" className="mt-1" />
                  <div className="flex-1">
                    <Label htmlFor="team" className="font-semibold text-base cursor-pointer flex items-center gap-2 mb-2">
                      <Users className="h-5 w-5 text-gray-600" />
                      Team Members Only
                    </Label>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      Share with specific team members you invite. <strong>You maintain full control</strong> over
                      who can view, edit, or export your contacts. Revoke access anytime instantly.
                    </p>
                  </div>
                </div>
              </div>
            </RadioGroup>
          </div>

          <Alert className="border-green-200 bg-green-50">
            <Check className="h-5 w-5 text-green-600" />
            <AlertDescription className="text-green-900 leading-relaxed">
              <strong className="block mb-1">Your data security guarantee:</strong>
              • AES-256 military-grade encryption at rest and in transit<br />
              • SOC 2 Type II certified infrastructure with annual audits<br />
              • GDPR compliant data handling and right-to-deletion<br />
              • We NEVER sell, share, or use your contacts for marketing<br />
              • Export or delete all your data with one click anytime
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <Button
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6 h-auto shadow-lg"
              onClick={handleFileUpload}
              disabled={!file || uploading}
            >
              {uploading ? (
                <>
                  <Zap className="h-5 w-5 mr-2 animate-pulse" />
                  Uploading & Encrypting...
                </>
              ) : (
                <>
                  <Shield className="h-5 w-5 mr-2" />
                  Upload Contacts Securely
                  <ArrowRight className="h-5 w-5 ml-2" />
                </>
              )}
            </Button>

            <p className="text-center text-sm text-gray-600">
              By uploading, you confirm you have permission to use this contact data and agree to our{' '}
              <a href="/terms" target="_blank" className="text-blue-600 hover:underline">Terms of Service</a>
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="mt-12 grid md:grid-cols-3 gap-6 text-center">
        <div className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="h-6 w-6 text-blue-600" />
          </div>
          <h4 className="font-semibold text-gray-900 mb-2">Private by Default</h4>
          <p className="text-sm text-gray-600">All uploads are encrypted and visible only to you unless you explicitly share</p>
        </div>

        <div className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="h-6 w-6 text-green-600" />
          </div>
          <h4 className="font-semibold text-gray-900 mb-2">Instant Processing</h4>
          <p className="text-sm text-gray-600">Contacts enriched and available in your Command Center within 60 seconds</p>
        </div>

        <div className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Download className="h-6 w-6 text-purple-600" />
          </div>
          <h4 className="font-semibold text-gray-900 mb-2">Export Anytime</h4>
          <p className="text-sm text-gray-600">Download your entire database as CSV or Excel with one click, no restrictions</p>
        </div>
      </div>
    </div>
  );
}

export function FeatureComparison() {
  return (
    <div className="max-w-6xl mx-auto py-16 px-4">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Demo Mode vs. Your Private Network
        </h2>
        <p className="text-lg text-gray-600">
          Understand what you're seeing now versus what you'll have with your own data
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <div className="flex items-center justify-between mb-2">
              <CardTitle className="text-xl">Demo Mode (Current View)</CardTitle>
              <Badge className="bg-blue-600 text-white">What You See Now</Badge>
            </div>
            <CardDescription>Exploring Doug Sandstedt's network data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">9,000+ executive contacts</p>
                <p className="text-sm text-gray-600">Real relationship data for testing</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Full feature access</p>
                <p className="text-sm text-gray-600">Experience all capabilities</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Read-only exploration</p>
                <p className="text-sm text-gray-600">See how the platform works</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Demo data only</p>
                <p className="text-sm text-gray-600">Not your actual network</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-200 bg-green-50">
          <CardHeader>
            <div className="flex items-center justify-between mb-2">
              <CardTitle className="text-xl">Your Private Network</CardTitle>
              <Badge className="bg-green-600 text-white">After Upload</Badge>
            </div>
            <CardDescription>Your actual contacts, fully private</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Your real contacts</p>
                <p className="text-sm text-gray-600">Imported from your files/CRM</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">AI-powered enrichment</p>
                <p className="text-sm text-gray-600">Enhanced with public data</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Full edit & management</p>
                <p className="text-sm text-gray-600">Add, update, delete freely</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Lock className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">100% private to you</p>
                <p className="text-sm text-gray-600">Encrypted & access-controlled</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50 inline-block">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to see YOUR network intelligence?
            </h3>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button
                size="lg"
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => document.getElementById('upload-section')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Upload className="h-5 w-5 mr-2" />
                Upload My Contacts Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById('trial-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Start Free Trial
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
