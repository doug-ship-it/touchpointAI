import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Upload, Search, Users, Plus } from "lucide-react";
import { motion } from "framer-motion";

export default function QuickActions() {
  const actions = [
    {
      title: "Upload Contacts",
      description: "Import your LinkedIn CSV/XLSX",
      icon: Upload,
      url: createPageUrl("NetworkIntelligenceDeep"),
      color: "blue"
    },
    {
      title: "Search Network", 
      description: "Find and rank your contacts",
      icon: Search,
      url: createPageUrl("NetworkIntelligenceDeep"),
      color: "green"
    },
    {
      title: "Intake Assessment",
      description: "Start strategic assessment",
      icon: Plus,
      url: createPageUrl("Intake"),
      color: "purple"
    },
    {
      title: "Vendor Network",
      description: "Browse verified partners", 
      icon: Users,
      url: createPageUrl("VendorMarketplace"),
      color: "orange"
    }
  ];

  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    green: "from-green-500 to-green-600",
    purple: "from-purple-500 to-purple-600", 
    orange: "from-orange-500 to-orange-600"
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {actions.map((action, index) => (
        <motion.div
          key={action.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="group hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm border-0 overflow-hidden">
            <CardContent className="p-6">
              <Link to={action.url} className="block">
                
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${colorClasses[action.color]} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <action.icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="font-semibold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {action.title}
                </h3>
                
                <p className="text-sm text-slate-600 leading-relaxed">
                  {action.description}
                </p>
                
              </Link>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}