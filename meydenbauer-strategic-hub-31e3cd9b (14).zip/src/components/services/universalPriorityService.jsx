import { adaptiveUserContextService } from './adaptiveUserContextService';
import { InvokeLLM } from '@/api/integrations';

/**
 * UNIVERSAL PRIORITY SERVICE - OPTIMIZED FOR RATE LIMITS
 * 100-point scoring system with minimal LLM usage
 * Uses deterministic scoring first, then selective LLM enhancement
 */
class UniversalPriorityService {
  constructor() {
    this.userContext = null;
    this.scoreCache = new Map();
    this.analysisCache = new Map();
    this.llmCallCount = 0;
    this.maxLLMCalls = 50; // Limit LLM calls per session
  }

  /**
   * Initialize with user's ICP context
   */
  async initialize(userEmail) {
    console.log('[UniversalPriority] Initializing for user:', userEmail);
    this.userContext = await adaptiveUserContextService.getUserContext(userEmail);
    console.log('[UniversalPriority] ✅ Loaded context:', this.userContext.business_type);
    return this.userContext;
  }

  /**
   * MAIN SCORING FUNCTION - OPTIMIZED
   * Calculate 100-point priority score with minimal LLM usage
   */
  async calculatePriorityScore(contact, userEmail, useLLM = false) {
    // Ensure context is loaded
    if (!this.userContext || this.userContext.user_email !== userEmail) {
      await this.initialize(userEmail);
    }

    // Check cache
    const cacheKey = `${contact.id}_${userEmail}`;
    if (this.scoreCache.has(cacheKey)) {
      return this.scoreCache.get(cacheKey);
    }

    try {
      // DETERMINISTIC SCORING (60 points total)
      const seniority = this._scoreSeniority(contact); // 15 points
      const momentum = this._analyzeRelationshipMomentum(contact); // 15 points
      const dataQuality = this._assessDataQuality(contact); // 15 points
      const icpFit = this._analyzeICPFitDeterministic(contact); // 15 points (deterministic version)

      // SELECTIVE LLM SCORING (40 points total)
      let intentScore = 5; // Default safe score
      let intentAnalysis = { intent_score: 5, primary_signal: 'none', reasoning: 'No clear signals detected', urgency: 'low' };

      // Only use LLM for high-potential contacts (seniority + ICP > 20)
      if (useLLM && (seniority.score + icpFit) > 20 && this.llmCallCount < this.maxLLMCalls) {
        try {
          intentAnalysis = await this._detectBuyingIntent(contact);
          intentScore = intentAnalysis.intent_score;
          this.llmCallCount++;
        } catch (error) {
          console.warn('[UniversalPriority] LLM call failed, using default:', error.message);
        }
      }

      // Total score
      const priorityScore = 
        seniority.score +
        intentScore +
        icpFit +
        momentum.score +
        dataQuality.score;

      const result = {
        contact_id: contact.id,
        contact_name: contact.connection_name,
        priority_score: Math.round(priorityScore),
        tier: this._getTier(priorityScore),
        breakdown: {
          seniority: seniority.score,
          intent: intentScore,
          icp_fit: icpFit,
          momentum: momentum.score,
          data_quality: dataQuality.score
        },
        analysis: {
          seniority_level: seniority.level,
          intent_signal: intentAnalysis.primary_signal,
          intent_reasoning: intentAnalysis.reasoning,
          relationship_status: momentum.status,
          urgency: intentAnalysis.urgency
        },
        contact
      };

      // Cache result
      this.scoreCache.set(cacheKey, result);
      
      return result;
    } catch (error) {
      console.error('[UniversalPriority] ❌ Scoring failed for contact:', contact.connection_name, error);
      
      // Return safe default
      return {
        contact_id: contact.id,
        contact_name: contact.connection_name,
        priority_score: 50,
        tier: 'warm',
        breakdown: { seniority: 5, intent: 5, icp_fit: 10, momentum: 10, data_quality: 10 },
        analysis: { error: 'Analysis unavailable' },
        contact
      };
    }
  }

  /**
   * COMPONENT 1: Seniority Scoring (15 points) - DETERMINISTIC
   */
  _scoreSeniority(contact) {
    const title = (contact.enriched_title || contact.connection_title || '').toLowerCase();
    const seniority = (contact.enriched_seniority || '').toLowerCase();

    // C-Suite / Founders: 15 points
    if (seniority.includes('cxo') || title.match(/\b(ceo|cfo|cto|coo|cmo|ciso|chief|founder|co-founder|president)\b/)) {
      return { score: 15, level: 'C-Suite' };
    }

    // VP level: 12 points
    if (seniority.includes('vp') || title.match(/\b(vp|vice president|v\.p\.)\b/)) {
      return { score: 12, level: 'VP' };
    }

    // Director level: 8 points
    if (title.match(/\b(director|head of)\b/) || seniority.includes('director')) {
      return { score: 8, level: 'Director' };
    }

    // Manager: 5 points
    if (title.match(/\b(manager|lead)\b/) || seniority.includes('manager')) {
      return { score: 5, level: 'Manager' };
    }

    // Senior IC: 3 points
    if (title.match(/\b(senior|sr|principal|staff)\b/) || seniority.includes('senior')) {
      return { score: 3, level: 'Senior' };
    }

    // Entry/Mid: 2 points
    return { score: 2, level: 'Individual Contributor' };
  }

  /**
   * COMPONENT 2: Buying Intent Detection (25 points) - LLM POWERED (SELECTIVE)
   */
  async _detectBuyingIntent(contact) {
    // Check analysis cache
    const cacheKey = `intent_${contact.id}`;
    if (this.analysisCache.has(cacheKey)) {
      return this.analysisCache.get(cacheKey);
    }

    try {
      const prompt = `Analyze buyer intent signals for this contact.

CONTACT INFORMATION:
- Name: ${contact.connection_name}
- Title: ${contact.enriched_title || contact.connection_title || 'Unknown'}
- Company: ${contact.enriched_company || contact.connection_company || 'Unknown'}
- Location: ${contact.enriched_location || 'Unknown'}
- Last Contact: ${contact.last_contact_date ? this._formatDateDistance(contact.last_contact_date) : 'Never'}

SCORING GUIDE:
- Job change <30 days: 25 pts (HOT)
- Job change 30-90 days: 18 pts
- Company growth signals: 15 pts
- Recent activity: 10 pts
- No clear signals: 5 pts

RETURN JSON:
{
  "intent_score": <0-25>,
  "primary_signal": "<job_change|company_growth|activity|none>",
  "reasoning": "<brief explanation>",
  "urgency": "<immediate|high|medium|low>"
}`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            intent_score: { type: 'number' },
            primary_signal: { type: 'string' },
            reasoning: { type: 'string' },
            urgency: { type: 'string' }
          }
        }
      });

      this.analysisCache.set(cacheKey, response);
      return response;
    } catch (error) {
      console.error('[UniversalPriority] Intent detection failed:', error);
      return {
        intent_score: 5,
        primary_signal: 'none',
        reasoning: 'Analysis unavailable',
        urgency: 'low'
      };
    }
  }

  /**
   * COMPONENT 3: ICP Fit Analysis (15 points) - DETERMINISTIC VERSION
   * Fast, rule-based matching without LLM
   */
  _analyzeICPFitDeterministic(contact) {
    if (!this.userContext) return 5;

    let score = 0;
    const matchedCriteria = [];

    // Check persona match (5 points)
    const title = (contact.enriched_title || contact.connection_title || '').toLowerCase();
    const targetPersonas = this.userContext.target_personas.map(p => p.toLowerCase());
    
    for (const persona of targetPersonas) {
      if (title.includes(persona.toLowerCase())) {
        score += 5;
        matchedCriteria.push('persona');
        break;
      }
    }

    // Check industry match (5 points)
    const industry = (contact.enriched_industry || '').toLowerCase();
    const targetIndustries = this.userContext.target_industries.map(i => i.toLowerCase());
    
    for (const targetIndustry of targetIndustries) {
      if (industry.includes(targetIndustry.toLowerCase())) {
        score += 5;
        matchedCriteria.push('industry');
        break;
      }
    }

    // Check company size match (5 points)
    const companySize = contact.company_size || '';
    if (this.userContext.target_company_sizes.includes(companySize)) {
      score += 5;
      matchedCriteria.push('company_size');
    }

    return Math.min(15, score);
  }

  /**
   * COMPONENT 4: Relationship Momentum (15 points) - DETERMINISTIC
   */
  _analyzeRelationshipMomentum(contact) {
    if (!contact.last_contact_date) {
      return { score: 8, status: 'Never contacted - opportunity' };
    }

    const daysSince = this._calculateDaysSince(contact.last_contact_date);

    if (daysSince < 30) {
      return { score: 15, status: 'Very recent - hot relationship' };
    }

    if (daysSince < 90) {
      return { score: 10, status: 'Recent - maintain momentum' };
    }

    if (daysSince < 180) {
      return { score: 5, status: 'Getting stale - re-engage' };
    }

    if (daysSince < 365) {
      return { score: 2, status: 'Dormant - needs revival' };
    }

    return { score: -5, status: 'Cold - major effort needed' };
  }

  /**
   * COMPONENT 5: Data Quality (15 points) - DETERMINISTIC
   */
  _assessDataQuality(contact) {
    let score = 0;
    const details = [];

    if (contact.linkedin_url) {
      score += 4;
      details.push('LinkedIn');
    }
    if (contact.connection_email || contact.enriched_email) {
      score += 3;
      details.push('Email');
    }
    if (contact.enriched_company || contact.connection_company) {
      score += 2;
      details.push('Company');
    }
    if (contact.enriched_title || contact.connection_title) {
      score += 2;
      details.push('Title');
    }
    if (contact.enriched_industry) {
      score += 2;
      details.push('Industry');
    }
    if (contact.enriched_seniority) {
      score += 1;
      details.push('Seniority');
    }
    if (contact.intelligent_summary) {
      score += 1;
      details.push('Bio');
    }

    return {
      score: Math.min(15, score),
      available_fields: details.join(', ')
    };
  }

  /**
   * Calculate top 10% threshold - OPTIMIZED
   */
  async calculatePriorityThreshold(contacts, userEmail) {
    console.log(`[UniversalPriority] Analyzing ${contacts.length} contacts...`);
    console.log(`[UniversalPriority] Using deterministic-first approach to minimize LLM calls`);

    // Ensure initialized
    if (!this.userContext || this.userContext.user_email !== userEmail) {
      await this.initialize(userEmail);
    }

    // Reset LLM call counter
    this.llmCallCount = 0;

    // First pass: All contacts with deterministic scoring only
    console.log('[UniversalPriority] Phase 1: Deterministic scoring for all contacts...');
    const allScored = await Promise.all(
      contacts.map(c => this.calculatePriorityScore(c, userEmail, false))
    );

    // Sort and identify top candidates for LLM enhancement
    allScored.sort((a, b) => b.priority_score - a.priority_score);
    const top10PercentCount = Math.max(10, Math.min(200, Math.floor(allScored.length * 0.10)));
    
    // Second pass: Enhance top 50 candidates with LLM (if we have capacity)
    const topCandidates = allScored.slice(0, Math.min(50, top10PercentCount));
    console.log(`[UniversalPriority] Phase 2: LLM enhancement for top ${topCandidates.length} candidates...`);
    
    const enhancedTop = await this._batchEnhanceWithLLM(topCandidates, userEmail);

    // Merge enhanced scores back
    const finalScored = [
      ...enhancedTop,
      ...allScored.slice(enhancedTop.length)
    ];

    // Re-sort after LLM enhancement
    finalScored.sort((a, b) => b.priority_score - a.priority_score);

    const priorityContacts = finalScored.slice(0, top10PercentCount);
    const threshold = priorityContacts[top10PercentCount - 1]?.priority_score || 70;

    console.log(`[UniversalPriority] ✅ Identified ${top10PercentCount} priority contacts`);
    console.log(`[UniversalPriority] Threshold score: ${threshold}/100`);
    console.log(`[UniversalPriority] LLM calls made: ${this.llmCallCount}/${this.maxLLMCalls}`);

    return {
      allScoredContacts: finalScored,
      priorityContacts,
      threshold,
      percentile: (top10PercentCount / finalScored.length * 100).toFixed(1),
      totalAnalyzed: finalScored.length,
      priorityCount: top10PercentCount,
      llmCallsUsed: this.llmCallCount
    };
  }

  /**
   * Batch enhance top contacts with LLM - with rate limiting
   */
  async _batchEnhanceWithLLM(contacts, userEmail) {
    const enhanced = [];
    const batchSize = 5; // Small batches to respect rate limits
    const delayMs = 2000; // 2 second delay between batches

    for (let i = 0; i < contacts.length; i += batchSize) {
      if (this.llmCallCount >= this.maxLLMCalls) {
        console.log('[UniversalPriority] Reached LLM call limit, skipping remaining');
        enhanced.push(...contacts.slice(i));
        break;
      }

      const batch = contacts.slice(i, i + batchSize);
      console.log(`[UniversalPriority] Processing batch ${Math.floor(i/batchSize) + 1}...`);
      
      const batchResults = await Promise.all(
        batch.map(c => this.calculatePriorityScore(c.contact, userEmail, true))
      );
      
      enhanced.push(...batchResults);

      // Rate limiting delay
      if (i + batchSize < contacts.length) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }

    return enhanced;
  }

  /**
   * Get tier classification
   */
  _getTier(score) {
    if (score >= 80) return 'hot';
    if (score >= 60) return 'warm';
    return 'cold';
  }

  /**
   * Helper: Calculate days since date
   */
  _calculateDaysSince(dateString) {
    if (!dateString) return Infinity;
    const date = new Date(dateString);
    const now = new Date();
    return Math.floor((now - date) / (1000 * 60 * 60 * 24));
  }

  /**
   * Helper: Format date distance
   */
  _formatDateDistance(dateString) {
    const days = this._calculateDaysSince(dateString);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 30) return `${days} days ago`;
    if (days < 365) return `${Math.floor(days/30)} months ago`;
    return `${Math.floor(days/365)} years ago`;
  }

  /**
   * Clear all caches
   */
  clearCache() {
    this.scoreCache.clear();
    this.analysisCache.clear();
    this.llmCallCount = 0;
  }
}

export const universalPriorityService = new UniversalPriorityService();