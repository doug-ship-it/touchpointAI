import { InvokeLLM } from '@/api/integrations';

/**
 * LINKEDIN MESSAGE GENERATOR FOR BASE44
 * Generates authentic, concise first-degree LinkedIn messages
 * Integrated into Find Connections and Command Center
 */

class LinkedInMessageGenerator {
  constructor() {
    this.maxLength = 600;
    this.targetLength = 350;
    this.prohibitedPhrases = [
      'best regards',
      'sincerely',
      'thanks',
      'dear',
      'to whom it may concern',
      'i noticed that you\'re',
      'your impressive background',
      'i came across your profile'
    ];
  }

  /**
   * Generate personalized LinkedIn message
   * @param {Object} target - Contact information
   * @param {Object} sender - Sender information
   * @param {string} triggerSource - 'find_connections' or 'command_center'
   * @returns {Promise<Object>} Generated message with metadata
   */
  async generateMessage(target, sender, triggerSource = 'find_connections') {
    try {
      console.log('[MessageGen] Generating message for:', target.first_name);

      const prompt = this._buildEnhancedPrompt(target, sender);
      
      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            message: { type: 'string' },
            length: { type: 'number' },
            personalization_elements: { 
              type: 'array', 
              items: { type: 'string' }
            }
          },
          required: ['message', 'length']
        }
      });

      // Validate output
      if (response.length > this.maxLength) {
        console.warn('[MessageGen] Response too long, trimming...');
        response.message = this._trimMessage(response.message);
        response.length = response.message.length;
      }

      // Check for prohibited content
      if (this._containsProhibitedContent(response.message)) {
        console.warn('[MessageGen] Prohibited content detected, regenerating...');
        return await this.generateMessage(target, sender, triggerSource);
      }

      console.log('[MessageGen] ✅ Generated message:', response.length, 'chars');
      
      return {
        message: response.message,
        length: response.length,
        personalization_elements: response.personalization_elements || [],
        trigger_source: triggerSource,
        generated_at: new Date().toISOString()
      };

    } catch (error) {
      console.error('[MessageGen] Generation failed:', error);
      throw new Error('Failed to generate message. Please try again.');
    }
  }

  /**
   * Build enhanced prompt with strict Base44 instructions
   */
  _buildEnhancedPrompt(target, sender) {
    const { first_name, role, company, recent_activity, linkedin_url } = target;
    const { first_name: senderFirstName, specialty } = sender;

    return `You are a professional LinkedIn message writer integrated into a relationship intelligence platform. Generate an authentic first-degree connection message following strict constraints.

CRITICAL CONSTRAINTS (ABSOLUTE REQUIREMENTS):
1. Maximum length: 600 characters (HARD STOP - exceeding this fails validation)
2. Target length: 300-400 characters (optimal range)
3. Format: Plain LinkedIn DM text ONLY (no email conventions)
4. Relationship: First-degree LinkedIn connection (already connected)
5. Tone: Conversational colleague starting genuine dialogue

STRICT PROHIBITIONS (AUTO-REJECT IF PRESENT):
❌ Email elements: Subject lines, "Dear...", signature blocks, "Best regards", "Sincerely"
❌ Contact info: Email addresses, phone numbers, LinkedIn URLs, calendar links
❌ Generic openers: "I noticed that you're...", "Your impressive background...", "I came across your profile..."
❌ Multiple CTAs or pushy sales language
❌ Excessive enthusiasm or flattery
❌ Corporate jargon walls ("synergies", "circle back", "touch base")

REQUIRED MESSAGE STRUCTURE:

**Opening Sentence (Required):**
- Start with natural, specific reference using active verbs
- Approved verbs: "saw", "appreciated", "liked", "noticed", "caught", "read"
- Reference options (in priority order):
  1. Recent activity/post (if provided): "Saw your post on [topic] at [company]"
  2. Current role: "Appreciated your perspective on [relevant topic]"
  3. Company context: "Liked your update on [company initiative]"
- Structure: [Verb] + [specific reference] + [at/on Company/Context]
- ❌ Never use: "I noticed that you're the [title] at..."

**Middle Sentence (Required):**
- Brief, natural connection between sender's work and recipient's domain
- Structure: [Sender context] + [relevant overlap]
- Length: 15-25 words maximum
- Example: "In my work with [specialty], I see similar challenges around [topic]"
- Purpose: Establish relevance WITHOUT selling

**Closing CTA (Required):**
- Light, optional invitation (never demanding)
- Approved patterns:
  * "Curious to [compare notes/swap perspectives/hear your take]"
  * "Open to [chatting/connecting/discussing] if [it makes sense/you're interested]"
  * "Let me know if [a conversation/quick chat] would be valuable"
  * "Happy to [share insights/exchange thoughts] if you're open to it"
- ❌ Avoid: "Would love to schedule", "Let's hop on a call", "Can I send you information"

CONTACT INFORMATION:
Target Contact:
- First Name: ${first_name}
- Role: ${role || 'Unknown'}
- Company: ${company || 'Unknown'}
${recent_activity ? `- Recent Activity: ${recent_activity}` : '- No recent activity provided'}

Sender Information:
- First Name: ${senderFirstName}
- Specialty: ${specialty}

GENERATION PRIORITY LOGIC:
1. IF recent_activity is provided → Lead with activity reference (preferred)
   Example: "Saw your post on AI implementation at Stripe"
2. IF recent_activity is empty → Lead with role + company context
   Example: "Appreciated your perspective on engineering leadership at GitHub"
3. Keep message focused and conversational (avoid over-explanation)

OUTPUT REQUIREMENTS:
Return strict JSON format:
{
  "message": "<generated_message_under_600_chars>",
  "length": <character_count>,
  "personalization_elements": ["<what made this message personalized>"]
}

QUALITY VALIDATION (Self-Check Before Output):
✓ Length ≤ 600 characters (CRITICAL)
✓ Ideally 300-400 characters
✓ 2-3 sentences total
✓ No email formatting
✓ No signature/closing
✓ Exactly 1 CTA at end
✓ Opens with active verb + specific reference
✓ Sounds natural when read aloud
✓ No prohibited phrases detected

EXAMPLES OF EXCELLENT MESSAGES:

Example 1 (With Recent Activity):
{
  "message": "Hi Jakub, saw your recent thoughts on open source leadership at GitHub. In my work advising engineering leaders, I often encounter the same scaling challenges you mentioned. Curious if you'd be open to swapping notes on building high-performance teams.",
  "length": 267
}

Example 2 (Without Recent Activity):
{
  "message": "Hi Sarah, appreciated your perspective on revenue operations at Salesforce. I advise RevOps leaders navigating similar go-to-market challenges. Let me know if you'd find value in comparing notes on scaling strategies.",
  "length": 223
}

Example 3 (With Company Context):
{
  "message": "Hi Michael, liked your update on Stripe's latest product initiatives. My clients in fintech often ask about building developer-first platforms. Open to chatting if you'd find it valuable to exchange insights.",
  "length": 215
}

Now generate an authentic, conversational LinkedIn message for ${first_name} that follows ALL constraints above.`;
  }

  /**
   * Trim message to fit length constraints
   */
  _trimMessage(message) {
    if (message.length <= this.maxLength) return message;

    // Remove adjectives first
    let trimmed = message.replace(/\b(very|really|quite|extremely|incredibly)\s+/gi, '');
    
    if (trimmed.length <= this.maxLength) return trimmed;

    // Truncate at last complete sentence before limit
    const sentences = trimmed.match(/[^.!?]+[.!?]+/g) || [];
    let result = '';
    
    for (const sentence of sentences) {
      if ((result + sentence).length > this.maxLength) break;
      result += sentence;
    }

    return result.trim() || message.substring(0, this.maxLength - 3) + '...';
  }

  /**
   * Check for prohibited content
   */
  _containsProhibitedContent(message) {
    const lowerMessage = message.toLowerCase();
    return this.prohibitedPhrases.some(phrase => lowerMessage.includes(phrase));
  }

  /**
   * Generate alternative message versions
   */
  async generateAlternatives(target, sender, count = 2) {
    const alternatives = [];
    
    for (let i = 0; i < count; i++) {
      try {
        const message = await this.generateMessage(target, sender);
        alternatives.push({
          version: i + 1,
          ...message
        });
        
        // Small delay between generations
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        console.error(`[MessageGen] Failed to generate alternative ${i + 1}:`, error);
      }
    }

    return alternatives;
  }
}

export const linkedInMessageGenerator = new LinkedInMessageGenerator();