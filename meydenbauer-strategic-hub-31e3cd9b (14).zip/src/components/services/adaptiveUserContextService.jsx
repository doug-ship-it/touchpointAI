import { UserICPProfile } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { User } from '@/api/entities';

/**
 * ADAPTIVE USER CONTEXT SERVICE
 * Learns each user's business model and ICP to personalize priority scoring
 */
class AdaptiveUserContextService {
  constructor() {
    this.contextCache = new Map();
  }

  /**
   * Get or generate user's business context
   * Returns ICP criteria for personalized priority scoring
   */
  async getUserContext(userEmail) {
    // Check memory cache first
    if (this.contextCache.has(userEmail)) {
      console.log('[AdaptiveContext] Using cached context for user:', userEmail);
      return this.contextCache.get(userEmail);
    }

    try {
      // Check database for existing profile
      const profiles = await UserICPProfile.filter({ user_email: userEmail });
      
      if (profiles && profiles.length > 0) {
        const profile = profiles[0];
        const context = this._parseStoredProfile(profile);
        this.contextCache.set(userEmail, context);
        console.log('[AdaptiveContext] Loaded existing profile for user:', userEmail);
        return context;
      }

      // No profile exists - generate new one
      console.log('[AdaptiveContext] No profile found, generating new context...');
      const user = await User.me();
      const context = await this.generateUserContext(user);
      
      // Save to database
      await this._saveContext(userEmail, context);
      this.contextCache.set(userEmail, context);
      
      return context;
    } catch (error) {
      console.error('[AdaptiveContext] Error loading context:', error);
      return this.getDefaultContext(userEmail);
    }
  }

  /**
   * Generate ICP context using AI analysis of user data
   */
  async generateUserContext(user) {
    try {
      const emailDomain = user.email.split('@')[1];
      const companyName = user.company_name || emailDomain.split('.')[0];
      
      console.log('[AdaptiveContext] Analyzing user:', { email: user.email, domain: emailDomain });

      const prompt = `Analyze this user's business context and generate their Ideal Customer Profile (ICP).

USER DATA:
- Email: ${user.email}
- Email Domain: ${emailDomain}
- Company: ${companyName}
- Job Title: ${user.job_title || 'Unknown'}
- LinkedIn: ${user.linkedin_url || 'Not provided'}

ANALYSIS REQUIRED:
Infer this user's business model and who they should prioritize in their network.

RETURN JSON FORMAT (strict schema):
{
  "business_type": "<sales_leader|consultant|recruiter|investor|entrepreneur|business_development>",
  "company_name": "<inferred company name>",
  "target_personas": ["<ideal contact titles>"],
  "target_industries": ["<industries they serve/target>"],
  "target_company_sizes": ["<employee ranges like '51-200', '201-500'>"],
  "buying_signals": ["<what indicates in-market prospect>"],
  "relationship_goals": "<what they want from their network>",
  "confidence_level": "<high|medium|low>"
}

EXAMPLES OF GOOD ANALYSIS:
- sales@acme.com → Target: VPs/Directors in SaaS, Tech companies 100-1000 employees
- john@consultingfirm.com → Target: C-Suite in PE/Finance, Looking for advisory opportunities
- recruiter@talentco.com → Target: Hiring managers, High-growth startups

Be specific and practical. Think about WHO this person needs in their network to succeed.`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            business_type: { type: 'string' },
            company_name: { type: 'string' },
            target_personas: { type: 'array', items: { type: 'string' } },
            target_industries: { type: 'array', items: { type: 'string' } },
            target_company_sizes: { type: 'array', items: { type: 'string' } },
            buying_signals: { type: 'array', items: { type: 'string' } },
            relationship_goals: { type: 'string' },
            confidence_level: { type: 'string' }
          }
        }
      });

      console.log('[AdaptiveContext] ✅ Generated context:', response);
      
      return {
        user_email: user.email,
        ...response,
        generated_at: new Date().toISOString()
      };
    } catch (error) {
      console.error('[AdaptiveContext] ❌ Generation failed:', error);
      return this.getDefaultContext(user.email);
    }
  }

  /**
   * Save context to database for persistence
   */
  async _saveContext(userEmail, context) {
    try {
      await UserICPProfile.create({
        user_email: userEmail,
        business_type: context.business_type,
        company_name: context.company_name,
        target_personas: JSON.stringify(context.target_personas),
        target_industries: JSON.stringify(context.target_industries),
        target_company_sizes: JSON.stringify(context.target_company_sizes),
        buying_signals: JSON.stringify(context.buying_signals),
        relationship_goals: context.relationship_goals,
        overall_confidence: context.confidence_level === 'high' ? 90 : context.confidence_level === 'medium' ? 70 : 50,
        analysis_date: new Date().toISOString()
      });
      
      console.log('[AdaptiveContext] ✅ Saved context to database');
    } catch (error) {
      console.error('[AdaptiveContext] ❌ Failed to save context:', error);
    }
  }

  /**
   * Parse stored profile from database
   */
  _parseStoredProfile(profile) {
    return {
      user_email: profile.user_email,
      business_type: profile.business_type,
      company_name: profile.company_name,
      target_personas: JSON.parse(profile.target_personas || '[]'),
      target_industries: JSON.parse(profile.target_industries || '[]'),
      target_company_sizes: JSON.parse(profile.target_company_sizes || '[]'),
      buying_signals: JSON.parse(profile.buying_signals || '[]'),
      relationship_goals: profile.relationship_goals,
      confidence_level: profile.overall_confidence > 80 ? 'high' : profile.overall_confidence > 60 ? 'medium' : 'low',
      generated_at: profile.analysis_date
    };
  }

  /**
   * Default context for fallback scenarios
   */
  getDefaultContext(userEmail) {
    return {
      user_email: userEmail,
      business_type: 'sales_leader',
      company_name: 'Unknown',
      target_personas: ['VP', 'Director', 'C-Suite', 'Head of'],
      target_industries: ['Technology', 'SaaS', 'Consulting', 'Finance'],
      target_company_sizes: ['51-200', '201-500', '501-1000', '1001-5000'],
      buying_signals: ['Job change', 'Company growth', 'New initiatives'],
      relationship_goals: 'Build relationships with decision makers and potential clients',
      confidence_level: 'low',
      generated_at: new Date().toISOString()
    };
  }

  /**
   * Allow manual updates to ICP
   */
  async updateUserContext(userEmail, updates) {
    try {
      const profiles = await UserICPProfile.filter({ user_email: userEmail });
      
      if (profiles && profiles.length > 0) {
        await UserICPProfile.update(profiles[0].id, {
          business_type: updates.business_type,
          target_personas: JSON.stringify(updates.target_personas),
          target_industries: JSON.stringify(updates.target_industries),
          target_company_sizes: JSON.stringify(updates.target_company_sizes),
          buying_signals: JSON.stringify(updates.buying_signals),
          relationship_goals: updates.relationship_goals
        });
      } else {
        await this._saveContext(userEmail, updates);
      }
      
      // Clear cache to force reload
      this.contextCache.delete(userEmail);
      console.log('[AdaptiveContext] ✅ Updated user context');
      
      return true;
    } catch (error) {
      console.error('[AdaptiveContext] ❌ Update failed:', error);
      return false;
    }
  }

  /**
   * Clear cache (useful for testing)
   */
  clearCache() {
    this.contextCache.clear();
  }
}

export const adaptiveUserContextService = new AdaptiveUserContextService();