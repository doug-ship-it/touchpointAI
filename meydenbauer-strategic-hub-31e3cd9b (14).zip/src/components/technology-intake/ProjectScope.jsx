import React from 'react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';

export default function ProjectScope({ formData, updateFormData }) {
  const handleGoalChange = (index, value) => {
    const goals = [...(formData.scope.goals || [])];
    goals[index] = value;
    updateFormData('scope', { goals });
  };

  return (
    <div className="space-y-6">
      <div>
        <Label htmlFor="description" className="text-lg font-semibold text-slate-800">Project Description</Label>
        <p className="text-sm text-slate-500 mb-2">Provide a high-level overview of the project.</p>
        <Textarea
          id="description"
          value={formData.scope.description}
          onChange={(e) => updateFormData('scope', { description: e.target.value })}
          placeholder="Describe the main purpose, features, and target users of this project..."
          rows={5}
        />
      </div>
      <div>
        <Label className="text-lg font-semibold text-slate-800">Primary Goals</Label>
        <p className="text-sm text-slate-500 mb-2">List up to 3 primary goals for this project.</p>
        <div className="space-y-2">
          <Input placeholder="Goal 1: e.g., Increase user retention by 20%" value={formData.scope.goals?.[0] || ''} onChange={e => handleGoalChange(0, e.target.value)} />
          <Input placeholder="Goal 2: e.g., Reduce onboarding time by 50%" value={formData.scope.goals?.[1] || ''} onChange={e => handleGoalChange(1, e.target.value)} />
          <Input placeholder="Goal 3: e.g., Automate manual reporting processes" value={formData.scope.goals?.[2] || ''} onChange={e => handleGoalChange(2, e.target.value)} />
        </div>
      </div>
      <div>
        <Label htmlFor="kpis" className="text-lg font-semibold text-slate-800">Key Performance Indicators (KPIs)</Label>
        <p className="text-sm text-slate-500 mb-2">How will we measure success? (e.g., Monthly Active Users, Conversion Rate, Churn Rate)</p>
        <Input
          id="kpis"
          value={formData.scope.kpis}
          onChange={(e) => updateFormData('scope', { kpis: e.target.value })}
          placeholder="List key metrics, separated by commas"
        />
      </div>
    </div>
  );
}