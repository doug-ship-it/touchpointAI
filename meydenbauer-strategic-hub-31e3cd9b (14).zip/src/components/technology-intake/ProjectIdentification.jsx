import React, { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { debounce } from 'lodash';
import { InvokeLLM } from '@/api/integrations';
import { Loader2, CheckCircle, Info, AlertTriangle, HelpCircle, Edit } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const ConfidenceIndicator = ({ score }) => {
  if (!score) return null;
  const config = {
    high: { Icon: CheckCircle, color: 'text-green-500', text: 'High Confidence' },
    medium: { Icon: Info, color: 'text-blue-500', text: 'Medium Confidence' },
    low: { Icon: AlertTriangle, color: 'text-yellow-500', text: 'Low Confidence' },
    very_low: { Icon: HelpCircle, color: 'text-red-500', text: 'Please Verify' },
  };
  const level = score >= 90 ? 'high' : score >= 70 ? 'medium' : score >= 40 ? 'low' : 'very_low';
  const { Icon, color, text } = config[level];

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Icon className={`${color} w-5 h-5 cursor-help`} />
        </TooltipTrigger>
        <TooltipContent>
          <p>{text}: Our system is {score}% confident in this information.</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

const AutoDetectedField = ({ label, value, confidence, onEdit, isEditing, onChange, fieldName }) => (
  <div>
    <Label htmlFor={fieldName}>{label}</Label>
    <div className="relative">
      <Input
        id={fieldName}
        value={value || ''}
        disabled={!isEditing}
        onChange={onChange}
        className={!isEditing ? 'pr-24' : ''}
      />
      {!isEditing && (
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 space-x-2">
          {confidence && <ConfidenceIndicator score={confidence} />}
          <Button variant="ghost" size="sm" onClick={onEdit}>
            <Edit className="w-4 h-4 mr-1" /> Edit
          </Button>
        </div>
      )}
    </div>
  </div>
);

export default function ProjectIdentification({ formData, updateFormData }) {
  const [isEnriching, setIsEnriching] = useState(false);
  const [enrichedData, setEnrichedData] = useState(null);
  const [editingFields, setEditingFields] = useState({});
  const [manualMode, setManualMode] = useState(false);

  const enrichCompanyData = useCallback(async (email) => {
    if (!email.includes('@') || !email.includes('.')) return;
    setIsEnriching(true);
    setManualMode(false);
    
    const domain = email.split('@')[1];
    const prompt = `Based on the email domain "${domain}", act as a data enrichment engine. Search public sources like the company website, LinkedIn, and business registries to find the following information. Return a JSON object with the data and a confidence score (0-100) for each field.

    **Required Fields:**
    - company_name: Official company name.
    - industry: Industry category.
    - company_size: Estimated employee count.
    - company_stage: e.g., 'Startup', 'Growth', 'Established', 'Enterprise'.
    - location: Headquarters location (City, State/Country).

    Prioritize accuracy and provide a confidence score for each piece of data. If data is unavailable, return null for that field.`;

    try {
      const result = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: 'object',
          properties: {
            company_name: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            industry: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            company_size: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            company_stage: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
            location: { type: 'object', properties: { value: { type: 'string' }, confidence: { type: 'number' } } },
          },
        },
      });
      
      if (result && result.company_name?.confidence >= 80) {
        setEnrichedData(result);
        const companyData = {};
        if (result.company_name?.confidence >= 80) companyData.name = result.company_name.value;
        if (result.industry?.confidence >= 80) companyData.industry = result.industry.value;
        if (result.company_size?.confidence >= 80) companyData.size = result.company_size.value;
        if (result.company_stage?.confidence >= 80) companyData.stage = result.company_stage.value;
        if (result.location?.confidence >= 80) companyData.location = result.location.value;
        updateFormData('company', companyData);
      } else {
        setManualMode(true);
      }
    } catch (error) {
      console.error('Enrichment failed:', error);
      setManualMode(true);
    } finally {
      setIsEnriching(false);
    }
  }, [updateFormData]);

  const debouncedEnrichment = useMemo(
    () => debounce(enrichCompanyData, 1000),
    [enrichCompanyData]
  );

  const handleEmailChange = (e) => {
    const email = e.target.value;
    updateFormData('contact', { email });
    debouncedEnrichment(email);
  };
  
  const handleFieldChange = (section, fieldName, value) => {
    updateFormData(section, { [fieldName]: value });
  };
  
  const toggleEdit = (fieldName) => {
    setEditingFields(prev => ({ ...prev, [fieldName]: !prev[fieldName] }));
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="firstName">First Name</Label>
          <Input 
            id="firstName"
            value={formData.contact.firstName}
            onChange={(e) => updateFormData('contact', { firstName: e.target.value })}
            placeholder="Jane"
          />
        </div>
        <div className="relative">
          <Label htmlFor="email">Work Email</Label>
          <Input 
            id="email"
            type="email"
            value={formData.contact.email}
            onChange={handleEmailChange}
            placeholder="jane@examplecorp.com"
          />
          {isEnriching && <Loader2 className="absolute top-8 right-3 w-5 h-5 animate-spin text-slate-400" />}
        </div>
      </div>
      
       <div>
          <Label htmlFor="projectName">Project Name</Label>
          <Input 
            id="projectName"
            value={formData.project.name}
            onChange={(e) => updateFormData('project', { name: e.target.value })}
            placeholder="e.g., 'New Customer Onboarding Platform'"
          />
        </div>

      <AnimatePresence>
        {(enrichedData || manualMode) && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6 pt-6 border-t"
          >
            {manualMode && !isEnriching && (
                <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-800">We couldn't automatically detect your company information. Please fill in the details below.</p>
                </div>
            )}
            
            <AutoDetectedField 
                label="Company Name"
                fieldName="name"
                value={formData.company.name}
                confidence={enrichedData?.company_name?.confidence}
                isEditing={manualMode || editingFields.name}
                onEdit={() => toggleEdit('name')}
                onChange={(e) => handleFieldChange('company', 'name', e.target.value)}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <AutoDetectedField 
                    label="Industry / Sector"
                    fieldName="industry"
                    value={formData.company.industry}
                    confidence={enrichedData?.industry?.confidence}
                    isEditing={manualMode || editingFields.industry}
                    onEdit={() => toggleEdit('industry')}
                    onChange={(e) => handleFieldChange('company', 'industry', e.target.value)}
                />
                 <AutoDetectedField 
                    label="Company Size"
                    fieldName="size"
                    value={formData.company.size}
                    confidence={enrichedData?.company_size?.confidence}
                    isEditing={manualMode || editingFields.size}
                    onEdit={() => toggleEdit('size')}
                    onChange={(e) => handleFieldChange('company', 'size', e.target.value)}
                />
                 <AutoDetectedField 
                    label="Company Stage"
                    fieldName="stage"
                    value={formData.company.stage}
                    confidence={enrichedData?.company_stage?.confidence}
                    isEditing={manualMode || editingFields.stage}
                    onEdit={() => toggleEdit('stage')}
                    onChange={(e) => handleFieldChange('company', 'stage', e.target.value)}
                />
                 <AutoDetectedField 
                    label="Location"
                    fieldName="location"
                    value={formData.company.location}
                    confidence={enrichedData?.location?.confidence}
                    isEditing={manualMode || editingFields.location}
                    onEdit={() => toggleEdit('location')}
                    onChange={(e) => handleFieldChange('company', 'location', e.target.value)}
                />
            </div>
             {!manualMode && enrichedData && <Button variant="link" onClick={() => setManualMode(true)}>Auto-detection not working? Click here to enter all information manually</Button>}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}