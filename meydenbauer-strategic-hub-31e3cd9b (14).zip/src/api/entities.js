import { base44 } from './base44Client';


export const Company = base44.entities.Company;

export const Resource = base44.entities.Resource;

export const Vendor = base44.entities.Vendor;

export const NetworkConnection = base44.entities.NetworkConnection;

export const Candidate = base44.entities.Candidate;

export const Lead = base44.entities.Lead;

export const Contact = base44.entities.Contact;

export const FormSubmission = base44.entities.FormSubmission;

export const Service = base44.entities.Service;

export const CaseStudy = base44.entities.CaseStudy;

export const Shortlist = base44.entities.Shortlist;

export const ShortlistContact = base44.entities.ShortlistContact;

export const AICRMContact = base44.entities.AICRMContact;

export const AICRMInteraction = base44.entities.AICRMInteraction;

export const AICRMReminder = base44.entities.AICRMReminder;

export const AICRMGroup = base44.entities.AICRMGroup;

export const PipelineOpportunity = base44.entities.PipelineOpportunity;

export const UserICPProfile = base44.entities.UserICPProfile;

export const UserTechStack = base44.entities.UserTechStack;

export const CRMDeal = base44.entities.CRMDeal;

export const CRMActivity = base44.entities.CRMActivity;

export const CRMTask = base44.entities.CRMTask;

export const TrialSignup = base44.entities.TrialSignup;

export const UserMessagingPreferences = base44.entities.UserMessagingPreferences;

export const GeneratedMessages = base44.entities.GeneratedMessages;

export const PrioritySegment = base44.entities.PrioritySegment;

export const ContactSegment = base44.entities.ContactSegment;

export const PriorityAnalysisCache = base44.entities.PriorityAnalysisCache;



// auth sdk:
export const User = base44.auth;