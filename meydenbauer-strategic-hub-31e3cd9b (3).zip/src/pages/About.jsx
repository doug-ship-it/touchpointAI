
import React from 'react';
import { motion } from 'framer-motion';
import { Users, Target, Lightbulb, Award, Zap, Brain, TrendingUp, ArrowRight, Mail } from 'lucide-react';
import { useExpandedView } from '../components/expanded-view/ExpandedViewProvider';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const values = [
  {
    icon: Target,
    title: "Precision & Insight",
    description: "We deliver actionable intelligence that drives strategic decision-making and measurable business outcomes."
  },
  {
    icon: Users,
    title: "Vetted Network", 
    description: "Our extensive network gives you unparalleled access to proven expertise and strategic connections."
  },
  {
    icon: Zap,
    title: "Accelerated Execution",
    description: "We bridge the gap between strategy and execution, helping you implement change faster and more effectively."
  },
  {
    icon: Award,
    title: "Proven Results",
    description: "Our track record includes saving launches, cutting costs by 18%, and boosting development speed by 40%."
  }
];

const approachSteps = [
    { icon: Brain, title: "Discovery & Analysis", description: "We dive deep into your business to understand your unique challenges and opportunities." },
    { icon: Target, title: "Strategic Roadmap", description: "We co-create a data-driven strategy tailored to your specific goals and market position." },
    { icon: TrendingUp, title: "Execution & Growth", description: "We leverage our network and expertise to implement the plan and drive tangible results." }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { duration: 0.6, ease: "easeOut" }
  },
};

export default function AboutPage() {
  const { openExpandedView } = useExpandedView();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 to-slate-800 text-white py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6"
            style={{fontFamily: 'Inter, system-ui, sans-serif'}}
          >
            About Meydenbauer Partners
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-xl text-slate-300 leading-relaxed"
          >
            Your strategic partner in technology, go-to-market, and executive enablement. We bridge the gap between vision and execution.
          </motion.p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="grid lg:grid-cols-2 gap-12 items-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div variants={itemVariants}>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Mission</h2>
              <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
                <p>
                  Meydenbauer Partners serves as an integrated operating system for network intelligence, 
                  technology strategy, and executive enablement. We believe that the right connections, 
                  insights, and strategies can transform businesses and accelerate growth.
                </p>
                <p>
                  Our platform combines deep industry expertise with cutting-edge AI to deliver 
                  personalized intelligence that drives real business outcomes.
                </p>
              </div>
            </motion.div>
            <motion.div 
              variants={itemVariants}
              className="bg-gradient-to-br from-teal-50 to-blue-50 p-8 rounded-2xl border border-gray-200"
            >
              <div className="grid grid-cols-2 gap-8 text-center">
                <div>
                  <h3 className="text-4xl lg:text-5xl font-bold text-teal-600 mb-2">9K+</h3>
                  <p className="text-slate-600 font-medium">Connections</p>
                </div>
                <div>
                  <h3 className="text-4xl lg:text-5xl font-bold text-teal-600 mb-2">40+</h3>
                  <p className="text-slate-600 font-medium">Vendor Partners</p>
                </div>
                 <div>
                  <h3 className="text-4xl lg:text-5xl font-bold text-teal-600 mb-2">$105M+</h3>
                  <p className="text-slate-600 font-medium">Client Revenue</p>
                </div>
                 <div>
                  <h3 className="text-4xl lg:text-5xl font-bold text-teal-600 mb-2">95%</h3>
                  <p className="text-slate-600 font-medium">Retention Rate</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 lg:py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y:20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Core Values</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">The principles that guide our work and partnerships.</p>
          </motion.div>
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={containerVariants}
          >
            {values.map((value) => (
              <motion.div
                key={value.title}
                variants={itemVariants}
                className="bg-slate-50/70 p-8 rounded-xl border border-slate-200 hover:shadow-xl hover:border-teal-300 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-blue-500 text-white rounded-full flex items-center justify-center mb-6 shadow-lg">
                  <value.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{value.title}</h3>
                <p className="text-slate-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-20 lg:py-24">
        <motion.div 
          className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y:20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Meet the Founder</h2>
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c743df2b981f4e31e3cd9b/884cf47a3_68425a8d8b7d1ec598528af0_Doug.png" 
            alt="Doug Sandstedt" 
            className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-white shadow-lg object-cover"
          />
          <h3 className="text-2xl font-bold text-slate-800">Doug Sandstedt</h3>
          <p className="text-teal-600 font-medium mb-4">Founder & Managing Partner</p>
          <p className="text-slate-600 leading-relaxed max-w-2xl mx-auto mb-8">
            Doug brings over 20 years of experience in technology, consulting, and executive leadership. 
            His passion for connecting people and ideas led to the creation of Meydenbauer Partners, 
            a firm dedicated to bringing enterprise-level intelligence and execution to businesses of all sizes.
          </p>
          <Button 
            onClick={() => openExpandedView('https://www.linkedin.com/in/dougsandstedt/', 'Doug Sandstedt on LinkedIn')}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Connect on LinkedIn
          </Button>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-24 bg-white">
        <motion.div 
          className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y:20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Ready to Accelerate Your Growth?</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8">
            Ready to accelerate your growth? Let's connect.
          </p>
          <Button asChild size="lg" className="mt-8 bg-gradient-to-r from-teal-600 to-blue-600 text-white hover:from-teal-700 hover:to-blue-700">
            <a href="mailto:admin@mbcpartners.co" className="flex items-center justify-center">
              <Mail className="w-5 h-5 mr-2" />
              Contact Us
            </a>
          </Button>
        </motion.div>
      </section>
    </div>
  );
}
