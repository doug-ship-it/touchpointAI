
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { Search, Users, Shield, Database, Zap, CheckCircle, Upload, Loader2, Trash2, Filter, X, PlusCircle, Share2 } from 'lucide-react';
import { NetworkConnection } from '.@/api/entities/NetworkConnection';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import DataEnrichmentTool from '../components/network/DataEnrichmentTool'; // Keep import for potential future use or if other components still reference it.
import ContactCard from '../components/network/ContactCard';
import Pagination from '../components/network/Pagination';
import PasswordProtectedModal from '../components/network/PasswordProtectedModal';
import { Toaster, toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { cleanConnectionData } from '@/api/functions';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

import ShortlistAuthModal from '../components/network/ShortlistAuthModal';
import ShortlistSidebar from '../components/network/ShortlistSidebar';
import { createShortlist } from '@/api/functions';
import { manageShortlistContact } from '@/api/functions';
import { Badge } from '@/components/ui/badge';

import PathSearchBar from '../components/network/relationship-path/PathSearchBar'; // Keep import for potential future use or if other components still reference it.
import RelationshipPathView from '../components/network/relationship-path/RelationshipPathView'; // Keep import for potential future use or if other components still reference it.
import SmartIntroFeed from '../components/network/relationship-path/SmartIntroFeed'; // Keep import for potential future use or if other components still reference it.
import LinkedInProfileModal from '../components/network/LinkedInProfileModal';

// NEW IMPORTS FOR PRIVACY/SHARING
import NetworkDashboard from '../components/network/NetworkDashboard';
import PrivacyControlledUploadModal from '../components/network/PrivacyControlledUploadModal';
import SharingLinkGenerator from '../components/network/SharingLinkGenerator';
import ContactPrivacyIndicator from '../components/network/ContactPrivacyIndicator';


// Enhanced Upload Button Component (This component is no longer directly used in the main rendering but kept for reference if needed elsewhere)
const EnhancedUploadButton = ({ onFileSelect, className }) => {
  return (
    <Card className={`text-center py-6 px-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 shadow-lg ${className}`}>
      <CardHeader className="p-0 mb-4">
        <CardTitle className="text-2xl font-bold text-blue-800 flex items-center justify-center gap-3">
          <Upload className="w-6 h-6 text-blue-600" />
          Upload Your Connections
        </CardTitle>
        <CardDescription className="text-gray-600 mt-2">
          Get started by importing your contact data from LinkedIn, CRM, or other sources.
          <br />
          <span className="text-sm text-green-600 font-medium">
            🔒 All connections remain private by default - you control what gets shared.
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <Button
          onClick={onFileSelect}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg shadow-md transition-all duration-200 ease-in-out transform hover:scale-105"
        >
          <Upload className="w-5 h-5 mr-2" />
          Import CSV / Excel
        </Button>
      </CardContent>
    </Card>
  );
};

// Enhanced Path Search Bar Component (Now integrated into the main component's JSX with new styling)
const EnhancedPathSearchBar = ({ onSearch, isLoading, allContacts }) => {
  // Example of using allContacts for an enhanced display,
  // the actual PathSearchBar might not directly use this prop for its core search logic.
  const warmIntroCount = useMemo(() => {
    return allContacts.filter(c => ['Strong', 'Medium'].includes(c.relationship_strength)).length;
  }, [allContacts]);

  return (
    <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 shadow-lg border border-gray-200 mb-8 max-w-2xl mx-auto">
      <CardHeader className="p-0 mb-4">
        <CardTitle className="text-xl font-bold text-gray-800 flex items-center gap-2 justify-center">
          <Zap className="w-5 h-5 text-purple-600" />
          Warm Introduction Finder
        </CardTitle>
        <CardDescription className="text-gray-600 text-center mt-2">
          Discover optimal paths to new contacts through your existing network.
          You have <span className="font-semibold text-purple-600">{warmIntroCount}</span> potential warm intro contacts.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <PathSearchBar onSearch={onSearch} isLoading={isLoading} />
      </CardContent>
    </Card>
  );
};

export default function NetworkIntelligenceDeep() {
  const [contacts, setContacts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    company: '', industry: '', location: '', seniority: '', function: '', strength: '', companySize: '', owner: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [resultsPerPage] = useState(25);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false); // Used for PrivacyControlledUploadModal now
  const [user, setUser] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deletionProgress, setDeletionProgress] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  // State variables for password protection
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState(null); // 'deletion'
  const [modalConfig, setModalConfig] = useState({}); // Stores title, description, actionType

  // New shortlist state
  const [selectedContacts, setSelectedContacts] = useState(new Set());
  const [shortlistContacts, setShortlistContacts] = useState([]); // Stores detailed contacts for sidebar
  const [currentShortlist, setCurrentShortlist] = useState(null); // Stores the created shortlist object (id, title, etc.)
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showShortlistSidebar, setShowShortlistSidebar] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Indicates if a shortlist has been authenticated/created
  const [hideSelected, setHideSelected] = useState(false);

  // State for Relationship Path feature - these states are now unused but kept in comments for context of removal
  // const [pathSearchTarget, setPathSearchTarget] = useState(null);
  // const [isPathSearching, setIsPathSearching] = useState(false);
  
  const [isLinkedInModalOpen, setIsLinkedInModalOpen] = useState(false); // This modal is still used, but the useEffect to auto-open is removed.

  // const searchSectionRef = useRef(null); // Removed: Create a ref for the search section

  // Removed: handleNavigateToSearch function
  // const handleNavigateToSearch = () => {
  //   searchSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  //   resetPathSearch();
  // };

  // Removed: useEffect to auto-open LinkedIn modal
  // useEffect(() => {
  //   if (sessionStorage.getItem('linkedInModalShown')) {
  //     return;
  //   }
  //   const timer = setTimeout(() => {
  //     setIsLinkedInModalOpen(true);
  //     sessionStorage.setItem('linkedInModalShown', 'true');
  //   }, 7000);
  //   return () => clearTimeout(timer);
  // }, []);


  // CHANGED: Set 'contacts' as default view instead of 'dashboard'
  const [view, setView] = useState('contacts');
  const [sharingModalOpen, setSharingModalOpen] = useState(false);
  const [sharingStats, setSharingStats] = useState({
    activeLinkCount: 0,
    totalViews: 0,
    enrichmentCount: 0,
    collaboratorCount: 0
  });

  // New component for the prominent shortlist button, defined inside the page for simplicity
  const SaveToShortlistButton = ({ onClick, isAdded, isFirstContact }) => {
    const [isPulsing, setIsPulsing] = useState(isFirstContact);

    useEffect(() => {
      if (isFirstContact) {
        const timer = setTimeout(() => setIsPulsing(false), 5000);
        return () => clearTimeout(timer);
      }
    }, [isFirstContact]);

    return (
      <div className="relative group">
        <motion.button
          className={`
            relative w-12 h-12 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center
            ${isAdded
              ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white'
              : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700'
            }
            ${isPulsing ? 'animate-pulse-glow' : ''}
          `}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={onClick}
        >
          <motion.div
            initial={false}
            animate={isAdded ? { rotate: 360 } : { rotate: 0 }}
            transition={{ duration: 0.4 }}
            className="flex items-center justify-center"
          >
            {isAdded ? (
              <CheckCircle className="w-6 h-6" />
            ) : (
              <PlusCircle className="w-6 h-6" />
            )}
          </motion.div>

          {isPulsing && !isAdded && (
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 animate-ping opacity-75" />
          )}
        </motion.button>
        <div className="absolute top-full mt-2 -right-4 w-max bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
          Save to Shortlist
        </div>
      </div>
    );
  };


  // Enhanced mapping functions from the provided code
  const mapFunction = useCallback((title) => {
    if (!title) return 'Business Development';
    const titleLower = title.toLowerCase();

    // Finance & Accounting
    if (titleLower.includes('cfo') || titleLower.includes('finance') || titleLower.includes('financial') || titleLower.includes('treasurer') || titleLower.includes('fp&a') || titleLower.includes('budget')) return 'Finance';
    if (titleLower.includes('accounting') || titleLower.includes('accountant') || titleLower.includes('bookkeeper') || titleLower.includes('controller') || titleLower.includes('audit')) return 'Accounting';

    // Engineering & Technical
    if (titleLower.includes('engineer') || titleLower.includes('developer') || titleLower.includes('architect') || titleLower.includes('technical') || titleLower.includes('cto') || titleLower.includes('programming') || titleLower.includes('software') || titleLower.includes('devops') || titleLower.includes('sre') || titleLower.includes('fullstack') || titleLower.includes('frontend') || titleLower.includes('backend')) return 'Engineering';
    if (titleLower.includes('it ') || titleLower.includes('information technology') || titleLower.includes('systems') || titleLower.includes('network') || titleLower.includes('infrastructure') || titleLower.includes('cybersecurity') || titleLower.includes('security')) return 'Information Technology';

    // Leadership & Management
    if (titleLower.includes('ceo') || titleLower.includes('founder') || titleLower.includes('owner') || titleLower.includes('entrepreneur') || titleLower.includes('president')) return 'Entrepreneurship';
    if (titleLower.includes('operations') || titleLower.includes('coo') || titleLower.includes('logistics') || titleLower.includes('supply chain') || titleLower.includes('process') || titleLower.includes('manufacturing')) return 'Operations';

    // Sales & Marketing
    if (titleLower.includes('sales') || titleLower.includes('cro') || titleLower.includes('revenue') || titleLower.includes('account executive') || titleLower.includes('business development') || titleLower.includes('bdr') || titleLower.includes('sdr') || titleLower.includes('account manager')) return 'Sales';
    if (titleLower.includes('marketing') || titleLower.includes('cmo') || titleLower.includes('brand') || titleLower.includes('promotion') || titleLower.includes('advertising') || titleLower.includes('digital marketing') || titleLower.includes('growth') || titleLower.includes('demand gen')) return 'Marketing';

    // Product & Design
    if (titleLower.includes('product') || titleLower.includes('cpo') || titleLower.includes('product manager') || titleLower.includes('product owner') || titleLower.includes('pm')) return 'Product Management';
    if (titleLower.includes('design') || titleLower.includes('creative') || titleLower.includes('ux') || titleLower.includes('ui') || titleLower.includes('graphic') || titleLower.includes('visual') || titleLower.includes('art director')) return 'Arts and Design';

    // Human Resources & People
    if (titleLower.includes('hr') || titleLower.includes('human resources') || titleLower.includes('people') || titleLower.includes('talent') || titleLower.includes('recruiting') || titleLower.includes('recruiter') || titleLower.includes('chief people officer') || titleLower.includes('people operations')) return 'Human Resources';

    // Consulting & Strategy
    if (titleLower.includes('consultant') || titleLower.includes('advisory') || titleLower.includes('strategy') || titleLower.includes('consulting') || titleLower.includes('strategic') || titleLower.includes('principal')) return 'Consulting';

    // Legal & Compliance
    if (titleLower.includes('legal') || titleLower.includes('attorney') || titleLower.includes('lawyer') || titleLower.includes('counsel') || titleLower.includes('compliance') || titleLower.includes('regulatory') || titleLower.includes('general counsel')) return 'Legal';

    // Research & Analytics
    if (titleLower.includes('research') || titleLower.includes('scientist') || titleLower.includes('analyst') || titleLower.includes('data') || titleLower.includes('analytics') || titleLower.includes('machine learning') || titleLower.includes('ai') || titleLower.includes('statistician')) return 'Research';

    // Project Management
    if (titleLower.includes('project') || titleLower.includes('program') || titleLower.includes('scrum') || titleLower.includes('agile') || titleLower.includes('delivery') || titleLower.includes('pmo') || titleLower.includes('project manager')) return 'Program and Project Management';

    // Support & Services
    if (titleLower.includes('support') || titleLower.includes('customer service') || titleLower.includes('help desk') || titleLower.includes('customer success') || titleLower.includes('technical support') || titleLower.includes('customer experience')) return 'Support';
    if (titleLower.includes('healthcare') || titleLower.includes('medical') || titleLower.includes('clinical') || titleLower.includes('nurse') || titleLower.includes('doctor') || titleLower.includes('physician')) return 'Healthcare Services';

    // Education
    if (titleLower.includes('professor') || titleLower.includes('teacher') || titleLower.includes('education') || titleLower.includes('instructor') || titleLower.includes('academic') || titleLower.includes('dean') || titleLower.includes('faculty')) return 'Education';

    // Administrative
    if (titleLower.includes('admin') || titleLower.includes('assistant') || titleLower.includes('coordinator') || titleLower.includes('secretary') || titleLower.includes('executive assistant') || titleLower.includes('office manager')) return 'Administrative';

    // Media & Communication
    if (titleLower.includes('media') || titleLower.includes('communication') || titleLower.includes('public relations') || titleLower.includes('journalism') || titleLower.includes('content') || titleLower.includes('pr') || titleLower.includes('communications')) return 'Media and Communication';

    // Quality & Testing
    if (titleLower.includes('quality') || titleLower.includes('qa') || titleLower.includes('testing') || titleLower.includes('assurance') || titleLower.includes('qe') || titleLower.includes('test engineer')) return 'Quality Assurance';

    // Purchasing & Procurement
    if (titleLower.includes('purchasing') || titleLower.includes('procurement') || titleLower.includes('buyer') || titleLower.includes('sourcing') || titleLower.includes('vendor') || titleLower.includes('supply')) return 'Purchasing';

    // Real Estate
    if (titleLower.includes('real estate') || titleLower.includes('property') || titleLower.includes('realtor') || titleLower.includes('facilities') || titleLower.includes('workplace') || titleLower.includes('facility')) return 'Real Estate';

    // Security & Military
    if (titleLower.includes('security') || titleLower.includes('military') || titleLower.includes('protection') || titleLower.includes('risk') || titleLower.includes('safety') || titleLower.includes('guard')) return 'Military and Protective Services';

    // Community Services
    if (titleLower.includes('community') || titleLower.includes('social') || titleLower.includes('nonprofit') || titleLower.includes('volunteer') || titleLower.includes('ngo') || titleLower.includes('charity')) return 'Community and Social Services';

    return 'Business Development';
  }, []);

  const mapSeniority = useCallback((title) => {
    if (!title) return 'Entry Level';
    const titleLower = title.toLowerCase();

    if (titleLower.includes('ceo') || titleLower.includes('cfo') || titleLower.includes('cto') || titleLower.includes('cmo') || titleLower.includes('coo') || titleLower.includes('chief') || titleLower.includes('cpo') || titleLower.includes('cro')) return 'CXO';
    if (titleLower.includes('founder') || titleLower.includes('owner') || titleLower.includes('partner') || titleLower.includes('co-founder') || titleLower.includes('managing partner')) return 'Owner / Partner';
    if (titleLower.includes('vp') || titleLower.includes('vice president') || titleLower.includes('svp') || titleLower.includes('senior vice president') || titleLower.includes('evp')) return 'Vice President';
    if (titleLower.includes('director') || titleLower.includes('head of') || titleLower.includes('senior director')) return 'Director';
    if (titleLower.includes('principal') || titleLower.includes('lead') || titleLower.includes('senior manager') || titleLower.includes('department head')) return 'Strategic';
    if (titleLower.includes('senior') && !titleLower.includes('manager') && !titleLower.includes('director')) return 'Senior';
    if (titleLower.includes('manager') || titleLower.includes('supervisor')) return 'Experienced Manager';
    if (titleLower.includes('associate') || titleLower.includes('coordinator') || titleLower.includes('jr ') || titleLower.includes('junior')) return 'Entry Level Manager';
    if (titleLower.includes('intern') || titleLower.includes('trainee') || titleLower.includes('apprentice')) return 'In Training';
    return 'Entry Level';
  }, []);

  const mapCompanySize = useCallback((company) => {
    if (!company) return '51-200 employees (Growing Company)';

    // Fortune 500 / Global Enterprise (10,000+ employees)
    const fortune500 = [
      'Microsoft', 'Amazon', 'Google', 'Apple', 'Meta', 'Salesforce', 'Oracle', 'Adobe', 'IBM', 'Cisco',
      'Intel', 'HP', 'Dell', 'Walmart', 'Boeing', 'General Electric', 'Johnson & Johnson', 'Pfizer',
      'Ford', 'General Motors', 'AT&T', 'Verizon', 'Comcast', 'Disney', 'Netflix', 'Tesla',
      'McKinsey & Company', 'Bain & Company', 'Boston Consulting Group', 'Deloitte', 'PwC', 'EY', 'KPMG',
      'Goldman Sachs', 'JPMorgan Chase', 'Morgan Stanley', 'Bank of America', 'Wells Fargo', 'Citigroup',
      'Blackstone', 'KKR', 'Carlyle Group', 'American Express', 'Visa', 'Mastercard', 'PayPal',
      'UnitedHealth', 'CVS Health', 'Anthem', 'Humana', 'Aetna', 'Kaiser Permanente',
      'ExxonMobil', 'Chevron', 'ConocoPhillips', 'Marathon Petroleum', 'Valero Energy',
      'Home Depot', 'Lowe\'s', 'Target', 'Costco', 'Best Buy', 'Macy\'s', 'Nordstrom',
      'FedEx', 'UPS', 'DHL', 'Lockheed Martin', 'Raytheon', 'Northrop Grumman',
      'Coca-Cola', 'PepsiCo', 'Procter & Gamble', 'Unilever', 'Nestlé', 'Kraft Heinz',
      'McDonald\'s', 'Starbucks', 'Yum! Brands', 'Subway', 'Marriott', 'Hilton'
    ];

    // Large Enterprise (5,001-10,000 employees)
    const largeEnterprise = [
      'Snowflake', 'Databricks', 'Palantir', 'ServiceNow', 'Workday', 'VMware', 'Splunk',
      'Okta', 'Twilio', 'MongoDB', 'Elastic', 'Confluent', 'Datadog', 'New Relic',
      'Zoom', 'Slack', 'Atlassian', 'JetBrains', 'GitLab', 'GitHub',
      'Uber', 'Lyft', 'Airbnb', 'DoorDash', 'Instacart', 'Grubhub', 'Postmates',
      'Stripe', 'Square', 'Coinbase', 'Robinhood', 'Chime', 'Credit Karma',
      'Peloton', 'Mirror', 'ClassPass', 'SoulCycle', 'Equinox', 'Planet Fitness',
      'Chewy', 'Wayfair', 'Overstock', 'Etsy', 'eBay', 'Shopify', 'BigCommerce',
      'Roku', 'Hulu', 'Spotify', 'Pandora', 'SiriusXM', 'iHeartMedia',
      'Unity', 'Epic Games', 'Roblox', 'Zynga', 'Electronic Arts', 'Activision Blizzard'
    ];

    // Enterprise (1,001-5,000 employees)
    const enterprise = [
      'Box', 'Dropbox', 'DocuSign', 'Zendesk', 'HubSpot', 'Marketo', 'Pardot',
      'Tableau', 'Looker', 'Sisense', 'Qlik', 'Domo', 'ThoughtSpot',
      'Asana', 'Monday.com', 'Notion', 'Airtable', 'Smartsheet', 'Wrike',
      'Figma', 'Sketch', 'InVision', 'Adobe XD', 'Canva', 'Webflow',
      'Vercel', 'Netlify', 'Heroku', 'DigitalOcean', 'Linode', 'Vultr',
      'Auth0', 'Firebase', 'Supabase', 'PlanetScale', 'Neon', 'Railway',
      'Segment', 'Mixpanel', 'Amplitude', 'Heap', 'Hotjar', 'FullStory',
      'Intercom', 'Drift', 'Crisp', 'Freshworks', 'Zoho', 'Pipedrive',
      'Toast', 'Resy', 'OpenTable', 'Yelp', 'TripAdvisor', 'Expedia',
      'WeWork', 'Regus', 'IWG', 'Knotel', 'Industrious', 'Convene'
    ];

    // Large Company (501-1,000 employees)
    const largeCompany = [
      'Clearbit', 'ZoomInfo', 'Apollo', 'Outreach', 'SalesLoft', 'Gong',
      'Calendly', 'Acuity Scheduling', 'When2meet', 'Doodle', 'Schedulicity',
      'Loom', 'Camtasia', 'ScreenFlow', 'OBS Studio', 'Riverside',
      'Linear', 'Height', 'ClickUp', 'Basecamp', 'Trello', 'Todoist',
      'Miro', 'Mural', 'Whimsical', 'LucidChart', 'Draw.io', 'Creately',
      'Retool', 'Bubble', 'Zapier', 'Integromat', 'Automate.io', 'IFTTT',
      'Postman', 'Insomnia', 'Paw', 'HTTPie', 'curl', 'Thunder Client',
      'Sentry', 'Rollbar', 'Bugsnag', 'Airbrake', 'Honeybadger', 'LogRocket'
    ];

    // Mid-Size Company (201-500 employees)
    const midSize = [
      'Cohere', 'OpenAI', 'Anthropic', 'Hugging Face', 'Stability AI',
      'Midjourney', 'RunwayML', 'Jasper', 'Copy.ai', 'Writesonic',
      'Temporal', 'Inngest', 'Trigger.dev', 'Windmill', 'Airplane',
      'Plaid', 'Yodlee', 'Finicity', 'MX', 'Tink', 'TrueLayer',
      'Discord', 'Telegram', 'Signal', 'WhatsApp Business', 'Viber',
      'TikTok', 'Snapchat', 'Pinterest', 'Reddit', 'Tumblr'
    ];

    // Growing Company (51-200 employees)
    const growing = [
      'Cal.com', 'Mintlify', 'Resend', 'Upstash', 'Clerk', 'NextAuth',
      'Prisma', 'Drizzle', 'tRPC', 'Zod', 'Valibot', 'Yup',
      'Framer', 'Spline', 'Rive', 'Lottie', 'After Effects', 'Cinema 4D',
      'Cursor', 'Replit', 'CodeSandbox', 'StackBlitz', 'Glitch', 'Codepen'
    ];

    // Small Startup (11-50 employees)
    const smallStartup = [
      'v0', 'Replicate', 'Modal', 'RunPod', 'Banana', 'Baseten',
      'Weights & Biases', 'Neptune', 'MLflow', 'Kubeflow', 'Feast'
    ];

    const companyLower = company.toLowerCase();
    if (fortune500.some(c => companyLower.includes(c.toLowerCase()))) return '10,000+ employees (Fortune 500/Global Enterprise)';
    if (largeEnterprise.some(c => companyLower.includes(c.toLowerCase()))) return '5,001-10,000 employees (Large Enterprise)';
    if (enterprise.some(c => companyLower.includes(c.toLowerCase()))) return '1,001-5,000 employees (Enterprise)';
    if (largeCompany.some(c => companyLower.includes(c.toLowerCase()))) return '501-1,000 employees (Large Company)';
    if (midSize.some(c => companyLower.includes(c.toLowerCase()))) return '201-500 employees (Mid-Size Company)';
    if (growing.some(c => companyLower.includes(c.toLowerCase()))) return '51-200 employees (Growing Company)';
    if (smallStartup.some(c => companyLower.includes(c.toLowerCase()))) return '11-50 employees (Small Startup)';

    return '51-200 employees (Growing Company)'; // Default for unknown companies
  }, []);

  const mapIndustry = useCallback((company, title) => {
    if (!company && !title) return 'Technology';

    const companyLower = (company || '').toLowerCase();
    const titleLower = (title || '').toLowerCase();

    // Technology
    if (['microsoft', 'apple', 'google', 'meta', 'amazon', 'netflix', 'tesla', 'uber', 'airbnb', 'oracle', 'sap', 'ibm', 'intel', 'cisco', 'salesforce', 'adobe', 'nvidia', 'qualcomm', 'broadcom', 'amd', 'hp', 'dell', 'lenovo', 'sony', 'samsung', 'huawei'].some(c => companyLower.includes(c)) ||
      titleLower.includes('software') || titleLower.includes('tech') || titleLower.includes('developer') || titleLower.includes('engineer')) return 'Technology';

    // Consulting
    if (['mckinsey', 'bain', 'bcg', 'deloitte', 'pwc', 'ey', 'kpmg', 'accenture', 'capgemini', 'wipro', 'tata consultancy services', 'cognizant'].some(c => companyLower.includes(c)) || titleLower.includes('consultant') || titleLower.includes('advisory')) return 'Business Consulting and Services';

    // Financial Services
    if (['goldman', 'jpmorgan', 'morgan stanley', 'blackstone', 'kkr', 'carlyle', 'bank', 'capital', 'investment', 'ventures', 'fidelity', 'vanguard', 'schwab', 'visa', 'mastercard', 'american express'].some(c => companyLower.includes(c)) || titleLower.includes('finance') || titleLower.includes('financial') || titleLower.includes('banking')) return 'Financial Services';

    // Healthcare
    if (['johnson', 'pfizer', 'moderna', 'healthcare', 'medical', 'pharma', 'hospital', 'astrazeneca', 'gilead', 'novartis', 'roche', 'merck', 'abbott', 'medtronic'].some(c => companyLower.includes(c)) || titleLower.includes('healthcare') || titleLower.includes('medical') || titleLower.includes('pharmaceutical')) return 'Hospitals and Health Care';

    // Professional Services (general)
    if (companyLower.includes('llc') || companyLower.includes('group') || companyLower.includes('advisors') || companyLower.includes('services') || companyLower.includes('law firm') || companyLower.includes('accounting firm')) return 'Professional Services';

    // Education
    if (companyLower.includes('university') || companyLower.includes('college') || companyLower.includes('school') || titleLower.includes('professor') || titleLower.includes('lecturer') || titleLower.includes('educator')) return 'Higher Education';

    // Retail
    if (companyLower.includes('retail') || companyLower.includes('store') || companyLower.includes('shop') || companyLower.includes('target') || companyLower.includes('walmart') || companyLower.includes('costco') || titleLower.includes('retail')) return 'Retail';

    // Manufacturing
    if (companyLower.includes('manufacturing') || companyLower.includes('factory') || companyLower.includes('production') || companyLower.includes('industrial') || companyLower.includes('general motors') || companyLower.includes('ford') || companyLower.includes('toyota') || titleLower.includes('manufacturing')) return 'Manufacturing';

    // Media & Telecommunications
    if (companyLower.includes('media') || companyLower.includes('entertainment') || companyLower.includes('studio') || companyLower.includes('disney') || companyLower.includes('netflix') || companyLower.includes('warner bros') || companyLower.includes('at&t') || companyLower.includes('verizon') || companyLower.includes('comcast') || titleLower.includes('journalist') || titleLower.includes('editor') || titleLower.includes('telecommunications')) return 'Media and Telecommunications';

    // Government / Public Administration
    if (companyLower.includes('government') || companyLower.includes('public sector') || companyLower.includes('federal') || companyLower.includes('state') || companyLower.includes('city') || titleLower.includes('government')) return 'Government Administration';

    // Automotive
    if (companyLower.includes('automotive') || companyLower.includes('tesla') || companyLower.includes('ford') || companyLower.includes('general motors') || companyLower.includes('toyota') || companyLower.includes('honda') || companyLower.includes('bmw') || companyLower.includes('mercedes') || titleLower.includes('automotive')) return 'Automotive';

    // Real Estate
    if (companyLower.includes('real estate') || companyLower.includes('realty') || companyLower.includes('brokerage') || titleLower.includes('real estate') || titleLower.includes('realtor')) return 'Real Estate';

    // Food & Beverage
    if (companyLower.includes('food') || companyLower.includes('beverage') || companyLower.includes('restaurant') || companyLower.includes('hospitality') || companyLower.includes('coca-cola') || companyLower.includes('pepsi') || titleLower.includes('chef') || titleLower.includes('restaurateur')) return 'Food & Beverages';

    return 'Technology'; // Default to Technology if no specific match
  }, []);

  // Helper function to normalize location data
  const normalizeLocation = useCallback((location) => {
    if (!location) return '';

    const locationMappings = {
      'ny': 'New York',
      'ca': 'California',
      'tx': 'Texas',
      'fl': 'Florida',
      'il': 'Illinois',
      'wa': 'Washington',
      'ma': 'Massachusetts',
      'ga': 'Georgia',
      'nc': 'North Carolina',
      'va': 'Virginia',
      'nyc': 'New York, NY',
      'sf': 'San Francisco, CA',
      'la': 'Los Angeles, CA',
      'chi': 'Chicago, IL',
      'bos': 'Boston, MA',
      'sea': 'Seattle, WA',
      'atl': 'Atlanta, GA',
      'mia': 'Miami, FL',
      'dal': 'Dallas, TX',
      'hou': 'Houston, TX',
      'usa': 'United States',
      'us': 'United States',
      'uk': 'United Kingdom',
      'uae': 'United Arab Emirates'
    };

    const cleaned = location.trim().toLowerCase();
    return locationMappings[cleaned] || location.trim();
  }, []);

  const fetchContacts = useCallback(async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    setError(null);
    try {
      const connections = await NetworkConnection.list('-updated_date');

      // Enhanced connections processing with better error handling
      const enhancedConnections = connections.map(contact => {
        try {
          // Clean special characters from names for better searching
          const cleanedName = contact.connection_name ?
            contact.connection_name.replace(/[^\w\s\-']/g, '').trim() : '';

          const mappedFunc = mapFunction(contact.connection_title);
          const mappedSenior = mapSeniority(contact.connection_title);
          const mappedInd = mapIndustry(contact.connection_company, contact.connection_title);
          const mappedSize = mapCompanySize(contact.connection_company);

          // Enhanced location processing
          const cleanedLocation = contact.enriched_location ?
            normalizeLocation(contact.enriched_location) : '';

          // Create comprehensive search index with cleaned data
          const searchIndex = [
            cleanedName,
            contact.connection_title,
            contact.connection_company,
            contact.enriched_industry,
            contact.enriched_function,
            cleanedLocation,
            contact.enriched_seniority,
            contact.company_size,
            contact.notes,
            contact.intelligent_summary,
            mappedFunc,
            mappedSenior,
            mappedInd,
            mappedSize,
            contact.user_email
          ].filter(Boolean).join(' ').toLowerCase();

          return {
            ...contact,
            connection_name: cleanedName || contact.connection_name,
            mappedFunction: mappedFunc,
            mappedSeniority: mappedSenior,
            mappedIndustry: mappedInd,
            mappedCompanySize: mappedSize,
            enriched_location: cleanedLocation || contact.enriched_location,
            searchIndex,
            // Assuming sharingStatus might come from backend or default to 'private'
            sharingStatus: contact.sharingStatus || 'private'
          };
        } catch (error) {
          console.warn(`Error processing contact ${contact.id || contact.connection_name || 'unknown'}:`, error);
          // Return original contact if processing fails, with a basic search index
          return {
            ...contact,
            searchIndex: [
              contact.connection_name,
              contact.connection_company,
              contact.connection_title
            ].filter(Boolean).join(' ').toLowerCase(),
            sharingStatus: contact.sharingStatus || 'private'
          };
        }
      }).filter(Boolean); // Remove any null/undefined contacts

      setContacts(enhancedConnections || []);
    } catch (e) {
      console.error('Failed to load connections:', e);
      setError('Unable to load network data. Please refresh the page.');
      toast.error('Failed to load connections.');
      setContacts([]);
    } finally {
      if (showLoading) setIsLoading(false);
    }
  }, [mapFunction, mapSeniority, mapIndustry, mapCompanySize, normalizeLocation]);

  useEffect(() => {
    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        await fetchContacts(false);
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (e) {
        console.warn("Not logged in, proceeding with public access.");
      } finally {
        setIsLoading(false);
      }
    };
    loadInitialData();
  }, [fetchContacts]);

  // Removed: handlePathSearch, resetPathSearch
  // const handlePathSearch = async (searchTerm) => {
  //   setIsPathSearching(true);
  //   const lowerCaseSearch = searchTerm.toLowerCase();
  //   const target = contacts.find(c =>
  //     (c.connection_name && c.connection_name.toLowerCase().includes(lowerCaseSearch)) ||
  //     (c.connection_company && c.connection_company.toLowerCase().includes(lowerCaseSearch)) ||
  //     (c.linkedin_url && c.linkedin_url.includes(lowerCaseSearch))
  //   );

  //   if (target) {
  //     setPathSearchTarget(target);
  //   } else {
  //     toast.error(`Could not find a contact matching "${searchTerm}".`);
  //   }
  //   await new Promise(resolve => setTimeout(resolve, 500));
  //   setIsPathSearching(false);
  // };

  // const resetPathSearch = () => {
  //   setPathSearchTarget(null);
  // };

  // Modified handleDeleteAllConnections to trigger password modal
  const handleDeleteAllConnections = () => {
    setModalConfig({
      title: "Confirm Data Deletion",
      description: "This is irreversible. Enter admin password to delete all network connections permanently.",
      actionType: "deletion"
    });
    setPendingAction('deletion');
    setIsPasswordModalOpen(true);
  };

  // The actual deletion logic, now called after successful password entry
  const executeDeleteAllConnections = async () => {
    const totalToDelete = contacts.length;
    if (totalToDelete === 0) {
      toast.info("No connections to delete.");
      return;
    }
    const confirmation = window.confirm(
      `⚠️ PERMANENT DELETION WARNING ⚠️\n\nThis will permanently delete ALL ${totalToDelete.toLocaleString()} network connections.\n\nThis action CANNOT be undone.\n\nAre you absolutely sure?`
    );

    if (!confirmation) {
      toast.info("Deletion cancelled.");
      return;
    }

    setIsDeleting(true);
    setDeletionProgress({ deleted: 0, total: totalToDelete });
    let totalDeletedThisSession = 0;
    let batchCount = 0;
    let adaptiveBatchSize = 50; // Start with a reasonable batch size

    const toastId = toast.loading(
      `Starting deletion of ${totalToDelete.toLocaleString()} connections...`
    );

    try {
      let isComplete = false;

      // Limit total batches to prevent infinite loops on persistent errors
      while (!isComplete && batchCount < 500) {
        batchCount++;

        try {
          const response = await cleanConnectionData({ batchSize: adaptiveBatchSize });

          if (response.data && response.data.success !== false) { // Check for explicit failure
            const recordsDeleted = response.data.recordsDeleted || 0;
            const recordsFailed = response.data.recordsFailed || 0;
            totalDeletedThisSession += recordsDeleted;
            isComplete = response.data.isComplete;

            // Adapt batch size based on performance
            if (recordsFailed === 0 && adaptiveBatchSize < 100) {
              adaptiveBatchSize = Math.min(adaptiveBatchSize + 10, 100); // Increase if successful
            } else if (recordsFailed > 0) {
              adaptiveBatchSize = Math.max(adaptiveBatchSize - 10, 10); // Decrease if errors
            }

            setDeletionProgress(prev => ({
              ...prev,
              deleted: totalDeletedThisSession
            }));

            toast.loading(
              `Batch ${batchCount}: Deleted ${totalDeletedThisSession.toLocaleString()} / ${totalToDelete.toLocaleString()} connections`,
              { id: toastId }
            );

            if (recordsDeleted === 0 && !isComplete && recordsFailed === 0) {
              isComplete = true;
              break;
            }
          } else {
            throw new Error(response.data?.error || 'Batch deletion returned an error');
          }
        } catch (batchError) {
          console.error(`Batch ${batchCount} failed:`, batchError);

          // Reduce batch size significantly on error and pause
          adaptiveBatchSize = Math.max(Math.floor(adaptiveBatchSize / 2), 10);
          toast.loading(
            `Batch ${batchCount} failed. Pausing and reducing batch size to ${adaptiveBatchSize}...`,
            { id: toastId, description: `Error: ${batchError.message || 'API error'}` }
          );

          // Pause for a few seconds to let rate limits cool down
          await new Promise(resolve => setTimeout(resolve, 3000));

          if (batchCount >= 20) { // Give up after more attempts
            throw new Error("Multiple consecutive batches failed. Aborting deletion.");
          }
        }
      }

      toast.success("🎉 Database Cleared Successfully!", {
        id: toastId,
        description: `Deleted ${totalDeletedThisSession.toLocaleString()} network connections in ${batchCount} batches.`,
        duration: 8000,
      });

      setContacts([]);
      setCurrentPage(1);
      setSearchTerm('');
      setFilters({ company: '', industry: '', location: '', seniority: '', function: '', strength: '', companySize: '', owner: '' });

    } catch (error) {
      console.error("Deletion failed:", error);
      toast.error("❌ Deletion Failed", {
        id: toastId,
        description: `Error: ${error.message || 'Unknown error occurred'}. Deleted ${totalDeletedThisSession} records before failure.`,
        duration: 10000
      });
    } finally {
      setIsDeleting(false);
      setDeletionProgress(null);

      // Re-fetch contacts after a short delay to ensure UI consistency
      setTimeout(() => {
        fetchContacts(false);
      }, 1000);
    }
  };

  // Add handler for removing placeholder contacts
  const handleRemovePlaceholders = async () => {
    if (user?.role !== 'admin') {
      toast.error('Admin access required to remove placeholder contacts');
      return;
    }

    const confirmation = window.confirm(
      'This will remove all placeholder/demo contacts (Laura Blue, David Black, Sarah Green, etc.). Continue?'
    );

    if (!confirmation) return;

    setIsLoading(true);
    try {
      const { removePlaceholderContacts } = await import('@/api/functions');
      const response = await removePlaceholderContacts({});
      
      if (response.data.success) {
        toast.success(`Removed ${response.data.totalDeleted} placeholder contacts`);
        await fetchContacts(false); // Refresh the contact list
      } else {
        toast.error(response.data.error || 'Failed to remove placeholder contacts');
      }
    } catch (error) {
      console.error('Error removing placeholder contacts:', error);
      toast.error('Failed to remove placeholder contacts');
    } finally {
      setIsLoading(false);
    }
  };

  // Removed: handleRequestPasswordAccess function (for enrichment)
  // const handleRequestPasswordAccess = (actionType) => {
  //   if (actionType === 'enrichment') {
  //     setModalConfig({
  //       title: "AI Enrichment Access",
  //       description: "Enter admin password to access advanced AI enrichment features for this session.",
  //       actionType: "enrichment"
  //     });
  //     setPendingAction('enrichment');
  //     setIsPasswordModalOpen(true);
  //   }
  // };

  const handlePasswordSuccess = () => {
    if (pendingAction === 'deletion') {
      executeDeleteAllConnections();
    }
    // Removed: else if (pendingAction === 'enrichment') logic
    // else if (pendingAction === 'enrichment') {
    //   setHasEnrichmentAccess(true); // Grant access to enrichment features for the session
    //   toast.success("Access Granted! Advanced AI Enrichment features are now available for this session.");
    // }
    setPendingAction(null); // Clear pending action after success
    setIsPasswordModalOpen(false); // Close the modal
  };

  // Shortlist management functions
  const handleAuthenticate = async (authData) => {
    try {
      const response = await createShortlist({
        ...authData,
        title: `${authData.company || 'My'} Strategic Network` // Use company if provided, else a default
      });

      if (response.data.success) {
        setCurrentShortlist(response.data.shortlist);
        setIsAuthenticated(true);
        setShowAuthModal(false);

        // Add any pre-selected contacts to the shortlist
        if (selectedContacts.size > 0) {
          const contactsToAdd = Array.from(selectedContacts).map(id => contacts.find(c => c.id === id)).filter(Boolean);
          await addContactsToShortlist(contactsToAdd);
        }

        toast.success(`Shortlist "${response.data.shortlist.title}" created! Welcome to strategic network intelligence.`);
      } else {
        toast.error(response.data.message || 'Failed to create shortlist. Please try again.');
      }
    } catch (error) {
      console.error('Authentication failed:', error);
      toast.error('Failed to create shortlist. Please try again.');
    }
  };

  const addContactsToShortlist = async (contactsToAdd) => {
    if (!currentShortlist) {
      toast.error("No active shortlist to add contacts to.");
      return;
    }

    for (const contact of contactsToAdd) {
      try {
        const response = await manageShortlistContact({
          shortlistId: currentShortlist.id,
          contactId: contact.id,
          action: 'add',
          contactData: contact,
          category: 'secondary' // Default category
        });

        if (response.data.success) {
          setShortlistContacts(prev => {
            if (!prev.some(c => c.contact_id === contact.id)) { // Prevent duplicates
              return [...prev, {
                contact_id: contact.id,
                ...contact,
                category: response.data.shortlistContact.category || 'secondary', // Use backend category if available
                notes: response.data.shortlistContact.notes || '',
                engagement_score: response.data.shortlistContact.engagement_score // Ensure score is saved
              }];
            }
            return prev;
          });
        }
      } catch (error) {
        console.error('Failed to add contact to shortlist:', error);
        toast.error(`Failed to add ${contact.connection_name} to shortlist.`);
      }
    }
  };

  const handleToggleContactSelection = async (contact) => {
    const isSelected = selectedContacts.has(contact.id);

    if (!isAuthenticated && !isSelected) {
      // If no shortlist is authenticated and user is trying to select a contact
      // Store the current contact as the initial selection and prompt for authentication
      setSelectedContacts(new Set([contact.id]));
      setShowAuthModal(true);
      return;
    }

    if (isSelected) {
      // Remove from selection and shortlist
      setSelectedContacts(prev => {
        const newSet = new Set(prev);
        newSet.delete(contact.id);
        return newSet;
      });

      if (currentShortlist) {
        try {
          await manageShortlistContact({
            shortlistId: currentShortlist.id,
            contactId: contact.id,
            action: 'remove'
          });
          setShortlistContacts(prev => prev.filter(c => c.contact_id !== contact.id)); // Fix filter logic to remove
          toast.info(`${contact.connection_name} removed from shortlist.`);
        } catch (error) {
          console.error('Failed to remove contact from shortlist:', error);
          toast.error(`Failed to remove ${contact.connection_name} from shortlist.`);
        }
      }
    } else {
      // Add to selection and shortlist
      setSelectedContacts(prev => new Set([...prev, contact.id]));

      if (currentShortlist) {
        await addContactsToShortlist([contact]);
        toast.success(`${contact.connection_name} added to shortlist.`);
      }
    }
  };

  const handleBulkSelection = async (action) => {
    const visibleContacts = paginatedData; // Use paginatedData which already considers hideSelected

    if (action === 'selectAll') {
      const newSelections = new Set([...selectedContacts, ...visibleContacts.map(c => c.id)]);
      setSelectedContacts(newSelections);

      if (currentShortlist) {
        const contactsToBulkAdd = visibleContacts
          .filter(c => !selectedContacts.has(c.id)); // Only add those not already selected
        await addContactsToShortlist(contactsToBulkAdd);
        toast.success(`Added ${contactsToBulkAdd.length} contacts to shortlist.`);
      } else {
        // If no shortlist is authenticated, set for auth modal
        setSelectedContacts(newSelections);
        if (newSelections.size > 0) {
          setShowAuthModal(true);
        }
      }
    } else if (action === 'clearAll') {
      setSelectedContacts(new Set());
      if (currentShortlist) {
        // Remove all contacts from the active shortlist in backend and local state
        const removedCount = shortlistContacts.length;
        for (const contact of shortlistContacts) {
          try {
            await manageShortlistContact({
              shortlistId: currentShortlist.id,
              contactId: contact.contact_id,
              action: 'remove'
            });
          } catch (error) {
            console.error(`Failed to remove ${contact.connection_name} during clearAll:`, error);
          }
        }
        setShortlistContacts([]);
        toast.info(`${removedCount} contacts removed from shortlist.`);
      }
    }
  };

  const handleUpdateContactNotes = async (contactId, notes) => {
    if (!currentShortlist) return;

    try {
      const response = await manageShortlistContact({
        shortlistId: currentShortlist.id,
        contactId: contactId,
        action: 'update',
        notes: notes
      });
      if (response.data.success) {
        setShortlistContacts(prev =>
          prev.map(c => c.contact_id === contactId ? { ...c, notes } : c)
        );
        toast.success("Note updated.");
      } else {
        toast.error("Failed to update note.");
      }
    } catch (error) {
      console.error('Failed to update contact notes:', error);
      toast.error("Failed to update note due to an error.");
    }
  };

  const handleUpdateContactCategory = async (contactId, category) => {
    if (!currentShortlist) return;

    try {
      const response = await manageShortlistContact({
        shortlistId: currentShortlist.id,
        contactId: contactId,
        action: 'update',
        category: category
      });
      if (response.data.success) {
        setShortlistContacts(prev =>
          prev.map(c => c.contact_id === contactId ? { ...c, category } : c)
        );
        toast.success("Category updated.");
      } else {
        toast.error("Failed to update category.");
      }
    } catch (error) {
      console.error('Failed to update contact category:', error);
      toast.error("Failed to update category due to an error.");
    }
  };

  const handleExportShortlist = () => {
    if (shortlistContacts.length === 0) {
      toast.info("No contacts in the shortlist to export.");
      return;
    }

    // Generate CSV export
    const csvContent = [
      'Name,Title,Company,Email,LinkedIn,Category,Notes,Engagement Score',
      ...shortlistContacts.map(contact => [
        `"${contact.connection_name || ''}"`,
        `"${contact.connection_title || ''}"`,
        `"${contact.connection_company || ''}"`,
        `"${contact.connection_email || ''}"`,
        `"${contact.linkedin_url || ''}"`,
        `"${contact.category || ''}"`,
        `"${contact.notes || ''}"`,
        `"${contact.engagement_score || ''}"`
      ].map(field => field.replace(/"/g, '""')).join(',')) // Escape double quotes within fields
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `strategic-shortlist-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success('Shortlist exported successfully!');
  };

  // MODIFIED: handleUploadComplete to stay in contacts view
  const handleUploadComplete = () => {
    fetchContacts();
    setIsCsvModalOpen(false);
    // Stay in contacts view after upload since it's now the primary view
  };

  // NEW: handleCreateSharingLink
  const handleCreateSharingLink = () => {
    if (contacts.length === 0) {
      toast.error('Please import some contacts first before creating sharing links.');
      return;
    }
    setSharingModalOpen(true);
  };

  // NEW: handleSharingLinkCreated
  const handleSharingLinkCreated = (link) => {
    setSharingStats(prev => ({
      ...prev,
      activeLinkCount: prev.activeLinkCount + 1 // This would ideally fetch actual stats from backend
    }));
    setSharingModalOpen(false);
    toast.success(`Sharing link "${link.title}" created successfully!`);
  };

  // Removed: handleEnrichmentComplete function
  // const handleEnrichmentComplete = () => {
  //   fetchContacts();
  // };

  // Enhanced filter options with comprehensive mapping and updated categories
  const filterOptions = useMemo(() => {
    if (!contacts || contacts.length === 0) {
      return {
        companies: [],
        functions: [],
        industries: [],
        locations: [],
        seniorities: [],
        strengths: [],
        companySizes: [],
        owners: []
      };
    }

    const companies = [...new Set(contacts.map(i => i.connection_company).filter(Boolean))].sort();
    const functions = [...new Set([
      ...contacts.map(i => i.enriched_function).filter(Boolean),
      ...contacts.map(i => i.mappedFunction).filter(Boolean)
    ])].sort();

    // Updated seniority levels matching provided categories
    const predefinedSeniorities = [
      "Owner / Partner",
      "CXO",
      "Vice President",
      "Director",
      "Strategic",
      "Senior",
      "Experienced Manager",
      "Entry Level Manager",
      "Entry Level",
      "In Training"
    ];
    const contactSeniorities = [...new Set([
      ...contacts.map(i => i.enriched_seniority).filter(Boolean),
      ...contacts.map(i => i.mappedSeniority).filter(Boolean)
    ])];
    const seniorities = [...new Set([...predefinedSeniorities, ...contactSeniorities])].sort((a, b) => {
      const order = {
        "Owner / Partner": 1,
        "CXO": 2,
        "Vice President": 3,
        "Director": 4,
        "Strategic": 5,
        "Senior": 6,
        "Experienced Manager": 7,
        "Entry Level Manager": 8,
        "Entry Level": 9,
        "In Training": 10
      };
      return (order[a] || 99) - (order[b] || 99);
    });

    const locations = [...new Set(contacts.map(i => i.enriched_location).filter(Boolean))].sort();

    // Updated industry categories matching provided list
    const predefinedIndustries = [
      "Professional Services",
      "Manufacturing",
      "Technology",
      "Information and Media",
      "Financial Services",
      "Government Administration",
      "Hospitals and Health Care",
      "Retail",
      "IT Services and IT Consulting",
      "Technology Information and Internet",
      "Education",
      "Construction",
      "Accommodation Services",
      "Entertainment Providers",
      "Business Consulting and Services",
      "Administrative and Support Services",
      "Transportation, Logistics, and Supply Chain",
      "Consumer Services",
      "Media and Telecommunications",
      "Advertising Services",
      "Software Development",
      "Food and Beverage Services",
      "Machinery Manufacturing",
      "Health and Human Services",
      "Transportation Equipment Manufacturing",
      "Education Administration Programs",
      "Accounting",
      "Credit Intermediation",
      "Higher Education",
      "Chemical Manufacturing",
      "Oil, Gas, and Mining",
      "Banking",
      "Medical Practices",
      "Equipment Rental Services",
      "Real Estate",
      "Wholesale",
      "Recreational Facilities",
      "Motor Vehicle Manufacturing",
      "Wellness and Fitness Services",
      "Appliances, Electrical and Electronics Manufacturing",
      "Design Services",
      "Legal Services",
      "Telecommunications",
      "Hospitality",
      "Primary and Secondary Education",
      "Insurance",
      "Oil and Gas",
      "Research Services",
      "Restaurants",
      "Computers and Electronics Manufacturing",
      "Food and Beverage Manufacturing",
      "Industrial Machinery Manufacturing"
    ];
    const contactIndustries = [...new Set([
      ...contacts.map(i => i.enriched_industry).filter(Boolean),
      ...contacts.map(i => i.mappedIndustry).filter(Boolean)
    ])];
    const industries = [...new Set([...predefinedIndustries, ...contactIndustries])].sort();

    const strengths = [...new Set(contacts.map(i => i.relationship_strength).filter(Boolean))].sort();

    // Updated company size categories matching provided list
    const predefinedCompanySizes = [
      "1-10 employees (Startup/Solo)",
      "11-50 employees (Small Startup)",
      "51-200 employees (Growing Company)",
      "201-500 employees (Mid-Size Company)",
      "501-1,000 employees (Large Company)",
      "1,001-5,000 employees (Enterprise)",
      "5,001-10,000 employees (Large Enterprise)",
      "10,000+ employees (Fortune 500/Global Enterprise)"
    ];
    const contactCompanySizes = [...new Set([
      ...contacts.map(i => i.company_size).filter(Boolean),
      ...contacts.map(i => i.mappedCompanySize).filter(Boolean)
    ])];
    const companySizes = [...new Set([...predefinedCompanySizes, ...contactCompanySizes])].sort((a, b) => {
      // Custom sorting for company sizes
      const getOrder = (size) => {
        if (!size) return 0;
        if (size.includes('1-10')) return 1;
        if (size.includes('11-50')) return 2;
        if (size.includes('51-200')) return 3;
        if (size.includes('201-500')) return 4;
        if (size.includes('501-1,000')) return 5;
        if (size.includes('1,001-5,000')) return 6;
        if (size.includes('5,001-10,000')) return 7;
        if (size.includes('10,000+')) return 8;
        return 0;
      };
      return getOrder(a) - getOrder(b);
    });

    const ownerCounts = contacts.reduce((acc, contact) => {
      if (contact.user_email) {
        acc[contact.user_email] = (acc[contact.user_email] || 0) + 1;
      }
      return acc;
    }, {});

    const owners = Object.entries(ownerCounts).map(([email, count]) => ({
      email,
      count
    })).sort((a, b) => b.count - a.count);

    return { companies, functions, industries, locations, seniorities, strengths, companySizes, owners };
  }, [contacts]);

  // Enhanced filtering with fuzzy matching
  const filteredContacts = useMemo(() => {
    if (!contacts || contacts.length === 0) return [];

    let results = contacts;

    // Enhanced text search with fuzzy matching
    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase().trim();
      const queryWords = query.split(' ').filter(word => word.length > 0);

      results = results.filter(contact => {
        // Check if all query words match somewhere in the contact's search index
        return contact.searchIndex && queryWords.every(word => {
          return contact.searchIndex.includes(word);
        });
      });
    }

    // Apply enhanced filters
    results = results.filter(contact =>
      (!filters.company || contact.connection_company === filters.company) &&
      (!filters.industry || contact.enriched_industry === filters.industry || contact.mappedIndustry === filters.industry) &&
      (!filters.function || contact.enriched_function === filters.function || contact.mappedFunction === filters.function) &&
      (!filters.seniority || contact.enriched_seniority === filters.seniority || contact.mappedSeniority === filters.seniority) &&
      (!filters.location || (contact.enriched_location && contact.enriched_location.toLowerCase().includes(filters.location.toLowerCase()))) &&
      (!filters.strength || contact.relationship_strength === filters.strength) &&
      (!filters.companySize || contact.company_size === filters.companySize || contact.mappedCompanySize === filters.companySize) &&
      (!filters.owner || contact.user_email === filters.owner)
    );

    return results;
  }, [searchTerm, filters, contacts]);

  // Updated filtered contacts to support hiding selected contacts
  const displayedContacts = useMemo(() => {
    let results = filteredContacts;

    if (hideSelected && selectedContacts.size > 0) {
      results = results.filter(contact => !selectedContacts.has(contact.id));
    }

    return results;
  }, [filteredContacts, hideSelected, selectedContacts]);

  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * resultsPerPage;
    return displayedContacts.slice(start, start + resultsPerPage);
  }, [displayedContacts, currentPage, resultsPerPage]);

  const totalPages = Math.ceil(displayedContacts.length / resultsPerPage);

  const totalEstimatedValue = useMemo(() => {
    if (!isAuthenticated) return 0; // Only calculate if authenticated to a shortlist
    let value = 0;
    for (const contact of shortlistContacts) {
      // Basic value calculation based on seniority and company size
      let contactValue = 1000; // Base value
      const seniority = contact.enriched_seniority || contact.mappedSeniority || '';
      if (seniority.includes('CXO')) contactValue *= 5;
      else if (seniority.includes('Vice President')) contactValue *= 3;
      else if (seniority.includes('Director')) contactValue *= 2;

      const companySize = contact.company_size || contact.mappedCompanySize || '';
      if (companySize.includes('10,000+')) contactValue *= 2;
      else if (companySize.includes('1,001-5,000')) contactValue *= 1.5;

      value += contactValue;
    }
    return value;
  }, [shortlistContacts, isAuthenticated]);


  const clearAllFilters = () => {
    setSearchTerm('');
    setFilters({ company: '', industry: '', location: '', seniority: '', function: '', strength: '', companySize: '', owner: '' });
    setCurrentPage(1);
    // Note: Don't hide filters automatically, keep them visible
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/20 to-teal-50/20 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="animate-spin h-16 w-16 text-[var(--primary-teal)] mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Loading Network Data</h2>
          <p className="text-gray-600">Preparing intelligent search capabilities...</p>
        </div>
      </div>
    );
  }

  // UPDATED: Empty state now shows Browse Contacts view with prominent upload
  if (!isLoading && contacts.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
        <PrivacyControlledUploadModal
          isOpen={isCsvModalOpen}
          onClose={() => setIsCsvModalOpen(false)}
          onUploadComplete={handleUploadComplete}
        />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Modern Empty State */}
          <div className="text-center">
            <div className="mx-auto w-32 h-32 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl flex items-center justify-center mb-8 shadow-lg">
              <Users className="w-16 h-16 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Build Your Network Intelligence</h1>
            <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
              Import your professional connections to unlock powerful relationship insights and strategic networking opportunities.
            </p>
            
            {/* Modern Upload Card */}
            <div className="max-w-2xl mx-auto">
              <Card className="border-0 shadow-xl bg-gradient-to-r from-white to-slate-50 backdrop-blur-sm">
                <CardContent className="p-8">
                  <div className="flex items-center justify-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-slate-900">Import Connections</h2>
                  </div>
                  <p className="text-slate-600 mb-6">
                    Upload CSV, Excel, or other contact files from LinkedIn, CRM systems, or any platform.
                  </p>
                  <Button 
                    onClick={() => setIsCsvModalOpen(true)}
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold px-8 py-3 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Get Started
                  </Button>
                  
                  {/* Privacy Badge */}
                  <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-200 rounded-full">
                    <Shield className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-green-800">100% Private by Default</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Feature Preview */}
            <div className="grid md:grid-cols-3 gap-6 mt-16 max-w-4xl mx-auto">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Database className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-bold text-slate-900 mb-2">Smart Organization</h3>
                  <p className="text-sm text-slate-600">Automatically categorize by company, role, and relationship strength</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Share2 className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-slate-900 mb-2">Selective Sharing</h3>
                  <p className="text-sm text-slate-600">Create secure links to collaborate with trusted partners</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Users className="w-6 h-6 text-emerald-600" />
                  </div>
                  <h3 className="font-bold text-slate-900 mb-2">Network Intelligence</h3>
                  <p className="text-sm text-slate-600">Advanced analytics for your professional relationships</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Toaster richColors />
      <LinkedInProfileModal isOpen={isLinkedInModalOpen} onClose={() => setIsLinkedInModalOpen(false)} />
      <style>{`
        @keyframes pulse-glow {
          0%, 100% {
            box-shadow: 0 0 20px rgba(79, 70, 229, 0.4);
          }
          50% {
            box-shadow: 0 0 30px rgba(147, 51, 234, 0.6);
          }
        }
        .animate-pulse-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }
      `}</style>
      <PasswordProtectedModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        onSuccess={handlePasswordSuccess}
        title={modalConfig.title}
        description={modalConfig.description}
        actionType={modalConfig.actionType}
      />

      <ShortlistAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onAuthenticate={handleAuthenticate}
        contactCount={selectedContacts.size}
      />

      <ShortlistSidebar
        isOpen={showShortlistSidebar}
        shortlist={currentShortlist}
        contacts={shortlistContacts}
        onClose={() => setShowShortlistSidebar(false)}
        onRemoveContact={(contactId) => {
          const contact = contacts.find(c => c.id === contactId);
          if (contact) handleToggleContactSelection(contact);
        }}
        onUpdateContactNotes={handleUpdateContactNotes}
        onUpdateContactCategory={handleUpdateContactCategory}
        onExportShortlist={handleExportShortlist}
        onClearAll={() => handleBulkSelection('clearAll')}
        totalEstimatedValue={totalEstimatedValue}
      />

      {/* NEW: Privacy Controlled Upload Modal */}
      <PrivacyControlledUploadModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        onUploadComplete={handleUploadComplete}
      />

      {/* NEW: Sharing Link Generator Modal */}
      <SharingLinkGenerator
        isOpen={sharingModalOpen}
        onClose={() => setSharingModalOpen(false)}
        contacts={contacts}
        onLinkCreated={handleSharingLinkCreated}
      />

      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        {/* Modern Header */}
        <div className="bg-white/80 backdrop-blur-lg border-b border-slate-200/50 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900">Find Connections</h1>
                  <p className="text-slate-600">{contacts.length.toLocaleString()} contacts in your network</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Modern Tab Navigation */}
                <div className="flex bg-slate-100 rounded-2xl p-1">
                  <Button
                    variant={view === 'contacts' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setView('contacts')}
                    className={`rounded-xl px-6 py-2 font-medium transition-all duration-200 ${
                      view === 'contacts' 
                        ? 'bg-white text-slate-900 shadow-sm' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Browse Contacts
                  </Button>
                  <Button
                    variant={view === 'dashboard' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setView('dashboard')}
                    className={`rounded-xl px-6 py-2 font-medium transition-all duration-200 ${
                      view === 'dashboard' 
                        ? 'bg-white text-slate-900 shadow-sm' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Dashboard
                  </Button>
                </div>
                
                {/* Action Buttons */}
                <Button
                  onClick={() => setIsCsvModalOpen(true)}
                  variant="outline"
                  className="border-blue-200 text-blue-700 hover:bg-blue-50 rounded-xl"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Import
                </Button>
                <Button
                  onClick={handleCreateSharingLink}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl shadow-lg"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>

                {/* Admin Actions */}
                {user?.role === 'admin' && (
                  <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
                    <Button
                      onClick={handleRemovePlaceholders}
                      variant="outline"
                      size="sm"
                      className="border-red-200 text-red-700 hover:bg-red-50 rounded-xl text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Remove Demo Data
                    </Button>
                    <Button
                      onClick={handleDeleteAllConnections}
                      variant="outline"
                      size="sm"
                      className="border-red-200 text-red-700 hover:bg-red-50 rounded-xl text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete All
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {view === 'dashboard' ? (
            <NetworkDashboard
              contacts={contacts}
              sharingStats={sharingStats}
              onUploadClick={() => setIsCsvModalOpen(true)}
              onCreateSharingLink={handleCreateSharingLink}
              onViewContacts={() => setView('contacts')}
            />
          ) : (
            <div>
              <AnimatePresence mode="wait">
                {/* Removed: Path search components (RelationshipPathView, PathSearchBar, SmartIntroFeed) */}
                {/* No pathSearchTarget means this block is always rendered now unless the view is 'dashboard' */}
                <motion.div key="main-view" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    {/* Removed: Modern Path Search Card */}
                    {/* Removed: SmartIntroFeed */}
                    {/* Removed: Modern Divider */}

                    {/* Modern Search and Filters */}
                    <div className="scroll-mt-24"> {/* Removed ref={searchSectionRef} */}
                      <Card className="border-0 shadow-lg bg-white/70 backdrop-blur-sm mb-8">
                        <CardContent className="p-6">
                          {/* Search Bar */}
                          <div className="relative mb-6">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                            <Input
                              type="text"
                              placeholder="Search by name, title, company..."
                              className="w-full pl-12 pr-10 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white/80 backdrop-blur-sm"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                            {searchTerm && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="absolute right-2 top-1/2 -translate-y-1/2 hover:bg-slate-100 rounded-xl" 
                                onClick={() => setSearchTerm('')}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            )}
                          </div>

                          {/* Filter Controls */}
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-4">
                            <div className="flex items-center gap-4 flex-wrap">
                              <Button 
                                variant="outline" 
                                onClick={() => setShowFilters(!showFilters)} 
                                className="rounded-xl border-slate-200 hover:bg-slate-50"
                              >
                                <Filter className="w-4 h-4 mr-2" />
                                Advanced Filters
                                {Object.values(filters).some(f => f) && (
                                  <Badge className="ml-2 bg-blue-600 text-white rounded-full">
                                    {Object.values(filters).filter(f => f).length}
                                  </Badge>
                                )}
                              </Button>
                              
                              {selectedContacts.size > 0 && (
                                <div className="flex items-center gap-2">
                                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full">
                                    {selectedContacts.size} selected
                                  </Badge>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setShowShortlistSidebar(true)}
                                    className="rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                                  >
                                    <Users className="w-3 h-3 mr-1" />
                                    View Shortlist
                                  </Button>
                                </div>
                              )}
                            </div>

                            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 text-sm text-slate-600">
                              {selectedContacts.size > 0 && (
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={hideSelected}
                                    onChange={(e) => setHideSelected(e.target.checked)}
                                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span>Hide selected</span>
                                </label>
                              )}
                              <div className="text-right">
                                Showing <span className="font-semibold text-blue-600">{displayedContacts.length.toLocaleString()}</span> of {contacts.length.toLocaleString()}
                              </div>
                            </div>
                          </div>

                          {/* Bulk Actions */}
                          {paginatedData.length > 0 && (
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200 mb-4 gap-4">
                              <div className="flex items-center gap-3 flex-wrap">
                                <span className="text-sm text-slate-700 font-medium">Bulk actions:</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleBulkSelection('selectAll')}
                                  className="rounded-xl border-slate-200 hover:bg-white"
                                >
                                  <PlusCircle className="w-3 h-3 mr-1" />
                                  Select Page
                                </Button>
                                {selectedContacts.size > 0 && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleBulkSelection('clearAll')}
                                    className="rounded-xl border-slate-200 hover:bg-white"
                                  >
                                    Clear All
                                  </Button>
                                )}
                              </div>

                              {isAuthenticated && selectedContacts.size > 0 && (
                                <div className="text-sm text-slate-600">
                                  Est. value: <span className="font-semibold text-emerald-600">
                                    ${totalEstimatedValue.toLocaleString()}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Filters */}
                          <AnimatePresence>
                            {showFilters && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="overflow-hidden"
                                transition={{ duration: 0.3 }}
                              >
                                <div className="border-t border-slate-200 pt-6">
                                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                                    <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.company} onChange={(e) => setFilters({ ...filters, company: e.target.value })}>
                                      <option value="">All Companies ({filterOptions.companies.length})</option>
                                      {filterOptions.companies.slice(0, 100).map(c => <option key={c} value={c}>{c}</option>)}
                                      {filterOptions.companies.length > 100 && <option disabled>... and {filterOptions.companies.length - 100} more</option>}
                                    </select>
                                    
                                    <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.function} onChange={(e) => setFilters({ ...filters, function: e.target.value })}>
                                      <option value="">All Functions</option>
                                      {filterOptions.functions.map(f => <option key={f} value={f}>{f}</option>)}
                                    </select>
                                    
                                    <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.industry} onChange={(e) => setFilters({ ...filters, industry: e.target.value })}>
                                      <option value="">All Industries</option>
                                      {filterOptions.industries.map(i => <option key={i} value={i}>{i}</option>)}
                                    </select>
                                    
                                    <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.seniority} onChange={(e) => setFilters({ ...filters, seniority: e.target.value })}>
                                      <option value="">All Seniority</option>
                                      {filterOptions.seniorities.map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                    
                                    <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.companySize} onChange={(e) => setFilters({ ...filters, companySize: e.target.value })}>
                                      <option value="">All Company Sizes</option>
                                      {filterOptions.companySizes.map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                    
                                    <Input 
                                      placeholder="Location contains..." 
                                      value={filters.location} 
                                      onChange={(e) => setFilters({ ...filters, location: e.target.value })} 
                                      className="rounded-xl border-slate-200 focus:ring-2 focus:ring-blue-500"
                                    />
                                    
                                    {user?.role === 'admin' && (
                                      <select className="border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white" value={filters.owner} onChange={(e) => setFilters({ ...filters, owner: e.target.value })}>
                                        <option value="">All Sources</option>
                                        {filterOptions.owners.map(owner => <option key={owner.email} value={owner.email}>{owner.email} ({owner.count})</option>)}
                                      </select>
                                    )}
                                    
                                    <Button 
                                      onClick={clearAllFilters} 
                                      variant="outline" 
                                      className="rounded-xl border-slate-200 hover:bg-slate-50 w-full"
                                    >
                                      Clear All
                                    </Button>
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Shortlist Summary */}
                    <AnimatePresence>
                      {selectedContacts.size > 0 && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mb-6"
                        >
                          <Card className="bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200 border-0 shadow-lg">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <div className="w-10 h-10 bg-emerald-500 rounded-2xl flex items-center justify-center">
                                    <CheckCircle className="w-5 h-5 text-white" />
                                  </div>
                                  <span className="font-semibold text-emerald-900">
                                    {selectedContacts.size} contacts saved to shortlist
                                  </span>
                                </div>
                                <Button 
                                  variant="ghost" 
                                  onClick={() => setShowShortlistSidebar(true)} 
                                  className="text-emerald-700 hover:text-emerald-800 hover:bg-emerald-100 font-semibold rounded-xl"
                                >
                                  View Shortlist →
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Removed: Data Enrichment Tool */}
                    {/* {contacts.length > 0 && (
                      <div className="mb-8">
                        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                          {(user?.role === 'admin' || hasEnrichmentAccess) ? (
                            <DataEnrichmentTool
                              connections={contacts}
                              onEnrichmentComplete={handleEnrichmentComplete}
                              onRequestPasswordAccess={handleRequestPasswordAccess}
                            />
                          ) : (
                            <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 overflow-hidden">
                              <CardContent className="p-8 text-center">
                                <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-600 to-indigo-600 rounded-3xl flex items-center justify-center mb-6">
                                  <Shield className="w-10 h-10 text-white" />
                                </div>
                                <h3 className="text-2xl font-bold text-slate-900 mb-3">Advanced AI Data Enrichment</h3>
                                <p className="text-slate-600 mb-8 text-lg max-w-2xl mx-auto">
                                  Unlock powerful AI-driven contact enrichment with industry insights, seniority mapping, and intelligent summaries.
                                </p>
                                <Button
                                  onClick={() => handleRequestPasswordAccess('enrichment')}
                                  size="lg"
                                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-3 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200"
                                >
                                  <Zap className="w-5 h-5 mr-2" />
                                  Unlock AI Enrichment
                                </Button>
                              </CardContent>
                            </Card>
                          )}
                        </motion.div>
                      </div>
                    )} */}

                    {/* Results */}
                    {paginatedData.length > 0 ? (
                      <>
                        <AnimatePresence mode="wait">
                          <motion.div 
                            key={currentPage} 
                            initial={{ opacity: 0, y: 20 }} 
                            animate={{ opacity: 1, y: 0 }} 
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.3 }}
                            className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8"
                          >
                            {paginatedData.map((contact, index) => (
                              <div key={contact.id} className="relative">
                                <ContactCard
                                  contact={contact}
                                  index={index}
                                  isSelected={selectedContacts.has(contact.id)}
                                  onToggleSelection={() => handleToggleContactSelection(contact)}
                                  showShortlistButton={true}
                                />
                                
                                {/* Privacy Indicator Overlay */}
                                <div className="absolute top-3 right-3 z-10">
                                  <ContactPrivacyIndicator
                                    contact={contact}
                                    sharingStatus={contact.sharingStatus}
                                  />
                                </div>
                              </div>
                            ))}
                          </motion.div>
                        </AnimatePresence>
                        <Pagination currentPage={currentPage} totalPages={totalPages} setCurrentPage={setCurrentPage} />
                      </>
                    ) : (
                      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-20">
                        <div className="w-24 h-24 bg-slate-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                          <Users className="w-12 h-12 text-slate-400" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 mb-3">No connections found</h3>
                        <p className="text-slate-600 mb-8 max-w-md mx-auto">
                          {searchTerm || Object.values(filters).some(f => f) 
                            ? "Try adjusting your search terms or filters to find relevant contacts." 
                            : "Start building your network by importing contacts from various sources."}
                        </p>
                        {(searchTerm || Object.values(filters).some(f => f)) ? (
                          <Button onClick={clearAllFilters} variant="outline" className="rounded-xl">
                            Clear Search & Filters
                          </Button>
                        ) : (
                          <Button onClick={() => setIsCsvModalOpen(true)} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl">
                            <Upload className="w-4 h-4 mr-2" />
                            Import Connections
                          </Button>
                        )}
                      </motion.div>
                    )}
                  </motion.div>
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Modern Floating Shortlist Button */}
        <AnimatePresence>
          {selectedContacts.size > 0 && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="fixed bottom-8 right-8 z-50"
            >
              <Button
                onClick={() => setShowShortlistSidebar(true)}
                size="lg"
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white shadow-2xl rounded-2xl h-16 px-6 text-lg font-semibold transform hover:scale-105 transition-all duration-200"
              >
                <Users className="w-6 h-6 mr-3" />
                Shortlist ({selectedContacts.size})
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}
