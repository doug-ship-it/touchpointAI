import Layout from "./Layout.jsx";

import ResourceLibrary from "./ResourceLibrary";

import CandidateIntake from "./CandidateIntake";

import IntelligentRouting from "./IntelligentRouting";

import Home from "./Home";

import ArchetypeDNA from "./ArchetypeDNA";

import About from "./About";

import PersonalizedDashboard from "./PersonalizedDashboard";

import OnboardingPage from "./OnboardingPage";

import Intake from "./Intake";

import SaaSDevelopment from "./SaaSDevelopment";

import GTM from "./GTM";

import Operations from "./Operations";

import CandidatePortal from "./CandidatePortal";

import ArchetypeDNALearning from "./ArchetypeDNALearning";

import SystemAudit from "./SystemAudit";

import OperationsIntake from "./OperationsIntake";

import TechnologyIntake from "./TechnologyIntake";

import NetworkIntelligenceDeep from "./NetworkIntelligenceDeep";

import CommandCenter from "./CommandCenter";

import AICRM from "./AICRM";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    ResourceLibrary: ResourceLibrary,
    
    CandidateIntake: CandidateIntake,
    
    IntelligentRouting: IntelligentRouting,
    
    Home: Home,
    
    ArchetypeDNA: ArchetypeDNA,
    
    About: About,
    
    PersonalizedDashboard: PersonalizedDashboard,
    
    OnboardingPage: OnboardingPage,
    
    Intake: Intake,
    
    SaaSDevelopment: SaaSDevelopment,
    
    GTM: GTM,
    
    Operations: Operations,
    
    CandidatePortal: CandidatePortal,
    
    ArchetypeDNALearning: ArchetypeDNALearning,
    
    SystemAudit: SystemAudit,
    
    OperationsIntake: OperationsIntake,
    
    TechnologyIntake: TechnologyIntake,
    
    NetworkIntelligenceDeep: NetworkIntelligenceDeep,
    
    CommandCenter: CommandCenter,
    
    AICRM: AICRM,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<ResourceLibrary />} />
                
                
                <Route path="/ResourceLibrary" element={<ResourceLibrary />} />
                
                <Route path="/CandidateIntake" element={<CandidateIntake />} />
                
                <Route path="/IntelligentRouting" element={<IntelligentRouting />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/ArchetypeDNA" element={<ArchetypeDNA />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/PersonalizedDashboard" element={<PersonalizedDashboard />} />
                
                <Route path="/OnboardingPage" element={<OnboardingPage />} />
                
                <Route path="/Intake" element={<Intake />} />
                
                <Route path="/SaaSDevelopment" element={<SaaSDevelopment />} />
                
                <Route path="/GTM" element={<GTM />} />
                
                <Route path="/Operations" element={<Operations />} />
                
                <Route path="/CandidatePortal" element={<CandidatePortal />} />
                
                <Route path="/ArchetypeDNALearning" element={<ArchetypeDNALearning />} />
                
                <Route path="/SystemAudit" element={<SystemAudit />} />
                
                <Route path="/OperationsIntake" element={<OperationsIntake />} />
                
                <Route path="/TechnologyIntake" element={<TechnologyIntake />} />
                
                <Route path="/NetworkIntelligenceDeep" element={<NetworkIntelligenceDeep />} />
                
                <Route path="/CommandCenter" element={<CommandCenter />} />
                
                <Route path="/AICRM" element={<AICRM />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}