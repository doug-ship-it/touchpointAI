
import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, DollarSign, Clock, Award, ArrowRight, Zap, BrainCircuit, BarChart3, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import AnimatedCaseStudies from '../components/home/AnimatedCaseStudies';
import ServiceGrid from '../components/home/ServiceGrid';
import ScrollingClientLogos from '../components/ScrollingClientLogos';
import PrototypeNotice from '../components/home/PrototypeNotice';

const keyMetrics = [
  { value: "150+", label: "Projects Delivered", icon: Briefcase },
  { value: "$350M+", label: "In Revenue Generated", icon: DollarSign },
  { value: "1M+", label: "Hours Saved", icon: Clock },
  { value: "95%", label: "Client Retention", icon: Award }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-300">
       <style>{`
          @keyframes gradient-wave {
              0% { background-position: 0% 50%; }
              50% { background-position: 100% 50%; }
              100% { background-position: 0% 50%; }
          }
          .animate-gradient-wave {
              background-size: 200% auto;
              animation: gradient-wave 4s ease infinite;
          }
        `}</style>
      
      {/* Hero Section */}
      <section className="relative text-center py-12 bg-gray-900 text-white overflow-hidden">
        <motion.div
            className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-teal-500/10 to-orange-500/10"
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}>

            <motion.img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c743df2b981f4e31e3cd9b/0d9b73c3f_-3W2Qm3cpMZrw55Z4Pz7-.png"
              alt="Touchpoint by mbAI"
              className="h-64 sm:h-80 md:h-[30rem] mx-auto mb-6"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
            
            <p className="text-base sm:text-lg text-gray-300 max-w-3xl mx-auto mb-6 px-4" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
              This platform is currently in beta, and we're actively seeking feedback from testers. Premium features, including CRM, Enrichment, and LinkedIn AI Copilot, are available to select users upon request.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Prototype Notice */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <PrototypeNotice />
      </div>
      
      {/* Metrics Section */}
      <section className="bg-black/20 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {keyMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-3">
                  <div className="p-3 rounded-full bg-teal-500/10 border border-teal-500/20">
                    <metric.icon className="w-5 h-5 sm:w-6 sm:h-6 text-teal-300" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-bold text-white mb-1">{metric.value}</div>
                <div className="text-xs sm:text-sm text-gray-400">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      <ScrollingClientLogos />

      <AnimatedCaseStudies />
      
      {/* Service Grid */}
      <ServiceGrid />

      {/* Final CTA */}
      <section className="py-20">
        <div className="max-w-3xl mx-auto text-center px-4">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button size="lg" className="bg-gradient-to-r from-teal-400 to-blue-500 hover:from-teal-500 hover:to-blue-600 text-white font-bold text-base px-8 py-6 rounded-full shadow-lg" asChild>
              <Link to={createPageUrl("Intake")}>
                Reserve Your Spot For a Limited Free Trial ($100 in AI Enrichment and 60 days of services included)
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
