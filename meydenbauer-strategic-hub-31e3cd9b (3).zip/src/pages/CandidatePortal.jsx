
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Candidate } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Briefcase, Globe, Clock, ArrowRight, CheckCircle, Star, Building } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const opportunityTypes = [
  {
    id: "full_time",
    icon: Building,
    title: "Executive Positions",
    description: "C-level and VP roles in growing technology companies",
    color: "from-blue-500 to-cyan-500",
    features: ["$200K - $500K+ compensation", "Equity participation", "Leadership opportunities", "Strategic impact"]
  },
  {
    id: "fractional_consulting",
    icon: Globe,
    title: "Fractional & Consulting",
    description: "High-impact fractional executive and specialized consulting roles",
    color: "from-purple-500 to-pink-500",
    features: ["$70 - $800 hourly", "Flexible engagement", "Multiple clients", "Expertise leverage"]
  },
  {
    id: "virtual_assistant",
    icon: Users,
    title: "Virtual Assistant Track",
    description: "Remote administrative and specialized support roles for executives and growing companies",
    color: "from-emerald-500 to-teal-500",
    features: ["$500 - $2500 monthly", "Remote-first opportunities", "Flexible schedules", "Skill development pathways"]
  }
];

const placementMetrics = [
  { value: "150+", label: "Successful Placements", icon: CheckCircle },
  { value: "$18M+", label: "Total Compensation Placed", icon: Star },
  { value: "95%", label: "Candidate Satisfaction", icon: Users },
  { value: "6 weeks", label: "Average Placement Time", icon: Clock }
];

const candidateSuccess = [
  {
    role: "VP of Engineering",
    company: "Series-B SaaS Company",
    placement: "Full-time Executive",
    compensation: "$285K + equity",
    timeframe: "4 weeks"
  },
  {
    role: "Fractional CTO",
    company: "Multiple Portfolio Companies",
    placement: "Fractional Consulting",
    compensation: "$350/hour",
    timeframe: "2 weeks"
  },
  {
    role: "Chief Revenue Officer",
    company: "PE-backed Growth Company",
    placement: "Full-time Executive",
    compensation: "$310K + equity",
    timeframe: "5 weeks"
  }
];

export default function CandidatePortal() {
  const navigate = useNavigate();
  const [selectedOpportunity, setSelectedOpportunity] = useState(null);
  const [candidates, setCandidates] = useState([]);
  const [selectedTab, setSelectedTab] = useState('opportunities');

  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        const data = await Candidate.list();
        setCandidates(data.slice(0, 10)); // Show recent candidates
      } catch (error) {
        console.error('Error fetching candidates:', error);
      }
    };
    fetchCandidates();
    
    // Guided tour animation for tabs - slowed down
    const timers = [
      setTimeout(() => setSelectedTab('success-stories'), 3000),
      setTimeout(() => setSelectedTab('process'), 6000),
      setTimeout(() => setSelectedTab('opportunities'), 9000)
    ];

    return () => timers.forEach(clearTimeout);
  }, []);

  const handleOpportunitySelect = (opportunityId) => {
    setSelectedOpportunity(opportunityId);
    navigate(createPageUrl(`CandidateIntake?type=${opportunityId}`));
  };
  
  const tabsConfig = [
      { id: 'opportunities', label: 'Opportunities' },
      { id: 'success-stories', label: 'Success' },
      { id: 'process', label: 'Process' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50/30 to-pink-50/30">
      {/* Hero Section */}
      <section className="py-12 sm:py-16 text-center bg-white border-b">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto px-4 sm:px-6"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full border border-purple-200 mb-4">
            <Users className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-700">Executive Search & Career Hub</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-gray-900">
            Candidate Portal
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Connect with executive opportunities and fractional consulting roles that match your expertise and career goals. Join our network of successful professionals.
          </p>
        </motion.div>
      </section>

      {/* Success Metrics */}
      <section className="py-12 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {placementMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-2">
                  <metric.icon className="w-8 h-8" />
                </div>
                <div className="text-3xl font-bold mb-1">{metric.value}</div>
                <div className="text-sm opacity-90">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-10">
          <div className="flex justify-center">
            <TabsList className="relative grid w-full max-w-md sm:max-w-3xl grid-cols-3 items-center justify-center rounded-2xl bg-gray-100 p-2 text-gray-500 border shadow-inner h-auto">
              {tabsConfig.map(tab => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="relative text-sm sm:text-base font-medium px-2 sm:px-4 py-3.5 rounded-xl transition-colors data-[state=active]:text-white z-20"
                >
                  <span className="relative z-10">{tab.label}</span>
                </TabsTrigger>
              ))}
              <motion.div
                layoutId="active-tab-candidate"
                className="absolute inset-y-2 h-[calc(100%-1rem)] rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 shadow-md z-10"
                style={{
                  width: `calc(100% / 3 - 8px)`,
                  left: `calc(${tabsConfig.findIndex(t => t.id === selectedTab) * (100 / 3)}% + 4px)`
                }}
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            </TabsList>
          </div>

          <TabsContent value="opportunities">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {opportunityTypes.map((type, index) => (
                <motion.div
                  key={type.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="group"
                >
                  <Card
                    className={`h-full cursor-pointer border-2 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-white border-gray-200 hover:border-purple-300 rounded-xl ${
                      selectedOpportunity === type.id ? 'ring-4 ring-purple-200 shadow-lg' : ''
                    }`}
                    onClick={() => handleOpportunitySelect(type.id)}
                  >
                    <CardContent className="p-8 flex flex-col h-full">
                      <div className="flex items-center gap-4 mb-6">
                        <div className={`p-4 rounded-xl bg-gradient-to-r ${type.color} shadow-lg`}>
                          <type.icon className="w-8 h-8 text-white" />
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-gray-900 group-hover:text-purple-700 transition-colors">
                            {type.title}
                          </h3>
                        </div>
                      </div>
                      
                      {/* Modified section for description and features - removed button */}
                      <div className="flex-grow"> {/* Removed mb-8 */}
                        <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                          {type.description}
                        </p>

                        <div className="space-y-3">
                          {type.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center gap-3">
                              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                              <span className="text-gray-700">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="success-stories">
            <div className="space-y-8">
              {candidateSuccess.map((success, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="grid md:grid-cols-4 gap-6 items-center">
                        <div>
                          <h3 className="font-bold text-lg mb-2">{success.role}</h3>
                          <Badge variant="outline" className="mb-2">{success.placement}</Badge>
                          <p className="text-gray-600 text-sm">{success.company}</p>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600 mb-1">{success.compensation}</div>
                          <div className="text-sm text-gray-500">Compensation</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-600 mb-1">{success.timeframe}</div>
                          <div className="text-sm text-gray-500">Placement Time</div>
                        </div>
                        <div className="text-center">
                          <Badge className="bg-green-100 text-green-800 flex items-center gap-1 justify-center">
                            <CheckCircle className="w-3 h-3" />
                            Placed Successfully
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="process">
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-600" />
                    Initial Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Resume and skill analysis</li>
                    <li>• Career goals alignment</li>
                    <li>• Market positioning assessment</li>
                    <li>• Compensation expectations</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-purple-600" />
                    Opportunity Matching
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Custom opportunity sourcing</li>
                    <li>• Client requirements matching</li>
                    <li>• Interview preparation and coaching</li>
                    <li>• Negotiation support</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-purple-600" />
                    Placement & Success
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Offer negotiation assistance</li>
                    <li>• Onboarding support</li>
                    <li>• 90-day success check-ins</li>
                    <li>• Long-term career partnership</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* CTA Section - Removed all buttons */}
        <section className="mt-16 text-center">
          <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Ready to Advance Your Career?</h2>
              <p className="mb-6 text-purple-100 max-w-2xl mx-auto">
                Join our network of successful executives and consultants. Get matched with opportunities that align with your expertise and career goals.
              </p>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
