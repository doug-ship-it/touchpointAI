
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { InvokeLLM } from '@/api/integrations';
import { Company } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Loader2, ArrowRight, ExternalLink, Linkedin, Building, Users, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function IntelligentRoutingPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    email: '',
    linkedin: 'https://www.linkedin.com/in/',
    pathway: '',
    ipData: null,
    companyData: null
  });
  
  const [isAutoFilling, setIsAutoFilling] = useState(false);
  const [autoFillComplete, setAutoFillComplete] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  // Geographic IP Detection
  useEffect(() => {
    const detectLocation = async () => {
      try {
        const response = await fetch('https://ipapi.co/json/');
        const ipData = await response.json();
        setFormData(prev => ({ ...prev, ipData }));
      } catch (error) {
        console.log('IP detection failed:', error);
      }
    };
    detectLocation();
  }, []);

  // Email Domain Analysis
  const handleEmailAutoFill = useCallback(async (email) => {
    if (!email || !email.includes('@') || isAutoFilling || autoFillComplete) return;

    const domain = email.split('@')[1];
    const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com', 'protonmail.com'];
    
    if (personalDomains.includes(domain)) {
      setAutoFillComplete(true);
      return;
    }

    setIsAutoFilling(true);
    
    try {
      const prompt = `Analyze the company with domain "${domain}" using ONLY verified sources:
      1. Official company website (About page, Services page)
      2. Official LinkedIn Company page
      
      Provide basic company information for business pathway qualification:
      - Company name and industry
      - Approximate employee count (if available)
      - Business stage indicators
      - Technology or service focus
      
      If reliable information cannot be found from official sources, indicate limited data.`;

      const companyData = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            companyName: { type: "string" },
            industry: { type: "string" },
            employeeCount: { type: "number" },
            businessStage: { type: "string" },
            hasOfficialData: { type: "boolean" },
            suggestedPathway: { type: "string", enum: ["business", "candidate", "unclear"] }
          }
        }
      });

      if (companyData && companyData.hasOfficialData) {
        setFormData(prev => ({ ...prev, companyData }));
      }
      
      setAutoFillComplete(true);
    } catch (error) {
      console.error('Company analysis failed:', error);
    }
    
    setIsAutoFilling(false);
  }, [isAutoFilling, autoFillComplete]);

  useEffect(() => {
    if (formData.email && formData.email.includes('@')) {
      const handler = setTimeout(() => {
        handleEmailAutoFill(formData.email);
      }, 1000);
      return () => clearTimeout(handler);
    }
  }, [formData.email, handleEmailAutoFill]);

  const handleLinkedInFocus = (e) => {
    if (e.target.value === 'https://www.linkedin.com/in/') {
      setTimeout(() => {
        e.target.setSelectionRange(e.target.value.length, e.target.value.length);
      }, 0);
    }
  };

  const handleLinkedInChange = (e) => {
    let value = e.target.value;
    if (!value.startsWith('https://www.linkedin.com/')) {
      if (value.includes('linkedin.com/')) {
        value = value.replace(/^.*linkedin\.com\//, 'https://www.linkedin.com/');
      } else {
        value = 'https://www.linkedin.com/in/';
      }
    }
    setFormData(prev => ({ ...prev, linkedin: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Business email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.pathway) {
      newErrors.pathway = 'Please select what brings you here';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const getPathwayRecommendation = () => {
    const { ipData, companyData, email } = formData;
    
    // Geographic pathway weighting
    let businessWeight = 0.5;
    let candidateWeight = 0.5;

    if (ipData) {
      const country = ipData.country_code;
      
      if (['US', 'CA'].includes(country)) {
        businessWeight += 0.2;
      } else if (['PL', 'UA', 'RO', 'CZ', 'BG'].includes(country)) {
        candidateWeight += 0.3;
      } else if (['IN', 'PH', 'VN', 'PK'].includes(country)) {
        candidateWeight += 0.4;
      } else if (['MX', 'AR', 'CO', 'BR'].includes(country)) {
        candidateWeight += 0.2;
      } else if (['ZA', 'NG', 'KE'].includes(country)) {
        candidateWeight += 0.1;
      }
    }

    // Email domain analysis
    const domain = email.split('@')[1] || '';
    const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com'];
    
    if (personalDomains.includes(domain)) {
      candidateWeight += 0.3;
    } else if (companyData && companyData.hasOfficialData) {
      businessWeight += 0.4;
    }

    return businessWeight > candidateWeight ? 'business' : 'candidate';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    try {
      // Store intake data for next steps
      const intakeData = {
        ...formData,
        timestamp: new Date().toISOString(),
        recommendedPathway: getPathwayRecommendation()
      };
      
      sessionStorage.setItem('intakeData', JSON.stringify(intakeData));
      
      // Route to personalized dashboard
      navigate(createPageUrl('OnboardingPage'));
      
    } catch (error) {
      console.error('Form submission error:', error);
      setErrors({ submit: 'Something went wrong. Please try again.' });
    }
    
    setIsSubmitting(false);
  };

  const suggestedPathway = getPathwayRecommendation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-teal-50/20">
      <div className="max-w-3xl mx-auto p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-100 rounded-full border border-teal-200 mb-6">
            <Building className="w-4 h-4 text-teal-600" />
            <span className="text-sm font-medium text-teal-700">Intake</span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            What Brings You Here?
          </h1>
          
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A few details help us point you in the right direction
          </p>
        </motion.div>

        {isAutoFilling && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
            <AlertDescription>
              🤖 Analyzing your company profile...
            </AlertDescription>
          </Alert>
        )}

        {autoFillComplete && formData.companyData && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription>
              ✨ Found {formData.companyData.companyName} - {formData.companyData.industry} company
            </AlertDescription>
          </Alert>
        )}

        <Card className="shadow-xl border border-gray-200">
          <CardContent className="p-6 md:p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Contact Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-base font-medium text-gray-700">
                    First Name *
                  </Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                    placeholder="Your first name"
                    className={`text-base p-3 ${errors.firstName ? 'border-red-500' : ''}`}
                  />
                  {errors.firstName && (
                    <p className="text-sm text-red-600">{errors.firstName}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base font-medium text-gray-700">
                    Business Email *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="your.email@company.com"
                    className={`text-base p-3 ${errors.email ? 'border-red-500' : ''}`}
                  />
                  {errors.email && (
                    <p className="text-sm text-red-600">{errors.email}</p>
                  )}
                </div>
              </div>

              {/* LinkedIn Profile */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="linkedin" className="text-base font-medium text-gray-700">
                    LinkedIn Profile (Optional)
                  </Label>
                  <a
                    href="https://www.linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-teal-600 hover:text-teal-700 transition-colors"
                  >
                    <Linkedin className="w-4 h-4" />
                    Open LinkedIn
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <Input
                  id="linkedin"
                  value={formData.linkedin}
                  onChange={handleLinkedInChange}
                  onFocus={handleLinkedInFocus}
                  placeholder="https://www.linkedin.com/in/"
                  className="text-base p-3"
                />
              </div>

              {/* Pathway Selection */}
              <div className="space-y-4">
                <Label className="text-base font-medium text-gray-700">
                  What brings you here? *
                </Label>
                
                <RadioGroup
                  value={formData.pathway}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, pathway: value }))}
                  className="space-y-4"
                >
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Card className={`cursor-pointer transition-all duration-200 ${
                      formData.pathway === 'business' 
                        ? 'border-teal-500 shadow-lg bg-teal-50/50' 
                        : 'border-gray-200 hover:border-teal-300'
                    } ${suggestedPathway === 'business' ? 'ring-2 ring-teal-200' : ''}`}>
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <RadioGroupItem 
                            value="business" 
                            id="business" 
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Building className="w-5 h-5 text-teal-600" />
                              <label 
                                htmlFor="business" 
                                className="text-lg font-bold text-gray-900 cursor-pointer"
                              >
                                I'm looking to grow my business
                              </label>
                              {suggestedPathway === 'business' && (
                                <span className="text-xs bg-teal-600 text-white px-2 py-1 rounded-full">
                                  Recommended
                                </span>
                              )}
                            </div>
                            <p className="text-gray-600">
                              Scale your team, optimize operations, accelerate growth
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Card className={`cursor-pointer transition-all duration-200 ${
                      formData.pathway === 'candidate' 
                        ? 'border-teal-500 shadow-lg bg-teal-50/50' 
                        : 'border-gray-200 hover:border-teal-300'
                    } ${suggestedPathway === 'candidate' ? 'ring-2 ring-teal-200' : ''}`}>
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <RadioGroupItem 
                            value="candidate" 
                            id="candidate" 
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Users className="w-5 h-5 text-teal-600" />
                              <label 
                                htmlFor="candidate" 
                                className="text-lg font-bold text-gray-900 cursor-pointer"
                              >
                                I'm exploring career opportunities
                              </label>
                              {suggestedPathway === 'candidate' && (
                                <span className="text-xs bg-teal-600 text-white px-2 py-1 rounded-full">
                                  Recommended
                                </span>
                              )}
                            </div>
                            <p className="text-gray-600">
                              Executive roles, fractional work, specialized positions
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </RadioGroup>

                {errors.pathway && (
                  <p className="text-sm text-red-600">{errors.pathway}</p>
                )}
              </div>

              {errors.submit && (
                <Alert variant="destructive">
                  <AlertDescription>{errors.submit}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white font-bold text-lg py-4 h-auto"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Continue
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="text-center mt-6 text-sm text-gray-500">
          We'll use this information to provide personalized recommendations and connect you with relevant opportunities.
        </div>
      </div>
    </div>
  );
}
