import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Candidate } from "@/api/entities";
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";

import ResumeUpload from "../components/candidate/ResumeUpload";
import CandidateProcessing from "../components/candidate/CandidateProcessing";
import CandidateProfileForm from "../components/candidate/CandidateProfileForm";
import CandidateCompletion from "../components/candidate/CandidateCompletion";

export default function CandidateIntake() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: upload, 2: processing, 3: profile, 4: completion
  const [opportunityType, setOpportunityType] = useState(null);
  const [resumeFile, setResumeFile] = useState(null);
  const [extractedData, setExtractedData] = useState(null);
  const [extractionStatus, setExtractionStatus] = useState('pending');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type');
    if (type) {
      setOpportunityType(type);
    }
  }, []);

  const handleResumeUpload = async (file) => {
    setResumeFile(file);
    setStep(2); // Move to processing
    setErrorMessage('');
    
    let file_url = null;
    let uploadSuccessful = false;
    
    try {
      // Attempt to upload the file with retry logic
      console.log('Attempting to upload file:', file.name);
      const uploadResult = await uploadFileWithRetry(file, 3);
      file_url = uploadResult.file_url;
      uploadSuccessful = true;
      console.log('File uploaded successfully:', file_url);
    } catch (error) {
      console.error('File upload failed after retries:', error);
      uploadSuccessful = false;
    }

    // Initialize basic extracted data structure
    let basicExtractedData = {
      full_name: '',
      email: '',
      phone: '',
      current_title: '',
      location: '',
      linkedin_url: '',
      summary: '',
      skills: [],
      years_experience: 0,
      education: [],
      experience: [],
      resume_url: file_url // May be null if upload failed
    };

    if (uploadSuccessful && file_url) {
      try {
        // Define schema for resume extraction
        const resumeSchema = {
          type: "object",
          properties: {
            full_name: { type: "string", description: "Candidate's full name" },
            email: { type: "string", description: "Email address" },
            phone: { type: "string", description: "Phone number" },
            current_title: { type: "string", description: "Current or most recent job title" },
            location: { type: "string", description: "Current location or address" },
            linkedin_url: { type: "string", description: "LinkedIn profile URL if mentioned" },
            summary: { type: "string", description: "Professional summary or objective" },
            skills: { 
              type: "array", 
              items: { type: "string" }, 
              description: "Key skills mentioned in the resume" 
            },
            years_experience: { 
              type: "number", 
              description: "Estimated total years of professional experience" 
            },
            education: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  degree: { type: "string" },
                  institution: { type: "string" },
                  year: { type: "number" }
                }
              },
              description: "Educational background"
            },
            experience: {
              type: "array",
              items: {
                type: "object", 
                properties: {
                  title: { type: "string" },
                  company: { type: "string" },
                  duration: { type: "string" },
                  description: { type: "string" }
                }
              },
              description: "Work experience entries"
            }
          },
          required: ["full_name"]
        };

        console.log('Attempting to extract data from resume');
        const result = await extractDataWithRetry(file_url, resumeSchema, 2);
        
        if (result.status === "success" && result.output) {
          basicExtractedData = { 
            ...basicExtractedData, 
            ...result.output,
            resume_url: file_url 
          };
          setExtractionStatus('success');
          console.log('Data extraction successful');
        } else {
          throw new Error("Extraction returned no data");
        }
      } catch (error) {
        console.error("Resume extraction failed:", error);
        setExtractionStatus('partial_failure');
        // Keep basic structure but note the failure
        setErrorMessage('We had trouble reading your resume automatically, but you can still fill in your information manually.');
      }
    } else {
      // Upload failed - user can still continue manually
      setExtractionStatus('upload_failure');
      setErrorMessage('File upload encountered an issue, but you can still enter your information manually.');
    }
    
    setExtractedData(basicExtractedData);
    setStep(3); // Move to profile form regardless
  };

  // Helper function to upload file with retries
  const uploadFileWithRetry = async (file, maxRetries) => {
    let attempt = 1;
    while (attempt <= maxRetries) {
      try {
        console.log(`Upload attempt ${attempt}/${maxRetries}`);
        const result = await UploadFile({ file });
        return result;
      } catch (error) {
        console.error(`Upload attempt ${attempt} failed:`, error);
        if (attempt === maxRetries) {
          throw error;
        }
        // Wait before retrying (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
        attempt++;
      }
    }
  };

  // Helper function to extract data with retries
  const extractDataWithRetry = async (file_url, schema, maxRetries) => {
    let attempt = 1;
    while (attempt <= maxRetries) {
      try {
        console.log(`Extraction attempt ${attempt}/${maxRetries}`);
        const result = await ExtractDataFromUploadedFile({
          file_url,
          json_schema: schema
        });
        return result;
      } catch (error) {
        console.error(`Extraction attempt ${attempt} failed:`, error);
        if (attempt === maxRetries) {
          throw error;
        }
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
        attempt++;
      }
    }
  };

  const handleProfileSubmit = async (profileData) => {
    setIsSubmitting(true);
    const finalData = { 
      ...extractedData, 
      ...profileData, 
      opportunity_type: opportunityType 
    };
    
    try {
      await Candidate.create(finalData);
      setStep(4); // Move to completion
    } catch (error) {
      console.error("Error submitting candidate profile:", error);
      setErrorMessage('There was an issue submitting your profile. Please try again.');
    }
    setIsSubmitting(false);
  };

  const handleStartOver = () => {
    setResumeFile(null);
    setExtractedData(null);
    setExtractionStatus('pending');
    setErrorMessage('');
    setStep(1);
  };

  const opportunityLabels = {
    full_time: "Full-Time Opportunities",
    fractional_consulting: "Fractional & Consulting"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50/30 to-pink-50/30">
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div key="step1" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <ResumeUpload 
              opportunityType={opportunityType}
              opportunityLabel={opportunityLabels[opportunityType]}
              onUpload={handleResumeUpload}
            />
          </motion.div>
        )}
        {step === 2 && (
          <motion.div key="step2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <CandidateProcessing />
          </motion.div>
        )}
        {step === 3 && (
          <motion.div key="step3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <CandidateProfileForm
              extractedData={extractedData}
              extractionStatus={extractionStatus}
              opportunityType={opportunityType}
              onSubmit={handleProfileSubmit}
              onStartOver={handleStartOver}
              isSubmitting={isSubmitting}
              errorMessage={errorMessage}
            />
          </motion.div>
        )}
        {step === 4 && (
          <motion.div key="step4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <CandidateCompletion 
              candidateData={extractedData}
              opportunityType={opportunityType}
              onContinue={() => navigate(createPageUrl("IndustryHub"))}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}