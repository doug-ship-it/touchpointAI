
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import { CaseStudy } from '@/api/entities';
import { Code, Zap, Brain, Shield, Cloud, GitBranch, Database, FlaskConical, Building2, Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import OurStackSection from '../components/saas/OurStackSection';


const technologyCapabilities = [
  {
    icon: Brain,
    title: "AI/ML Implementation",
    description: "Custom AI solutions, machine learning pipelines, and intelligent automation systems",
    technologies: ["TensorFlow", "PyTorch", "OpenAI", "Hugging Face", "AutoML"]
  },
  {
    icon: Cloud,
    title: "Cloud Architecture",
    description: "Scalable cloud infrastructure design and implementation across major platforms",
    technologies: ["AWS", "Azure", "GCP", "Kubernetes", "Terraform"]
  },
  {
    icon: Code,
    title: "SaaS Development",
    description: "Full-stack SaaS applications with modern frameworks and best practices",
    technologies: ["React", "Node.js", "Python", "TypeScript", "GraphQL"]
  },
  {
    icon: Shield,
    title: "Security & Compliance",
    description: "Enterprise-grade security implementation and compliance frameworks",
    technologies: ["OAuth", "GDPR", "HIPAA", "SOC2", "Encryption"]
  },
  {
    icon: Database,
    title: "Data Engineering",
    description: "Data pipelines, warehousing, and analytics infrastructure",
    technologies: ["PostgreSQL", "MongoDB", "Redis", "Elasticsearch", "Snowflake"]
  },
  {
    icon: GitBranch,
    title: "DevOps/CI-CD",
    description: "Automated deployment pipelines and infrastructure management",
    technologies: ["GitHub Actions", "Jenkins", "Docker", "Monitoring", "Testing"]
  }
];

const successMetrics = [
  { value: "40%", label: "Faster Development Cycles", icon: Zap },
  { value: "60%", label: "Reduction in Bugs", icon: Shield },
  { value: "$2M+", label: "Annual Client Savings", icon: Code },
  { value: "99.9%", label: "Uptime Achieved", icon: Cloud }
];

export default function SaaSDevelopment() {
  const [caseStudies, setCaseStudies] = useState([]);
  const [selectedTab, setSelectedTab] = useState('overview');
  
  const scrollContainerRef = useRef(null);
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const fetchCaseStudies = async () => {
      try {
        const studies = await CaseStudy.filter({ service_category: 'technology' });
        setCaseStudies(studies);
      } catch (error) {
        console.error('Error fetching case studies:', error);
      }
    };
    
    fetchCaseStudies();

    // Guided tour animation for tabs (now only 2 tabs)
    const timers = [
      setTimeout(() => setSelectedTab('process'), 2000),
      setTimeout(() => setSelectedTab('overview'), 4000)
    ];

    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer || caseStudies.length === 0) return;

    let animationFrameId;

    const scroll = () => {
      if (!isHovering) {
        // When the scroll position reaches the start of the duplicated content, reset to the beginning
        // The scrollWidth is total width including hidden overflow. We have doubled the content.
        // So, if scrollLeft passes the width of the original content, it's time to loop.
        if (scrollContainer.scrollLeft >= scrollContainer.scrollWidth / 2) {
          scrollContainer.scrollLeft = 0;
        } else {
          // Adjust the increment for speed (lower is slower)
          scrollContainer.scrollLeft += 0.5;
        }
      }
      animationFrameId = requestAnimationFrame(scroll);
    };

    animationFrameId = requestAnimationFrame(scroll);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isHovering, caseStudies]);

  const tabsConfig = [
    { id: 'overview', label: 'Capabilities' },
    { id: 'process', label: 'Approach' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      {/* Hero Section */}
      <section className="py-8 sm:py-12 lg:py-16 text-center bg-white border-b">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto px-4 sm:px-6"
        >
          <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 bg-blue-100 rounded-full border border-blue-200 mb-4">
            <Code className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-700">Technology Services</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 text-gray-900">
            App Dev, Cloud + AI
          </h1>
          <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
            From AI-powered platforms to scalable cloud infrastructure, we build technology solutions that drive business outcomes and competitive advantage.
          </p>
        </motion.div>
      </section>

      {/* Success Metrics */}
      <section className="py-8 sm:py-12 bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {successMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-2">
                  <metric.icon className="w-6 sm:w-7 lg:w-8 h-6 sm:h-7 lg:h-8" />
                </div>
                <div className="text-xl sm:text-2xl lg:text-3xl font-bold mb-1">{metric.value}</div>
                <div className="text-xs sm:text-sm opacity-90">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        
        {/* Recommended Section */}
        <section className="py-8 sm:py-12 lg:py-16 mb-8 sm:mb-12 bg-white rounded-2xl shadow-lg border border-gray-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 bg-blue-100 rounded-full border border-blue-200 mb-4">
              <Sparkles className="w-4 sm:w-5 h-4 sm:h-5 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Recommended Next Steps</span>
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-4">Accelerate Your Project</h2>
            <p className="text-sm sm:text-base lg:text-lg text-gray-600 mb-6 sm:mb-8">
              Use our intelligent tools and curated partner network to ensure your project's success from day one.
            </p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
              {/* Card 1 */}
              <motion.div
                animate={{ scale: [1, 1.03, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                className="h-full"
              >
                <Link to={createPageUrl('TechStackAnalysis')} className="block h-full">
                  <Card className="text-left h-full hover:shadow-xl transition-all duration-300 group border-2 border-transparent hover:border-blue-500">
                    <CardHeader>
                      <div className="p-3 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 w-fit mb-3">
                        <FlaskConical className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                      </div>
                      <CardTitle className="text-base sm:text-lg group-hover:text-blue-600 transition-colors">Tech Stack Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm sm:text-base text-gray-600 mb-4">Submit your stack for a free, AI-powered ROI and consolidation analysis.</p>
                      <Button variant="link" className="p-0 h-auto font-semibold text-sm sm:text-base">Get Your Free Analysis <ArrowRight className="w-4 h-4 ml-1" /></Button>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
              {/* Card 2 */}
              <motion.div
                animate={{ scale: [1, 1.03, 1]} }
                transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                className="h-full"
              >
                <Link to={createPageUrl('VerifiedPartners')} className="block h-full">
                  <Card className="text-left h-full hover:shadow-xl transition-all duration-300 group border-2 border-transparent hover:border-blue-500">
                    <CardHeader>
                      <div className="p-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 w-fit mb-3">
                        <Building2 className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                      </div>
                      <CardTitle className="text-base sm:text-lg group-hover:text-blue-600 transition-colors">Verified Partners</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm sm:text-base text-gray-600 mb-4">Explore our curated network of vetted technology partners.</p>
                      <Button variant="link" className="p-0 h-auto font-semibold text-sm sm:text-base">Explore Partner Network <ArrowRight className="w-4 h-4 ml-1" /></Button>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Success Stories Scrolling Section */}
        <section className="mb-12 sm:mb-16">
          <div className="text-center mb-6 sm:mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
              Real results from our technology partnerships and implementations.
            </p>
          </div>
          
          {caseStudies.length > 0 ? (
            <div 
              className="relative overflow-hidden cursor-grab"
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
            >
              {/* Gradient overlays for smooth edges */}
              <div className="absolute left-0 top-0 w-10 sm:w-20 h-full bg-gradient-to-r from-blue-50 to-transparent z-10 pointer-events-none" />
              <div className="absolute right-0 top-0 w-10 sm:w-20 h-full bg-gradient-to-l from-blue-50 to-transparent z-10 pointer-events-none" />
              
              <div 
                ref={scrollContainerRef}
                className="flex overflow-x-auto scrollbar-hide space-x-4 sm:space-x-6 pb-4"
              >
                {/* Render the list twice for a seamless loop */}
                {[...caseStudies, ...caseStudies].map((study, index) => (
                  <motion.div
                    key={`${study.id}-${index}`}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex-shrink-0 w-72 sm:w-80"
                  >
                    <Card className="h-full hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-4 sm:p-6">
                        <div className="space-y-4">
                          <div>
                            <h3 className="font-bold text-base sm:text-lg mb-2">{study.title}</h3>
                            <Badge variant="outline" className="mb-3 text-xs sm:text-sm">{study.client}</Badge>
                          </div>
                          
                          {study.image_url && (
                            <div className="w-full h-32 sm:h-40 overflow-hidden rounded-lg">
                              <img 
                                src={study.image_url} 
                                alt={study.title}
                                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                              />
                            </div>
                          )}
                          
                          <p className="text-gray-600 text-sm leading-relaxed">
                            {study.description}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 sm:py-16">
              <Code className="w-12 sm:w-16 h-12 sm:h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">Success Stories Loading</h3>
              <p className="text-sm sm:text-base text-gray-500">Our technology success stories will appear here</p>
            </div>
          )}
        </section>

        {/* Updated Tabs Section - Only Technology Capabilities and Our Approach */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-8 sm:space-y-10">
          <div className="flex justify-center">
             <TabsList className="relative grid w-full max-w-sm sm:max-w-md lg:max-w-2xl grid-cols-2 items-center justify-center rounded-2xl bg-gray-100 p-2 text-gray-500 border shadow-inner h-auto">
              {tabsConfig.map(tab => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="relative text-sm sm:text-base font-medium px-2 sm:px-4 py-3 sm:py-3.5 rounded-xl transition-colors data-[state=active]:text-white"
                >
                  <span className="relative z-10">{tab.label}</span>
                </TabsTrigger>
              ))}
              <motion.div
                layoutId="active-tab-saas"
                className="absolute inset-y-2 h-auto rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 shadow-md"
                style={{
                  width: `calc(100% / ${tabsConfig.length})`,
                  x: `${tabsConfig.findIndex(t => t.id === selectedTab) * 100}%`
                }}
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            </TabsList>
          </div>

          <TabsContent value="overview">
            <motion.div
              className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8"
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: {
                    staggerChildren: 0.1,
                  },
                },
              }}
              initial="hidden"
              animate="visible"
            >
              {technologyCapabilities.map((capability, index) => (
                <motion.div
                  key={index}
                  variants={{
                    hidden: { opacity: 0, y: 20 },
                    visible: { opacity: 1, y: 0 },
                  }}
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="h-full shadow-md hover:shadow-xl transition-shadow duration-300">
                    <CardHeader className="flex flex-row items-center gap-3 sm:gap-4">
                      <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 w-fit">
                        <capability.icon className="w-5 sm:w-6 h-5 sm:h-6 text-white" />
                      </div>
                      <CardTitle className="text-base sm:text-lg">{capability.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 text-sm sm:text-base h-10 sm:h-12">{capability.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {capability.technologies.map(tech => (
                          <Badge key={tech} variant="outline" className="text-xs font-medium bg-blue-50 border-blue-200 text-blue-800">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="process">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Discovery & Architecture</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Requirements analysis and technical assessment</li>
                    <li>• System architecture design and technology selection</li>
                    <li>• Security and compliance framework planning</li>
                    <li>• Performance and scalability considerations</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Development & Deployment</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm sm:text-base text-gray-600">
                    <li>• Agile development with regular stakeholder feedback</li>
                    <li>• Automated testing and quality assurance</li>
                    <li>• CI/CD pipeline setup and monitoring</li>
                    <li>• Production deployment and optimization</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
        
        {/* CTA Section */}
        <section className="mt-12 sm:mt-16 text-center">
          <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
            <CardContent className="p-6 sm:p-8">
              <h2 className="text-xl sm:text-2xl font-bold mb-4">Ready to Build Something Amazing?</h2>
              <p className="mb-6 text-blue-100 text-sm sm:text-base lg:text-lg">
                Let's discuss your technology challenges and create a solution that drives real business impact.
              </p>
              <Button size="lg" variant="outline" className="text-blue-600 bg-white hover:bg-gray-100" asChild>
                <Link to={createPageUrl('Intake')}>
                  Start Your Project
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </section>

        <OurStackSection />
      </div>
    </div>
  );
}
