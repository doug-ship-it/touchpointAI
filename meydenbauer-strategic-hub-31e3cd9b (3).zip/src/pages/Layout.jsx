

import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutGrid,
  GitFork,
  Code,
  TrendingUp,
  Hammer,
  Users,
  BrainCircuit,
  Database,
  Menu
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import MeydenbauerLogo from "@/components/ui/MeydenbauerLogo";
import { ExpandedViewProvider } from "@/components/expanded-view/ExpandedViewProvider";
import { Toaster } from 'sonner';
import FloatingIntakeButton from '@/components/ui/FloatingIntakeButton';

const coreServices = [
  {
    title: "App Dev, Cloud + AI",
    url: createPageUrl("SaaSDevelopment"),
    icon: Code,
    description: "Custom software, AI implementation & optimization"
  },
  {
    title: "Operations + VA",
    url: createPageUrl("Operations"),
    icon: Hammer,
    description: "Process optimization & virtual assistance"
  },
];

const intelligenceHubTools = [
  {
    title: "Command Center",
    url: createPageUrl("CommandCenter"),
    icon: LayoutGrid,
    description: "Strategic dashboard & navigation hub"
  },
  {
    title: "Find Connections",
    url: createPageUrl("NetworkIntelligenceDeep"),
    icon: Database,
    description: "Deep-dive search with enriched data"
  },
  {
    title: "AICRM",
    url: createPageUrl("AICRM"),
    icon: Users,
    description: "Network Intelligence & Relationship Management"
  },
  {
    title: "GTM + RevOps",
    url: createPageUrl("GTM"),
    icon: TrendingUp,
    description: "GTM strategy & demand generation automation"
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  // Add Jotform chatbot script to all pages.
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jotfor.ms/agent/embedjs/01992b881dad7799a266b4169cc6e4ed9ad7/embed.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      // Cleanup the script and any elements it creates when the component unmounts
      const existingScript = document.querySelector(`script[src="${script.src}"]`);
      if (existingScript) {
        document.body.removeChild(existingScript);
      }
      // Jotform may also create other elements, we can try to remove them as well.
      // This is a common pattern for chat widgets.
      const jotformWidgets = document.querySelectorAll('iframe[src*="jotform.com"]');
      jotformWidgets.forEach(widget => {
        if (widget.parentElement) {
            widget.parentElement.remove();
        } else {
            widget.remove();
        }
      });
    };
  }, []);

  const NavLink = ({ item }) => (
    <SidebarMenuItem>
      <SidebarMenuButton
        asChild
        className={`hover:bg-[var(--light-teal)] hover:text-[var(--navy)] transition-all duration-200 rounded-lg ${
          location.pathname === item.url
            ? 'bg-[var(--light-teal)] text-[var(--navy)] border-l-4 border-[var(--primary-teal)]'
            : 'text-gray-600 hover:text-[var(--navy)]'
        }`}
      >
        <Link to={item.url} className="flex items-center gap-3 px-3 py-3 w-full">
          <item.icon className="w-5 h-5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="font-medium text-sm" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              {item.title}
            </div>
            <div className="text-xs text-gray-500 truncate" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
              {item.description}
            </div>
          </div>
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );

  return (
    <ExpandedViewProvider>
      <div className="min-h-screen bg-gray-50">
        <style>{`
          :root {
            --primary-teal: #2D7A7A;
            --secondary-teal: #4A9B8E;
            --light-teal: #B8E6E1;
            --accent-teal: #7BC4BC;
            --navy: #2C3E50;
            --warm-gray: #F8F9FA;
          }
          @keyframes pulse-yellow {
            0%, 100% {
              transform: scale(1);
              box-shadow: 0 0 0 0 rgba(250, 204, 21, 0.7);
            }
            50% {
              transform: scale(1.05);
              box-shadow: 0 0 0 10px rgba(250, 204, 21, 0);
            }
          }
          .animate-pulse-yellow {
            animation: pulse-yellow 2s infinite;
          }
        `}</style>

        <SidebarProvider>
          <div className="flex w-full">
            <Sidebar className="hidden md:flex flex-col border-r border-gray-200 bg-white">
              <SidebarHeader className="border-b border-gray-100 p-6">
                <div className="flex items-center gap-3">
                  <MeydenbauerLogo className="w-10 h-10" />
                  <div>
                    <h2 className="font-bold text-lg text-[var(--navy)]" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                      Touchpoint OS
                    </h2>
                    <p className="text-sm text-gray-600" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
                      by mbAI
                    </p>
                  </div>
                </div>
              </SidebarHeader>

              <SidebarContent className="p-3">
                <SidebarMenu className="space-y-1">
                    <NavLink item={{
                      title: "Home",
                      url: createPageUrl("Home"),
                      icon: LayoutGrid,
                      description: "Welcome & overview hub"
                    }} />
                </SidebarMenu>

                <SidebarGroup className="mt-4">
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                    Intake & Routing
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu className="space-y-1">
                      <NavLink item={{
                        title: "Intake & Routing",
                        url: createPageUrl("Intake"),
                        icon: GitFork,
                        description: "Intelligent business need assessment"
                      }} />
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>

                <SidebarGroup className="mt-4">
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                    Intelligence Hub
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu className="space-y-1">
                      {intelligenceHubTools.map((item) => <NavLink key={item.title} item={item} />)}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>

                <SidebarGroup className="mt-4">
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                    Professional Services
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu className="space-y-1">
                      {coreServices.map((item) => <NavLink key={item.title} item={item} />)}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </SidebarContent>
            </Sidebar>

            <main className="flex-1 flex flex-col min-h-screen bg-[var(--warm-gray)] w-full overflow-x-hidden">
              <header className="bg-white border-b border-gray-200 px-4 sm:px-6 py-3 md:hidden sticky top-0 z-40">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MeydenbauerLogo className="w-8 h-8" />
                    <h1 className="text-lg font-bold text-[var(--navy)]" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                      Touchpoint OS
                    </h1>
                  </div>
                  <SidebarTrigger className="animate-pulse-yellow bg-yellow-400 hover:bg-yellow-500 text-gray-900 p-2 rounded-lg transition-colors">
                     <Menu className="w-6 h-6" />
                  </SidebarTrigger>
                </div>
              </header>
              <div className="flex-1 overflow-auto">
                {children}
              </div>
            </main>
          </div>
        </SidebarProvider>
        <Toaster />
      </div>
      <FloatingIntakeButton />
    </ExpandedViewProvider>
  );
}

