import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Resource } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Search, 
  Filter, 
  BookOpen, 
  Download, 
  Star,
  TrendingUp,
  Clock,
  Target,
  Sparkles
} from "lucide-react";

import ResourceCard from "../components/resources/ResourceCard";
import ResourceFilters from "../components/resources/ResourceFilters";
import FeaturedResources from "../components/resources/FeaturedResources";

export default function ResourceLibrary() {
  const [resources, setResources] = useState([]);
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilters, setSelectedFilters] = useState({
    type: "all",
    industry: "all",
    serviceLines: []
  });
  const [activeTab, setActiveTab] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    loadResources();
    loadUser();
  }, []);

  const loadResources = async () => {
    try {
      const data = await Resource.list("-created_date");
      setResources(data);
    } catch (error) {
      console.error("Error loading resources:", error);
    }
    setIsLoading(false);
  };

  const loadUser = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
    } catch (error) {
      console.error("Error loading user data:", error);
    }
  };

  const filterResources = () => {
    let filtered = resources;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(resource =>
        resource.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resource.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (resource.tags || []).some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Type filter
    if (selectedFilters.type !== "all") {
      filtered = filtered.filter(resource => resource.type === selectedFilters.type);
    }

    // Industry filter
    if (selectedFilters.industry !== "all" && user?.industry_segment) {
      filtered = filtered.filter(resource => 
        (resource.industry_segments || []).includes(selectedFilters.industry) ||
        (resource.industry_segments || []).includes(user.industry_segment)
      );
    }

    // Tab filter
    switch (activeTab) {
      case "recommended":
        // Filter by user's industry and show higher-rated content
        filtered = filtered.filter(resource =>
          (resource.industry_segments || []).includes(user?.industry_segment) ||
          resource.featured
        );
        break;
      case "recent":
        // Already sorted by created_date in descending order
        break;
      case "popular":
        filtered = filtered.sort((a, b) => (b.download_count || 0) - (a.download_count || 0));
        break;
      default:
        break;
    }

    return filtered;
  };

  const filteredResources = filterResources();

  const handleResourceAccess = async (resource) => {
    // Track resource access and update download count
    try {
      await Resource.update(resource.id, {
        download_count: (resource.download_count || 0) + 1
      });
      
      // Update user engagement
      if (user) {
        await User.updateMyUserData({
          lead_score: (user.lead_score || 0) + 5,
          engagement_level: user.engagement_level === 'cold' ? 'warm' : user.engagement_level
        });
      }
      
      // Open resource
      if (resource.content_url) {
        window.open(resource.content_url, '_blank');
      }
      
      // Refresh data
      loadResources();
    } catch (error) {
      console.error("Error accessing resource:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/20 to-teal-50/20">
      {/* Header */}
      <div className="px-6 pt-8 pb-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-teal-200 mb-4">
              <BookOpen className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-700" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                Personalized for {user?.company_name || 'You'}
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
              Strategic Resource Library
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
              Discover curated insights, templates, and tools designed to accelerate your strategic transformation
            </p>
          </motion.div>

          {/* Featured Resources */}
          <FeaturedResources 
            resources={resources.filter(r => r.featured)} 
            onResourceAccess={handleResourceAccess}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 pb-16">
        <div className="max-w-7xl mx-auto">
          {/* Search and Filter Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 shadow-lg mb-8"
          >
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search resources..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12"
                />
              </div>
              
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                </Button>
                
                <Badge variant="secondary" className="px-3 py-1">
                  {filteredResources.length} resources
                </Badge>
              </div>
            </div>

            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 pt-6 border-t border-gray-200"
                >
                  <ResourceFilters
                    selectedFilters={selectedFilters}
                    onFiltersChange={setSelectedFilters}
                    userIndustry={user?.industry_segment}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="bg-white/90 backdrop-blur-sm border border-gray-200 shadow-md p-1">
              <TabsTrigger value="all" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                All Resources
              </TabsTrigger>
              <TabsTrigger value="recommended" className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Recommended
              </TabsTrigger>
              <TabsTrigger value="recent" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Recently Added
              </TabsTrigger>
              <TabsTrigger value="popular" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Most Popular
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-6">
              <AnimatePresence>
                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array(6).fill(0).map((_, i) => (
                      <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                        <div className="h-4 bg-gray-200 rounded mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded mb-4"></div>
                        <div className="h-8 bg-gray-200 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : filteredResources.length > 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
                  >
                    {filteredResources.map((resource, index) => (
                      <ResourceCard
                        key={resource.id}
                        resource={resource}
                        onAccess={handleResourceAccess}
                        delay={index * 0.1}
                      />
                    ))}
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-16"
                  >
                    <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No resources found</h3>
                    <p className="text-gray-500 mb-6">Try adjusting your search or filters</p>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedFilters({ type: "all", industry: "all", serviceLines: [] });
                      }}
                    >
                      Clear Filters
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}