import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutGrid, 
  Users, 
  Database, 
  TrendingUp, 
  Zap, 
  Brain,
  Shield,
  Lightbulb,
  ArrowRight,
  Upload,
  Code,
  Hammer,
  Building2,
  FileText,
  UserPlus,
  Target,
  CheckCircle2,
  Calendar,
  MessageSquare
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { NetworkConnection } from '.@/api/entities/NetworkConnection';
import { User } from '@/api/entities';
import { toast } from 'sonner';

// Import migrated components
import DataEnrichmentTool from '../components/network/DataEnrichmentTool';
import SmartIntroFeed from '../components/network/relationship-path/SmartIntroFeed';
import PathSearchBar from '../components/network/relationship-path/PathSearchBar';
import RelationshipPathView from '../components/network/relationship-path/RelationshipPathView';

export default function CommandCenter() {
  const [contacts, setContacts] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasEnrichmentAccess, setHasEnrichmentAccess] = useState(false);
  
  // Migrated state for relationship path functionality
  const [pathSearchTarget, setPathSearchTarget] = useState(null);
  const [isPathSearching, setIsPathSearching] = useState(false);

  const coreServices = [
    {
      title: "App Dev, Cloud + AI",
      description: "Custom software, AI implementation & optimization",
      icon: Code,
      url: createPageUrl("SaaSDevelopment"),
      color: "bg-blue-500"
    },
    {
      title: "Operations + VA",
      description: "Process optimization & virtual assistance", 
      icon: Hammer,
      url: createPageUrl("Operations"),
      color: "bg-green-500"
    }
  ];

  const intelligenceTools = [
    {
      title: "Find Connections",
      description: "Browse and search your professional network",
      icon: Database,
      url: createPageUrl("NetworkIntelligenceDeep"),
      color: "bg-purple-500"
    },
    {
      title: "AICRM",
      description: "Network Intelligence & Relationship Management",
      icon: Users,
      url: createPageUrl("AICRM"),
      color: "bg-indigo-500"
    },
    {
      title: "GTM + RevOps", 
      description: "GTM strategy & demand generation automation",
      icon: TrendingUp,
      url: createPageUrl("GTM"),
      color: "bg-orange-500"
    }
  ];

  const additionalResources = [
    {
      title: "Resource Library",
      description: "Case studies, whitepapers & strategic resources",
      icon: FileText,
      url: createPageUrl("ResourceLibrary"),
      color: "bg-teal-500"
    },
    {
      title: "Candidate Portal",
      description: "Access talent acquisition resources",
      icon: UserPlus,
      url: createPageUrl("CandidatePortal"),
      color: "bg-pink-500"
    },
    {
      title: "ArchetypeDNA",
      description: "Discover your leadership archetype",
      icon: Target,
      url: createPageUrl("ArchetypeDNA"),
      color: "bg-amber-500"
    }
  ];

  // Migrated functions from NetworkIntelligenceDeep
  const fetchContacts = useCallback(async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    try {
      const connections = await NetworkConnection.list('-updated_date');
      setContacts(connections || []);
    } catch (e) {
      console.error('Failed to load connections:', e);
      setContacts([]);
    } finally {
      if (showLoading) setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        await fetchContacts(false);
        const currentUser = await User.me();
        setUser(currentUser);
        // Check if user has admin role for enrichment access
        if (currentUser?.role === 'admin') {
          setHasEnrichmentAccess(true);
        }
      } catch (e) {
        console.warn("Not logged in, proceeding with limited access.");
      } finally {
        setIsLoading(false);
      }
    };
    loadInitialData();
  }, [fetchContacts]);

  // Migrated path search functionality
  const handlePathSearch = async (searchTerm) => {
    setIsPathSearching(true);
    const lowerCaseSearch = searchTerm.toLowerCase();
    const target = contacts.find(c =>
      (c.connection_name && c.connection_name.toLowerCase().includes(lowerCaseSearch)) ||
      (c.connection_company && c.connection_company.toLowerCase().includes(lowerCaseSearch)) ||
      (c.linkedin_url && c.linkedin_url.includes(lowerCaseSearch))
    );

    if (target) {
      setPathSearchTarget(target);
    } else {
      toast.error(`Could not find a contact matching "${searchTerm}".`);
    }

    await new Promise(resolve => setTimeout(resolve, 500));
    setIsPathSearching(false);
  };

  const resetPathSearch = () => {
    setPathSearchTarget(null);
  };

  const handleNavigateToSearch = () => {
    // Navigate to Find Connections page
    window.location.href = createPageUrl("NetworkIntelligenceDeep");
  };

  // Migrated enrichment functionality
  const handleRequestPasswordAccess = (actionType) => {
    if (actionType === 'enrichment') {
      const ADMIN_PASSWORD = "mbai2024";
      const enteredPassword = window.prompt("Enter admin password for AI enrichment access:");
      
      if (enteredPassword === ADMIN_PASSWORD) {
        setHasEnrichmentAccess(true);
        toast.success("Access Granted! Advanced AI Enrichment features are now available for this session.");
      } else if (enteredPassword !== null) {
        toast.error("Incorrect password. Access denied.");
      }
    }
  };

  const handleEnrichmentComplete = () => {
    fetchContacts();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[var(--primary-teal)] mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Loading Command Center</h2>
          <p className="text-gray-600">Preparing your strategic dashboard...</p>
        </div>
      </div>
    );
  }

  // Show relationship path view if target is selected
  if (pathSearchTarget) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
        <div className="max-w-7xl mx-auto">
          <RelationshipPathView
            target={pathSearchTarget}
            allContacts={contacts}
            currentUser={user}
            onBack={resetPathSearch}
            onNavigateToSearch={handleNavigateToSearch}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="w-20 h-20 bg-gradient-to-br from-[var(--primary-teal)] to-[var(--secondary-teal)] rounded-3xl flex items-center justify-center mx-auto mb-6">
            <LayoutGrid className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Command Center</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your strategic dashboard for business intelligence, network analysis, and growth acceleration
          </p>
        </motion.div>

        {/* AI-Powered Features Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-16"
        >
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-2">
              <Brain className="w-6 h-6 text-[var(--primary-teal)]" />
              AI-Powered Intelligence
            </h2>
            <p className="text-gray-600">Advanced tools for network enrichment and relationship discovery</p>
          </div>

          {/* Warm Introduction Finder */}
          <Card className="mb-8 border-0 shadow-lg bg-gradient-to-r from-purple-50 to-blue-50 backdrop-blur-sm">
            <CardContent className="p-8">
              <div className="text-center max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mb-3">Warm Introduction Finder</h2>
                <p className="text-slate-600 mb-6">
                  Discover optimal paths to new contacts through your existing network.
                </p>
                <PathSearchBar onSearch={handlePathSearch} isLoading={isPathSearching} />
              </div>
            </CardContent>
          </Card>

          {/* Smart Introduction Suggestions */}
          <SmartIntroFeed onFindPath={handlePathSearch} />

          {/* AI Data Enrichment Tool */}
          <div className="mt-12">
            {(user?.role === 'admin' || hasEnrichmentAccess) ? (
              <DataEnrichmentTool
                connections={contacts}
                onEnrichmentComplete={handleEnrichmentComplete}
                onRequestPasswordAccess={handleRequestPasswordAccess}
              />
            ) : (
              <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 overflow-hidden">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-600 to-indigo-600 rounded-3xl flex items-center justify-center mb-6">
                    <Shield className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-3">Advanced AI Data Enrichment</h3>
                  <p className="text-slate-600 mb-8 text-lg max-w-2xl mx-auto">
                    Unlock powerful AI-driven contact enrichment with industry insights, seniority mapping, and intelligent summaries.
                  </p>
                  <Button
                    onClick={() => handleRequestPasswordAccess('enrichment')}
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-3 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200"
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Unlock AI Enrichment
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </motion.div>

        {/* Core Services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Core Services</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {coreServices.map((service, index) => (
              <motion.div
                key={service.title}
                whileHover={{ scale: 1.02, y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <Link to={service.url}>
                  <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <CardContent className="p-8">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <service.icon className="w-7 h-7 text-white" />
                        </div>
                        <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-[var(--primary-teal)] group-hover:translate-x-1 transition-all duration-300" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-[var(--primary-teal)] transition-colors duration-300">
                        {service.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">{service.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Intelligence Hub Tools */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Intelligence Hub</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {intelligenceTools.map((tool, index) => (
              <motion.div
                key={tool.title}
                whileHover={{ scale: 1.02, y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <Link to={tool.url}>
                  <Card className="h-full border-0 shadow-md hover:shadow-lg transition-all duration-300 group">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <div className={`w-12 h-12 ${tool.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <tool.icon className="w-6 h-6 text-white" />
                        </div>
                        <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[var(--primary-teal)] group-hover:translate-x-1 transition-all duration-300" />
                      </div>
                      <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-[var(--primary-teal)] transition-colors duration-300">
                        {tool.title}
                      </h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{tool.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Additional Resources */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Additional Resources</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {additionalResources.map((resource, index) => (
              <motion.div
                key={resource.title}
                whileHover={{ scale: 1.02, y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <Link to={resource.url}>
                  <Card className="h-full border-0 shadow-md hover:shadow-lg transition-all duration-300 group">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <div className={`w-12 h-12 ${resource.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <resource.icon className="w-6 h-6 text-white" />
                        </div>
                        <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[var(--primary-teal)] group-hover:translate-x-1 transition-all duration-300" />
                      </div>
                      <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-[var(--primary-teal)] transition-colors duration-300">
                        {resource.title}
                      </h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{resource.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Stats */}
        {contacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.0 }}
            className="mt-16"
          >
            <Card className="border-0 shadow-lg bg-gradient-to-r from-[var(--primary-teal)] to-[var(--secondary-teal)] text-white">
              <CardContent className="p-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Network Overview</h3>
                  <p className="text-teal-100 mb-6">Your professional network at a glance</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="text-center">
                      <div className="text-3xl font-bold mb-2">{contacts.length.toLocaleString()}</div>
                      <div className="text-teal-100">Total Contacts</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold mb-2">
                        {[...new Set(contacts.map(c => c.connection_company).filter(Boolean))].length}
                      </div>
                      <div className="text-teal-100">Companies</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold mb-2">
                        {contacts.filter(c => c.enriched_industry).length}
                      </div>
                      <div className="text-teal-100">Enriched Profiles</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}