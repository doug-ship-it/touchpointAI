
import React, { useState } from 'react';
import AppLayout from '../components/aicrm/AppLayout';
import IntelligenceDashboard from '../components/aicrm/IntelligenceDashboard';
import ExecutiveHeader from '../components/aicrm/ExecutiveHeader';
import ContactList from '../components/aicrm/ContactList';
import ContactDetailView from '../components/aicrm/ContactDetailView';

// New imports for the changes
import CSVUploadModal from '../components/network/CSVUploadModal';
import EnhancedUploadButton from '../components/network/EnhancedUploadButton';

export default function AICRM() {
  // New state variables from outline
  const [selectedContactId, setSelectedContactId] = useState(null);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);

  // New function for upload completion from outline
  const handleUploadComplete = () => {
    setIsCsvModalOpen(false);
    // Refresh the contact list if needed
    window.location.reload();
  };

  // New function to open CSV modal from outline
  const handleFileSelect = () => {
    setIsCsvModalOpen(true);
  };

  return (
    <>
      <CSVUploadModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        onUploadComplete={handleUploadComplete}
      />

      {/* Main container with updated min-h-screen and no custom styles */}
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <AppLayout>
          <ExecutiveHeader />
          
          {/* Enhanced Upload Button as per outline */}
          <div className="px-6 mb-6">
            <EnhancedUploadButton 
              onFileSelect={handleFileSelect}
              className="max-w-xl"
            />
          </div>

          {/* Main content area with flex layout as per outline */}
          <div className="flex-1 flex">
            {/* Left pane for Contact List/Detail View */}
            <div className="flex-1">
              {selectedContactId ? (
                <ContactDetailView 
                  contactId={selectedContactId} 
                  onBack={() => setSelectedContactId(null)} 
                />
              ) : (
                <ContactList onSelectContact={setSelectedContactId} />
              )}
            </div>
            {/* Right pane for Intelligence Dashboard */}
            <div className="w-80 bg-white border-l border-gray-200">
              <IntelligenceDashboard />
            </div>
          </div>
        </AppLayout>
      </div>
    </>
  );
}
