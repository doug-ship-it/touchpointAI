import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

export default function ResourceFilters({ selectedFilters, onFiltersChange, userIndustry }) {
  const resourceTypes = [
    { value: 'case_study', label: 'Case Studies' },
    { value: 'whitepaper', label: 'Whitepapers' },
    { value: 'template', label: 'Templates' },
    { value: 'guide', label: 'Guides' },
    { value: 'webinar', label: 'Webinars' },
    { value: 'assessment', label: 'Assessments' },
    { value: 'toolkit', label: 'Toolkits' }
  ];

  const industries = [
    { value: 'technology', label: 'Technology' },
    { value: 'consulting_financial', label: 'Consulting & Financial' },
    { value: 'private_equity_real_estate', label: 'Private Equity & Real Estate' },
    { value: 'non_profit', label: 'Non-Profit' },
    { value: 'retail_consumer', label: 'Retail & Consumer' },
    { value: 'other', label: 'Other' }
  ];

  const serviceLines = [
    'App Development & AI',
    'GTM & RevOps',
    'Operations & VA',
    'Strategic Consulting',
    'Executive Search',
    'Market Research'
  ];

  const handleServiceLineToggle = (serviceLine) => {
    const currentServiceLines = selectedFilters.serviceLines || [];
    const newServiceLines = currentServiceLines.includes(serviceLine)
      ? currentServiceLines.filter(sl => sl !== serviceLine)
      : [...currentServiceLines, serviceLine];
    
    onFiltersChange({
      ...selectedFilters,
      serviceLines: newServiceLines
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Resource Type
          </label>
          <Select
            value={selectedFilters.type}
            onValueChange={(value) => onFiltersChange({ ...selectedFilters, type: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {resourceTypes.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Industry Focus
          </label>
          <Select
            value={selectedFilters.industry}
            onValueChange={(value) => onFiltersChange({ ...selectedFilters, industry: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="All Industries" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Industries</SelectItem>
              {userIndustry && (
                <SelectItem value={userIndustry}>
                  My Industry ({industries.find(i => i.value === userIndustry)?.label})
                </SelectItem>
              )}
              {industries.map(industry => (
                <SelectItem key={industry.value} value={industry.value}>
                  {industry.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Service Lines
        </label>
        <div className="flex flex-wrap gap-2">
          {serviceLines.map(serviceLine => {
            const isSelected = selectedFilters.serviceLines?.includes(serviceLine);
            return (
              <Badge
                key={serviceLine}
                variant={isSelected ? "default" : "outline"}
                className={`cursor-pointer transition-colors ${
                  isSelected 
                    ? 'bg-teal-600 text-white hover:bg-teal-700' 
                    : 'hover:bg-gray-100'
                }`}
                onClick={() => handleServiceLineToggle(serviceLine)}
              >
                {serviceLine}
                {isSelected && (
                  <X className="w-3 h-3 ml-1" />
                )}
              </Badge>
            );
          })}
        </div>
      </div>
    </div>
  );
}