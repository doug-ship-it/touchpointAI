import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BookOpen, Download, ExternalLink } from 'lucide-react';

export default function ResourceCard({ resource, onAccess, delay = 0 }) {
  const getResourceTypeColor = (type) => {
    const colors = {
      case_study: 'bg-blue-100 text-blue-800',
      whitepaper: 'bg-purple-100 text-purple-800',
      template: 'bg-green-100 text-green-800',
      guide: 'bg-orange-100 text-orange-800',
      webinar: 'bg-red-100 text-red-800',
      assessment: 'bg-indigo-100 text-indigo-800',
      toolkit: 'bg-teal-100 text-teal-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  const getResourceIcon = (type) => {
    const icons = {
      case_study: BookOpen,
      whitepaper: BookOpen,
      template: Download,
      guide: BookOpen,
      webinar: ExternalLink,
      assessment: BookOpen,
      toolkit: Download
    };
    const Icon = icons[type] || BookOpen;
    return <Icon className="w-4 h-4" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="h-full hover:shadow-lg transition-shadow duration-300 bg-white/90 backdrop-blur-sm border border-gray-200">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <Badge className={`${getResourceTypeColor(resource.type)} mb-2`}>
                {resource.type?.replace('_', ' ').toUpperCase()}
              </Badge>
              <CardTitle className="text-lg font-semibold text-gray-900 leading-tight">
                {resource.title}
              </CardTitle>
            </div>
            <div className="text-gray-400">
              {getResourceIcon(resource.type)}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          <p className="text-gray-600 text-sm mb-4 line-clamp-3">
            {resource.description}
          </p>
          
          {resource.tags && resource.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-4">
              {resource.tags.slice(0, 3).map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
              {resource.tags.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{resource.tags.length - 3}
                </Badge>
              )}
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <div className="text-xs text-gray-500">
              {resource.download_count > 0 && (
                <span>{resource.download_count} downloads</span>
              )}
            </div>
            <Button
              onClick={() => onAccess(resource)}
              className="bg-teal-600 hover:bg-teal-700 text-white"
              size="sm"
            >
              Access Resource
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}