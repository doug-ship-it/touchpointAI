import React, { useEffect, useState } from 'react';
import { motion, useSpring, AnimatePresence } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { useExpandedView } from '../expanded-view/ExpandedViewProvider';

const BouncingResourceCircle = ({ particle, isRecommended, isSpecialPulse }) => {
  const { title, Icon, link, size, color, pos } = particle;
  const [isHovered, setIsHovered] = useState(false);
  const { openExpandedView } = useExpandedView();

  // Use springs for smooth animation with improved settings
  const smoothX = useSpring(pos.x, { stiffness: 120, damping: 25, mass: 0.8 });
  const smoothY = useSpring(pos.y, { stiffness: 120, damping: 25, mass: 0.8 });

  useEffect(() => {
    smoothX.set(pos.x);
    smoothY.set(pos.y);
  }, [pos.x, pos.y, smoothX, smoothY]);
  
  const finalSize = (isRecommended || isSpecialPulse) ? size * 1.15 : size;

  const handleClick = (e) => {
    e.preventDefault();
    openExpandedView(link, title);
  };

  return (
    <motion.div
      style={{
        width: finalSize,
        height: finalSize,
        x: smoothX,
        y: smoothY,
        zIndex: isHovered ? 50 : (isRecommended ? 20 : (isSpecialPulse ? 15 : 10)),
      }}
      className={`absolute flex items-center justify-center rounded-full cursor-pointer overflow-hidden ${color}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.08, transition: { duration: 0.3 } }}
      animate={
        isRecommended ? {
            scale: [1, 1.12, 1],
            transition: { duration: 1.8, repeat: Infinity, ease: "easeInOut" }
        } : isSpecialPulse ? {
            scale: [1, 1.08, 1],
            transition: { duration: 2.2, repeat: Infinity, ease: "easeInOut" }
        } : {}
      }
    >
      <AnimatePresence>
        {isRecommended && !isHovered && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.5, delay: 1, ease: "easeOut" }}
            className="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-sm px-4 py-2 rounded-lg shadow-lg whitespace-nowrap z-50"
          >
            I think you'll like this one 💪🏻
          </motion.div>
        )}
      </AnimatePresence>

      <button onClick={handleClick} className="w-full h-full">
        <motion.div
          className="w-full h-full p-4 flex flex-col items-center justify-center text-center"
          animate={{
            background: isRecommended
              ? `radial-gradient(circle, rgba(0, 191, 165, 0.1) 0%, transparent 70%)`
              : `radial-gradient(circle, rgba(255, 255, 255, 0.8) 0%, transparent 70%)`,
          }}
        >
          <AnimatePresence>
            {!isHovered ? (
              <motion.div
                key="icon"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                className="flex flex-col items-center w-full"
              >
                <div className="p-3 bg-gradient-to-br from-teal-500 to-blue-500 rounded-full mb-3">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <span className="text-sm font-bold leading-tight text-slate-700 text-center px-2 break-words">
                  {title}
                </span>
              </motion.div>
            ) : (
              <motion.div
                key="explore"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="flex flex-col items-center justify-center"
              >
                <ArrowUpRight className="w-12 h-12 text-teal-500 mb-2"/>
                <span className="text-lg font-bold text-slate-700">Explore</span>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </button>
      {(isRecommended || isSpecialPulse) && (
         <motion.div 
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{boxShadow: isRecommended ? '0 0 25px 8px rgba(0, 191, 165, 0.6)' : '0 0 20px 6px rgba(80, 78, 217, 0.6)'}}
            animate={{
                boxShadow: isRecommended 
                ? [
                    '0 0 25px 8px rgba(0, 191, 165, 0.6)',
                    '0 0 40px 15px rgba(0, 191, 165, 0.4)',
                    '0 0 25px 8px rgba(0, 191, 165, 0.6)',
                ]
                : [
                    '0 0 20px 6px rgba(80, 78, 217, 0.6)',
                    '0 0 35px 12px rgba(80, 78, 217, 0.4)',
                    '0 0 20px 6px rgba(80, 78, 217, 0.6)',
                ]
            }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
         />
      )}
    </motion.div>
  );
};

export default BouncingResourceCircle;