
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FormSubmission } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { User } from '@/api/entities';
import BouncingResourceCircle from './BouncingResourceCircle';
import { Loader, Library, Presentation, Code, Map, Users, TrendingUp, Bot, Sparkles } from 'lucide-react';

const resources = [
  { id: 1, title: "Notion Tech Library", Icon: Library, link: "https://mdbrp.com/tech-notion-library", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 2, title: "Part-Time Virtual Assistant", Icon: Presentation, link: "https://mdbrp.com/va", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 3, title: "Top 7 Fintech APIs", Icon: Code, link: "https://mdbrp.com/fintech-apis", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 4, title: "2025 MCP Guide", Icon: Map, link: "https://mdbrp.com/guide-MCP", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 5, title: "Demand Gen Autopilot", Icon: Users, link: "https://mdbrp.com/gtm-services", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 6, title: "AI Healthtech Case Study", Icon: TrendingUp, link: "https://mdbrp.com/vendor-rfi", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" },
  { id: 7, title: "TouchpointAI Copilot", Icon: Bot, link: "https://touchpointconsulting.co", size: 260, color: "bg-white/90 backdrop-blur-sm border-2 border-teal-500 shadow-xl" }
];

export default function ResourcesUniverse() {
  const [recommendedId, setRecommendedId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [userArchetype, setUserArchetype] = useState(null);
  const containerRef = useRef(null);
  const [particles, setParticles] = useState([]);
  const requestRef = useRef();
  const [containerBounds, setContainerBounds] = useState({ width: 0, height: 0 });

  // Fetch user archetype
  useEffect(() => {
    const fetchUser = async () => {
        try {
            const me = await User.me();
            if (me && me.techArchetype) {
                setUserArchetype(me.techArchetype);
            }
        } catch (e) {
            console.warn("Could not fetch user archetype.", e);
        }
    };
    fetchUser();
  }, []);

  // Initialize particles with proper boundaries - bottom 80% only
  useEffect(() => {
    if (containerRef.current && particles.length === 0) {
      const container = containerRef.current;
      const { clientWidth, clientHeight } = container;
      
      // Set up boundaries - particles occupy bottom 80% only
      const headerReservedHeight = clientHeight * 0.2; // Reserve top 20% for header
      const topBoundary = headerReservedHeight;
      const bottomBoundary = 50; // Space for any bottom UI
      
      // Calculate middle 60% horizontal bounds
      const totalWidth = clientWidth;
      const usableWidth = totalWidth * 0.6; // 60% of total width
      const horizontalOffset = (totalWidth - usableWidth) / 2; // Center the 60% area
      
      const availableHeight = clientHeight - topBoundary - bottomBoundary;
      
      setContainerBounds({ width: clientWidth, height: clientHeight });
      
      setParticles(resources.map((res, index) => {
        const radius = res.size / 2;
        const maxX = usableWidth - res.size;
        const maxY = availableHeight - res.size;
        
        // Create a grid-like distribution for better spacing
        const cols = Math.ceil(Math.sqrt(resources.length));
        const rows = Math.ceil(resources.length / cols);
        
        const col = index % cols;
        const row = Math.floor(index / cols);
        
        // Base position in grid with some randomization
        const baseX = (col / Math.max(cols - 1, 1)) * Math.max(0, maxX);
        const baseY = (row / Math.max(rows - 1, 1)) * Math.max(0, maxY);
        
        // Add some randomization to avoid perfect grid
        const randomOffsetX = (Math.random() - 0.5) * (usableWidth / cols) * 0.3;
        const randomOffsetY = (Math.random() - 0.5) * (availableHeight / rows) * 0.3;
        
        return {
          ...res,
          pos: {
            x: horizontalOffset + Math.max(0, Math.min(maxX, baseX + randomOffsetX)),
            y: topBoundary + Math.max(0, Math.min(maxY, baseY + randomOffsetY)),
          },
          vel: {
            x: (Math.random() - 0.5) * 0.96, // Increased by 20% (0.8 * 1.2)
            y: (Math.random() - 0.5) * 0.96, // Increased by 20%
          },
          radius: radius,
          horizontalBounds: { left: horizontalOffset, right: horizontalOffset + usableWidth }
        };
      }));
    }
  }, [containerRef, particles.length]);

  // Handle container resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const { clientWidth, clientHeight } = containerRef.current;
        setContainerBounds({ width: clientWidth, height: clientHeight });

        // Re-initialize particles to adjust to new bounds
        setParticles(prevParticles => {
          const totalWidth = clientWidth;
          const usableWidth = totalWidth * 0.6;
          const horizontalOffset = (totalWidth - usableWidth) / 2;
          const headerReservedHeight = clientHeight * 0.2; // Top 20% reserved
          const topBoundary = headerReservedHeight;
          const bottomBoundary = 50;
          const availableHeight = clientHeight - topBoundary - bottomBoundary;

          return prevParticles.map(p => {
            const newHorizontalBounds = { left: horizontalOffset, right: horizontalOffset + usableWidth };
            
            // Ensure particles stay within new bounds after resize
            let newX = p.pos.x;
            let newY = p.pos.y;

            if (newX < newHorizontalBounds.left) newX = newHorizontalBounds.left;
            if (newX + p.size > newHorizontalBounds.right) newX = newHorizontalBounds.right - p.size;
            if (newY < topBoundary) newY = topBoundary;
            if (newY + p.size > topBoundary + availableHeight) newY = topBoundary + availableHeight - p.size;

            return {
              ...p,
              pos: { x: newX, y: newY },
              horizontalBounds: newHorizontalBounds
            };
          });
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const animate = useCallback(() => {
    setParticles(prevParticles => {
      const newParticles = prevParticles.map(p => ({
        ...p,
        pos: { ...p.pos },
        vel: { ...p.vel }
      }));

      if (!containerRef.current) return newParticles;
      
      const { clientHeight } = containerRef.current;
      const headerReservedHeight = clientHeight * 0.2; // Top 20% reserved
      const topBoundary = headerReservedHeight;
      const bottomBoundary = 50;

      // Update positions and handle boundary collisions
      newParticles.forEach(p => {
        p.pos.x += p.vel.x;
        p.pos.y += p.vel.y;

        // Left/right boundary collisions - use particle's horizontal bounds
        const leftBound = p.horizontalBounds?.left || 0;
        const rightBound = p.horizontalBounds?.right || containerRef.current.clientWidth;
        
        if (p.pos.x < leftBound) {
          p.vel.x = Math.abs(p.vel.x); // Ensure positive velocity
          p.pos.x = leftBound;
        } else if (p.pos.x + p.size > rightBound) {
          p.vel.x = -Math.abs(p.vel.x); // Ensure negative velocity
          p.pos.x = rightBound - p.size;
        }

        // Top/bottom boundary collisions - respect header space
        if (p.pos.y < topBoundary) {
          p.vel.y = Math.abs(p.vel.y); // Ensure positive velocity
          p.pos.y = topBoundary;
        } else if (p.pos.y + p.size > clientHeight - bottomBoundary) {
          p.vel.y = -Math.abs(p.vel.y); // Ensure negative velocity
          p.pos.y = clientHeight - bottomBoundary - p.size;
        }
      });

      // Handle circle-to-circle collisions with enhanced physics (increased by 20%)
      for (let i = 0; i < newParticles.length; i++) {
        for (let j = i + 1; j < newParticles.length; j++) {
          const p1 = newParticles[i];
          const p2 = newParticles[j];

          const dx = (p1.pos.x + p1.radius) - (p2.pos.x + p2.radius);
          const dy = (p1.pos.y + p1.radius) - (p2.pos.y + p2.radius);
          const distance = Math.sqrt(dx * dx + dy * dy);
          const minDistance = p1.radius + p2.radius;

          if (distance < minDistance && distance > 0) {
            // Resolve overlap with improved separation (increased by 20%)
            const overlap = minDistance - distance + 2.4; // Increased by 20% (2 * 1.2)
            const normalX = dx / distance;
            const normalY = dy / distance;

            const separationX = normalX * overlap * 0.6; // Increased by 20% (0.5 * 1.2)
            const separationY = normalY * overlap * 0.6;

            p1.pos.x += separationX;
            p1.pos.y += separationY;
            p2.pos.x -= separationX;
            p2.pos.y -= separationY;

            // Elastic collision with enhanced dampening (increased dynamics by 20%)
            const relativeVelX = p1.vel.x - p2.vel.x;
            const relativeVelY = p1.vel.y - p2.vel.y;
            const dotProduct = relativeVelX * normalX + relativeVelY * normalY;

            if (dotProduct > 0) continue;

            const restitution = 0.96; // Increased by 20% (0.8 * 1.2)
            const impulse = 2 * dotProduct * restitution / 2; // Assuming equal mass

            p1.vel.x -= impulse * normalX * 0.6; // Increased by 20% (0.5 * 1.2)
            p1.vel.y -= impulse * normalY * 0.6;
            p2.vel.x += impulse * normalX * 0.6;
            p2.vel.y += impulse * normalY * 0.6;

            // Apply velocity limits to prevent excessive speeds (increased by 20%)
            const maxVel = 2.4; // Increased by 20% (2 * 1.2)
            p1.vel.x = Math.max(-maxVel, Math.min(maxVel, p1.vel.x));
            p1.vel.y = Math.max(-maxVel, Math.min(maxVel, p1.vel.y));
            p2.vel.x = Math.max(-maxVel, Math.min(maxVel, p2.vel.x));
            p2.vel.y = Math.max(-maxVel, Math.min(maxVel, p2.vel.y));
          }
        }
      }

      return newParticles;
    });
    requestRef.current = requestAnimationFrame(animate);
  }, []);

  // Animation loop
  useEffect(() => {
    if (particles.length > 0) {
      requestRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [animate, particles.length]);

  // Get AI recommendation based on user intake
  useEffect(() => {
    const getRecommendation = async () => {
      try {
        const submissions = await FormSubmission.list('-created_date', 1);
        if (submissions.length > 0) {
          const latestSubmission = submissions[0];
          let userNeeds = {};
          
          try {
            const intakeData = JSON.parse(latestSubmission.intake_data);
            userNeeds = {
              challenges: intakeData.challenges || [],
              hiring: intakeData.hiring || [],
              support: intakeData.support || [],
              company: intakeData.company || {}
            };
          } catch (parseError) {
            console.warn("Could not parse intake data:", parseError);
            userNeeds = { challenges: [], hiring: [], support: [], company: {} };
          }

          const resourcesForLLM = resources.map(({ id, title }) => ({ id, title }));
          const prompt = `Based on a user's business needs from their intake form (Challenges: ${userNeeds.challenges.join(', ')}, Hiring needs: ${userNeeds.hiring.join(', ')}, Support needs: ${userNeeds.support.join(', ')}, Industry: ${userNeeds.company.industry || 'Unknown'}), which of the following resources would be most valuable? Respond with a JSON object like {"recommended_id": 2}. Resources: ${JSON.stringify(resourcesForLLM)}`;
          
          const result = await InvokeLLM({ 
            prompt, 
            response_json_schema: { 
              type: "object", 
              properties: { 
                recommended_id: { type: "number" } 
              } 
            } 
          });
          
          if (result && result.recommended_id) {
            setRecommendedId(result.recommended_id);
            setTimeout(() => setAnalysisComplete(true), 1000);
          }
        }
      } catch (error) {
        console.error("Failed to get recommendation:", error);
      } finally {
        setTimeout(() => setIsLoading(false), 1200);
      }
    };
    getRecommendation();
  }, []);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900 text-white flex flex-col items-center justify-center p-4 sm:p-8 overflow-hidden relative">
      {/* Background glassmorphism effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-teal-500/5 via-blue-500/5 to-purple-500/5 backdrop-blur-3xl"></div>
      
      <div className="absolute top-0 left-0 w-full z-20 pointer-events-none" style={{ height: '20%' }}>
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center my-8 md:my-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-4">
            <Sparkles className="w-5 h-5 text-teal-300" />
            <span className="text-sm font-medium text-teal-200">AI-Powered Resource Discovery</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-white via-teal-200 to-blue-200 bg-clip-text text-transparent">
            Resource Universe
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed px-4">
            Explore our curated collection of strategic resources. Hover or click on any bubble to discover valuable insights tailored to your business needs.
          </p>
        </motion.div>

        <div className="h-12 flex items-center justify-center">
          <AnimatePresence>
            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                className="flex items-center gap-3 text-teal-300 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/20 pointer-events-auto"
              >
                <Loader className="animate-spin w-5 h-5" />
                <span className="font-medium">Analyzing your intake to suggest a resource...</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div
        ref={containerRef}
        className="absolute inset-0 w-full"
        style={{ 
          top: '0px',
          bottom: '0px',
          pointerEvents: 'auto'
        }}
      >
        {particles.length > 0 && particles.map((particle) => (
          <BouncingResourceCircle
            key={particle.id}
            isRecommended={analysisComplete && recommendedId === particle.id}
            isSpecialPulse={userArchetype === 'The Builder' && particle.id === 2}
            particle={particle}
          />
        ))}
      </div>
    </div>
  );
}
