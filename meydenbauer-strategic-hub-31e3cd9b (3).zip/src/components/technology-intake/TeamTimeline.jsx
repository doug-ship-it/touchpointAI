import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function TeamTimeline({ formData, updateFormData }) {
  return (
    <div className="space-y-8">
      <div>
        <Label htmlFor="team" className="text-lg font-semibold text-slate-800">Internal Team</Label>
        <p className="text-sm text-slate-500 mb-2">Who are the key internal stakeholders for this project? (e.g., Project Manager, Lead Engineer)</p>
        <Input
          id="team"
          value={formData.timeline.team}
          onChange={(e) => updateFormData('timeline', { team: e.target.value })}
          placeholder="e.g., John Doe (Product Manager), Jane Smith (Tech Lead)"
        />
      </div>
      <div>
        <Label className="text-lg font-semibold text-slate-800">Estimated Budget</Label>
        <p className="text-sm text-slate-500 mb-2">Provide a rough budget estimate for the initial project phase.</p>
        <div className="flex items-center gap-4 mt-2">
          <Slider
            min={10000}
            max={500000}
            step={10000}
            value={[formData.timeline.budget || 50000]}
            onValueChange={([value]) => updateFormData('timeline', { budget: value })}
            className="flex-1"
          />
          <span className="font-semibold text-slate-800 w-24 text-center">
            ${(formData.timeline.budget || 50000).toLocaleString()}
          </span>
        </div>
      </div>
      <div>
        <Label htmlFor="startDate" className="text-lg font-semibold text-slate-800">Ideal Start Date</Label>
         <p className="text-sm text-slate-500 mb-2">When would you ideally like to start this project?</p>
        <Select
          value={formData.timeline.startDate}
          onValueChange={(value) => updateFormData('timeline', { startDate: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="asap">As soon as possible</SelectItem>
            <SelectItem value="2_weeks">In the next 2 weeks</SelectItem>
            <SelectItem value="1_month">In the next month</SelectItem>
            <SelectItem value="3_months">In 1-3 months</SelectItem>
            <SelectItem value="researching">Just researching</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}