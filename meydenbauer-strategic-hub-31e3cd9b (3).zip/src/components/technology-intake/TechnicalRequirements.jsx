import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const securityOptions = ["GDPR", "HIPAA", "SOC 2", "PCI-DSS", "None"];

export default function TechnicalRequirements({ formData, updateFormData }) {
  const handleSecurityChange = (req) => {
    const currentReqs = formData.technical.security || [];
    const newReqs = currentReqs.includes(req)
      ? currentReqs.filter((c) => c !== req)
      : [...currentReqs, req];
    updateFormData('technical', { security: newReqs });
  };

  return (
    <div className="space-y-6">
      <div>
        <Label className="text-lg font-semibold text-slate-800">Platform</Label>
        <RadioGroup
          value={formData.technical.platform}
          onValueChange={(value) => updateFormData('technical', { platform: value })}
          className="mt-2 grid grid-cols-2 gap-4"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="web" id="web" />
            <Label htmlFor="web">Web Application</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="mobile" id="mobile" />
            <Label htmlFor="mobile">Mobile App (iOS/Android)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="backend" id="backend" />
            <Label htmlFor="backend">Backend/API Service</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="other" id="other" />
            <Label htmlFor="other">Other</Label>
          </div>
        </RadioGroup>
      </div>
      <div>
        <Label htmlFor="techStack" className="text-lg font-semibold text-slate-800">Preferred Tech Stack</Label>
        <p className="text-sm text-slate-500 mb-2">List any preferred technologies (e.g., React, Python, AWS). Leave blank if none.</p>
        <Input
          id="techStack"
          value={formData.technical.techStack?.join(', ')}
          onChange={(e) => updateFormData('technical', { techStack: e.target.value.split(',').map(t => t.trim()) })}
          placeholder="e.g., React, Node.js, PostgreSQL, AWS"
        />
      </div>
      <div>
        <Label htmlFor="integrations" className="text-lg font-semibold text-slate-800">Required Integrations</Label>
        <p className="text-sm text-slate-500 mb-2">List any third-party systems this project needs to connect to (e.g., Stripe, Salesforce).</p>
        <Input
          id="integrations"
          value={formData.technical.integrations?.join(', ')}
          onChange={(e) => updateFormData('technical', { integrations: e.target.value.split(',').map(t => t.trim()) })}
          placeholder="e.g., Stripe, Salesforce, Google Maps API"
        />
      </div>
      <div>
        <Label className="text-lg font-semibold text-slate-800">Security & Compliance</Label>
        <p className="text-sm text-slate-500 mb-2">Select any required compliance standards.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-2">
          {securityOptions.map((req) => (
            <div key={req} className="flex items-center space-x-2">
              <Checkbox
                id={req}
                checked={formData.technical.security?.includes(req)}
                onCheckedChange={() => handleSecurityChange(req)}
              />
              <Label htmlFor={req} className="font-normal">{req}</Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}