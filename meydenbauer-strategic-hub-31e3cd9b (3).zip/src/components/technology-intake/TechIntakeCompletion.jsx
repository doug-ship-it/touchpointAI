
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Calendar, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function TechIntakeCompletion() {
  return (
    <motion.div 
      className="text-center"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
    >
      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold mb-2">Project Intake Submitted!</h2>
      <p className="text-slate-600 mb-6 max-w-md mx-auto">
        Thank you for providing your project details. Our team will review the information and prepare a tailored proposal for you. We will be in touch within 24-48 hours.
      </p>

      <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg">
              <a href="https://calendly.com/dougsandstedt/30min" target="_blank" rel="noopener noreferrer">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule a Scoping Call
              </a>
          </Button>
          <Button variant="outline" asChild size="lg">
              <a href="mailto:admin@mbcpartners.co">
                  <Mail className="w-4 h-4 mr-2" />
                  Contact Us
              </a>
          </Button>
      </div>
    </motion.div>
  );
}
