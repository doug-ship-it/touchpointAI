import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, ArrowRight, DollarSign, Clock, Users } from 'lucide-react';

// Executive Search Workflow
export const ExecutiveSearchWorkflow = ({ step, data, onNext, onBack }) => {
  const [stepData, setStepData] = useState({});

  const workflows = {
    2: {
      question: "What type of executive leadership are you looking to hire?",
      type: "single_select",
      options: [
        { value: "cto_vp_eng", label: "CTO/VP Engineering", compensation_range: "$250K-$500K" },
        { value: "chief_of_staff", label: "Chief of Staff", compensation_range: "$180K-$300K" },
        { value: "sales_leadership", label: "Sales Leadership", compensation_range: "$200K-$400K" },
        { value: "ops_leadership", label: "Operations Leadership", compensation_range: "$180K-$350K" },
        { value: "fractional_c_suite", label: "Fractional C-Suite", compensation_range: "$150K-$250K" },
        { value: "technical_principal", label: "Technical Principal/Architect", compensation_range: "$200K-$350K" },
        { value: "other_specialized", label: "Other specialized role", compensation_range: "varies" }
      ]
    },
    3: {
      question: "What's driving the timeline for this hire?",
      type: "single_select",
      options: [
        { value: "critical_gap", label: "Critical gap impacting growth", priority: "high" },
        { value: "planned_expansion", label: "Planned expansion", priority: "medium" },
        { value: "strategic_initiative", label: "Strategic initiative launch", priority: "high" },
        { value: "replacement", label: "Replacement for departing leader", priority: "high" },
        { value: "exploring_options", label: "Exploring options for future need", priority: "low" }
      ]
    },
    4: {
      question: "What's the target compensation range for this role?",
      type: "single_select",
      options: [
        "$120K-$180K annually",
        "$180K-$250K annually", 
        "$250K-$350K annually",
        "$350K-$500K annually",
        "$500K+ annually",
        "Equity participation expected",
        "Need market analysis to determine range"
      ]
    },
    5: {
      question: "Final qualification details",
      type: "multi_field",
      fields: [
        {
          name: "location_requirements",
          label: "Location & Work Model Requirements",
          type: "select",
          options: [
            "Remote-first (US-based)",
            "Remote-first (Global talent acceptable)",
            "Hybrid - specific metro area required",
            "On-site required",
            "Open to relocation candidates"
          ]
        },
        {
          name: "decision_authority",
          label: "Decision Making Process",
          type: "select",
          options: [
            "I have full authority to engage",
            "CEO/Founder approval required",
            "Board or investor approval needed",
            "Multiple stakeholder consensus required"
          ]
        }
      ]
    }
  };

  const currentWorkflow = workflows[step];

  if (!currentWorkflow) {
    return (
      <div className="text-center py-8">
        <h3 className="text-lg font-semibold mb-4">Executive Search Assessment Complete</h3>
        <p className="text-gray-600 mb-6">Ready to connect you with our executive search specialists.</p>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button onClick={() => onNext(stepData)} className="bg-teal-600 hover:bg-teal-700">
            Complete Assessment
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  const handleSubmit = () => {
    onNext(stepData);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <Users className="w-12 h-12 text-teal-600 mx-auto mb-4" />
        <h3 className="text-xl font-bold mb-2">{currentWorkflow.question}</h3>
      </div>

      {currentWorkflow.type === "single_select" && (
        <RadioGroup
          value={stepData.response}
          onValueChange={(value) => setStepData({ response: value })}
          className="space-y-3"
        >
          {currentWorkflow.options.map((option) => (
            <Card 
              key={option.value || option} 
              className="cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <RadioGroupItem value={option.value || option} />
                  <div className="flex-1">
                    <Label className="cursor-pointer text-base">
                      {option.label || option}
                    </Label>
                    {option.compensation_range && (
                      <div className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                        <DollarSign className="w-3 h-3" />
                        {option.compensation_range}
                      </div>
                    )}
                    {option.priority && (
                      <div className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                        <Clock className="w-3 h-3" />
                        Priority: {option.priority}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </RadioGroup>
      )}

      {currentWorkflow.type === "multi_field" && (
        <div className="space-y-6">
          {currentWorkflow.fields.map((field) => (
            <div key={field.name}>
              <Label className="text-base font-medium mb-2 block">{field.label}</Label>
              {field.type === "select" && (
                <Select
                  value={stepData[field.name]}
                  onValueChange={(value) => setStepData(prev => ({ ...prev, [field.name]: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {field.options.map((option) => (
                      <SelectItem key={option} value={option}>{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleSubmit} 
          className="bg-teal-600 hover:bg-teal-700"
          disabled={!stepData.response && Object.keys(stepData).length === 0}
        >
          {step === 5 ? 'Complete' : 'Continue'}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

// Technology Assessment Workflow
export const TechAssessmentWorkflow = ({ step, data, onNext, onBack }) => {
  const [stepData, setStepData] = useState({});

  const workflows = {
    2: {
      question: "What type of technical evaluation do you need?",
      type: "single_select",
      options: [
        { value: "vendor_selection", label: "Software vendor selection", scope: "$35K-$75K" },
        { value: "dev_team_capabilities", label: "Development team capabilities", scope: "$25K-$50K" },
        { value: "tech_stack_audit", label: "Technology stack audit", scope: "$15K-$35K" },
        { value: "ai_implementation", label: "AI implementation readiness", scope: "$50K-$150K" },
        { value: "offshore_partner", label: "Offshore partner assessment", scope: "$20K-$40K" },
        { value: "custom_dev_scoping", label: "Custom development project scoping", scope: "$75K-$200K+" }
      ]
    },
    3: {
      question: "What's prompting this assessment?",
      type: "single_select",
      options: [
        { value: "underperforming", label: "Existing solution underperforming", urgency: "high" },
        { value: "scaling_challenges", label: "Scaling challenges with current setup", urgency: "medium" },
        { value: "cost_optimization", label: "Cost optimization requirements", urgency: "medium" },
        { value: "new_project", label: "New project requirements", urgency: "low" },
        { value: "due_diligence", label: "Due diligence for acquisition/investment", urgency: "high" },
        { value: "compliance_security", label: "Compliance or security concerns", urgency: "high" }
      ]
    },
    4: {
      question: "When do you need recommendations?",
      type: "single_select",
      options: [
        { value: "1_2_weeks", label: "Within 1-2 weeks (urgent decision)", multiplier: 1.5 },
        { value: "30_day", label: "30-day comprehensive assessment", multiplier: 1.0 },
        { value: "60_90_day", label: "60-90 day strategic evaluation", multiplier: 0.8 },
        { value: "ongoing_advisory", label: "Ongoing advisory relationship", multiplier: 1.2 }
      ]
    },
    5: {
      question: "Investment framework and requirements",
      type: "multi_field",
      fields: [
        {
          name: "budget_framework",
          label: "Budget Framework",
          type: "select",
          options: [
            "Assessment Only: $15K-$35K (2-4 week evaluation)",
            "Assessment + Implementation Planning: $35K-$75K (4-6 week comprehensive)", 
            "Full-Service Project Management: $75K-$200K (3-6 month engagement)",
            "Ongoing Advisory + Execution: $200K-$500K+ (6-12 month partnership)",
            "Need ROI analysis: Help determine appropriate investment level"
          ]
        },
        {
          name: "delivery_model",
          label: "Geographic & Delivery Preferences",
          type: "select",
          options: [
            "Fully Remote Delivery: Global team capabilities",
            "US-Only Teams: Domestic delivery preference", 
            "Global Delivery Model: Leverage offshore/nearshore capabilities",
            "Client Site Required: Full on-site engagement"
          ]
        }
      ]
    }
  };

  const currentWorkflow = workflows[step];

  if (!currentWorkflow) {
    return (
      <div className="text-center py-8">
        <h3 className="text-lg font-semibold mb-4">Technology Assessment Complete</h3>
        <p className="text-gray-600 mb-6">Ready to connect you with our technical assessment specialists.</p>
        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button onClick={() => onNext(stepData)} className="bg-teal-600 hover:bg-teal-700">
            Complete Assessment
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  const handleSubmit = () => {
    onNext(stepData);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-bold mb-2">{currentWorkflow.question}</h3>
      </div>

      {currentWorkflow.type === "single_select" && (
        <RadioGroup
          value={stepData.response}
          onValueChange={(value) => setStepData({ response: value })}
          className="space-y-3"
        >
          {currentWorkflow.options.map((option) => (
            <Card 
              key={option.value || option} 
              className="cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <RadioGroupItem value={option.value || option} />
                  <div className="flex-1">
                    <Label className="cursor-pointer text-base">
                      {option.label || option}
                    </Label>
                    {option.scope && (
                      <div className="text-sm text-gray-500 mt-1">
                        Typical scope: {option.scope}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </RadioGroup>
      )}

      {currentWorkflow.type === "multi_field" && (
        <div className="space-y-6">
          {currentWorkflow.fields.map((field) => (
            <div key={field.name}>
              <Label className="text-base font-medium mb-2 block">{field.label}</Label>
              <Select
                value={stepData[field.name]}
                onValueChange={(value) => setStepData(prev => ({ ...prev, [field.name]: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map((option) => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleSubmit} 
          className="bg-teal-600 hover:bg-teal-700"
          disabled={!stepData.response && Object.keys(stepData).length === 0}
        >
          {step === 5 ? 'Complete' : 'Continue'}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};