import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Loader2, Server, Database, BrainCircuit, FileJson } from "lucide-react";

const processingSteps = [
  { text: "Analyzing company domain...", icon: Server },
  { text: "Identifying company profile...", icon: Database },
  { text: "Enriching data from public sources...", icon: BrainCircuit },
  { text: "Generating personalized profile...", icon: FileJson },
];

export default function ProcessingScreen() {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const timers = processingSteps.map((_, index) => 
      setTimeout(() => {
        setCurrentStep(index);
      }, index * 4000) // 4 seconds per step
    );
    return () => timers.forEach(clearTimeout);
  }, []);

  const Icon = processingSteps[currentStep].icon;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center p-6 bg-gradient-to-br from-gray-50 via-teal-50/30 to-blue-50/30">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="relative mb-8">
            <Loader2 className="w-24 h-24 text-teal-500 animate-spin" />
            <Icon className="w-10 h-10 text-blue-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"/>
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-4" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
          Building Your Personalized Hub
        </h1>
        <p className="text-lg text-gray-600 mb-8 max-w-xl" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
          Please wait while we analyze your information and create a tailored experience just for you. This may take a moment.
        </p>

        <div className="w-full max-w-md mx-auto">
            <motion.div
                key={currentStep}
                initial={{ opacity: 0.5, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4 }}
                className="text-center font-medium text-gray-700"
            >
                {processingSteps[currentStep].text}
            </motion.div>
        </div>
      </motion.div>
    </div>
  );
}