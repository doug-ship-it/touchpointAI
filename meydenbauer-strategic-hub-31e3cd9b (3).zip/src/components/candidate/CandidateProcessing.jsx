import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Loader2, FileSearch, BrainCircuit, UserCheck, Sparkles } from "lucide-react";

const processingSteps = [
  { text: "Reading your resume...", icon: FileSearch },
  { text: "Extracting key information...", icon: BrainCircuit },
  { text: "Analyzing experience and skills...", icon: Sparkles },
  { text: "Building your candidate profile...", icon: UserCheck },
];

export default function CandidateProcessing() {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const timers = processingSteps.map((_, index) => 
      setTimeout(() => {
        setCurrentStep(index);
      }, index * 3500) // 3.5 seconds per step
    );
    return () => timers.forEach(clearTimeout);
  }, []);

  const Icon = processingSteps[currentStep].icon;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="relative mb-8">
          <Loader2 className="w-24 h-24 text-purple-500 animate-spin" />
          <Icon className="w-10 h-10 text-pink-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-4" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
          Analyzing Your Resume
        </h1>
        <p className="text-lg text-gray-600 mb-8 max-w-xl" style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}>
          Our AI is extracting your experience, skills, and qualifications to create a comprehensive candidate profile.
        </p>

        <div className="w-full max-w-md mx-auto">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0.5, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="text-center font-medium text-gray-700"
            style={{fontFamily: 'Source Sans Pro, system-ui, sans-serif'}}
          >
            {processingSteps[currentStep].text}
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}