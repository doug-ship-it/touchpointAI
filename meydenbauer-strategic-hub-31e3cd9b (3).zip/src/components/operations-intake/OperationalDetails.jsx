import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Cpu, Shield, Workflow, Globe } from 'lucide-react';

const techPlatforms = [
  'Microsoft 365', 'Google Workspace', 'Slack', 'Zoom', 'Asana', 'Monday.com', 'Trello',
  'Salesforce', 'HubSpot', 'Pipedrive', 'QuickBooks', 'Xero', 'NetSuite', 'Sage',
  'Shopify', 'WooCommerce', 'Magento', 'AWS', 'Microsoft Azure', 'Google Cloud',
  'Dropbox', 'OneDrive', 'Box', 'Notion', 'Airtable', 'Zapier', 'Microsoft Power Platform',
  'Tableau', 'Power BI', 'Looker', 'Jira', 'Confluence', 'GitHub', 'GitLab'
];

const complianceRequirements = [
  { id: 'hipaa', name: 'HIPAA', description: 'Healthcare data protection' },
  { id: 'gdpr', name: 'GDPR', description: 'EU data privacy regulation' },
  { id: 'sox', name: 'SOX', description: 'Sarbanes-Oxley financial compliance' },
  { id: 'pci', name: 'PCI DSS', description: 'Payment card industry standards' },
  { id: 'iso27001', name: 'ISO 27001', description: 'Information security management' },
  { id: 'ccpa', name: 'CCPA', description: 'California privacy rights' },
  { id: 'ferpa', name: 'FERPA', description: 'Educational records privacy' },
  { id: 'other', name: 'Other', description: 'Industry-specific requirements' }
];

const automationOpportunities = [
  'Email management and filtering',
  'Calendar scheduling and coordination',
  'Data entry and migration',
  'Report generation and distribution',
  'Invoice processing and approvals',
  'Customer support ticket routing',
  'Social media posting and monitoring',
  'Inventory tracking and reordering',
  'Employee onboarding workflows',
  'Document approval processes'
];

export default function OperationalDetails({ formData, updateFormData }) {
  const handleTechPlatformToggle = (platform) => {
    const currentPlatforms = formData.operations.tech || [];
    const newPlatforms = currentPlatforms.includes(platform)
      ? currentPlatforms.filter(p => p !== platform)
      : [...currentPlatforms, platform];
    updateFormData('operations', { tech: newPlatforms });
  };

  const handleComplianceToggle = (requirement) => {
    const currentCompliance = formData.operations.compliance || [];
    const newCompliance = currentCompliance.includes(requirement)
      ? currentCompliance.filter(c => c !== requirement)
      : [...currentCompliance, requirement];
    updateFormData('operations', { compliance: newCompliance });
  };

  const handleAutomationToggle = (opportunity) => {
    const currentAutomation = formData.operations.automation || [];
    const newAutomation = currentAutomation.includes(opportunity)
      ? currentAutomation.filter(a => a !== opportunity)
      : [...currentAutomation, opportunity];
    updateFormData('operations', { automation: newAutomation });
  };

  return (
    <div className="space-y-8">
      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-blue-600" />
          Current Technology Ecosystem
        </Label>
        <p className="text-sm text-slate-500 mb-4">Select the platforms and tools your team currently uses.</p>
        
        <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto border rounded-lg p-4">
          {techPlatforms.map(platform => {
            const isSelected = (formData.operations.tech || []).includes(platform);
            return (
              <Badge
                key={platform}
                variant={isSelected ? "default" : "outline"}
                className={`cursor-pointer transition-all ${
                  isSelected 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'hover:bg-gray-100'
                }`}
                onClick={() => handleTechPlatformToggle(platform)}
              >
                {platform}
              </Badge>
            );
          })}
        </div>

        <div className="mt-4">
          <Label htmlFor="otherTech" className="font-medium">Other platforms not listed:</Label>
          <Input
            id="otherTech"
            placeholder="e.g., Custom CRM, legacy systems, industry-specific tools..."
            value={formData.operations.otherTech || ''}
            onChange={(e) => updateFormData('operations', { otherTech: e.target.value })}
            className="mt-2"
          />
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Shield className="w-5 h-5 text-green-600" />
          Compliance & Security Requirements
        </Label>
        <p className="text-sm text-slate-500 mb-4">Select any compliance standards that apply to your organization.</p>
        
        <div className="grid md:grid-cols-2 gap-4">
          {complianceRequirements.map(req => (
            <div key={req.id} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50">
              <Checkbox
                checked={(formData.operations.compliance || []).includes(req.id)}
                onCheckedChange={() => handleComplianceToggle(req.id)}
                className="mt-1"
              />
              <div>
                <Label className="font-semibold text-slate-800">{req.name}</Label>
                <p className="text-sm text-slate-600">{req.description}</p>
              </div>
            </div>
          ))}
        </div>

        {(formData.operations.compliance || []).includes('other') && (
          <div className="mt-4">
            <Label htmlFor="otherCompliance">Please specify other compliance requirements:</Label>
            <Textarea
              id="otherCompliance"
              placeholder="Describe specific compliance or regulatory requirements..."
              value={formData.operations.otherCompliance || ''}
              onChange={(e) => updateFormData('operations', { otherCompliance: e.target.value })}
              className="mt-2"
            />
          </div>
        )}
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Workflow className="w-5 h-5 text-purple-600" />
          Process Automation Opportunities
        </Label>
        <p className="text-sm text-slate-500 mb-4">Which repetitive processes could benefit from automation?</p>
        
        <div className="grid md:grid-cols-2 gap-3">
          {automationOpportunities.map(opportunity => (
            <div key={opportunity} className="flex items-center space-x-2">
              <Checkbox
                checked={(formData.operations.automation || []).includes(opportunity)}
                onCheckedChange={() => handleAutomationToggle(opportunity)}
              />
              <Label className="font-normal text-slate-700">{opportunity}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <Globe className="w-5 h-5 text-teal-600" />
          Geographic & Communication Preferences
        </Label>
        <div className="grid md:grid-cols-2 gap-6 mt-4">
          <div>
            <Label htmlFor="timezone">Preferred Time Zone for Support</Label>
            <Select 
              value={formData.operations.timezone} 
              onValueChange={(value) => updateFormData('operations', { timezone: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select time zone preference" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pst">Pacific (PST/PDT)</SelectItem>
                <SelectItem value="mst">Mountain (MST/MDT)</SelectItem>
                <SelectItem value="cst">Central (CST/CDT)</SelectItem>
                <SelectItem value="est">Eastern (EST/EDT)</SelectItem>
                <SelectItem value="gmt">GMT/UTC</SelectItem>
                <SelectItem value="cet">Central European (CET)</SelectItem>
                <SelectItem value="flexible">Flexible/Follow-the-sun</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="communicationStyle">Communication Style Preference</Label>
            <Select 
              value={formData.operations.communicationStyle} 
              onValueChange={(value) => updateFormData('operations', { communicationStyle: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select communication preference" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="proactive">Proactive updates and check-ins</SelectItem>
                <SelectItem value="responsive">Responsive when contacted</SelectItem>
                <SelectItem value="scheduled">Scheduled status meetings</SelectItem>
                <SelectItem value="minimal">Minimal, results-focused</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div>
        <Label htmlFor="additionalContext" className="text-lg font-semibold text-slate-800">Additional Context</Label>
        <p className="text-sm text-slate-500 mb-3">Share any additional operational challenges, constraints, or specific requirements.</p>
        <Textarea
          id="additionalContext"
          placeholder="e.g., Seasonal workload variations, integration challenges, team structure changes, upcoming projects..."
          value={formData.operations.additionalContext || ''}
          onChange={(e) => updateFormData('operations', { additionalContext: e.target.value })}
          className="min-h-[120px]"
        />
      </div>
    </div>
  );
}