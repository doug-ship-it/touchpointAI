import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Users, Zap, Shield } from 'lucide-react';

const serviceTypes = [
  { id: 'virtual_ea', name: 'Virtual Executive Assistant', description: 'Dedicated EA support for calendar, communication, and admin tasks' },
  { id: 'operations_manager', name: 'Operations Manager', description: 'Strategic operations oversight and process improvement' },
  { id: 'project_coordinator', name: 'Project Coordinator', description: 'Project management and cross-team coordination' },
  { id: 'admin_specialist', name: 'Administrative Specialist', description: 'Specialized administrative and back-office support' },
  { id: 'automation_consultant', name: 'Process Automation', description: 'AI and workflow automation implementation' }
];

const urgencyLevels = [
  { value: 'immediate', label: 'Immediate (Within 1 week)', color: 'text-red-600' },
  { value: 'urgent', label: 'Urgent (Within 2 weeks)', color: 'text-orange-600' },
  { value: 'standard', label: 'Standard (Within 1 month)', color: 'text-green-600' },
  { value: 'flexible', label: 'Flexible (As needed)', color: 'text-blue-600' }
];

const workingStyles = [
  'Proactive and anticipatory',
  'Detail-oriented and systematic', 
  'Fast-paced and decisive',
  'Collaborative and communicative',
  'Independent and self-directed'
];

export default function ServiceLevel({ formData, updateFormData }) {
  const handleServiceTypeChange = (serviceId) => {
    const currentTypes = formData.service.types || [];
    const newTypes = currentTypes.includes(serviceId)
      ? currentTypes.filter(t => t !== serviceId)
      : [...currentTypes, serviceId];
    updateFormData('service', { types: newTypes });
  };

  const handleWorkingStyleChange = (style) => {
    const currentStyles = formData.service.workingStyles || [];
    const newStyles = currentStyles.includes(style)
      ? currentStyles.filter(s => s !== style)
      : [...currentStyles, style];
    updateFormData('service', { workingStyles: newStyles });
  };

  return (
    <div className="space-y-8">
      <div>
        <Label className="text-lg font-semibold text-slate-800">Service Level Requirements</Label>
        <p className="text-sm text-slate-500 mb-6">Define the level and type of operational support you need.</p>
        
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Clock className="w-5 h-5 text-blue-600" />
                Weekly Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Slider
                  value={[formData.service.hours || 20]}
                  onValueChange={([value]) => updateFormData('service', { hours: value })}
                  max={40}
                  min={5}
                  step={5}
                  className="flex-1"
                />
                <span className="font-semibold text-slate-800 w-16 text-center">
                  {formData.service.hours || 20} hrs/week
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Zap className="w-5 h-5 text-orange-600" />
                Urgency Level
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select 
                value={formData.service.urgency} 
                onValueChange={(value) => updateFormData('service', { urgency: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select urgency level" />
                </SelectTrigger>
                <SelectContent>
                  {urgencyLevels.map(level => (
                    <SelectItem key={level.value} value={level.value}>
                      <span className={level.color}>{level.label}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800">Service Type Focus</Label>
        <p className="text-sm text-slate-500 mb-4">Select all types of operational support that would benefit your organization.</p>
        <div className="grid md:grid-cols-2 gap-4">
          {serviceTypes.map(service => (
            <Card key={service.id} className={`cursor-pointer transition-all border-2 ${
              (formData.service.types || []).includes(service.id) 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}>
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    checked={(formData.service.types || []).includes(service.id)}
                    onCheckedChange={() => handleServiceTypeChange(service.id)}
                    className="mt-1"
                  />
                  <div>
                    <h4 className="font-semibold text-slate-800">{service.name}</h4>
                    <p className="text-sm text-slate-600 mt-1">{service.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <Label className="text-lg font-semibold text-slate-800">Working Style Preferences</Label>
        <p className="text-sm text-slate-500 mb-4">What working style would best complement your team?</p>
        <div className="grid md:grid-cols-2 gap-3">
          {workingStyles.map(style => (
            <div key={style} className="flex items-center space-x-2">
              <Checkbox
                checked={(formData.service.workingStyles || []).includes(style)}
                onCheckedChange={() => handleWorkingStyleChange(style)}
              />
              <Label className="font-normal text-slate-700">{style}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label htmlFor="specialRequirements" className="text-lg font-semibold text-slate-800">Special Requirements</Label>
        <p className="text-sm text-slate-500 mb-3">Any specific requirements, preferences, or constraints we should know about?</p>
        <Textarea
          id="specialRequirements"
          placeholder="e.g., Industry experience required, specific software expertise, time zone preferences, confidentiality requirements..."
          value={formData.service.specialRequirements || ''}
          onChange={(e) => updateFormData('service', { specialRequirements: e.target.value })}
          className="min-h-[100px]"
        />
      </div>
    </div>
  );
}