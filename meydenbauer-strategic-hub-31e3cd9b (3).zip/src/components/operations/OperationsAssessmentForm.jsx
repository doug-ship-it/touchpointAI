
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { FormSubmission } from '@/api/entities';
import { User } from '@/api/entities';
import { 
  ChevronRight, 
  ChevronLeft, 
  Clock, 
  Users, 
  Target, 
  DollarSign, 
  CheckCircle,
  Building,
  Loader2,
  X
} from 'lucide-react';
import { toast } from 'sonner';

const steps = [
  { id: 'company', title: 'Company Overview', icon: Building },
  { id: 'current-state', title: 'Current Operations', icon: Users },
  { id: 'challenges', title: 'Key Challenges', icon: Target },
  { id: 'goals', title: 'Goals & Timeline', icon: Clock },
  { id: 'budget', title: 'Investment & ROI', icon: DollarSign }
];

export default function OperationsAssessmentForm({ onClose, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    industry: '',
    companySize: '',
    annualRevenue: '',
    currentTeamSize: '',
    operationalAreas: [],
    currentTools: [],
    biggestTimeWasters: '',
    primaryChallenges: [],
    urgencyLevel: '',
    previousSolutions: '',
    primaryGoals: [],
    timeline: '',
    successMetrics: [],
    currentSpend: '',
    budgetRange: '',
    roiExpectations: '',
    decisionMakers: []
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value) 
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const calculateQualificationScore = () => {
    let score = 0;
    if (formData.companySize === '50-200' || formData.companySize === '200-500') score += 20;
    if (formData.companySize === '500+') score += 30;
    if (formData.annualRevenue === '$10M-50M') score += 25;
    if (formData.annualRevenue === '$50M+') score += 35;
    if (formData.urgencyLevel === 'immediate') score += 20;
    if (formData.urgencyLevel === '1-3months') score += 15;
    if (formData.budgetRange === '$50k-100k' || formData.budgetRange === '$100k+') score += 20;
    return Math.min(score, 100);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await FormSubmission.create({
        tracking_id: `operations-assessment-${Date.now()}`,
        form_type: 'OPERATIONS_ASSESSMENT',
        workflow_type: 'operations',
        intake_data: JSON.stringify(formData),
        submission_date: new Date().toISOString(),
        qualification_score: calculateQualificationScore(),
      });

      try {
        const user = await User.me();
        await User.updateMyUserData({
          lead_score: (user.lead_score || 0) + 25,
          engagement_level: 'hot'
        });
      } catch (error) {
        console.log('User not logged in, skipping engagement update');
      }

      toast.success('Assessment submitted successfully!');
      onComplete?.();
    } catch (error) {
      console.error('Assessment submission failed:', error);
      toast.error('Failed to submit assessment. Please try again.');
    }
    setIsSubmitting(false);
  };

  const operationalAreas = [
    'Executive Assistance', 'Project Management', 'Customer Support', 
    'Data Analysis', 'Process Documentation', 'Quality Assurance',
    'Vendor Management', 'Compliance'
  ];

  const challenges = [
    'Scaling operations with growth',
    'Lack of standardized processes',
    'Poor cross-team communication',
    'Manual, repetitive tasks',
    'Inconsistent quality control',
    'Limited operational visibility',
    'Difficulty finding qualified staff',
    'High operational costs'
  ];

  const goals = [
    'Reduce operational costs by 20%+',
    'Improve process efficiency',
    'Scale operations without proportional headcount increase',
    'Improve quality and consistency',
    'Better operational visibility and reporting',
    'Free up leadership time for strategic work',
    'Standardize processes across teams',
    'Improve customer satisfaction'
  ];

  const metrics = [
    'Cost reduction', 'Time savings', 'Quality improvements',
    'Employee satisfaction', 'Customer satisfaction', 'Revenue growth',
    'Process standardization', 'Compliance improvements'
  ];

  const decisionMakers = [
    'CEO/President', 'COO', 'CFO', 'VP Operations',
    'Department Heads', 'Board Members', 'External Advisors', 'Just me'
  ];

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div>
              <Label htmlFor="companyName">Company Name *</Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={(e) => handleInputChange('companyName', e.target.value)}
                placeholder="Enter your company name"
              />
            </div>
            
            <div>
              <Label>Industry *</Label>
              <Select value={formData.industry} onValueChange={(value) => handleInputChange('industry', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="financial-services">Financial Services</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="retail">Retail & E-commerce</SelectItem>
                  <SelectItem value="professional-services">Professional Services</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Company Size *</Label>
                <Select value={formData.companySize} onValueChange={(value) => handleInputChange('companySize', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Employees" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-10">1-10</SelectItem>
                    <SelectItem value="11-50">11-50</SelectItem>
                    <SelectItem value="50-200">50-200</SelectItem>
                    <SelectItem value="200-500">200-500</SelectItem>
                    <SelectItem value="500+">500+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Annual Revenue</Label>
                <Select value={formData.annualRevenue} onValueChange={(value) => handleInputChange('annualRevenue', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Revenue range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="<$1M">Less than $1M</SelectItem>
                    <SelectItem value="$1M-10M">$1M - $10M</SelectItem>
                    <SelectItem value="$10M-50M">$10M - $50M</SelectItem>
                    <SelectItem value="$50M+">$50M+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div>
              <Label>Current Operations Team Size</Label>
              <Select value={formData.currentTeamSize} onValueChange={(value) => handleInputChange('currentTeamSize', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select team size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">No dedicated ops team</SelectItem>
                  <SelectItem value="1-2">1-2 people</SelectItem>
                  <SelectItem value="3-5">3-5 people</SelectItem>
                  <SelectItem value="6-10">6-10 people</SelectItem>
                  <SelectItem value="10+">10+ people</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>What operational areas need the most support? (Select all that apply)</Label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {operationalAreas.map((area) => (
                  <div key={area} className="flex items-center space-x-2">
                    <Checkbox
                      id={area}
                      checked={formData.operationalAreas.includes(area)}
                      onCheckedChange={() => handleArrayToggle('operationalAreas', area)}
                    />
                    <Label htmlFor={area} className="text-sm">{area}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>What are your biggest operational time-wasters or bottlenecks?</Label>
              <Textarea
                value={formData.biggestTimeWasters}
                onChange={(e) => handleInputChange('biggestTimeWasters', e.target.value)}
                placeholder="Describe the main inefficiencies or bottlenecks..."
                rows={3}
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <Label>What are your primary operational challenges? (Select all that apply)</Label>
              <div className="grid grid-cols-1 gap-3 mt-2">
                {challenges.map((challenge) => (
                  <div key={challenge} className="flex items-center space-x-2">
                    <Checkbox
                      id={challenge}
                      checked={formData.primaryChallenges.includes(challenge)}
                      onCheckedChange={() => handleArrayToggle('primaryChallenges', challenge)}
                    />
                    <Label htmlFor={challenge} className="text-sm">{challenge}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>How urgent is resolving these challenges?</Label>
              <RadioGroup 
                value={formData.urgencyLevel} 
                onValueChange={(value) => handleInputChange('urgencyLevel', value)}
                className="mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="immediate" id="immediate" />
                  <Label htmlFor="immediate">Immediate (within 30 days)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="1-3months" id="1-3months" />
                  <Label htmlFor="1-3months">1-3 months</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="3-6months" id="3-6months" />
                  <Label htmlFor="3-6months">3-6 months</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="planning" id="planning" />
                  <Label htmlFor="planning">Just planning ahead</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label>Have you tried any solutions before? What worked/didn't work?</Label>
              <Textarea
                value={formData.previousSolutions}
                onChange={(e) => handleInputChange('previousSolutions', e.target.value)}
                placeholder="Tell us about previous attempts to solve these challenges..."
                rows={3}
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <Label>What are your primary goals for operational improvement? (Select all that apply)</Label>
              <div className="grid grid-cols-1 gap-3 mt-2">
                {goals.map((goal) => (
                  <div key={goal} className="flex items-center space-x-2">
                    <Checkbox
                      id={goal}
                      checked={formData.primaryGoals.includes(goal)}
                      onCheckedChange={() => handleArrayToggle('primaryGoals', goal)}
                    />
                    <Label htmlFor={goal} className="text-sm">{goal}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>What's your ideal timeline for implementation?</Label>
              <Select value={formData.timeline} onValueChange={(value) => handleInputChange('timeline', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select timeline" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asap">As soon as possible</SelectItem>
                  <SelectItem value="1-2months">1-2 months</SelectItem>
                  <SelectItem value="3-6months">3-6 months</SelectItem>
                  <SelectItem value="6-12months">6-12 months</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>How will you measure success? (Select all that apply)</Label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {metrics.map((metric) => (
                  <div key={metric} className="flex items-center space-x-2">
                    <Checkbox
                      id={metric}
                      checked={formData.successMetrics.includes(metric)}
                      onCheckedChange={() => handleArrayToggle('successMetrics', metric)}
                    />
                    <Label htmlFor={metric} className="text-sm">{metric}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div>
              <Label>What do you currently spend annually on operational support?</Label>
              <Select value={formData.currentSpend} onValueChange={(value) => handleInputChange('currentSpend', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select current spend" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="<$25k">Less than $25k</SelectItem>
                  <SelectItem value="$25k-50k">$25k - $50k</SelectItem>
                  <SelectItem value="$50k-100k">$50k - $100k</SelectItem>
                  <SelectItem value="$100k-250k">$100k - $250k</SelectItem>
                  <SelectItem value="$250k+">$250k+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>What's your budget range for operational improvements?</Label>
              <Select value={formData.budgetRange} onValueChange={(value) => handleInputChange('budgetRange', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select budget range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="<$25k">Less than $25k</SelectItem>
                  <SelectItem value="$25k-50k">$25k - $50k</SelectItem>
                  <SelectItem value="$50k-100k">$50k - $100k</SelectItem>
                  <SelectItem value="$100k+">$100k+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>What ROI timeframe are you expecting?</Label>
              <Select value={formData.roiExpectations} onValueChange={(value) => handleInputChange('roiExpectations', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select ROI expectation" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">3 months</SelectItem>
                  <SelectItem value="6months">6 months</SelectItem>
                  <SelectItem value="12months">12 months</SelectItem>
                  <SelectItem value="18months">18+ months</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Who else is involved in this decision? (Select all that apply)</Label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {decisionMakers.map((decision) => (
                  <div key={decision} className="flex items-center space-x-2">
                    <Checkbox
                      id={decision}
                      checked={formData.decisionMakers.includes(decision)}
                      onCheckedChange={() => handleArrayToggle('decisionMakers', decision)}
                    />
                    <Label htmlFor={decision} className="text-sm">{decision}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const getCurrentStepIcon = () => {
    const IconComponent = steps[currentStep].icon;
    return <IconComponent className="w-5 h-5 text-orange-600" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-yellow-500 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
          
          <h2 className="text-2xl font-bold mb-2">Operations Assessment</h2>
          <p className="text-orange-100">
            Help us understand your operational needs to provide tailored recommendations
          </p>
          
          {/* Progress Steps */}
          <div className="flex items-center gap-2 mt-6">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                  ${index <= currentStep ? 'bg-white text-orange-600' : 'bg-orange-400 text-white'}
                `}>
                  {index < currentStep ? <CheckCircle className="w-4 h-4" /> : index + 1}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-8 h-0.5 mx-1 ${index < currentStep ? 'bg-white' : 'bg-orange-400'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              {getCurrentStepIcon()}
              {steps[currentStep].title}
            </h3>
            <div className="w-full bg-gray-200 rounded-full h-1 mt-2">
              <div 
                className="bg-gradient-to-r from-orange-500 to-yellow-500 h-1 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              />
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderStepContent()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-gray-50 flex justify-between items-center">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="flex items-center gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>

          <div className="text-sm text-gray-500">
            Step {currentStep + 1} of {steps.length}
          </div>

          {currentStep === steps.length - 1 ? (
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  Complete Assessment
                  <CheckCircle className="w-4 h-4" />
                </>
              )}
            </Button>
          ) : (
            <Button
              onClick={nextStep}
              className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 flex items-center gap-2"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
