import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowRight, BookOpen, Network, FileText, BarChart, Users, HardHat, AlertTriangle, Edit } from 'lucide-react';

const PathCard = ({ title, description, icon: Icon, cta, color, recommended, onClick }) => (
    <motion.div
        whileHover={{ y: -5, boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)' }}
        className={`h-full ${recommended ? 'ring-2 ring-offset-2 ring-teal-500' : ''} rounded-2xl cursor-pointer`}
        onClick={onClick}
    >
        <Card className="h-full bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                    </div>
                    {recommended && <Badge>Recommended</Badge>}
                </div>
            </CardHeader>
            <CardContent className="flex flex-col">
                <h3 className="text-xl font-bold text-gray-900 mb-2 flex-grow">{title}</h3>
                <p className="text-gray-600 text-sm mb-6 flex-grow">{description}</p>
                <Button className="w-full bg-gradient-to-r from-teal-600 to-blue-600 text-white group">
                    {cta} 
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
            </CardContent>
        </Card>
    </motion.div>
);

export default function AnalysisDashboard({ analysisData, analysisStatus, website, onStartOver, companyId }) {
    const navigate = useNavigate();

    const decidePrimaryPath = () => {
        const indicators = analysisData?.high_intent_indicators;
        if (indicators?.has_recent_funding || indicators?.is_hiring_aggressively || indicators?.has_tech_gaps) {
            return 'proposal';
        }
        if (analysisData?.industry?.toLowerCase().includes('consulting') || analysisData?.industry?.toLowerCase().includes('agency')) {
            return 'network';
        }
        return 'resources';
    };
    
    const primaryPath = decidePrimaryPath();
    const companyName = analysisData?.company_legal_name || website.replace(/^https?:\/\//, '').split('/')[0];
    const industry = analysisData?.industry;

    if (analysisStatus === 'failure') {
        return (
            <div className="min-h-screen flex items-center justify-center p-6">
                <Card className="max-w-lg text-center p-8">
                    <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold mb-2">Analysis Incomplete</h2>
                    <p className="text-gray-600 mb-6">We had trouble analyzing {website}. Don't worry, you can still explore our resources or fill out your profile manually.</p>
                    <div className="flex gap-4 justify-center">
                        <Button onClick={onStartOver} variant="outline">Try Another Website</Button>
                        <Button onClick={() => navigate(createPageUrl("QuickValueDiscovery"))}>Proceed Manually</Button>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen p-6 md:p-12">
            <div className="max-w-7xl mx-auto">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                    <div className="flex justify-between items-center mb-8">
                        <div>
                            <h1 className="text-3xl md:text-4xl font-bold text-gray-900">{companyName}</h1>
                            <div className="flex items-center gap-2 mt-2">
                                <Badge variant="secondary">{industry || 'Industry Analysis Pending'}</Badge>
                                <Button variant="ghost" size="sm" className="flex items-center gap-1 text-gray-500 hover:text-gray-800">
                                    <Edit className="w-3 h-3" /> Edit if incorrect
                                </Button>
                            </div>
                        </div>
                        <Button onClick={onStartOver} variant="outline">Analyze Another Company</Button>
                    </div>
                    
                    <Alert className="mb-10 bg-teal-50 border-teal-200">
                        <BarChart className="h-4 w-4 !text-teal-700" />
                        <AlertTitle className="text-teal-900">Analysis Complete!</AlertTitle>
                        <AlertDescription className="text-teal-800">
                            Based on your company profile, we've identified three potential paths to accelerate your growth. Start with our recommendation or choose your own adventure.
                        </AlertDescription>
                    </Alert>
                </motion.div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <PathCard
                        title="Quick Value Discovery"
                        description={`Access our most popular resources for ${industry || 'similar'} companies. Includes ROI calculators, case studies, and implementation guides.`}
                        icon={BookOpen}
                        cta="Explore Resources"
                        color="from-blue-500 to-cyan-500"
                        recommended={primaryPath === 'resources'}
                        onClick={() => navigate(createPageUrl("QuickValueDiscovery"))}
                    />
                    <PathCard
                        title="Network Intelligence"
                        description="Unlock vendor recommendations based on your tech stack and get warm introductions to potential partners in your industry."
                        icon={Network}
                        cta="Access Network"
                        color="from-purple-500 to-pink-500"
                        recommended={primaryPath === 'network'}
                        onClick={() => navigate(createPageUrl("NetworkIntelligence"))}
                    />
                    <PathCard
                        title="Full Proposal Generation"
                        description="Complete a 5-step intake to receive a custom business transformation proposal, including strategy, candidates, and vendor shortlists."
                        icon={FileText}
                        cta="Get Custom Proposal"
                        color="from-emerald-500 to-teal-500"
                        recommended={primaryPath === 'proposal'}
                        onClick={() => navigate(createPageUrl("FullProposalGeneration"))}
                    />
                </div>
            </div>
        </div>
    );
}