import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Users, 
  Download, 
  Trash2, 
  Star,
  Building2,
  Briefcase,
  MapPin,
  Mail,
  ExternalLink,
  Calendar,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

const ContactPreview = ({ contact, onRemove, onUpdateNotes, onUpdateCategory }) => {
  const [showNotes, setShowNotes] = useState(false);
  const [notes, setNotes] = useState(contact.notes || '');

  const categoryColors = {
    priority: 'bg-red-100 text-red-800 border-red-200',
    secondary: 'bg-blue-100 text-blue-800 border-blue-200',
    research: 'bg-gray-100 text-gray-800 border-gray-200'
  };

  const handleNotesSubmit = () => {
    onUpdateNotes(contact.contact_id, notes);
    setShowNotes(false);
  };

  return (
    <Card className="mb-3 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-gray-900 truncate">
              {contact.connection_name}
            </h4>
            <p className="text-sm text-gray-600 truncate">
              {contact.connection_title}
            </p>
            <p className="text-xs text-teal-600 truncate">
              {contact.connection_company}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={categoryColors[contact.category]}>
              {contact.category}
            </Badge>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-red-500 hover:text-red-700"
              onClick={() => onRemove(contact.contact_id)}
            >
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
          <MapPin className="w-3 h-3" />
          <span>{contact.enriched_location || 'Location N/A'}</span>
        </div>

        <div className="flex gap-2 mb-3">
          {['priority', 'secondary', 'research'].map(cat => (
            <Button
              key={cat}
              size="sm"
              variant={contact.category === cat ? "default" : "outline"}
              className={cn(
                "text-xs h-6",
                contact.category === cat && "pointer-events-none"
              )}
              onClick={() => onUpdateCategory(contact.contact_id, cat)}
            >
              {cat}
            </Button>
          ))}
        </div>

        <AnimatePresence>
          {showNotes && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <Textarea
                placeholder="Add notes about this contact..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mb-2 text-xs min-h-[60px]"
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={handleNotesSubmit} className="text-xs">
                  Save
                </Button>
                <Button size="sm" variant="outline" onClick={() => setShowNotes(false)} className="text-xs">
                  Cancel
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!showNotes && (
          <div className="flex justify-between items-center">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowNotes(true)}
              className="text-xs text-gray-500 h-6 p-1"
            >
              <FileText className="w-3 h-3 mr-1" />
              {contact.notes ? 'Edit Notes' : 'Add Notes'}
            </Button>
            {contact.engagement_score && (
              <Badge variant="outline" className="text-xs">
                Score: {contact.engagement_score}%
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default function ShortlistSidebar({ 
  isOpen, 
  contacts = [], 
  onClose, 
  onRemoveContact,
  onUpdateContactNotes,
  onUpdateContactCategory,
  onExportShortlist,
  onClearAll,
  totalEstimatedValue = 0
}) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const priorityContacts = contacts.filter(c => c.category === 'priority');
  const secondaryContacts = contacts.filter(c => c.category === 'secondary');
  const researchContacts = contacts.filter(c => c.category === 'research');

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 z-40 lg:hidden"
            onClick={onClose}
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: isCollapsed ? 'calc(100% - 60px)' : '0%' }}
            exit={{ x: '100%' }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl z-50 border-l border-gray-200"
          >
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b bg-gray-50">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="h-8 w-8"
                  >
                    {isCollapsed ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  </Button>
                  {!isCollapsed && (
                    <div>
                      <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                        <Users className="w-4 h-4 text-teal-600" />
                        Strategic Shortlist
                      </h3>
                      <p className="text-xs text-gray-600">
                        {contacts.length} contacts • Est. value ${totalEstimatedValue.toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
                {!isCollapsed && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    className="h-8 w-8 text-gray-500"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {!isCollapsed && (
                <>
                  {/* Actions */}
                  <div className="p-4 border-b space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        size="sm"
                        onClick={onExportShortlist}
                        className="bg-teal-600 hover:bg-teal-700"
                        disabled={contacts.length === 0}
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Export
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={onClearAll}
                        disabled={contacts.length === 0}
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Clear All
                      </Button>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 overflow-y-auto p-4">
                    {contacts.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p className="text-sm font-medium">No contacts selected</p>
                        <p className="text-xs">Start building your strategic shortlist</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {priorityContacts.length > 0 && (
                          <div>
                            <h4 className="font-medium text-red-700 mb-2 flex items-center gap-1">
                              <Star className="w-3 h-3" />
                              Priority ({priorityContacts.length})
                            </h4>
                            {priorityContacts.map(contact => (
                              <ContactPreview
                                key={contact.contact_id}
                                contact={contact}
                                onRemove={onRemoveContact}
                                onUpdateNotes={onUpdateContactNotes}
                                onUpdateCategory={onUpdateContactCategory}
                              />
                            ))}
                          </div>
                        )}

                        {secondaryContacts.length > 0 && (
                          <div>
                            <h4 className="font-medium text-blue-700 mb-2">
                              Secondary ({secondaryContacts.length})
                            </h4>
                            {secondaryContacts.map(contact => (
                              <ContactPreview
                                key={contact.contact_id}
                                contact={contact}
                                onRemove={onRemoveContact}
                                onUpdateNotes={onUpdateContactNotes}
                                onUpdateCategory={onUpdateContactCategory}
                              />
                            ))}
                          </div>
                        )}

                        {researchContacts.length > 0 && (
                          <div>
                            <h4 className="font-medium text-gray-700 mb-2">
                              Research ({researchContacts.length})
                            </h4>
                            {researchContacts.map(contact => (
                              <ContactPreview
                                key={contact.contact_id}
                                contact={contact}
                                onRemove={onRemoveContact}
                                onUpdateNotes={onUpdateContactNotes}
                                onUpdateCategory={onUpdateContactCategory}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Footer */}
                  {contacts.length > 0 && (
                    <div className="p-4 border-t bg-gray-50">
                      <div className="text-xs text-gray-600 mb-2">
                        Optimal shortlist size: 15-25 contacts
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-teal-600 h-2 rounded-full transition-all"
                          style={{ width: `${Math.min(100, (contacts.length / 20) * 100)}%` }}
                        />
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}