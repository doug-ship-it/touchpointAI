import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, X, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SubscriptionLockModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.9, y: 20, opacity: 0 }}
          className="relative bg-white rounded-2xl shadow-xl w-full max-w-md p-8 text-center"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="absolute top-4 right-4">
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5 text-gray-500" />
            </Button>
          </div>
          
          <div className="w-16 h-16 mx-auto bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-6">
            <Lock className="w-8 h-8 text-white" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Feature Locked</h2>
          <p className="text-gray-600 mb-8">
            Direct contact features and introduction requests are available for premium subscribers.
          </p>
          
          <Button 
            size="lg" 
            className="w-full bg-gradient-to-r from-teal-500 to-blue-600 text-white font-semibold text-base shadow-lg transform hover:scale-105 transition-transform"
            onClick={onClose} // In a real app, this would link to a subscription page
          >
            <Zap className="w-5 h-5 mr-2" />
            Upgrade to Premium
          </Button>
          
          <p className="text-xs text-gray-500 mt-4">
            Unlock the full power of your network.
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}