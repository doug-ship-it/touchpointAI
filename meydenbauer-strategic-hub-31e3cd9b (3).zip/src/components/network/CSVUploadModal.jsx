
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, FileText, CheckCircle, AlertCircle, Loader2, Eye, Download, Play, Pause, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { processCsvBatch } from '@/api/functions';
import { ExtractDataFromUploadedFile, UploadFile } from '@/api/integrations';
import { User } from '@/api/entities';
import { toast } from 'sonner';

// --- Enhanced Helper Functions for File Processing ---

// Clean special characters from names
const cleanName = (name) => {
  if (!name) return '';
  // Remove special characters but keep letters, spaces, hyphens, and apostrophes
  return name.replace(/[^\w\s\-']/g, '').trim();
};

// Enhanced location normalization
const normalizeLocation = (location) => {
  if (!location) return '';
  
  const cleaned = location.trim();
  
  // Common location mappings
  const locationMappings = {
    // US States
    'ny': 'New York', 'n.y.': 'New York',
    'ca': 'California', 'c.a.': 'California',
    'tx': 'Texas', 't.x.': 'Texas',
    'fl': 'Florida', 'f.l.': 'Florida',
    'il': 'Illinois', 'i.l.': 'Illinois',
    'wa': 'Washington', 'w.a.': 'Washington',
    'ma': 'Massachusetts', 'm.a.': 'Massachusetts',
    'ga': 'Georgia', 'g.a.': 'Georgia',
    'nc': 'North Carolina', 'n.c.': 'North Carolina',
    'va': 'Virginia', 'v.a.': 'Virginia',
    // Major cities
    'nyc': 'New York, NY', 'new york city': 'New York, NY',
    'sf': 'San Francisco, CA', 's.f.': 'San Francisco, CA', 'san francisco': 'San Francisco, CA',
    'la': 'Los Angeles, CA', 'l.a.': 'Los Angeles, CA', 'los angeles': 'Los Angeles, CA',
    'chi': 'Chicago, IL', 'chicago': 'Chicago, IL',
    'bos': 'Boston, MA', 'boston': 'Boston, MA',
    'sea': 'Seattle, WA', 'seattle': 'Seattle, WA',
    'atl': 'Atlanta, GA', 'atlanta': 'Atlanta, GA',
    'mia': 'Miami, FL', 'miami': 'Miami, FL',
    'dal': 'Dallas, TX', 'dallas': 'Dallas, TX',
    'hou': 'Houston, TX', 'houston': 'Houston, TX',
    // Countries
    'usa': 'United States', 'us': 'United States', 'u.s.': 'United States', 'united states of america': 'United States',
    'uk': 'United Kingdom', 'u.k.': 'United Kingdom', 'united kingdom': 'United Kingdom', 'great britain': 'United Kingdom',
    'uae': 'United Arab Emirates', 'u.a.e.': 'United Arab Emirates', 'united arab emirates': 'United Arab Emirates'
  };
  
  const lowerCleaned = cleaned.toLowerCase();
  
  // Try direct mapping
  if (locationMappings[lowerCleaned]) {
    return locationMappings[lowerCleaned];
  }

  // Capitalize first letter of each word if no direct mapping
  return cleaned.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};

// Helper to parse a single CSV line, handling quoted fields
const parseCSVLine = (line) => {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      // Handle escaped double quotes "" inside a quoted field
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++; // Skip the next quote since it's part of the escaped sequence
      } else {
        inQuotes = !inQuotes; // Toggle inQuotes state
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim()); // Add the last field
  return result;
};

// Helper to parse the entire CSV text into an array of objects
const parseCSVData = (csvText) => {
  const lines = csvText.split('\n').filter(line => line.trim());
  if (lines.length === 0) {
    throw new Error('CSV file is empty or contains no valid data.');
  }

  // Handle cases where the first few lines might be notes from LinkedIn or other metadata
  // We look for a line containing "first name" to identify the header row
  let headerIndex = -1;
  for (let i = 0; i < lines.length; i++) {
      // Lowercase and trim for robust matching, also remove quotes
      if (lines[i].toLowerCase().replace(/"/g, '').includes('first name')) { // Only check for 'first name' for header
          headerIndex = i;
          break;
      }
  }

  if (headerIndex === -1) {
      throw new Error('Could not find a valid header row in the CSV (missing "First Name").');
  }

  const rawHeaders = parseCSVLine(lines[headerIndex]);
  // Clean headers: remove quotes and trim whitespace
  const headers = rawHeaders.map(h => h.replace(/"/g, '').trim());
  
  const data = [];

  for (let i = headerIndex + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue; // Skip empty data lines

    const values = parseCSVLine(line);
    
    // Only process rows that have enough values to match the headers, or slightly more (extra empty columns)
    if (values.length >= headers.length) {
      const row = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      data.push(row);
    } else if (values.some(v => v !== '')) { // If line is not completely empty but has fewer values
        // Optionally, log or warn about malformed lines if they contain data
        console.warn(`Skipping malformed CSV line ${i + 1}: Not enough columns. Expected ${headers.length}, got ${values.length}. Line: "${line}"`);
    }
  }
  return { data, headers };
};

// Helper to parse different file formats
const parseFileData = async (file) => {
  const fileExtension = file.name.split('.').pop().toLowerCase();
  
  if (fileExtension === 'csv') {
    return parseCSVData(await file.text());
  } else if (['txt', 'pdf', 'xlsx', 'xls', 'tsv', 'json', 'ods'].includes(fileExtension)) {
    // Upload file and extract data using AI
    const { file_url } = await UploadFile({ file });
    
    const extractionSchema = {
      type: "object",
      properties: {
        contacts: {
          type: "array",
          items: {
            type: "object",
            properties: {
              "First Name": { type: "string" },
              "Last Name": { type: "string" },
              "Company": { type: "string" },
              "Position": { type: "string" },
              "Email Address": { type: "string" },
              "URL": { type: "string" },
              "Connected On": { type: "string" },
              "Location": { type: "string" }
            },
            required: ["First Name", "Company"] // AI should prioritize these for extraction
          }
        }
      },
      required: ["contacts"]
    };
    
    const result = await ExtractDataFromUploadedFile({
      file_url,
      json_schema: extractionSchema
    });
    
    if (result.status === "success" && result.output?.contacts) {
      // AI output format directly matches what we need as input to validateAndProcessData
      // The headers need to be explicitly set as AI doesn't give a 'rawHeaders' list,
      // and we expect specific keys from the schema.
      const aiGeneratedHeaders = ["First Name", "Last Name", "Company", "Position", "Email Address", "URL", "Connected On", "Location"];
      return { 
        data: result.output.contacts,
        headers: aiGeneratedHeaders
      };
    } else {
      throw new Error("Could not extract contact data from file. Please ensure the file contains structured contact information.");
    }
  } else {
    throw new Error("Unsupported file format.");
  }
};

// Normalizes various possible header names to a standard internal key
const normalizeHeaders = (headers) => {
  const headerMap = {
    'firstName': ['first name', 'first_name', 'fname'],
    'lastName': ['last name', 'last_name', 'lname'],
    'connection_email': ['email', 'email address', 'email_address'],
    'connection_company': ['company', 'organization'],
    'connection_title': ['position', 'title', 'job title'],
    'linkedin_url': ['url', 'linkedin url', 'profile url', 'linkedin_profile_url'],
    'connection_since': ['connected on', 'connection date', 'connection_date'],
    'company_size': ['company size', 'company_size'],
    'industry': ['industry'],
    'seniority': ['seniority'],
    'location': ['location', 'city', 'region', 'area'] // Added location
  };

  const normalized = {};
  headers.forEach(header => {
    const lowerHeader = header.toLowerCase().trim();
    for (const standardKey in headerMap) {
      if (headerMap[standardKey].includes(lowerHeader)) {
        normalized[standardKey] = header; // Store the original header name found
        return;
      }
    }
  });
  return normalized;
};

// Main Component
export default function CSVUploadModal({ isOpen, onClose, onUploadComplete }) {
  const [uploadState, setUploadState] = useState('idle'); // idle, parsing, preview, processing, success, error
  const [progress, setProgress] = useState(0);
  const [rawData, setRawData] = useState([]);
  const [processedData, setProcessedData] = useState([]);
  // Changed 'duplicates' to 'fileDuplicates' for clarity in client-side validation
  const [validationResults, setValidationResults] = useState({ valid: 0, invalid: 0, warnings: 0, fileDuplicates: 0 }); 
  const [importStats, setImportStats] = useState({ processed: 0, successful: 0, failed: 0, duplicates: 0, total: 0 });
  const [errorLog, setErrorLog] = useState([]);
  const [isPaused, setIsPaused] = useState(false);
  const [estimatedTime, setEstimatedTime] = useState('');
  const fileInputRef = useRef(null);
  const abortControllerRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileValidationError, setFileValidationError] = useState(null);

  const handleFileSelectionChange = async (file) => {
    if (!file) {
      setSelectedFile(null);
      setFileValidationError(null);
      return;
    }

    // Accept all major file types
    const validMimeTypes = [
      'text/csv',
      'application/vnd.ms-excel', // for older .xls
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // for .xlsx
      'text/plain',
      'application/pdf',
      'text/tab-separated-values', // for .tsv
      'application/json', // for .json
      'application/vnd.oasis.opendocument.spreadsheet', // for .ods
      'application/x-comma-separated-values' // alternative CSV mime type
    ];
    
    const validExtensions = ['csv', 'txt', 'pdf', 'xlsx', 'xls', 'tsv', 'json', 'ods'];
    const fileExtension = file.name.split('.').pop().toLowerCase();
    
    // Check both MIME type and extension for robustness
    if (!validMimeTypes.includes(file.type) && !validExtensions.includes(fileExtension)) {
      setFileValidationError('Please upload a supported file format (CSV, Excel, TXT, PDF, TSV, JSON, ODS).');
      setSelectedFile(null);
      return;
    }
    
    if (file.size > 50 * 1024 * 1024) { // Increased to 50MB limit
      setFileValidationError('File size must be under 50MB.');
      setSelectedFile(null);
      return;
    }
    
    setSelectedFile(file);
    setFileValidationError(null);
    
    // Immediately start parsing after file selection if it's valid
    setUploadState('parsing');
    setProgress(10);

    try {
      const { data: parsed, headers: rawHeaders } = await parseFileData(file);
      
      if (parsed.length === 0) {
        throw new Error('File is empty or could not be parsed.');
      }

      setRawData(parsed);
      setProgress(25);
      
      const { processedData: validatedRecords, validation } = await validateAndProcessData(parsed, rawHeaders);
      setProcessedData(validatedRecords);
      setValidationResults(validation);
      
      setUploadState('preview');
      toast.success(`Parsed ${parsed.length} records. Review data before importing.`);
    } catch (error) {
      console.error('File parsing failed:', error);
      setUploadState('error');
      setFileValidationError(`Failed to parse file: ${error.message}`);
      toast.error(`Failed to parse file: ${error.message}`);
    }
  };

  const validateAndProcessData = async (data, rawHeaders) => {
    const processedRecords = [];
    const validation = { valid: 0, invalid: 0, warnings: 0, fileDuplicates: 0 }; // Use `fileDuplicates`
    const errors = [];
    const seenLinkedInUrls = new Set();
    
    // Normalize headers to handle different file formats
    const normalizedHeaderMap = normalizeHeaders(rawHeaders);

    for (let i = 0; i < data.length; i++) {
      const record = data[i];
      // First, perform basic field validation for the record
      const processed = await processRecord(record, i + 2, normalizedHeaderMap);
      
      let currentRecordErrors = [...processed.errors];
      let currentRecordWarnings = [...processed.warnings];

      let isFileDuplicate = false;
      // Check for file-internal duplicates IF the record is valid by fields
      // This prevents trying to add invalid records to processedRecords or checking their (possibly missing) linkedin_url
      if (processed.isValid) { 
        const linkedinUrl = processed.data.linkedin_url;
        if (linkedinUrl) {
          if (seenLinkedInUrls.has(linkedinUrl)) {
            validation.fileDuplicates++;
            currentRecordErrors.push('Duplicate LinkedIn URL found in this file; record will be skipped.');
            isFileDuplicate = true;
          } else {
            seenLinkedInUrls.add(linkedinUrl);
          }
        }
      }

      if (!processed.isValid) {
        // Record has field validation errors
        validation.invalid++;
        errors.push({
          line: i + 2,
          record: record,
          errors: currentRecordErrors
        });
      } else if (isFileDuplicate) {
        // Record is valid by fields, but a file duplicate
        // It's already counted in validation.fileDuplicates
        errors.push({
          line: i + 2,
          record: record,
          errors: currentRecordErrors
        });
        // We don't increment validation.invalid here, as fileDuplicates is a distinct category.
      } else {
        // Record is valid by fields and unique in file
        processedRecords.push(processed.data);
        validation.valid++;
      }

      if (currentRecordWarnings.length > 0) {
        validation.warnings++;
      }
    }

    setErrorLog(errors);
    return { processedData: processedRecords, validation };
  };

  const processRecord = async (record, lineNumber, headerMap) => {
    const errors = [];
    const warnings = [];
    
    // Helper to get value from record using the normalized header map
    const getOriginalValue = (standardKey) => {
      const csvHeader = headerMap[standardKey]; // Get the actual header name from the file
      return record[csvHeader]?.trim() || ''; // Access record using actual header
    };

    // Extract and clean names with special character removal
    const rawFirstName = getOriginalValue('firstName');
    const rawLastName = getOriginalValue('lastName');
    const { firstName, lastName, credentials } = extractNameAndCredentials(cleanName(rawFirstName), cleanName(rawLastName));

    // Relaxed validation - only firstName and company are required
    if (!firstName) errors.push('First Name is required');
    if (!getOriginalValue('connection_company')) errors.push('Company is required');

    // Process and validate email (more lenient)
    const rawEmail = getOriginalValue('connection_email');
    const email = cleanEmail(rawEmail);
    if (rawEmail && rawEmail.includes('@') && !email) {
      warnings.push('Email format may be invalid but will be preserved');
      // Keep the original email even if it doesn't pass strict validation
    }

    // Clean and validate LinkedIn URL (more lenient)
    const rawLinkedinUrl = getOriginalValue('linkedin_url');
    const linkedinUrl = cleanLinkedInUrl(rawLinkedinUrl);
    if (rawLinkedinUrl && rawLinkedinUrl.includes('linkedin') && !linkedinUrl) {
      warnings.push('LinkedIn URL format may be invalid but will be preserved');
      // Keep the original URL even if it doesn't pass strict validation
    }

    // Parse connection date with better error handling
    const rawConnectionDate = getOriginalValue('connection_since');
    const connectionDate = parseConnectionDate(rawConnectionDate);
    if (rawConnectionDate && !connectionDate) {
      warnings.push('Could not parse connection date, will use import date');
    }

    // Clean position title with better handling
    const position = cleanPositionTitle(getOriginalValue('connection_title'));

    // Enhanced location normalization
    const location = normalizeLocation(getOriginalValue('location'));

    // Standardize company size with fallback
    const companySize = standardizeCompanySize(getOriginalValue('company_size'));

    // Normalize industry with fallback
    const industry = normalizeIndustry(getOriginalValue('industry'));

    const processedData = {
      connection_name: `${firstName} ${lastName || ''}`.trim(),
      firstName,
      lastName: lastName || '',
      credentials,
      connection_email: email || rawEmail || '', // Use cleaned or original email
      connection_company: getOriginalValue('connection_company'),
      connection_title: position,
      linkedin_url: linkedinUrl || rawLinkedinUrl || '', // Use cleaned or original URL
      enriched_industry: industry,
      enriched_seniority: getOriginalValue('seniority'),
      enriched_location: location,
      company_size: companySize,
      connection_since: connectionDate,
      relationship_strength: 'medium',
      import_source: 'file_upload',
      import_date: new Date().toISOString()
    };

    return {
      isValid: errors.length === 0, // Only fail on actual errors, not warnings
      data: processedData,
      errors,
      warnings
    };
  };

  const extractNameAndCredentials = (firstName, lastName) => {
    let cleanFirstName = firstName;
    let cleanLastName = lastName;
    let credentials = [];

    // Check for credentials in lastName (like "Bell, PhD, MAI")
    const lastNameParts = (lastName || '').split(',');
    if (lastNameParts.length > 1) {
      cleanLastName = lastNameParts[0].trim();
      credentials = lastNameParts.slice(1).map(c => c.trim()).filter(Boolean);
    }

    // Check for credentials in firstName (like "Berthaboucha B." -> "B.")
    const firstNameParts = (firstName || '').split(' ');
    if (firstNameParts.length > 1) {
      const potentialCredential = firstNameParts[firstNameParts.length - 1];
      if (potentialCredential.includes('.') || ['CPA', 'PhD', 'MAI', 'CPM'].some(cred => potentialCredential.includes(cred))) {
        credentials.push(potentialCredential);
        cleanFirstName = firstNameParts.slice(0, -1).join(' ').trim();
      }
    }

    return {
      firstName: cleanFirstName,
      lastName: cleanLastName,
      credentials: credentials.join(', ')
    };
  };

  // Enhanced email cleaning with fallback
  const cleanEmail = (email) => {
    if (!email?.trim()) return '';
    const cleaned = email.toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(cleaned) ? cleaned : ''; // Return empty if invalid, processRecord handles fallback
  };

  // Enhanced LinkedIn URL cleaning with fallback
  const cleanLinkedInUrl = (url) => {
    if (!url?.trim()) return '';
    let cleaned = url.trim();
    
    // More lenient LinkedIn URL validation: must contain 'linkedin.com'
    if (!cleaned.includes('linkedin.com')) {
      return ''; // If it's not a LinkedIn URL at all, return empty. processRecord will fallback to raw.
    }
    
    // Try to standardize format
    try {
      if (!cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
        cleaned = 'https://' + cleaned;
      }
      // Standardize to www.linkedin.com format for consistency
      cleaned = cleaned.replace(/https?:\/\/[^\/]*linkedin\.com/, 'https://www.linkedin.com');
      
      return cleaned;
    } catch (error) {
      // Log the error for debugging, but return empty to signal failure to standardize
      console.warn('Error standardizing LinkedIn URL:', url, error);
      return ''; // Return empty on error, processRecord handles fallback
    }
  };

  // Enhanced connection date parsing
  const parseConnectionDate = (dateStr) => {
    if (!dateStr?.trim()) return null;
    
    try {
      // Define multiple date formats to try
      const formats = [
        // LinkedIn format: "17-Jun-25" (Day-Mon-YY)
        /^(\d{1,2})-([A-Za-z]{3})-(\d{2})$/i,
        // YYYY-MM-DD
        /^(\d{4})-(\d{1,2})-(\d{1,2})$/,
        // MM/DD/YYYY
        /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/,
        // MM/DD/YY
        /^(\d{1,2})\/(\d{1,2})\/(\d{2})$/
      ];
      
      // Try LinkedIn format first (Day-Mon-YY)
      let match = dateStr.match(formats[0]);
      if (match) {
        const [, day, monthStr, year] = match;
        const monthMap = {
          'jan': 0, 'feb': 1, 'mar': 2, 'apr': 3, 'may': 4, 'jun': 5,
          'jul': 6, 'aug': 7, 'sep': 8, 'oct': 9, 'nov': 10, 'dec': 11
        };
        const month = monthMap[monthStr.toLowerCase()];
        
        let fullYear = parseInt(year, 10);
        // Convert 2-digit year to 4-digit
        // Heuristic: if YY is <= current year last 2 digits + 10, assume 20YY, else 19YY
        const currentYearTwoDigits = new Date().getFullYear() % 100;
        if (fullYear <= currentYearTwoDigits + 10) { // e.g., if current year is 2023, 23, 24, ..., 33 becomes 2023, 2024, ..., 2033
          fullYear += 2000;
        } else { // e.g., 90, 91, etc. becomes 1990, 1991
          fullYear += 1900;
        }
        
        if (month !== undefined) {
          const date = new Date(fullYear, month, parseInt(day, 10));
          if (!isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
          }
        }
      }

      // Try other standard formats if LinkedIn format didn't match or failed
      for (let i = 1; i < formats.length; i++) {
        match = dateStr.match(formats[i]);
        if (match) {
          let date;
          if (i === 1) { // YYYY-MM-DD
              const [, year, month, day] = match;
              date = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10));
          } else if (i === 2 || i === 3) { // MM/DD/YYYY or MM/DD/YY
              const [, month, day, year] = match;
              let fullYear = parseInt(year, 10);
              if (fullYear < 100) { // Handle 2-digit years
                  const currentYearTwoDigits = new Date().getFullYear() % 100;
                  fullYear += (fullYear <= currentYearTwoDigits + 10 ? 2000 : 1900);
              }
              date = new Date(fullYear, parseInt(month, 10) - 1, parseInt(day, 10));
          }

          if (date && !isNaN(date.getTime())) {
              return date.toISOString().split('T')[0];
          }
        }
      }
      
      // Fallback to standard Date parsing if no regex matched
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    } catch (error) {
      console.warn('Date parsing failed for:', dateStr, error);
    }
    
    return null;
  };

  const cleanPositionTitle = (title) => {
    if (!title?.trim()) return '';
    // Remove special characters like ¬¨¬®‚àö√ú
    return title.replace(/[^\w\s\-&\/(),.']/g, '').trim();
  };

  const standardizeCompanySize = (size) => {
    if (!size?.trim()) return '';
    const cleaned = size.toLowerCase().trim();
    
    if (cleaned.includes('1-10')) return '1-10 employees';
    if (cleaned.includes('11-50')) return '11-50 employees';
    if (cleaned.includes('51-200')) return '51-200 employees';
    if (cleaned.includes('201-500')) return '201-500 employees';
    if (cleaned.includes('501-1,000') || cleaned.includes('501-1000')) return '501-1,000 employees';
    if (cleaned.includes('1,001-5,000') || cleaned.includes('1001-5000')) return '1,001-5,000 employees';
    if (cleaned.includes('5,001-10,000') || cleaned.includes('5001-10000')) return '5,001-10,000 employees';
    if (cleaned.includes('10,000+') || cleaned.includes('10000+')) return '10,000+ employees';
    
    return size.trim();
  };

  const normalizeIndustry = (industry) => {
    if (!industry?.trim()) return '';
    const cleaned = industry.trim();
    
    // Map to standardized industry categories
    const industryMap = {
      'Professional Services': 'Professional Services',
      'Financial Services': 'Financial Services',
      'Education': 'Education',
      'Technology': 'Technology',
      'Healthcare': 'Healthcare',
      'Manufacturing': 'Manufacturing',
      'Retail': 'Retail'
    };
    
    return industryMap[cleaned] || cleaned;
  };

  const startBulkImport = async () => {
    if (processedData.length === 0) {
      toast.error('No valid data to import');
      return;
    }

    setUploadState('processing');
    setProgress(50);
    abortControllerRef.current = new AbortController();
    
    const currentUser = await User.me();
    const userEmail = currentUser.email;
    
    const dataWithUser = processedData.map(record => ({ ...record, user_email: userEmail }));

    const BATCH_SIZE = 500; // Increased batch size for faster uploads
    const totalBatches = Math.ceil(dataWithUser.length / BATCH_SIZE);
    let processedCount = 0;
    let successCount = 0;
    let failCount = 0;
    let duplicateCount = 0; // This will count duplicates found in the backend database
    const startTime = Date.now();

    try {
      for (let i = 0; i < totalBatches; i++) {
        if (abortControllerRef.current.signal.aborted) {
          toast.info('Import cancelled.');
          break;
        }
        while (isPaused) {
          // Keep waiting until not paused
          await new Promise(resolve => setTimeout(resolve, 100));
        }

        const batch = dataWithUser.slice(i * BATCH_SIZE, (i + 1) * BATCH_SIZE);
        
        try {
          // The new backend function handles the entire batch at once
          const response = await processCsvBatch({ records: batch });
          
          if (response.data.success) {
            successCount += response.data.imported;
            failCount += response.data.failed;
            duplicateCount += response.data.duplicates; // Accumulate backend-reported duplicates
          } else {
            failCount += batch.length; // Assume entire batch failed if API call fails
          }
        } catch (error) {
          console.error(`Batch ${i + 1} failed:`, error);
          failCount += batch.length;
        }
        
        processedCount += batch.length;
        const progressPercent = 50 + (processedCount / dataWithUser.length) * 45;
        setProgress(progressPercent);
        
        setImportStats({
          processed: processedCount,
          successful: successCount,
          failed: failCount,
          duplicates: duplicateCount, // Update with backend duplicates
          total: dataWithUser.length
        });

        // Update estimated time
        const elapsed = Date.now() - startTime;
        const remaining = ((dataWithUser.length - processedCount) / processedCount) * elapsed;
        setEstimatedTime(formatTime(remaining));
        
        // A smaller delay is fine now as the backend is much faster
        if (i < totalBatches - 1) {
          await new Promise(resolve => setTimeout(resolve, 50));
        }
      }

      if (!abortControllerRef.current.signal.aborted) {
        setProgress(100);
        setUploadState('success');
        toast.success(`Import completed! ${successCount} successful, ${failCount} failed, ${duplicateCount} duplicates.`);
        
        if (onUploadComplete) {
          onUploadComplete();
        }
      }
    } catch (error) {
      console.error('Bulk import failed:', error);
      setUploadState('error');
      toast.error(`Import failed: ${error.message}`);
    }
  };

  const formatTime = (ms) => {
    if (ms < 1000) return 'Less than 1 second';
    if (ms < 60000) return `${Math.round(ms / 1000)} seconds`;
    return `${Math.round(ms / 60000)} minutes`;
  };

  const exportErrors = () => {
    if (errorLog.length === 0) return;
    
    // Create CSV content manually
    const csvContent = [
      'Line,First Name,Last Name,Company,Errors', // Header
      ...errorLog.map(error => [
        error.line,
        `"${error.record['First Name'] || ''}"`,
        `"${error.record['Last Name'] || ''}"`,
        `"${error.record.Company || ''}"`,
        `"${error.errors.join('; ')}"`
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'import_errors.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const resetUpload = () => {
    setUploadState('idle');
    setProgress(0);
    setRawData([]);
    setProcessedData([]);
    setValidationResults({ valid: 0, invalid: 0, warnings: 0, fileDuplicates: 0 }); // Reset with new key
    setImportStats({ processed: 0, successful: 0, failed: 0, duplicates: 0, total: 0 });
    setErrorLog([]);
    setIsPaused(false);
    setEstimatedTime('');
    setSelectedFile(null); // Reset selected file
    setFileValidationError(null); // Clear file validation error
  };

  const handleClose = () => {
    if (uploadState === 'processing' && !isPaused) {
      const confirm = window.confirm('Import is in progress. Are you sure you want to close?');
      if (!confirm) return;
      
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    }
    
    resetUpload();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && handleClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-4xl max-h-[90vh] overflow-auto"
        >
          <Card className="bg-white">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Professional File Import System
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={handleClose}>
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* File Upload Stage */}
              {uploadState === 'idle' && (
                <div className="space-y-6">
                  <div
                    className="border-2 border-dashed rounded-lg p-8 text-center transition-colors hover:border-teal-400 hover:bg-gray-50"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Upload Contact File
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Supports various formats with intelligent parsing
                    </p>
                    <Button variant="outline">
                      <File className="w-4 h-4 mr-2" />
                      Select File
                    </Button>
                  </div>

                  {fileValidationError && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                      <strong className="font-bold">Error:</strong>
                      <span className="block sm:inline"> {fileValidationError}</span>
                    </div>
                  )}

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">Supported File Types:</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm text-blue-800 mb-3">
                      <div>• CSV Files (.csv)</div>
                      <div>• Excel Files (.xlsx, .xls)</div>
                      <div>• Text Files (.txt)</div>
                      <div>• PDF Files (.pdf)</div>
                      <div>• TSV Files (.tsv)</div>
                      <div>• JSON Files (.json)</div>
                      <div>• OpenDocument (.ods)</div>
                      <div>• Any structured data format</div>
                    </div>
                    <h4 className="font-semibold text-blue-900 mb-2">Required Fields:</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm text-blue-800">
                      <div>• First Name* (required)</div>
                      <div>• Company* (required)</div>
                      <div>• Last Name (optional)</div>
                      <div>• Position/Title (optional)</div>
                      <div>• Email (optional)</div>
                      <div>• LinkedIn URL (optional)</div>
                      <div>• Location (optional)</div>
                      <div>• Connection Date (optional)</div>
                    </div>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,.txt,.pdf,.xlsx,.xls,.tsv,.json,.ods"
                    onChange={(e) => handleFileSelectionChange(e.target.files[0])}
                    className="hidden"
                  />
                </div>
              )}

              {/* Parsing Stage */}
              {uploadState === 'parsing' && (
                <div className="text-center space-y-4 py-8">
                  <Loader2 className="w-12 h-12 animate-spin mx-auto text-teal-600" />
                  <div>
                    <h3 className="text-lg font-medium">Parsing File Data...</h3>
                    <p className="text-sm text-gray-500">Processing and validating records</p>
                    <Progress value={progress} className="w-full mt-2" />
                  </div>
                </div>
              )}

              {/* Preview Stage */}
              {uploadState === 'preview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-green-50 p-4 rounded-lg text-center">
                      <div className="text-2xl font-bold text-green-600">{validationResults.valid}</div>
                      <div className="text-sm text-green-800">Valid for Import</div>
                    </div>
                    <div className="bg-yellow-50 p-4 rounded-lg text-center">
                      <div className="text-2xl font-bold text-yellow-600">{validationResults.warnings}</div>
                      <div className="text-sm text-yellow-800">With Warnings</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg text-center">
                      <div className="text-2xl font-bold text-red-600">{validationResults.invalid}</div>
                      <div className="text-sm text-red-800">Invalid Records (Field Errors)</div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg text-center">
                      <div className="text-2xl font-bold text-blue-600">{validationResults.fileDuplicates}</div> {/* Display fileDuplicates */}
                      <div className="text-sm text-blue-800">File Duplicates (Skipped)</div> {/* Clarified label */}
                    </div>
                  </div>

                  {processedData.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">Preview (First 5 Records):</h4>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm border-collapse border border-gray-300">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="border border-gray-300 p-2">Name</th>
                              <th className="border border-gray-300 p-2">Company</th>
                              <th className="border border-gray-300 p-2">Position</th>
                              <th className="border border-gray-300 p-2">Email</th>
                            </tr>
                          </thead>
                          <tbody>
                            {processedData.slice(0, 5).map((record, index) => (
                              <tr key={index}>
                                <td className="border border-gray-300 p-2">{record.connection_name}</td>
                                <td className="border border-gray-300 p-2">{record.connection_company}</td>
                                <td className="border border-gray-300 p-2">{record.connection_title}</td>
                                <td className="border border-gray-300 p-2">{record.connection_email || 'N/A'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {errorLog.length > 0 && (
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold text-red-800">Validation Errors:</h4>
                        <Button size="sm" variant="outline" onClick={exportErrors}>
                          <Download className="w-4 h-4 mr-1" />
                          Export Errors
                        </Button>
                      </div>
                      <div className="max-h-32 overflow-y-auto text-sm text-red-700">
                        {errorLog.slice(0, 5).map((error, index) => (
                          <div key={index} className="mb-1">
                            Line {error.line}: {error.errors.join(', ')}
                          </div>
                        ))}
                        {errorLog.length > 5 && (
                          <div className="text-red-600 font-medium">
                            ... and {errorLog.length - 5} more errors
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button onClick={resetUpload} variant="outline" className="flex-1">
                      Start Over
                    </Button>
                    <Button 
                      onClick={startBulkImport}
                      disabled={processedData.length === 0}
                      className="flex-1 bg-teal-600 hover:bg-teal-700"
                    >
                      Import {validationResults.valid} Records
                    </Button>
                  </div>
                </div>
              )}

              {/* Processing Stage */}
              {uploadState === 'processing' && (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
                      <h3 className="text-lg font-medium">
                        Importing {importStats.total} Records...
                      </h3>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setIsPaused(!isPaused)}
                      >
                        {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                        {isPaused ? 'Resume' : 'Pause'}
                      </Button>
                    </div>
                    <Progress value={progress} className="w-full mb-4" />
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>Processed: {importStats.processed} / {importStats.total}</p>
                      <p>Successful: {importStats.successful} | Failed: {importStats.failed} | Duplicates: {importStats.duplicates}</p>
                      {estimatedTime && <p>Estimated time remaining: {estimatedTime}</p>}
                    </div>
                  </div>
                </div>
              )}

              {/* Success Stage */}
              {uploadState === 'success' && (
                <div className="text-center space-y-4 py-8">
                  <CheckCircle className="w-16 h-16 mx-auto text-green-600" />
                  <div>
                    <h3 className="2xl font-medium text-green-700 mb-2">Import Completed!</h3>
                    <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                      <div className="bg-green-50 p-3 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{importStats.successful}</div>
                        <div className="text-sm text-green-800">Successfully Imported</div>
                      </div>
                      <div className="bg-red-50 p-3 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">{importStats.failed}</div>
                        <div className="text-sm text-red-800">Failed</div>
                      </div>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{importStats.duplicates}</div>
                        <div className="text-sm text-blue-800">Duplicates Skipped</div>
                      </div>
                    </div>
                  </div>
                  <Button onClick={handleClose} className="bg-teal-600 hover:bg-teal-700">
                    Done
                  </Button>
                </div>
              )}

              {/* Error Stage */}
              {uploadState === 'error' && (
                <div className="text-center space-y-4 py-8">
                  <AlertCircle className="w-16 h-16 mx-auto text-red-600" />
                  <div>
                    <h3 className="xl font-medium text-red-700 mb-2">Import Failed</h3>
                    <p className="text-gray-600 mb-4">Please check your file format and try again</p>
                  </div>
                  <div className="flex gap-2 justify-center">
                    <Button variant="outline" onClick={resetUpload}>
                      Try Again
                    </Button>
                    <Button variant="outline" onClick={handleClose}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
