
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Play, Pause, X, ShieldCheck, List, FileDown, Brain, Sparkles, DollarSign, Clock, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { NetworkConnection } from '@/api/entities';
import { toast } from 'sonner';
import { enrichContactData } from '@/api/functions';

export default function DataEnrichmentTool({ connections, onEnrichmentComplete, onRequestPasswordAccess }) {
  // Enhanced state management with cost tracking
  const [isEnriching, setIsEnriching] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isCoolingDown, setIsCoolingDown] = useState(false);
  const [cooldownTime, setCooldownTime] = useState(0);
  const [stats, setStats] = useState({
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    skipped: 0
  });
  const [costTracking, setCostTracking] = useState({
    currentCost: 0,
    estimatedTotalCost: 0,
    costPerEnrichment: 0.025
  });
  const [performanceMetrics, setPerformanceMetrics] = useState({
    startTime: null,
    avgTimePerContact: 0,
    contactsPerMinute: 0,
    estimatedCompletion: null
  });
  const [currentBatch, setCurrentBatch] = useState('');
  const [enrichmentLog, setEnrichmentLog] = useState([]);
  const [showDetailedLog, setShowDetailedLog] = useState(false);

  // Refs for managing the enrichment process
  const abortControllerRef = useRef(null);
  const enrichmentQueueRef = useRef([]);
  const pausedRef = useRef(false);
  const cooldownTimerRef = useRef(null);

  // Optimized configuration for maximum speed
  const BATCH_SIZE = 6; // Increased for speed
  const MAX_PARALLEL_BATCHES = 2; // Process multiple batches simultaneously
  const RATE_LIMIT_COOLDOWN = 60000; // Cooldown time for rate limits (increased to 60s)
  const BATCH_DELAY = 800; // Reduced delay between batches
  const MAX_RETRIES = 2; // Reduced retries for speed

  useEffect(() => {
    return () => {
      if (cooldownTimerRef.current) {
        clearInterval(cooldownTimerRef.current);
      }
    };
  }, []);

  // Helper function to check if contact needs enrichment
  const needsEnrichment = (contact) => {
    return !contact.enriched_industry ||
           !contact.enriched_seniority ||
           !contact.enriched_function ||
           !contact.intelligent_summary ||
           !contact.enriched_location ||
           !contact.company_size;
  };

  // Add log entry with timestamp and performance metrics
  const addLogEntry = useCallback((message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    setEnrichmentLog(prev => [logEntry, ...prev.slice(0, 149)]); // Increased log capacity

    if (type === 'error') {
      console.error(logEntry);
    } else if (type === 'warning') {
      console.warn(logEntry);
    } else {
      console.log(logEntry);
    }
  }, []);

  // Update performance metrics
  const updatePerformanceMetrics = useCallback((processedCount, startTime) => {
    const elapsedMs = Date.now() - startTime;
    const elapsedMinutes = elapsedMs / 60000;
    const avgTimePerContact = elapsedMs / processedCount;
    const contactsPerMinute = processedCount / elapsedMinutes;
    const remainingContacts = stats.total - processedCount;
    const estimatedCompletionMs = remainingContacts * avgTimePerContact;
    const estimatedCompletion = new Date(Date.now() + estimatedCompletionMs);

    setPerformanceMetrics({
      startTime,
      avgTimePerContact,
      contactsPerMinute: Math.round(contactsPerMinute * 10) / 10,
      estimatedCompletion
    });
  }, [stats.total]);

  // High-speed batch processing with parallel execution
  const processBatch = async (batchContacts) => {
    const promises = batchContacts.map(async (contact) => {
      for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        if (abortControllerRef.current?.signal.aborted) return { success: false, contact, error: 'Aborted by user' };

        try {
          const response = await enrichContactData({ contact });

          if (response.data?.success && response.data.enrichedData) {
            await NetworkConnection.update(contact.id, {
              ...response.data.enrichedData,
              last_enriched: new Date().toISOString()
            });

            const cost = response.data.cost_estimate || costTracking.costPerEnrichment;
            addLogEntry(`✓ Enhanced ${contact.connection_name} (+$${cost.toFixed(3)})`, 'success');
            return { success: true, contact, cost };
          } else {
            // Handle logical failures from the backend function
            const errorMsg = response.data?.error || 'Enrichment failed with no specific error';
            if (attempt === MAX_RETRIES) {
              addLogEntry(`✗ Failed ${contact.connection_name}: ${errorMsg}`, 'error');
              return { success: false, contact, error: errorMsg };
            }
          }
        } catch (error) {
          const isRateLimit = error?.response?.status === 429;
          const errorMsg = error.message || 'Unknown error';

          if (isRateLimit) {
            addLogEntry(`RATE LIMIT HIT for ${contact.connection_name}. Re-queuing.`, 'warning');
            return { success: false, contact, error: 'Rate limit hit', isRateLimit: true };
          }

          if (attempt === MAX_RETRIES) {
            addLogEntry(`✗ Failed ${contact.connection_name} after ${MAX_RETRIES} attempts: ${errorMsg}`, 'error');
            return { success: false, contact, error: errorMsg };
          }

          // Quick exponential backoff for retries
          await new Promise(resolve => setTimeout(resolve, 500 * attempt));
        }
      }
      return { success: false, contact, error: 'Max retries exceeded' };
    });

    return Promise.all(promises);
  };

  const startCooldown = () => {
    setIsCoolingDown(true);
    setCooldownTime(RATE_LIMIT_COOLDOWN / 1000);
    toast.warning(`Rate limit hit. Cooling down for ${RATE_LIMIT_COOLDOWN / 1000} seconds...`);

    cooldownTimerRef.current = setInterval(() => {
      setCooldownTime(prev => {
        if (prev <= 1) {
          clearInterval(cooldownTimerRef.current);
          setIsCoolingDown(false);
          toast.info('Cooldown finished. Resuming enrichment.');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Ultra-fast enrichment engine with parallel processing
  const handleEnrichContacts = async () => {
    try {
      setIsEnriching(true);
      pausedRef.current = false;
      setIsPaused(false);
      setIsCoolingDown(false); // Ensure cooldown is reset
      setCooldownTime(0); // Ensure cooldown time is reset
      if (cooldownTimerRef.current) {
        clearInterval(cooldownTimerRef.current);
        cooldownTimerRef.current = null;
      }

      abortControllerRef.current = new AbortController();

      const contactsToEnrich = connections.filter(needsEnrichment);
      enrichmentQueueRef.current = [...contactsToEnrich];

      const initialStats = {
        total: contactsToEnrich.length,
        processed: 0,
        successful: 0,
        failed: 0,
        skipped: connections.length - contactsToEnrich.length
      };
      setStats(initialStats);
      setEnrichmentLog([]);

      // Initialize cost and performance tracking
      const startTime = Date.now();
      const estimatedTotalCost = contactsToEnrich.length * costTracking.costPerEnrichment;
      setCostTracking(prev => ({
        ...prev,
        currentCost: 0,
        estimatedTotalCost
      }));
      setPerformanceMetrics({
        startTime,
        avgTimePerContact: 0,
        contactsPerMinute: 0,
        estimatedCompletion: null
      });

      addLogEntry(`🚀 Initiating Ultra-Fast AI Enrichment System`, 'info');
      addLogEntry(`📊 Processing ${contactsToEnrich.length} contacts with parallel batching`, 'info');
      addLogEntry(`💰 Estimated total cost: $${estimatedTotalCost.toFixed(2)}`, 'info');
      toast.info(`Ultra-Fast AI Enrichment started! Estimated cost: $${estimatedTotalCost.toFixed(2)}`);

      if (contactsToEnrich.length === 0) {
        addLogEntry('✨ All contacts already enriched!', 'success');
        toast.success('All contacts are already enriched!');
        setIsEnriching(false);
        return;
      }

      let batchNumber = 0;
      let activeBatches = [];

      while (enrichmentQueueRef.current.length > 0 && !abortControllerRef.current?.signal.aborted) {
        // Handle pause or cooldown state
        while (pausedRef.current || isCoolingDown) {
          await new Promise(resolve => setTimeout(resolve, 100));
          if (abortControllerRef.current?.signal.aborted) break;
        }

        if (abortControllerRef.current?.signal.aborted) break;

        // Process multiple batches in parallel for maximum speed
        while (activeBatches.length < MAX_PARALLEL_BATCHES && enrichmentQueueRef.current.length > 0) {
          batchNumber++;
          const batch = enrichmentQueueRef.current.splice(0, BATCH_SIZE);

          setCurrentBatch(`Ultra-Processing: ${activeBatches.length + 1} parallel batches running...`);
          addLogEntry(`⚡ Launching parallel batch ${batchNumber}: ${batch.map(c => c.connection_name).join(', ')}`, 'info');

          const batchPromise = processBatch(batch);
          activeBatches.push(batchPromise);
        }

        // Wait for any batch to complete
        if (activeBatches.length > 0) {
          const completedPromise = await Promise.race(activeBatches.map(p => p.then(res => ({res, p}))));
          activeBatches = activeBatches.filter(p => p !== completedPromise.p);
          const results = completedPromise.res;

          const rateLimitHit = results.some(r => r && r.isRateLimit);

          if (rateLimitHit) {
            const failedDueToRateLimit = results.filter(r => r && r.isRateLimit).map(r => r.contact);
            enrichmentQueueRef.current.unshift(...failedDueToRateLimit);
            addLogEntry(`🔄 Re-queuing ${failedDueToRateLimit.length} contacts after rate limit`, 'warning');
            startCooldown();
          }

          let successfulInBatch = 0;
          let failedInBatch = 0;
          let batchCost = 0;

          results.forEach(result => {
            if (result) {
              if (result.success) {
                successfulInBatch++;
                batchCost += result.cost || 0;
              } else if (!result.isRateLimit) { // Only count as failed if not a rate limit
                failedInBatch++;
              }
            }
          });

          if (successfulInBatch > 0 || failedInBatch > 0) {
            setStats(prev => {
              const newProcessed = prev.processed + successfulInBatch + failedInBatch;
              const newSuccessful = prev.successful + successfulInBatch;
              const newFailed = prev.failed + failedInBatch;

              // Update performance metrics
              if (newProcessed > 0) {
                updatePerformanceMetrics(newProcessed, startTime);
              }

              return { ...prev, processed: newProcessed, successful: newSuccessful, failed: newFailed };
            });
            setCostTracking(prev => ({...prev, currentCost: prev.currentCost + batchCost}));
          }
        }

        // Brief pause between batch cycles for system stability
        if (enrichmentQueueRef.current.length > 0) {
          await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
        }
      }

      // Wait for all remaining batches to complete
      if (activeBatches.length > 0) {
        await Promise.all(activeBatches);
      }

      // Final completion with cost summary
      const finalStats = stats; // Capture current stats before final update
      const finalCost = costTracking.currentCost;

      if (finalStats.failed === 0) {
        addLogEntry(`🎉 Ultra-Fast enrichment completed! ${finalStats.successful} contacts enhanced for $${finalCost.toFixed(2)}`, 'success');
        toast.success(`🎉 Enrichment complete! ${finalStats.successful} contacts enhanced for $${finalCost.toFixed(2)}`);
      } else {
        addLogEntry(`⚠️ Enrichment finished: ${finalStats.successful} succeeded, ${finalStats.failed} failed. Total cost: $${finalCost.toFixed(2)}`, 'warning');
        toast.warning(`Enrichment finished. ${finalStats.successful} succeeded, ${finalStats.failed} failed. Cost: $${finalCost.toFixed(2)}`);
      }

      onEnrichmentComplete();

    } catch (err) {
      console.error('Enrichment system failure:', err);
      addLogEntry(`💥 System error: ${err.message}`, 'error');
      toast.error(`Enrichment system failed: ${err.message}`);
    } finally {
      setIsEnriching(false);
      setCurrentBatch('');
      if (cooldownTimerRef.current) {
        clearInterval(cooldownTimerRef.current);
      }
      setIsCoolingDown(false);
      setCooldownTime(0);
    }
  };

  // Password-protected enrichment handler
  const handleEnrichmentButtonClick = () => {
    if (onRequestPasswordAccess) {
      onRequestPasswordAccess('enrichment');
    } else {
      handleEnrichContacts(); // Direct execution if no password protection callback
    }
  };

  const stopEnrichment = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      addLogEntry('🛑 Ultra-fast enrichment stopped by user.', 'warning');
      toast.warning('Enrichment process stopped.');
      setIsEnriching(false);
      if (cooldownTimerRef.current) {
        clearInterval(cooldownTimerRef.current);
      }
      setIsCoolingDown(false);
      setCooldownTime(0);
    }
  };

  const togglePause = () => {
    pausedRef.current = !pausedRef.current;
    setIsPaused(pausedRef.current);
    if (pausedRef.current) {
      addLogEntry('⏸️ Process paused.', 'info');
      toast.info('Enrichment paused.');
    } else {
      addLogEntry('▶️ Process resumed.', 'info');
      toast.info('Enrichment resumed.');
    }
  };

  const exportEnrichmentLog = () => {
    const logContent = [
      `AI Enrichment Session Report - ${new Date().toISOString()}`,
      `Total Processed: ${stats.processed}`,
      `Successful: ${stats.successful}`,
      `Failed: ${stats.failed}`,
      `Total Cost: $${costTracking.currentCost.toFixed(2)}`,
      `Performance: ${performanceMetrics.contactsPerMinute} contacts/minute`,
      '',
      'Detailed Log:',
      ...enrichmentLog
    ].join('\n');

    const blob = new Blob([logContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ultra-enrichment-report-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const contactsNeedingEnrichment = connections.filter(needsEnrichment).length;
  const enrichmentProgress = stats.total > 0 ? (stats.processed / stats.total) * 100 : 0;

  return (
    <Card className="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 shadow-2xl border-0 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white">
        <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between gap-2">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl font-bold">Ultra-Fast AI Data Enrichment</CardTitle>
              <p className="text-blue-100 text-sm">Advanced Parallel Processing • Cost-Optimized</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30 mt-2 sm:mt-0">
            <Sparkles className="w-3 h-3 mr-1" />
            Premium Ultra
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="p-4 md:p-6">
        {/* Enhanced Status Overview with Cost Tracking */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 md:gap-4 mb-6">
          <div className="bg-white rounded-lg p-3 md:p-4 text-center shadow-sm">
            <div className="text-2xl font-bold text-blue-600">{contactsNeedingEnrichment}</div>
            <div className="text-xs text-gray-600">To Enrich</div>
          </div>
          <div className="bg-white rounded-lg p-3 md:p-4 text-center shadow-sm">
            <div className="text-2xl font-bold text-green-600">{stats.successful}</div>
            <div className="text-xs text-gray-600">Enhanced</div>
          </div>
          <div className="bg-white rounded-lg p-3 md:p-4 text-center shadow-sm">
            <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
            <div className="text-xs text-gray-600">Failed</div>
          </div>
          <div className="bg-white rounded-lg p-3 md:p-4 text-center shadow-sm">
            <div className="text-2xl font-bold text-purple-600">{Math.round(enrichmentProgress)}%</div>
            <div className="text-xs text-gray-600">Complete</div>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-3 md:p-4 text-center shadow-sm border border-green-200">
            <div className="text-2xl font-bold text-green-600">${costTracking.currentCost.toFixed(2)}</div>
            <div className="text-xs text-green-800 font-medium">Live Cost</div>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-lg p-3 md:p-4 text-center shadow-sm border border-orange-200">
            <div className="text-2xl font-bold text-orange-600">{performanceMetrics.contactsPerMinute}</div>
            <div className="text-xs text-orange-800 font-medium">Per Minute</div>
          </div>
        </div>

        {/* Real-time Cost and Performance Dashboard */}
        {isEnriching && (
          <div className="bg-gradient-to-r from-green-50 via-blue-50 to-purple-50 rounded-lg p-4 mb-6 border border-gray-200">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="flex items-center">
                <DollarSign className="w-4 h-4 text-green-600 mr-2 shrink-0" />
                <div>
                  <div className="font-medium text-gray-900">Live Cost</div>
                  <div className="text-green-600 font-bold">${costTracking.currentCost.toFixed(2)} / ${costTracking.estimatedTotalCost.toFixed(2)}</div>
                </div>
              </div>
              <div className="flex items-center">
                <TrendingUp className="w-4 h-4 text-blue-600 mr-2 shrink-0" />
                <div>
                  <div className="font-medium text-gray-900">Speed</div>
                  <div className="text-blue-600 font-bold">{performanceMetrics.contactsPerMinute}/min</div>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-orange-600 mr-2 shrink-0" />
                <div>
                  <div className="font-medium text-gray-900">ETA</div>
                  <div className="text-orange-600 font-bold">
                    {performanceMetrics.estimatedCompletion ?
                      performanceMetrics.estimatedCompletion.toLocaleTimeString() : 'Calculating...'}
                  </div>
                </div>
              </div>
              <div className="flex items-center">
                <Zap className="w-4 h-4 text-purple-600 mr-2 shrink-0" />
                <div>
                  <div className="font-medium text-gray-900">Efficiency</div>
                  <div className="text-purple-600 font-bold">${(costTracking.currentCost / Math.max(stats.successful, 1)).toFixed(3)}/contact</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Current Status */}
        {isEnriching && (
          <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-gray-900">Ultra-Fast Processing Status</span>
              <div className="flex items-center space-x-2">
                {isCoolingDown ? (
                   <Badge variant="outline" className="text-red-600 border-red-300">
                    <Clock className="w-3 h-3 mr-1 animate-pulse" />
                    Cooling Down ({cooldownTime}s)
                  </Badge>
                ) : isPaused ? (
                  <Badge variant="outline" className="text-yellow-600 border-yellow-300">
                    <Pause className="w-3 h-3 mr-1" />
                    Paused
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-green-600 border-green-300">
                    <Play className="w-3 h-3 mr-1" />
                    Ultra-Processing
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-sm text-gray-600 mb-2">{currentBatch}</div>
            <Progress value={enrichmentProgress} className="h-3 bg-gray-200">
              <div className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 rounded-full transition-all duration-300"
                   style={{ width: `${enrichmentProgress}%` }} />
            </Progress>
          </div>
        )}

        {/* Ultra-Fast Controls - WITH PASSWORD PROTECTION */}
        <div className="flex flex-wrap gap-3 mb-6">
          {!isEnriching ? (
            <Button
              onClick={handleEnrichmentButtonClick} // This now triggers password protection
              disabled={contactsNeedingEnrichment === 0}
              className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-lg grow sm:grow-0"
            >
              <Zap className="w-4 h-4 mr-2" />
              Ultra-Fast AI Enrichment ({contactsNeedingEnrichment} contacts, ~${(contactsNeedingEnrichment * costTracking.costPerEnrichment).toFixed(2)})
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button onClick={togglePause} variant="outline" disabled={isCoolingDown}>
                {isPaused ? <Play className="w-4 h-4 mr-2" /> : <Pause className="w-4 h-4 mr-2" />}
                {isPaused ? 'Resume' : 'Pause'}
              </Button>
              <Button onClick={stopEnrichment} variant="destructive">
                <X className="w-4 h-4 mr-2" />
                Stop
              </Button>
            </div>
          )}

          <Button
            variant="outline"
            onClick={() => setShowDetailedLog(!showDetailedLog)}
            disabled={enrichmentLog.length === 0}
            className="grow sm:grow-0"
          >
            <List className="w-4 h-4 mr-2" />
            {showDetailedLog ? 'Hide' : 'Show'} Live Log ({enrichmentLog.length})
          </Button>

          {enrichmentLog.length > 0 && (
            <Button variant="outline" onClick={exportEnrichmentLog} className="grow sm:grow-0">
              <FileDown className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          )}
        </div>

        {/* Enhanced Live Log */}
        <AnimatePresence>
          {showDetailedLog && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-gray-900 rounded-lg p-4 font-mono text-sm overflow-hidden"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-white font-semibold">Live Enrichment Log</h4>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">{enrichmentLog.length} entries</Badge>
                  {isEnriching && <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />}
                </div>
              </div>
              <div className="max-h-64 overflow-y-auto space-y-1">
                {enrichmentLog.slice(0, 50).map((entry, index) => (
                  <div key={index} className="text-gray-300 text-xs leading-relaxed">
                    {entry}
                  </div>
                ))}
                {enrichmentLog.length > 50 && (
                  <div className="text-gray-500 text-xs italic">
                    ... and {enrichmentLog.length - 50} more entries (export for full log)
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Enhanced Feature Description */}
        <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 rounded-lg border border-blue-200">
          <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
            <ShieldCheck className="w-4 h-4 mr-2" />
            Ultra-Fast AI Enrichment Capabilities
          </h4>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3 text-sm text-blue-800">
            <div>• Parallel Batch Processing (6x Speed)</div>
            <div>• Real-time Cost Optimization</div>
            <div>• Advanced Industry Classification</div>
            <div>• Intelligent Seniority Detection</div>
            <div>• Professional Function Mapping</div>
            <div>• Location Standardization</div>
            <div>• Company Size Intelligence</div>
            <div>• AI-Generated Professional Summaries</div>
            <div>• Live Performance Metrics</div>
          </div>
          <div className="mt-3 p-2 bg-green-100 rounded text-xs text-green-800">
            💡 <strong>Cost-Optimized:</strong> ~$0.025 per contact enrichment with premium AI models
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
