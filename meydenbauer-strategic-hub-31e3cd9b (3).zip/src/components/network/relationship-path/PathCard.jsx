
import React from 'react';
import { motion } from 'framer-motion';
import { User, Briefcase, Mail, Linkedin, ChevronRight, Share2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PathCard({ path, target, requester, isPrimary }) {
  const getScoreColor = (score) => {
    if (score >= 95) return 'text-green-500';
    if (score >= 85) return 'text-blue-500';
    return 'text-yellow-500';
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const handleRequestIntro = () => {
    const subject = "TouchpointAI - Intro Request";
    const body = `${target.connection_name}`;
    const mailtoLink = `mailto:doug@mbcpartners.co?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
  };

  return (
    <motion.div 
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      className={`bg-white rounded-2xl shadow-sm border overflow-hidden transition-all duration-300 ${isPrimary ? 'border-blue-500 shadow-blue-500/10' : 'border-gray-200 hover:shadow-md'}`}
    >
      <div className="p-6">
        <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
          {/* Connector Info */}
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-full flex-shrink-0 flex items-center justify-center text-white font-bold text-lg bg-gradient-to-br ${isPrimary ? 'from-blue-500 to-purple-600' : 'from-gray-400 to-gray-600'}`}>
              {path.connector.name?.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900">{path.connector.name}</h3>
              <p className="text-sm text-gray-600">{path.connector.title}</p>
            </div>
          </div>

          {/* Score & Action */}
          <div className="flex items-center gap-4 w-full sm:w-auto">
              <div className="text-right">
                  <div className={`text-2xl font-bold ${getScoreColor(path.score)}`}>{path.score}%</div>
                  <div className="text-xs text-gray-500">Match Score</div>
              </div>
            <Button onClick={handleRequestIntro} className="bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg">
              <Share2 className="w-4 h-4 mr-2" />
              Request Intro
            </Button>
          </div>
        </div>
        
        {/* Path Reasoning */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <p className="text-sm text-gray-700 italic">
            <Star className="w-4 h-4 inline-block mr-2 text-yellow-400 fill-current" />
            <span className="font-semibold">Suggested Path:</span> {path.reasoning}
          </p>
        </div>
      </div>
    </motion.div>
  );
}
