import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, ArrowRight, BrainCircuit } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function PathSearchBar({ onSearch, isLoading }) {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim());
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white/50 backdrop-blur-sm rounded-2xl border border-gray-200 shadow-lg p-6 md:p-8 w-full max-w-4xl mx-auto"
    >
      <div className="flex items-center gap-2 mb-3">
        <BrainCircuit className="w-5 h-5 text-[var(--primary-teal)]" />
        <h2 className="text-xl md:text-2xl font-bold text-gray-800" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
          Find a Warm Introduction Path
        </h2>
      </div>
      <p className="text-gray-600 mb-6 text-sm md:text-base">
        Enter a prospect's name, company, or LinkedIn URL to discover the strongest introduction routes through your network.
      </p>
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            type="text"
            placeholder="e.g., 'Satya Nadella', 'Microsoft', or LinkedIn URL..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 h-12 border-gray-300 rounded-lg text-base"
            disabled={isLoading}
          />
        </div>
        <Button 
          type="submit" 
          className="w-full sm:w-auto bg-gradient-to-r from-[var(--primary-teal)] to-[var(--secondary-teal)] text-white font-semibold px-6 py-3 h-12 rounded-lg flex items-center justify-center gap-2"
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <>
              <span>Find Path</span>
              <ArrowRight className="w-5 h-5" />
            </>
          )}
        </Button>
      </form>
    </motion.div>
  );
}