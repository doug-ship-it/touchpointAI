import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ArrowRight, BrainCircuit, Filter, Sparkles, Users, Building } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const searchPrompts = [
  "Looking for a VP Sales at a Series B SaaS company in Seattle?",
  "Need an introduction to PE partners in healthcare?",
  "Connecting with CTOs at portfolio companies?",
  "Finding board members with exit experience?"
];

const quickFilters = [
  { label: "C-Level", type: "seniority", value: "CXO" },
  { label: "VPs", type: "seniority", value: "Vice President" },
  { label: "Directors", type: "seniority", value: "Director" },
  { label: "Tech", type: "industry", value: "Technology" },
  { label: "Finance", type: "industry", value: "Financial Services" },
  { label: "Healthcare", type: "industry", value: "Healthcare" }
];

export default function EnhancedPathSearchBar({ onSearch, isLoading, allContacts = [] }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPrompt, setCurrentPrompt] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [activeFilters, setActiveFilters] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const searchRef = useRef(null);

  // Rotate prompts every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPrompt(prev => (prev + 1) % searchPrompts.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Generate suggestions based on search term
  useEffect(() => {
    if (searchTerm.length >= 2) {
      const matchingSuggestions = [];
      
      // Search through contacts for matches
      allContacts.slice(0, 5).forEach(contact => {
        if (
          contact.connection_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          contact.connection_company?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          contact.connection_title?.toLowerCase().includes(searchTerm.toLowerCase())
        ) {
          matchingSuggestions.push({
            type: 'contact',
            name: contact.connection_name,
            company: contact.connection_company,
            title: contact.connection_title,
            confidence: 95
          });
        }
      });

      // Add company suggestions
      const companies = [...new Set(allContacts.map(c => c.connection_company).filter(Boolean))];
      companies.filter(company => 
        company.toLowerCase().includes(searchTerm.toLowerCase())
      ).slice(0, 3).forEach(company => {
        matchingSuggestions.push({
          type: 'company',
          name: company,
          confidence: 85
        });
      });

      setSuggestions(matchingSuggestions);
      setShowSuggestions(matchingSuggestions.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm, allContacts]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim(), activeFilters);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    const searchValue = suggestion.type === 'contact' ? suggestion.name : suggestion.name;
    setSearchTerm(searchValue);
    onSearch(searchValue, activeFilters);
    setShowSuggestions(false);
  };

  const handleFilterToggle = (filter) => {
    setActiveFilters(prev => {
      const exists = prev.find(f => f.type === filter.type && f.value === filter.value);
      if (exists) {
        return prev.filter(f => !(f.type === filter.type && f.value === filter.value));
      } else {
        return [...prev, filter];
      }
    });
  };

  const handlePromptClick = () => {
    setSearchTerm(searchPrompts[currentPrompt]);
    setTimeout(() => {
      onSearch(searchPrompts[currentPrompt], activeFilters);
    }, 100);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white/80 backdrop-blur-sm rounded-2xl border border-gray-200 shadow-lg p-6 md:p-8 w-full max-w-4xl mx-auto relative"
    >
      <div className="flex items-center gap-2 mb-3">
        <BrainCircuit className="w-6 h-6 text-[var(--primary-teal)]" />
        <h2 className="text-xl md:text-2xl font-bold text-gray-800" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
          Find Warm Introduction Paths
        </h2>
        <Sparkles className="w-5 h-5 text-yellow-500 animate-pulse" />
      </div>
      
      {/* Dynamic Prompt */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPrompt}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="mb-4"
        >
          <button
            onClick={handlePromptClick}
            className="text-sm text-gray-600 hover:text-[var(--primary-teal)] transition-colors duration-200 cursor-pointer italic bg-gray-50 hover:bg-[var(--light-teal)]/30 px-3 py-2 rounded-lg"
          >
            💡 Try: "{searchPrompts[currentPrompt]}"
          </button>
        </motion.div>
      </AnimatePresence>

      {/* Search Form */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            ref={searchRef}
            type="text"
            placeholder="Enter prospect name, company, LinkedIn URL, or use AI suggestions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-32 py-4 h-14 border-gray-300 rounded-xl text-base bg-white/80 backdrop-blur-sm"
            disabled={isLoading}
            onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          />
          <Button 
            type="submit" 
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-[var(--primary-teal)] to-[var(--secondary-teal)] text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2 hover:shadow-lg transition-all duration-200"
            disabled={isLoading}
          >
            {isLoading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            ) : (
              <>
                <span className="hidden sm:inline">Find Path</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </Button>
        </div>

        {/* Auto-complete Suggestions */}
        <AnimatePresence>
          {showSuggestions && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl border border-gray-200 shadow-xl z-50 overflow-hidden"
            >
              {suggestions.map((suggestion, index) => (
                <motion.button
                  key={index}
                  type="button"
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-150 flex items-center justify-between border-b border-gray-100 last:border-b-0"
                  whileHover={{ backgroundColor: 'rgba(0, 0, 0, 0.02)' }}
                >
                  <div className="flex items-center gap-3">
                    {suggestion.type === 'contact' ? (
                      <Users className="w-4 h-4 text-[var(--primary-teal)]" />
                    ) : (
                      <Building className="w-4 h-4 text-[var(--secondary-teal)]" />
                    )}
                    <div>
                      <div className="font-medium text-gray-900">{suggestion.name}</div>
                      {suggestion.company && (
                        <div className="text-sm text-gray-600">{suggestion.company}</div>
                      )}
                      {suggestion.title && (
                        <div className="text-xs text-gray-500">{suggestion.title}</div>
                      )}
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {suggestion.confidence}% match
                  </Badge>
                </motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </form>

      {/* Quick Filters */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Filter className="w-4 h-4 text-gray-500" />
        <span className="text-sm text-gray-600 font-medium mr-2">Quick filters:</span>
        {quickFilters.map((filter, index) => (
          <motion.button
            key={index}
            type="button"
            onClick={() => handleFilterToggle(filter)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-200 ${
              activeFilters.find(f => f.type === filter.type && f.value === filter.value)
                ? 'bg-[var(--primary-teal)] text-white shadow-md'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {filter.label}
          </motion.button>
        ))}
      </div>

      {/* Active Filters Display */}
      <AnimatePresence>
        {activeFilters.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 flex flex-wrap gap-2"
          >
            <span className="text-sm text-gray-600">Active filters:</span>
            {activeFilters.map((filter, index) => (
              <Badge key={index} variant="outline" className="flex items-center gap-1">
                {filter.label}
                <button
                  onClick={() => handleFilterToggle(filter)}
                  className="ml-1 hover:text-red-500"
                >
                  ×
                </button>
              </Badge>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}