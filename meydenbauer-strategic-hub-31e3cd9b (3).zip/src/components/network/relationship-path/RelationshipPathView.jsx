import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Users, Zap, UserX, Share2 } from 'lucide-react';
import PathCard from './PathCard';

export default function RelationshipPathView({ target, allContacts, currentUser, onBack, onNavigateToSearch }) {
  // --- ADVANCED PATHFINDING LOGIC ---
  const findPaths = () => {
    if (!target || !currentUser) return [];

    let paths = new Map(); // Use a Map to avoid duplicate connectors

    const addPath = (path) => {
        // Use connector name as key to ensure one path per connector
        if (!paths.has(path.connector.name)) {
            paths.set(path.connector.name, path);
        }
    };

    // --- Path 1: Direct Ownership (You own this contact record) ---
    if (target.user_email === currentUser.email) {
      addPath({
        id: `direct-${target.id}`,
        connector: {
          name: currentUser.full_name || currentUser.email.split('@')[0],
          title: 'You (Direct Connection)',
          photo: null
        },
        score: 99,
        reasoning: `This contact is in your direct network. You can reach out immediately.`,
        type: 'Direct'
      });
    }

    // --- Path 2: Introduction through the Target's Owner (An internal team member) ---
    const ownerEmail = target.user_email;
    if (ownerEmail && ownerEmail !== currentUser.email) {
      // Find if the owner exists as a contact in the user's *own* network
      const ownerAsContactInMyNetwork = allContacts.find(c => c.connection_email === ownerEmail && c.user_email === currentUser.email);
      addPath({
        id: `owner-${target.id}`,
        connector: {
          name: ownerAsContactInMyNetwork?.connection_name || ownerEmail.split('@')[0],
          title: ownerAsContactInMyNetwork?.connection_title || 'Internal Colleague',
          photo: null
        },
        score: 95,
        reasoning: `Your colleague, ${ownerAsContactInMyNetwork?.connection_name || ownerEmail.split('@')[0]}, is the owner of this contact record.`,
        type: 'Internal Intro'
      });
    }
    
    // --- Path 3: Introduction through a Colleague at the Target's Company ---
    const colleaguesInMyNetwork = allContacts.filter(c => 
        c.user_email === currentUser.email && // It's my connection
        c.id !== target.id && // Not the target themselves
        c.connection_company === target.connection_company // Works at the same company
    );

    colleaguesInMyNetwork.slice(0, 2).forEach(colleague => { // Limit to 2 for brevity
        addPath({
            id: `colleague-${colleague.id}`,
            connector: {
                name: colleague.connection_name,
                title: colleague.connection_title,
                photo: null
            },
            score: 88,
            reasoning: `Your connection, ${colleague.connection_name}, is a colleague of ${target.connection_name} at ${target.connection_company}.`,
            type: 'Colleague Intro'
        });
    });

    // --- Path 4 & 5: Simulate paths based on shared past experiences (using existing data) ---
    // This is a simulation as we don't have explicit "past company" data.
    // We'll find contacts who have a strong relationship score and are in a related industry.
    const strongRelevantConnections = allContacts.filter(c =>
        c.user_email === currentUser.email &&
        (c.relationship_score || 0) >= 8 && // Using the 1-10 scale
        c.enriched_industry === target.enriched_industry
    ).slice(0, 2);

    strongRelevantConnections.forEach(contact => {
        addPath({
            id: `industry-${contact.id}`,
            connector: {
                name: contact.connection_name,
                title: contact.connection_title,
                photo: null
            },
            score: 82,
            reasoning: `Your connection, ${contact.connection_name}, has a strong network in the ${target.enriched_industry} industry.`,
            type: 'Industry Intro'
        });
    });

    // Convert map to array, sort by score, and take top 5
    return Array.from(paths.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  };

  const foundPaths = findPaths();
  const hasConfidentPath = foundPaths.length > 0 && foundPaths[0].score >= 80;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full max-w-5xl mx-auto"
    >
      <div className="flex items-center justify-between mb-8">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Search
        </Button>
        <div className="text-right">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Introduction Paths</h1>
            <p className="text-gray-500">to <span className="font-semibold text-gray-700">{target.connection_name}</span></p>
        </div>
      </div>
      
      {hasConfidentPath ? (
        <div className="space-y-6">
          <AnimatePresence>
            {foundPaths.map((path, index) => (
              <PathCard 
                key={path.id}
                path={path}
                target={target}
                requester={currentUser}
                isPrimary={index === 0}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-2xl border border-dashed flex flex-col items-center">
            <UserX className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-800">No High-Confidence Paths Found</h3>
            <p className="text-gray-500 mt-2 max-w-md mx-auto">We couldn't find any relevant connection paths. Our network is somewhat limited during this Beta phase, so please check back soon!</p>
            <Button onClick={onNavigateToSearch} className="mt-6">
                <Share2 className="w-4 h-4 mr-2" />
                Navigate to Intelligent Network Search
            </Button>
        </div>
      )}

    </motion.div>
  );
}