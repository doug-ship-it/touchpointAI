import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Users, TrendingUp, Shield, Mail, Building, User, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function ShortlistAuthModal({ isOpen, onClose, onAuthenticate, contactCount = 0 }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    company: '',
    role: '',
    useCase: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await onAuthenticate(formData);
      onClose();
    } catch (error) {
      console.error('Authentication failed:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNext = () => {
    if (step === 1 && formData.email) {
      setStep(2);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-2xl max-h-[90vh] overflow-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <Card className="shadow-2xl border-0">
            <CardHeader className="relative bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-t-lg">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 text-white hover:bg-white/20"
                onClick={onClose}
              >
                <X className="w-5 h-5" />
              </Button>
              
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-xl">Create Strategic Shortlist</CardTitle>
                  <p className="text-blue-100 text-sm">
                    Join 500+ strategic leaders using network intelligence
                  </p>
                </div>
              </div>
              
              {contactCount > 0 && (
                <Badge className="bg-white/20 text-white border-white/30 w-fit">
                  {contactCount} contacts selected
                </Badge>
              )}
            </CardHeader>

            <CardContent className="p-8">
              {step === 1 ? (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="text-center mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Unlock Your Network Intelligence
                    </h3>
                    <p className="text-gray-600">
                      Get started with intelligent contact management and strategic relationship building
                    </p>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-teal-50 rounded-lg">
                      <Shield className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-teal-800">Secure</p>
                      <p className="text-xs text-teal-600">Enterprise-grade security</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-blue-800">Intelligent</p>
                      <p className="text-xs text-blue-600">AI-powered insights</p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-purple-800">Strategic</p>
                      <p className="text-xs text-purple-600">Relationship mapping</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <Input
                        type="email"
                        placeholder="Enter your business email"
                        className="pl-10 h-12 text-lg"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>
                    
                    <Button
                      onClick={handleNext}
                      disabled={!formData.email}
                      className="w-full h-12 text-lg bg-teal-600 hover:bg-teal-700"
                    >
                      Continue to Profile Setup
                    </Button>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="text-center mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Complete Your Profile
                    </h3>
                    <p className="text-gray-600">
                      Help us personalize your network intelligence experience
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="relative">
                        <Building className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input
                          placeholder="Company name"
                          className="pl-10"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          required
                        />
                      </div>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input
                          placeholder="Your role/title"
                          className="pl-10"
                          value={formData.role}
                          onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    
                    <Textarea
                      placeholder="What's your specific use case for this shortlist? (e.g., partnership opportunities, hiring pipeline, investor outreach)"
                      className="min-h-[100px]"
                      value={formData.useCase}
                      onChange={(e) => setFormData({ ...formData, useCase: e.target.value })}
                      required
                    />

                    <div className="flex gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setStep(1)}
                        className="flex-1"
                      >
                        Back
                      </Button>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="flex-1 bg-teal-600 hover:bg-teal-700"
                      >
                        {isSubmitting ? 'Creating Shortlist...' : 'Create Shortlist'}
                      </Button>
                    </div>
                  </form>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}