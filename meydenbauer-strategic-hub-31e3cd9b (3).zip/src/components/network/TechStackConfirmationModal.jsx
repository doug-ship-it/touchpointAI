import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Settings, Zap, Brain, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export default function TechStackConfirmationModal({ 
  isOpen, 
  onClose, 
  techStackData, 
  isHighConfidence,
  onConfirm 
}) {
  const [selectedTools, setSelectedTools] = useState({});
  const [customTools, setCustomTools] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && techStackData) {
      // Pre-select high-confidence tools
      const initialSelection = {};
      
      Object.entries(techStackData).forEach(([category, tools]) => {
        if (Array.isArray(tools)) {
          initialSelection[category] = {};
          tools.forEach(tool => {
            if (tool.confidence_score >= 90) {
              initialSelection[category][tool.tool] = true;
            }
          });
        }
      });
      
      setSelectedTools(initialSelection);
    }
  }, [isOpen, techStackData]);

  const handleToolToggle = (category, tool) => {
    setSelectedTools(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [tool]: !prev[category]?.[tool]
      }
    }));
  };

  const handleCustomToolAdd = (category, customTool) => {
    if (!customTool.trim()) return;
    
    setSelectedTools(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [customTool]: true
      }
    }));
    
    setCustomTools(prev => ({
      ...prev,
      [category]: ''
    }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Format selected tools for backend
      const confirmedTechStack = {};
      
      Object.entries(selectedTools).forEach(([category, tools]) => {
        confirmedTechStack[category] = Object.entries(tools)
          .filter(([tool, selected]) => selected)
          .map(([tool]) => ({
            tool,
            confirmed: true,
            source: customTools[tool] ? 'manual' : 'ai_identified'
          }));
      });

      await onConfirm(confirmedTechStack);
      toast.success('Tech stack confirmed! Your connection recommendations are now personalized.');
      onClose();
    } catch (error) {
      console.error('Tech stack confirmation failed:', error);
      toast.error('Failed to save tech stack. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const categoryLabels = {
    crm_systems: 'CRM Systems',
    communication_tools: 'Communication Tools',
    marketing_automation: 'Marketing Automation',
    analytics_platforms: 'Analytics Platforms',
    development_tools: 'Development Tools'
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <Card className="shadow-2xl border-0">
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-4 right-4 z-10" 
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </Button>
            
            <CardHeader className="text-center p-8 bg-gradient-to-r from-blue-50 to-purple-50">
              <div className="w-16 h-16 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-4">
                {isHighConfidence ? (
                  <Brain className="w-8 h-8 text-white" />
                ) : (
                  <Settings className="w-8 h-8 text-white" />
                )}
              </div>
              
              <CardTitle className="text-2xl font-bold text-gray-900">
                {isHighConfidence ? 'Confirm Your Tech Stack' : 'Build Your Tech Profile'}
              </CardTitle>
              
              <p className="text-gray-600 mt-2">
                {isHighConfidence 
                  ? 'We detected these tools with high confidence. Confirm or modify below.'
                  : 'Help us understand your technology preferences to personalize your connections.'
                }
              </p>
              
              <div className="flex items-center justify-center gap-2 mt-4">
                <Zap className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-blue-600 font-medium">
                  Personalizing your connection recommendations
                </span>
              </div>
            </CardHeader>

            <CardContent className="p-8">
              <div className="space-y-8">
                {Object.entries(techStackData).map(([category, tools]) => {
                  if (!Array.isArray(tools) || tools.length === 0) return null;
                  
                  return (
                    <div key={category} className="space-y-4">
                      <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                        {categoryLabels[category] || category}
                        <Badge variant="outline" className="text-xs">
                          {tools.length} detected
                        </Badge>
                      </h3>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {tools.map(tool => (
                          <div 
                            key={tool.tool}
                            className={`p-3 rounded-lg border-2 transition-all cursor-pointer ${
                              selectedTools[category]?.[tool.tool]
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => handleToolToggle(category, tool.tool)}
                          >
                            <div className="flex items-center gap-3">
                              <Checkbox 
                                checked={selectedTools[category]?.[tool.tool] || false}
                                onChange={() => handleToolToggle(category, tool.tool)}
                              />
                              <div className="flex-1">
                                <p className="font-medium text-gray-900">{tool.tool}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      tool.confidence_score >= 90 
                                        ? 'bg-green-50 text-green-700 border-green-200'
                                        : 'bg-gray-50 text-gray-600'
                                    }`}
                                  >
                                    {tool.confidence_score}% confidence
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                        
                        {/* Add custom tool option */}
                        <div className="p-3 rounded-lg border-2 border-dashed border-gray-300 bg-gray-50">
                          <div className="flex items-center gap-2">
                            <Input
                              placeholder="Other tool..."
                              value={customTools[category] || ''}
                              onChange={(e) => setCustomTools(prev => ({
                                ...prev,
                                [category]: e.target.value
                              }))}
                              className="text-sm"
                              onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                  handleCustomToolAdd(category, customTools[category]);
                                }
                              }}
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleCustomToolAdd(category, customTools[category])}
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between mt-8 pt-6 border-t">
                <Button variant="outline" onClick={onClose}>
                  Skip for now
                </Button>
                <Button 
                  onClick={handleSubmit} 
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      Confirm & Personalize
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}