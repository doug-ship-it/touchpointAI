import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, Shield, Users, Lock, FileText, CheckCircle, AlertCircle, Loader2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import EnhancedUploadButton from './EnhancedUploadButton';

export default function PrivacyControlledUploadModal({ isOpen, onClose, onUploadComplete }) {
  const [uploadState, setUploadState] = useState('idle'); // idle, uploading, success, error
  const [selectedFile, setSelectedFile] = useState(null);
  const [privacySettings, setPrivacySettings] = useState({
    defaultPrivacy: 'private', // 'private' or 'shared'
    allowEnrichment: false,
    shareWithTrustedPartners: false
  });
  const [uploadProgress, setUploadProgress] = useState(0);
  const [importStats, setImportStats] = useState(null);

  const handleFileSelect = (file) => {
    setSelectedFile(file);
    setUploadState('uploading');
    simulateUpload(file);
  };

  const simulateUpload = async (file) => {
    // Simulate upload progress
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 200));
    }

    // Simulate processing results
    setImportStats({
      totalContacts: 1247,
      newContacts: 892,
      duplicates: 355,
      errors: 0
    });

    setUploadState('success');
    
    // Call the completion handler
    setTimeout(() => {
      onUploadComplete();
    }, 2000);
  };

  const handleClose = () => {
    if (uploadState === 'uploading') {
      const confirm = window.confirm('Upload is in progress. Are you sure you want to close?');
      if (!confirm) return;
    }
    
    setUploadState('idle');
    setSelectedFile(null);
    setUploadProgress(0);
    setImportStats(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && handleClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-4xl max-h-[90vh] overflow-auto"
        >
          <Card className="bg-white">
            <CardHeader className="flex flex-row items-center justify-between border-b">
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-[var(--primary-teal)]" />
                Import Your Professional Network
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={handleClose}>
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>
            
            <CardContent className="p-6">
              {uploadState === 'idle' && (
                <div className="space-y-6">
                  {/* Privacy Assurance */}
                  <Alert className="border-green-200 bg-green-50">
                    <Shield className="w-4 h-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      <strong>Your privacy is our priority.</strong> All connections remain private by default. 
                      You control what gets shared and with whom through granular permission settings.
                    </AlertDescription>
                  </Alert>

                  {/* Upload Area */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Import CSV/Excel Files</h3>
                    <p className="text-gray-600 mb-4">
                      Upload your professional connections from LinkedIn, CRM, or other sources. 
                      We support CSV, Excel, and other common formats.
                    </p>
                    
                    <EnhancedUploadButton 
                      onFileSelect={handleFileSelect}
                      className="w-full"
                    />
                  </div>

                  {/* Privacy Settings Preview */}
                  <Card className="bg-gray-50">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Lock className="w-4 h-4" />
                        Default Privacy Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Default Contact Privacy</span>
                          <Badge className="bg-gray-100 text-gray-800">
                            <Lock className="w-3 h-3 mr-1" />
                            Private
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Allow Trusted Partner Enrichment</span>
                          <Badge variant="outline">Disabled</Badge>
                        </div>
                        <div className="text-xs text-gray-500 mt-3 p-3 bg-blue-50 rounded-lg">
                          <Info className="w-4 h-4 inline mr-1" />
                          You can adjust these settings after import and create selective sharing links for collaboration.
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Supported Formats */}
                  <div>
                    <h4 className="font-semibold mb-3">Supported File Types & Sources</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex items-center gap-2 text-sm">
                        <FileText className="w-4 h-4 text-blue-500" />
                        CSV Files (.csv)
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <FileText className="w-4 h-4 text-green-500" />
                        Excel Files (.xlsx, .xls)
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="w-4 h-4 text-purple-500" />
                        LinkedIn Exports
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <FileText className="w-4 h-4 text-orange-500" />
                        CRM Exports
                      </div>
                    </div>
                  </div>

                  {/* LinkedIn Export Instructions */}
                  <Card className="bg-blue-50 border-blue-200">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-blue-900 mb-2">LinkedIn Export Instructions</h4>
                      <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                        <li>Go to LinkedIn Settings & Privacy</li>
                        <li>Click "Data Privacy" → "Get a copy of your data"</li>
                        <li>Select "Connections" and request archive</li>
                        <li>Download and upload the CSV file here</li>
                      </ol>
                    </CardContent>
                  </Card>
                </div>
              )}

              {uploadState === 'uploading' && (
                <div className="space-y-6 text-center py-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-16 h-16 bg-[var(--primary-teal)] rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <Loader2 className="w-8 h-8 text-white animate-spin" />
                  </motion.div>
                  
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Processing Your Network</h3>
                    <p className="text-gray-600 mb-4">
                      Importing and securing your professional connections...
                    </p>
                    <Progress value={uploadProgress} className="w-full max-w-md mx-auto mb-2" />
                    <p className="text-sm text-gray-500">{uploadProgress}% complete</p>
                  </div>

                  <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mt-6">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <CheckCircle className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                      <div className="text-xs text-blue-800">Validating</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Shield className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                      <div className="text-xs text-gray-600">Securing</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Users className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                      <div className="text-xs text-gray-600">Organizing</div>
                    </div>
                  </div>
                </div>
              )}

              {uploadState === 'success' && importStats && (
                <div className="space-y-6 text-center py-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <CheckCircle className="w-8 h-8 text-white" />
                  </motion.div>

                  <div>
                    <h3 className="text-xl font-semibold text-green-700 mb-2">Import Successful!</h3>
                    <p className="text-gray-600 mb-6">
                      Your network has been securely imported with privacy protection enabled.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{importStats.totalContacts}</div>
                      <div className="text-sm text-green-800">Total Imported</div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{importStats.newContacts}</div>
                      <div className="text-sm text-blue-800">New Contacts</div>
                    </div>
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600">{importStats.duplicates}</div>
                      <div className="text-sm text-yellow-800">Duplicates Merged</div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-gray-600">{importStats.errors}</div>
                      <div className="text-sm text-gray-800">Errors</div>
                    </div>
                  </div>

                  <Alert className="border-green-200 bg-green-50 max-w-2xl mx-auto">
                    <Shield className="w-4 h-4 text-green-600" />
                    <AlertDescription className="text-green-800 text-left">
                      <strong>Privacy Status:</strong> All {importStats.totalContacts} contacts are now private by default. 
                      You can create selective sharing links when you're ready to collaborate.
                    </AlertDescription>
                  </Alert>

                  <Button onClick={handleClose} className="bg-[var(--primary-teal)] hover:bg-[var(--secondary-teal)]">
                    Explore Your Network
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}