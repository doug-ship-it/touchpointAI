import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Users, Upload, Share2, Lock, Building2, TrendingUp, Eye, Shield } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function NetworkDashboard({ 
  contacts, 
  sharingStats, 
  onUploadClick, 
  onCreateSharingLink, 
  onViewContacts 
}) {
  const stats = useMemo(() => {
    const totalContacts = contacts.length;
    const privateContacts = contacts.filter(c => !c.sharingStatus?.isShared).length;
    const sharedContacts = contacts.filter(c => c.sharingStatus?.isShared).length;
    const activeSharingLinks = sharingStats?.activeLinkCount || 0;

    // Group by company
    const companyCounts = contacts.reduce((acc, contact) => {
      const company = contact.connection_company || 'Unknown';
      acc[company] = (acc[company] || 0) + 1;
      return acc;
    }, {});

    const topCompanies = Object.entries(companyCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5);

    return {
      totalContacts,
      privateContacts,
      sharedContacts,
      activeSharingLinks,
      topCompanies
    };
  }, [contacts, sharingStats]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Network Intelligence</h1>
          <p className="text-gray-600 mt-1">
            Manage your professional connections with enterprise-grade privacy controls
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={onUploadClick} className="bg-[var(--primary-teal)] hover:bg-[var(--secondary-teal)]">
            <Upload className="w-4 h-4 mr-2" />
            Import Connections
          </Button>
          <Button 
            onClick={onCreateSharingLink} 
            variant="outline"
            disabled={stats.totalContacts === 0}
          >
            <Share2 className="w-4 h-4 mr-2" />
            Create Sharing Link
          </Button>
        </div>
      </div>

      {/* Privacy Assurance Banner */}
      <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-green-800">Your Privacy is Protected</h3>
              <p className="text-sm text-green-700">
                All connections remain private by default. You control what gets shared and with whom.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
          <Card className="cursor-pointer" onClick={onViewContacts}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Contacts</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center gap-2">
                <Users className="w-8 h-8 text-[var(--primary-teal)]" />
                <span className="text-2xl font-bold text-gray-900">{stats.totalContacts.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Private Contacts</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center gap-2">
                <Lock className="w-8 h-8 text-gray-500" />
                <span className="text-2xl font-bold text-gray-900">{stats.privateContacts.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Shared Contacts</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center gap-2">
                <Share2 className="w-8 h-8 text-blue-500" />
                <span className="text-2xl font-bold text-gray-900">{stats.sharedContacts.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Active Links</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center gap-2">
                <Eye className="w-8 h-8 text-purple-500" />
                <span className="text-2xl font-bold text-gray-900">{stats.activeSharingLinks}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Top Companies */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[var(--primary-teal)]" />
            Top Companies in Your Network
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stats.topCompanies.map(([company, count], index) => (
              <div key={company} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    {index + 1}
                  </div>
                  <span className="font-medium text-gray-900">{company}</span>
                </div>
                <Badge variant="outline">{count} contacts</Badge>
              </div>
            ))}
            {stats.topCompanies.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Building2 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>Import your connections to see company insights</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Sharing Analytics */}
      {stats.activeSharingLinks > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-500" />
              Collaboration Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{sharingStats?.totalViews || 0}</div>
                <div className="text-sm text-blue-800">Total Views</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{sharingStats?.enrichmentCount || 0}</div>
                <div className="text-sm text-green-800">Contacts Enriched</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{sharingStats?.collaboratorCount || 0}</div>
                <div className="text-sm text-purple-800">Active Collaborators</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}