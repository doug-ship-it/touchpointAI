import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { PlusCircle, CheckCircle, Building2, MapPin, Award, Briefcase, Mail, ExternalLink, Send } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { User } from '@/api/entities';
import SubscriptionLockModal from './SubscriptionLockModal';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const SaveToShortlistButton = ({ onClick, isAdded, isFirstContact }) => {
  const [isPulsing, setIsPulsing] = useState(isFirstContact);

  useEffect(() => {
    if (isFirstContact) {
      const timer = setTimeout(() => setIsPulsing(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [isFirstContact]);

  return (
    <div className="relative group">
      <motion.button
        className={`
          relative w-12 h-12 rounded-2xl shadow-lg transition-all duration-300 flex items-center justify-center flex-shrink-0
          ${isAdded 
            ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-white shadow-emerald-200' 
            : 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:from-blue-600 hover:to-indigo-700 shadow-blue-200'
          }
          ${isPulsing ? 'animate-pulse-glow' : ''}
        `}
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.95 }}
        onClick={(e) => {
            e.stopPropagation();
            onClick();
        }}
      >
        <motion.div
          initial={false}
          animate={isAdded ? { rotate: 360 } : { rotate: 0 }}
          transition={{ duration: 0.4 }}
          className="flex items-center justify-center"
        >
          {isAdded ? (
            <CheckCircle className="w-6 h-6" />
          ) : (
            <PlusCircle className="w-6 h-6" />
          )}
        </motion.div>
        
        {isPulsing && !isAdded && (
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-400 to-indigo-500 animate-ping opacity-75" />
        )}
      </motion.button>
      <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 w-max bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 whitespace-nowrap">
        Save to Shortlist
      </div>
    </div>
  );
};

export default function ContactCard({ contact, index, isSelected, onToggleSelection, showShortlistButton = false }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isLockModalOpen, setIsLockModalOpen] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (e) {
        console.warn("User not logged in or failed to fetch user:", e);
      }
    };
    fetchUser();
  }, []);

  const handleGatedAction = (e, action) => {
    e.stopPropagation();
    if (currentUser?.role === 'admin') {
      action();
    } else {
      setIsLockModalOpen(true);
    }
  };

  const isFirstContact = index === 0;

  const getStrengthValue = (strength) => {
    switch(strength?.toLowerCase()) {
      case 'strong': return 3;
      case 'medium': return 2;
      case 'weak': return 1;
      default: return 1;
    }
  };
  const connectionStrengthValue = getStrengthValue(contact.relationship_strength);

  return (
    <>
      <SubscriptionLockModal isOpen={isLockModalOpen} onClose={() => setIsLockModalOpen(false)} />
      <motion.div
        className="bg-white rounded-2xl shadow-lg border border-slate-200/50 p-6 hover:shadow-xl hover:shadow-blue-100/20 transition-all duration-300 group backdrop-blur-sm"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ y: -4 }}
        transition={{ delay: index * 0.05 }}
      >
        {/* Header with Avatar, Contact Info, and Save Button */}
        <div className="flex items-start gap-4 mb-5">
          {/* Modern Avatar */}
          <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0 shadow-lg">
            {contact.connection_name ? contact.connection_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : '??'}
          </div>
          
          {/* Contact Info - Flexible container */}
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-900 text-lg leading-tight break-words mb-1">
              {contact.connection_name || 'Unknown Contact'}
            </h3>
            <p className="text-sm text-slate-600 leading-tight break-words">
              {contact.connection_title || 'No position'}
            </p>
          </div>
          
          {/* Save to Shortlist Button */}
          {showShortlistButton && (
             <SaveToShortlistButton 
                onClick={onToggleSelection}
                isAdded={isSelected}
                isFirstContact={isFirstContact}
              />
          )}
        </div>

        {/* Company and Location Details */}
        <div className="space-y-3 mb-5">
          <div className="flex items-center text-sm text-slate-600">
            <Building2 className="w-4 h-4 mr-3 text-slate-400 flex-shrink-0" />
            <span className="break-words font-medium">{contact.connection_company || 'No company'}</span>
          </div>
          <div className="flex items-center text-sm text-slate-600">
            <MapPin className="w-4 h-4 mr-3 text-slate-400 flex-shrink-0" />
            <span className="break-words">{contact.enriched_location || 'No location'}</span>
          </div>
        </div>

        {/* AI Summary */}
        {contact.intelligent_summary && (
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100 text-sm text-blue-900 italic mb-5 break-words">
            <div className="flex items-start gap-2">
              <Award className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
              <span>"{contact.intelligent_summary}"</span>
            </div>
          </div>
        )}

        {/* Connection Strength and Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <div className="flex items-center space-x-3">
            <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Connection:</span>
            <div className="flex space-x-1">
              {[1, 2, 3].map((level) => (
                <div
                  key={level}
                  className={`w-3 h-3 rounded-full transition-all duration-200 ${
                    level <= connectionStrengthValue
                      ? 'bg-gradient-to-r from-emerald-400 to-green-500 shadow-sm'
                      : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            {contact.connection_email && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="w-9 h-9 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition-all duration-200" 
                onClick={(e) => handleGatedAction(e, () => window.location.href = `mailto:${contact.connection_email}`)}
                title="Send Email"
              >
                <Mail className="w-4 h-4" />
              </Button>
            )}
            {contact.linkedin_url && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="w-9 h-9 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition-all duration-200" 
                onClick={(e) => handleGatedAction(e, () => window.open(contact.linkedin_url, '_blank', 'noopener noreferrer'))}
                title="View LinkedIn"
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </motion.div>
    </>
  );
}