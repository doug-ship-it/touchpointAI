import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Link } from 'lucide-react';

export default function ToolNode({ tool, pillarColor, onClick, isSelected }) {
  const colorVariants = {
    blue: { bg: 'bg-blue-50', border: 'border-blue-300', ring: 'ring-blue-500' },
    green: { bg: 'bg-green-50', border: 'border-green-300', ring: 'ring-green-500' },
    orange: { bg: 'bg-orange-50', border: 'border-orange-300', ring: 'ring-orange-500' },
    purple: { bg: 'bg-purple-50', border: 'border-purple-300', ring: 'ring-purple-500' },
  };
  const colors = colorVariants[pillarColor];

  const handleNodeClick = (e) => {
    // Allow clicking the link icon without triggering the node selection
    if (e.target.closest('.tool-link')) return;
    onClick(tool.id);
  }

  return (
    <motion.div
      onClick={handleNodeClick}
      className={cn(
        'relative w-full h-28 rounded-xl flex flex-col items-center justify-center p-3 text-center cursor-pointer border-2 transition-all duration-300 group',
        colors.bg,
        colors.border,
        isSelected ? `${colors.ring} ring-4 shadow-lg` : 'hover:shadow-md hover:-translate-y-0.5',
      )}
      layout
    >
      <a 
        href={tool.url} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="absolute top-2 right-2 p-1 rounded-full bg-white/50 opacity-0 group-hover:opacity-100 transition-opacity tool-link hover:bg-white"
        title={`Visit ${tool.name}`}
      >
        <Link className="w-3 h-3 text-gray-500"/>
      </a>
      <img
        src={tool.logo}
        alt={`${tool.name} logo`}
        className="w-10 h-10 object-contain mb-2 flex-shrink-0"
        loading="lazy"
        onError={(e) => { e.target.src = 'https://img.icons8.com/fluency-systems-filled/48/layers.png' }}
      />
      <span className="text-xs font-bold leading-tight text-gray-800">{tool.name}</span>
      <p className="text-[10px] text-gray-500 leading-snug mt-1 line-clamp-2">{tool.description}</p>
    </motion.div>
  );
}