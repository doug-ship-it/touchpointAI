
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toolDatabase } from './toolData';
import { X, Zap, CheckCircle2, AlertTriangle, Layers, PlusCircle, Info, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { GTMAnalysisEngine } from './AnalysisEngine';

const stageIcons = {
  'Lead Generation & Prospecting': Layers,
  'Lead Qualification & Scoring': CheckCircle2,
  'Multi-Channel Engagement': Zap,
  'Deal Management & Closing': DollarSign,
};

const ToolNode = ({ toolId, onInfoClick, overlaps = [] }) => {
  const tool = toolDatabase[toolId];
  if (!tool) return null;

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.5 }}
      className="relative flex items-center gap-2 p-2 bg-white border rounded-lg shadow-sm"
    >
      <img src={tool.logo} alt={tool.name} className="w-6 h-6 object-contain flex-shrink-0" />
      <span className="text-sm font-medium text-gray-800 flex-grow">{tool.name}</span>
      {overlaps.length > 0 && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <AlertTriangle className="w-4 h-4 text-orange-500 flex-shrink-0" />
            </TooltipTrigger>
            <TooltipContent>
              <p>Overlaps with: {overlaps.map(o => o.partner).join(', ')}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
      <button onClick={() => onInfoClick(tool)} className="flex-shrink-0">
        <Info className="w-4 h-4 text-gray-400 hover:text-blue-600" />
      </button>
    </motion.div>
  );
};

const RecommendationNode = ({ rec, onAdd }) => {
  const tool = toolDatabase[rec.toolId];
  if (!tool) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 p-2 bg-gray-50 border border-dashed rounded-lg"
    >
      <img src={tool.logo} alt={tool.name} className="w-6 h-6 object-contain" />
      <div className="flex-grow">
        <p className="text-sm font-semibold text-gray-700">{tool.name}</p>
        <p className="text-xs text-gray-500">Fills gap in {rec.capability}</p>
      </div>
      <Button size="sm" variant="ghost" onClick={() => onAdd(rec)} className="h-auto p-1">
        <PlusCircle className="w-5 h-5 text-green-600" />
      </Button>
    </motion.div>
  );
};

const InfoPanel = ({ tool, onAdd, onClose, overlaps = [] }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      className="w-80 flex-shrink-0 p-4 bg-white border-l rounded-r-lg shadow-lg"
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">Tool Details</h3>
        <Button variant="ghost" size="icon" onClick={onClose} className="w-7 h-7">
          <X className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="flex items-center gap-3 mb-4">
        <img src={tool.logo} alt={tool.name} className="w-12 h-12 object-contain" />
        <div>
          <h4 className="font-semibold">{tool.name}</h4>
          <p className="text-sm text-gray-600">{tool.description}</p>
        </div>
      </div>
      
      <div className="space-y-3 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">Category:</span>
          <span className="font-medium capitalize">{tool.category}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Est. Price / License:</span>
          <span className="font-medium">${tool.price}/mo</span>
        </div>
      </div>

      {overlaps.length > 0 && (
          <div className="mt-4">
              <h4 className="font-semibold text-sm mb-2 text-orange-600">Feature Overlap Detected:</h4>
              <ul className="space-y-1 text-xs">
                  {overlaps.map(overlap => (
                      <li key={overlap.partner}>
                          vs. <strong>{overlap.partner}</strong>: {overlap.features.join(', ')}
                      </li>
                  ))}
              </ul>
          </div>
      )}
      
      {onAdd && (
        <Button onClick={onAdd} className="w-full mt-6 bg-green-600 hover:bg-green-700">
          <PlusCircle className="w-4 h-4 mr-2" /> Add to Workflow
        </Button>
      )}
    </motion.div>
  );
};


export default function InteractiveWorkflow({ initialAnalysis }) {
  const [analysis, setAnalysis] = useState(initialAnalysis);
  const [selectedInfo, setSelectedInfo] = useState(null); // { type: 'tool' | 'rec', data: tool | rec }
  const analysisEngine = useMemo(() => new GTMAnalysisEngine(), []);

  const handleAddRecommendation = (rec) => {
    const newToolId = rec.toolId;

    // Add tool to selected tools
    const newSelectedTools = new Set(analysis.selectedTools);
    newSelectedTools.add(newToolId);

    // Re-run analysis engine with new toolset
    const newAnalysis = analysisEngine.analyzeStack(newSelectedTools);
    
    setAnalysis(newAnalysis);
    setSelectedInfo({ type: 'tool', data: toolDatabase[newToolId] });
  };
  
  const handleShowInfo = (tool) => {
    setSelectedInfo({ type: 'tool', data: tool });
  };

  const handleShowRecInfo = (rec) => {
    setSelectedInfo({ type: 'rec', data: rec });
  };

  const renderInfoPanel = () => {
    if (!selectedInfo) return null;

    if (selectedInfo.type === 'tool') {
        const toolId = selectedInfo.data.id;
        const overlapData = analysis.overlapAnalysis[toolId] || [];
        return <InfoPanel tool={selectedInfo.data} onClose={() => setSelectedInfo(null)} overlaps={overlapData} />;
    }

    if (selectedInfo.type === 'rec') {
      const rec = selectedInfo.data;
      const tool = toolDatabase[rec.toolId];
      return <InfoPanel tool={tool} onAdd={() => handleAddRecommendation(rec)} onClose={() => setSelectedInfo(null)} />;
    }

    return null;
  };

  return (
    <div className="flex gap-6 items-start">
      <div className="flex-grow">
        <h2 className="text-xl font-bold mb-2">Your Lead-to-Revenue Workflow</h2>
        <p className="text-gray-600 mb-6">This is how your selected tools map to a typical sales process. Click on recommendations to see how they can fill gaps and enhance your workflow.</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {analysis.workflowCoverage.map((stage, index) => {
            const Icon = stageIcons[stage.stage] || Layers;
            const stageTools = analysis.workflow.stages.find(s => s.name === stage.stage)?.tools || [];
            const stageRecs = analysis.recommendations.filter(r => r.stage === stage.stage && r.reason === 'fills_gap');

            return (
              <Card key={stage.stage} className="bg-gray-50/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                    <h3 className="font-semibold text-gray-900">{stage.stage}</h3>
                  </div>
                  
                  <div className="space-y-2">
                    {stageTools.map(toolId => (
                      <ToolNode 
                        key={toolId} 
                        toolId={toolId} 
                        onInfoClick={handleShowInfo}
                        overlaps={analysis.overlapAnalysis[toolId]}
                      />
                    ))}
                    {stageRecs.slice(0, 2).map(rec => (
                      <RecommendationNode 
                        key={rec.toolId}
                        rec={rec}
                        onAdd={handleAddRecommendation}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
      
      <AnimatePresence>
        {renderInfoPanel()}
      </AnimatePresence>
    </div>
  );
}
