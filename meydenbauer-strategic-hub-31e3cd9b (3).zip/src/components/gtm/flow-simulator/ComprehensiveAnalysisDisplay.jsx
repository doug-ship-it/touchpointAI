
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Zap,
  BarChart3,
  Target,
  Clock,
  Settings,
  ArrowRight,
  Download,
  Calendar,
  X,
  Share2,
  Copy,
  FileText,
  Mail
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { toolDatabase } from './toolData';
import { generateTechAnalysisPdf } from '@/api/functions';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function ComprehensiveAnalysisDisplay({ analysis, onClose }) {
  const [selectedRecommendation, setSelectedRecommendation] = useState(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      // Safely access properties and provide fallbacks
      const executiveSummary = `Comprehensive analysis of your ${analysis.selectedTools.length} selected tools reveals ${analysis.gaps.length} improvement opportunities with potential ROI of ${analysis.roiProjections.roiPercentage || 0}%.`;
      
      const potentialAnnualSavings = analysis.roiProjections.totalAnnualBenefit - analysis.roiProjections.totalImplementationCost;
      
      const detailedConsolidationPlan = `Based on your current stack analysis, we recommend focusing on ${analysis.gaps.slice(0, 3).map(g => g.category).join(', ')} to maximize ROI and operational efficiency.`;

      const analysisData = {
        executive_summary: executiveSummary,
        current_stack_cost: {
          total_annual_cost: analysis.costAnalysis.totalAnnualCost || 0,
          cost_breakdown: analysis.costAnalysis.costBreakdown.map(item => ({
            tool: toolDatabase[item.tool]?.name || item.tool,
            license_tier: item.tier || 'N/A',
            licenses_needed: item.seats || 0,
            cost_per_license: item.monthly || 0,
            annual_cost: item.annual || 0,
            key_features: toolDatabase[item.tool]?.description ? [toolDatabase[item.tool].description] : []
          }))
        },
        financial_impact: {
          potential_annual_savings: Math.max(0, potentialAnnualSavings || 0),
          roi_percentage: analysis.roiProjections.roiPercentage || 0,
          payback_period_months: analysis.roiProjections.paybackMonths || 0
        },
        detailed_consolidation_plan: detailedConsolidationPlan,
        overlap_analysis: analysis.overlapAnalysis ? Object.entries(analysis.overlapAnalysis).flatMap(([toolId, overlaps]) => 
          overlaps.map(overlap => ({
            overlapping_tools: [toolDatabase[toolId]?.name || toolId, toolDatabase[overlap.partner]?.name || overlap.partner],
            conflicting_features: overlap.features || [],
            recommendation: `Consider consolidating these overlapping features to reduce complexity and cost.`,
            consolidation_savings: overlap.features.length * 1000 // Placeholder logic, adjust as needed
          }))
        ) : []
      };

      const response = await generateTechAnalysisPdf({ analysisData });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `GTM-Stack-Analysis-${new Date().toISOString().split('T')[0]}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Analysis report downloaded successfully!');
      } else {
        throw new Error('Failed to generate PDF');
      }
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download report. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShareAnalysis = async (method) => {
    const shareData = {
      title: 'GTM Stack Analysis Results',
      text: `I just completed a comprehensive GTM stack analysis. Here are the key findings: ${analysis.gaps.length} improvement opportunities identified with ${analysis.roiProjections.roiPercentage || 0}% projected ROI.`,
      url: window.location.origin + '/gtm-analysis-results' // Assuming a route exists for public sharing or a generic landing
    };

    try {
      switch (method) {
        case 'native':
          if (navigator.share) {
            await navigator.share(shareData);
            toast.success('Analysis shared successfully!');
          } else {
            throw new Error('Web Share API not supported, falling back to copy.');
          }
          break;
        
        case 'copy':
          await navigator.clipboard.writeText(`${shareData.title}\n\n${shareData.text}\n\n${shareData.url}`);
          toast.success('Analysis details copied to clipboard!');
          break;
        
        case 'email':
          const emailSubject = encodeURIComponent(shareData.title);
          const emailBody = encodeURIComponent(`${shareData.text}\n\nView full analysis: ${shareData.url}`);
          window.open(`mailto:?subject=${emailSubject}&body=${emailBody}`);
          break;
        
        default:
          throw new Error('Unknown share method');
      }
    } catch (error) {
      console.error('Share failed:', error);
      if (error.message.includes('Web Share API not supported') || method === 'native') {
        // Fallback to copy if native share fails or is not supported
        handleShareAnalysis('copy');
      } else {
        toast.error('Failed to share analysis. Please try again.');
      }
    }
  };

  const handleScheduleConsultation = () => {
    window.open('https://calendly.com/dougsandstedt', '_blank'); // Replace with actual Calendly link
    toast.success('Opening consultation booking...');
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'excellent': return 'text-green-600 bg-green-100';
      case 'good': return 'text-blue-600 bg-blue-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-red-600 bg-red-100';
    }
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'High': return 'bg-red-100 text-red-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  const OverviewTab = () => (
    <div className="space-y-6">
      {/* Executive Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Executive Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">
            Your current tech stack of <strong>{analysis.selectedTools.length} tools</strong> shows strong foundational capabilities 
            with <strong>{analysis.gaps.filter(g => g.priority === 'High').length} critical gaps</strong> identified. 
            Our analysis reveals <strong>${(analysis.roiProjections.totalAnnualBenefit || 0).toLocaleString()} in potential annual benefits</strong> 
            with a projected <strong>{analysis.roiProjections.roiPercentage || 0}% ROI</strong> and payback period of 
            <strong> {analysis.roiProjections.paybackMonths || 0} months</strong>.
          </p>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Annual Investment</p>
                <p className="text-xl font-bold">${(analysis.costAnalysis.totalAnnualCost || 0).toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Tools in Stack</p>
                <p className="text-xl font-bold">{analysis.selectedTools.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <AlertTriangle className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Priority Gaps</p>
                <p className="text-xl font-bold">{analysis.gaps.filter(g => g.priority === 'High').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Projected ROI</p>
                <p className="text-xl font-bold">{analysis.roiProjections.roiPercentage || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Workflow Coverage */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Revenue Process Coverage Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analysis.workflowCoverage.map((stage, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-gray-900">{stage.stage}</h4>
                  <Badge className={getStatusColor(stage.status)}>
                    {stage.coverage}% Complete
                  </Badge>
                </div>
                <div className="mb-2">
                  <Progress value={stage.coverage} className="h-2" />
                </div>
                <div className="text-sm text-gray-600">
                  Coverage: {stage.capabilities.filter(c => c.covered).length} of {stage.capabilities.length} capabilities
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Recommendations Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            High-Impact Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.recommendations.slice(0, 4).map((rec, index) => {
              const tool = toolDatabase[rec.toolId];
              return (
                <div key={index} className="border rounded-xl p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-3 mb-2">
                    <img src={tool.logo} alt={tool.name} className="w-8 h-8 object-contain" />
                    <div className="flex-1">
                      <h4 className="font-semibold">{tool.name}</h4>
                      <p className="text-xs text-gray-500">{rec.category || 'Enhancement'}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{rec.gapAddress || tool.description}</p>
                  <div className="flex justify-between items-center">
                    <Badge className={getPriorityColor('High')}>
                      Impact: {rec.impact || 0}%
                    </Badge>
                    <span className="text-sm font-medium text-green-600">
                      ${rec.pricing?.monthly || 'TBD'}/mo
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const CostAnalysisTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Current Stack Investment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-blue-600">${analysis.costAnalysis.totalMonthlyCost}</p>
              <p className="text-gray-500">Monthly Cost</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-green-600">${analysis.costAnalysis.totalAnnualCost}</p>
              <p className="text-gray-500">Annual Cost</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-purple-600">${Math.round(analysis.costAnalysis.costPerEmployee)}</p>
              <p className="text-gray-500">Per Employee/Month</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cost Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Tool-by-Tool Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analysis.costAnalysis.costBreakdown.map((item, index) => {
              const tool = toolDatabase[item.tool];
              return (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <img src={tool.logo} alt={tool.name} className="w-8 h-8 object-contain" />
                    <div>
                      <p className="font-semibold">{tool.name}</p>
                      <p className="text-sm text-gray-500">{item.tier} Plan</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">${item.monthly}/month</p>
                    <p className="text-sm text-gray-500">${item.annual}/year</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Industry Benchmark */}
      <Card>
        <CardHeader>
          <CardTitle>Industry Benchmark</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <p className="mb-2">Your spend vs. industry average:</p>
              <div className="bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-blue-600 h-3 rounded-full"
                  style={{ width: `${Math.min((analysis.costAnalysis.costPerEmployee / 300) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
            <Badge className={
              analysis.costAnalysis.industryBenchmark.status === 'below_average' ? 'bg-green-100 text-green-800' :
              analysis.costAnalysis.industryBenchmark.status === 'average' ? 'bg-blue-100 text-blue-800' :
              'bg-orange-100 text-orange-800'
            }>
              {analysis.costAnalysis.industryBenchmark.status.replace('_', ' ')}
            </Badge>
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Industry range: {analysis.costAnalysis.industryBenchmark.range}
          </p>
        </CardContent>
      </Card>
    </div>
  );

  const GapsAndRecommendationsTab = () => (
    <div className="space-y-6">
      {/* Critical Gaps */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Identified Capability Gaps
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analysis.gaps.map((gap, index) => (
              <div key={index} className="border-l-4 border-orange-400 pl-4 py-2">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-900">{gap.category}</h4>
                  <Badge className={getPriorityColor(gap.priority)}>
                    {gap.priority} Priority
                  </Badge>
                </div>
                <p className="text-gray-600 mb-2">{gap.description}</p>
                <p className="text-sm text-green-600 font-medium">{gap.roiImpact}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Intelligent Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-600" />
            Smart Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.recommendations.map((rec, index) => {
              const tool = toolDatabase[rec.toolId];
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer"
                  onClick={() => setSelectedRecommendation(rec)}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <img src={tool.logo} alt={tool.name} className="w-10 h-10 object-contain" />
                    <div className="flex-1">
                      <h4 className="font-semibold">{tool.name}</h4>
                      <Badge className="bg-blue-100 text-blue-800 text-xs">
                        {rec.implementationComplexity}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">${rec.pricing.monthly}/mo</p>
                      <p className="text-xs text-gray-500">${rec.pricing.annual}/yr</p>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-3">{rec.gapAddress}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">Impact Score:</span>
                      <span className="font-semibold">{rec.impact}/100</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">Payback Period:</span>
                      <span className="font-semibold">{rec.paybackPeriod}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">ROI Impact:</span>
                      <span className="font-semibold text-green-600">{rec.roiImpact}</span>
                    </div>
                  </div>
                  
                  {rec.integrations.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <p className="text-xs text-gray-500 mb-1">Integrates with:</p>
                      <div className="flex flex-wrap gap-1">
                        {rec.integrations.slice(0, 3).map(int => (
                          <Badge key={int} variant="outline" className="text-xs">
                            {toolDatabase[int]?.name || int}
                          </Badge>
                        ))}
                        {rec.integrations.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{rec.integrations.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const WorkflowOptimizationTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-purple-600" />
            Available Workflow Optimizations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {analysis.workflowOptimizations.map((opt, index) => (
              <div key={index} className="border rounded-xl p-6 bg-gradient-to-r from-purple-50 to-blue-50">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900 mb-2">{opt.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</h4>
                    <p className="text-gray-600">{opt.description}</p>
                  </div>
                  <Badge className={opt.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                    {opt.status}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <Clock className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                    <p className="font-semibold">{opt.time_saved}</p>
                    <p className="text-xs text-gray-500">Time Saved Daily</p>
                  </div>
                  <div className="text-center">
                    <DollarSign className="w-6 h-6 text-green-600 mx-auto mb-1" />
                    <p className="font-semibold">{opt.cost_benefit}</p>
                    <p className="text-xs text-gray-500">Monthly Benefit</p>
                  </div>
                  <div className="text-center">
                    <Settings className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                    <p className="font-semibold">{opt.setup_complexity}</p>
                    <p className="text-xs text-gray-500">Setup Complexity</p>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  <span className="text-sm text-gray-500">Required tools:</span>
                  {opt.tools.map(toolId => {
                    const tool = toolDatabase[toolId];
                    return (
                      <Badge key={toolId} variant={analysis.selectedTools.includes(toolId) ? "default" : "outline"}>
                        {tool?.name || toolId}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const ROIProjectionsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">{analysis.roiProjections.roiPercentage}%</p>
            <p className="text-sm text-gray-500">Projected ROI</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">{analysis.roiProjections.paybackMonths}</p>
            <p className="text-sm text-gray-500">Payback Months</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <DollarSign className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">${analysis.roiProjections.totalAnnualBenefit.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Annual Benefit</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="w-8 h-8 text-orange-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">{analysis.roiProjections.totalProductivityGains}%</p>
            <p className="text-sm text-gray-500">Productivity Gain</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Investment vs. Return Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 px-4 bg-red-50 rounded-lg">
              <span className="font-medium">Implementation Cost</span>
              <span className="text-xl font-bold text-red-600">-${analysis.roiProjections.totalImplementationCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center py-3 px-4 bg-green-50 rounded-lg">
              <span className="font-medium">Annual Benefit</span>
              <span className="text-xl font-bold text-green-600">+${analysis.roiProjections.totalAnnualBenefit.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center py-3 px-4 bg-blue-50 rounded-lg border-2 border-blue-200">
              <span className="font-bold">Net Annual Return</span>
              <span className="text-xl font-bold text-blue-600">
                +${(analysis.roiProjections.totalAnnualBenefit - analysis.roiProjections.totalImplementationCost).toLocaleString()}
              </span>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="font-medium">Confidence Score: {analysis.roiProjections.confidenceScore}%</span>
            </div>
            <p className="text-sm text-gray-600">
              Based on industry benchmarks and similar company implementations
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header with Close Button */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">GTM Stack Analysis Complete</h1>
          <p className="text-gray-600">
            Comprehensive analysis of your {analysis.selectedTools.length} selected tools with intelligent recommendations
          </p>
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={onClose}
          className="h-10 w-10 hover:bg-gray-100"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Enhanced Action Bar */}
      <div className="flex flex-wrap gap-4 mb-8 p-4 bg-gray-50 rounded-lg">
        <Button 
          onClick={handleDownloadPDF}
          disabled={isDownloading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {isDownloading ? (
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
          ) : (
            <Download className="w-4 h-4 mr-2" />
          )}
          {isDownloading ? 'Generating...' : 'Export Report (PDF)'}
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              Share Analysis
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => handleShareAnalysis('native')}>
              <Share2 className="w-4 h-4 mr-2" />
              Share via System
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShareAnalysis('copy')}>
              <Copy className="w-4 h-4 mr-2" />
              Copy to Clipboard
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShareAnalysis('email')}>
              <Mail className="w-4 h-4 mr-2" />
              Share via Email
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Button variant="outline" onClick={handleScheduleConsultation}>
          <Calendar className="w-4 h-4 mr-2" />
          Schedule Consultation
        </Button>
      </div>

      {/* Main Analysis Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="costs">Cost Analysis</TabsTrigger>
          <TabsTrigger value="gaps">Gaps & Recs</TabsTrigger>
          <TabsTrigger value="workflow">Workflow Opts</TabsTrigger>
          <TabsTrigger value="roi">ROI Projections</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="costs">
          <CostAnalysisTab />
        </TabsContent>

        <TabsContent value="gaps">
          <GapsAndRecommendationsTab />
        </TabsContent>

        <TabsContent value="workflow">
          <WorkflowOptimizationTab />
        </TabsContent>

        <TabsContent value="roi">
          <ROIProjectionsTab />
        </TabsContent>
      </Tabs>

      {/* Recommendation Detail Modal */}
      <AnimatePresence>
        {selectedRecommendation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedRecommendation(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal content would go here */}
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">{toolDatabase[selectedRecommendation.toolId].name}</h3>
                <button
                  onClick={() => setSelectedRecommendation(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              <p className="text-gray-600">{selectedRecommendation.gapAddress}</p>
              {/* Add more modal content as needed */}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
