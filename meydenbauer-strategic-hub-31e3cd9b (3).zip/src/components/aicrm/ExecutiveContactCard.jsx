import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Building2, 
  MapPin, 
  TrendingUp, 
  Target, 
  Clock, 
  Star,
  Linkedin,
  Mail,
  ExternalLink,
  Brain
} from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function ExecutiveContactCard({ contact, onSelect }) {
  const getInfluenceColor = (score) => {
    if (score >= 8) return 'text-red-500 bg-red-50';
    if (score >= 6) return 'text-yellow-500 bg-yellow-50';
    return 'text-green-500 bg-green-50';
  };

  const getAccessibilityColor = (score) => {
    if (score >= 8) return 'text-green-500';
    if (score >= 6) return 'text-yellow-500';
    return 'text-red-500';
  };

  const formatCurrency = (amount) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    }
    if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toFixed(0)}`;
  };

  const handleLinkedInClick = () => {
    if (contact.linkedin_url) {
      // Ensure URL has proper protocol
      let url = contact.linkedin_url;
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
      }
      window.open(url, '_blank', 'noopener,noreferrer');
      toast.success(`Opening ${contact.name}'s LinkedIn profile`);
    } else {
      toast.error('No LinkedIn profile available for this contact');
    }
  };

  const handleEmailClick = () => {
    if (contact.email) {
      const subject = encodeURIComponent(`Following up from our network connection`);
      const body = encodeURIComponent(`Hi ${contact.first_name || contact.name.split(' ')[0]},

I hope this message finds you well. I wanted to reach out and reconnect.

Best regards`);
      
      const mailtoLink = `mailto:${contact.email}?subject=${subject}&body=${body}`;
      window.location.href = mailtoLink;
      toast.success(`Opening email to ${contact.name}`);
    } else {
      toast.error('No email address available for this contact');
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <Card className="bg-gradient-to-br from-white to-gray-50 border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              <Avatar className="h-12 w-12 border-2 border-gray-200">
                <AvatarImage 
                  src={contact.profile_picture_url} 
                  alt={contact.name}
                />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold">
                  {contact.name?.split(' ').map(n => n[0]).join('').toUpperCase() || '??'}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 
                    className="text-lg font-bold text-gray-900 truncate cursor-pointer hover:text-blue-600 transition-colors"
                    onClick={() => onSelect(contact)}
                  >
                    {contact.name || 'Unknown Contact'}
                  </h3>
                  {contact.starred && (
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  )}
                </div>
                
                <p className="text-sm text-gray-600 truncate mb-1">
                  {contact.job_title || 'No title specified'}
                </p>
                
                <div className="flex items-center gap-1 text-xs text-blue-600">
                  <Building2 className="w-3 h-3" />
                  <span className="truncate">{contact.company || 'Unknown Company'}</span>
                </div>
              </div>
            </div>
            
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getInfluenceColor(contact.influence_score)}`}>
              {contact.influence_score}/10
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0 space-y-4">
          {/* Contact Actions - LinkedIn and Email */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleLinkedInClick}
              disabled={!contact.linkedin_url}
              className="flex items-center gap-1 text-xs h-8 flex-1 bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Linkedin className="w-3 h-3" />
              LinkedIn
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleEmailClick}
              disabled={!contact.email}
              className="flex items-center gap-1 text-xs h-8 flex-1 bg-green-50 hover:bg-green-100 border-green-200 text-green-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Mail className="w-3 h-3" />
              Email
            </Button>
          </div>

          {/* Executive Intelligence Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1 mb-1">
                <Target className="w-3 h-3 text-purple-500" />
                <span className="text-xs font-medium text-gray-600">Deal Potential</span>
              </div>
              <div className="text-sm font-bold text-gray-900">
                {formatCurrency(contact.deal_potential)}
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1 mb-1">
                <TrendingUp className={`w-3 h-3 ${getAccessibilityColor(contact.accessibility_score)}`} />
                <span className="text-xs font-medium text-gray-600">Accessibility</span>
              </div>
              <div className={`text-sm font-bold ${getAccessibilityColor(contact.accessibility_score)}`}>
                {contact.accessibility_score}/10
              </div>
            </div>
          </div>

          {/* Location & AI Summary */}
          <div className="space-y-2">
            {contact.location && (
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <MapPin className="w-3 h-3" />
                <span className="truncate">{contact.location}</span>
              </div>
            )}
            
            {contact.notes && (
              <div className="bg-blue-50 rounded-lg p-2 border border-blue-100">
                <div className="flex items-center gap-1 mb-1">
                  <Brain className="w-3 h-3 text-blue-500" />
                  <span className="text-xs font-medium text-blue-700">AI Intelligence</span>
                </div>
                <p className="text-xs text-blue-800 line-clamp-2 leading-relaxed">
                  {contact.notes.length > 100 ? `${contact.notes.substring(0, 100)}...` : contact.notes}
                </p>
              </div>
            )}
          </div>

          {/* Status Badges */}
          <div className="flex gap-1 flex-wrap">
            <Badge variant="secondary" className="text-xs px-2 py-0.5">
              {contact.enriched_seniority || 'Entry Level'}
            </Badge>
            
            {contact.relationship_strength && (
              <Badge 
                variant="outline" 
                className={`text-xs px-2 py-0.5 ${
                  contact.relationship_strength === 'strong' ? 'border-green-500 text-green-700' :
                  contact.relationship_strength === 'medium' ? 'border-yellow-500 text-yellow-700' :
                  'border-gray-500 text-gray-700'
                }`}
              >
                {contact.relationship_strength} connection
              </Badge>
            )}
            
            {contact.job_change_probability > 50 && (
              <Badge variant="destructive" className="text-xs px-2 py-0.5">
                Job Change Risk
              </Badge>
            )}
          </div>

          {/* Next Action Suggestion */}
          {contact.next_best_action && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-yellow-600" />
                <span className="text-xs font-medium text-yellow-800">Suggested Action:</span>
              </div>
              <p className="text-xs text-yellow-700 mt-1">{contact.next_best_action}</p>
            </div>
          )}

          {/* View Full Profile Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onSelect(contact)}
            className="w-full text-xs h-8 text-gray-600 hover:text-gray-900 hover:bg-gray-100"
          >
            <ExternalLink className="w-3 h-3 mr-1" />
            View Executive Intelligence Profile
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}