
import React from 'react';
import { format } from 'date-fns';
import { Mail, Phone, Users, MessageSquare, Linkedin, Handshake, MoreHorizontal } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const interactionIcons = {
  email: Mail,
  call: Phone,
  meeting: Users,
  text: MessageSquare,
  linkedin: Linkedin,
  in_person: Handshake,
  other: MoreHorizontal,
};

export default function InteractionItem({ interaction }) {
  const Icon = interactionIcons[interaction.interaction_type] || MoreHorizontal;
  
  return (
    <div className="flex items-start gap-4 relative z-10">
      <div className="flex flex-col items-center">
        <div className="bg-light-gray p-2 rounded-full">
          <Icon className="h-5 w-5 text-neutral-gray" />
        </div>
      </div>
      <div className="pb-8 flex-1">
        <p className="text-sm text-neutral-gray">
          {format(new Date(interaction.interaction_date), 'MMMM d, yyyy')}
        </p>
        <Card className="mt-1">
          <CardContent className="p-3">
             <p className="text-sm text-dark-gray">{interaction.notes}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
