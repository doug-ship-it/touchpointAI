import React, { useState, useEffect, useCallback } from 'react';
import { Search, Brain, Zap, Filter, Users, Building2, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';

export default function EnhancedContactSearch({ contacts, onSearchResults, onFilterChange }) {
  const [query, setQuery] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeFilters, setActiveFilters] = useState([]);

  // Smart search suggestions based on contact data patterns
  const generateSmartSuggestions = useCallback((searchQuery, contactData) => {
    const suggestions = [];
    
    if (searchQuery.length < 3) return suggestions;
    
    const query = searchQuery.toLowerCase();
    
    // Analyze contact patterns
    const industries = [...new Set(contactData.map(c => c.enriched_industry || c.mappedIndustry).filter(Boolean))];
    const seniorities = [...new Set(contactData.map(c => c.enriched_seniority || c.mappedSeniority).filter(Boolean))];
    const companies = [...new Set(contactData.map(c => c.connection_company).filter(Boolean))];
    
    // Generate contextual suggestions
    if (query.includes('tech') || query.includes('technology')) {
      const techContacts = contactData.filter(c => 
        (c.enriched_industry && c.enriched_industry.toLowerCase().includes('tech')) ||
        (c.mappedIndustry && c.mappedIndustry.toLowerCase().includes('tech'))
      );
      suggestions.push({
        type: 'industry',
        description: `Technology professionals`,
        count: techContacts.length,
        filter: { industry: 'Technology' }
      });
    }
    
    if (query.includes('ceo') || query.includes('founder') || query.includes('executive')) {
      const executives = contactData.filter(c => 
        (c.enriched_seniority && (c.enriched_seniority.includes('CXO') || c.enriched_seniority.includes('Owner'))) ||
        (c.connection_title && (c.connection_title.toLowerCase().includes('ceo') || c.connection_title.toLowerCase().includes('founder')))
      );
      suggestions.push({
        type: 'seniority',
        description: `C-level executives and founders`,
        count: executives.length,
        filter: { seniority: 'CXO' }
      });
    }
    
    if (query.includes('recent') || query.includes('new')) {
      const recentContacts = contactData.filter(c => {
        const createdDate = new Date(c.created_date);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return createdDate > thirtyDaysAgo;
      });
      suggestions.push({
        type: 'temporal',
        description: `Recently added contacts (last 30 days)`,
        count: recentContacts.length,
        filter: { recent: true }
      });
    }
    
    // Company-specific suggestions
    const matchingCompanies = companies.filter(company => 
      company.toLowerCase().includes(query)
    ).slice(0, 3);
    
    matchingCompanies.forEach(company => {
      const companyContacts = contactData.filter(c => c.connection_company === company);
      suggestions.push({
        type: 'company',
        description: `Contacts at ${company}`,
        count: companyContacts.length,
        filter: { company }
      });
    });
    
    return suggestions.slice(0, 5); // Limit to 5 suggestions
  }, []);

  const handleAISearch = useCallback(async (searchQuery) => {
    if (searchQuery.length < 3) {
      setAiSuggestions([]);
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Generate smart suggestions based on existing contact data
      const smartSuggestions = generateSmartSuggestions(searchQuery, contacts);
      setAiSuggestions(smartSuggestions);
      
      // For more complex queries, use AI analysis
      if (searchQuery.length > 10 && (
        searchQuery.includes('who') || 
        searchQuery.includes('find') || 
        searchQuery.includes('show me') ||
        searchQuery.includes('prospects')
      )) {
        try {
          const aiResponse = await InvokeLLM({
            prompt: `Analyze this contact search query and provide structured search criteria: "${searchQuery}". 
            
            Available contact fields: name, company, title, industry, seniority, location, relationship_strength.
            
            Return a JSON object with suggested filters and a human-readable description.`,
            response_json_schema: {
              type: "object",
              properties: {
                description: { type: "string" },
                filters: {
                  type: "object",
                  properties: {
                    industry: { type: "string" },
                    seniority: { type: "string" },
                    company_contains: { type: "string" },
                    title_contains: { type: "string" }
                  }
                },
                confidence: { type: "number" }
              }
            }
          });
          
          if (aiResponse.confidence > 0.7) {
            const matchingContacts = contacts.filter(contact => {
              return Object.entries(aiResponse.filters).every(([key, value]) => {
                if (!value) return true;
                
                switch (key) {
                  case 'industry':
                    return (contact.enriched_industry || contact.mappedIndustry || '').toLowerCase().includes(value.toLowerCase());
                  case 'seniority':
                    return (contact.enriched_seniority || contact.mappedSeniority || '').toLowerCase().includes(value.toLowerCase());
                  case 'company_contains':
                    return (contact.connection_company || '').toLowerCase().includes(value.toLowerCase());
                  case 'title_contains':
                    return (contact.connection_title || '').toLowerCase().includes(value.toLowerCase());
                  default:
                    return true;
                }
              });
            });
            
            setAiSuggestions(prev => [
              {
                type: 'ai',
                description: aiResponse.description,
                count: matchingContacts.length,
                filter: aiResponse.filters,
                isAI: true
              },
              ...prev
            ]);
          }
        } catch (aiError) {
          console.warn('AI search analysis failed, using smart suggestions only:', aiError);
        }
      }
      
    } catch (error) {
      console.error('Search suggestion generation failed:', error);
    } finally {
      setIsLoading(false);
    }
  }, [contacts, generateSmartSuggestions]);

  const executeAISearch = (suggestion) => {
    // Add to active filters
    const newFilter = {
      id: Date.now(),
      ...suggestion
    };
    
    setActiveFilters(prev => [...prev, newFilter]);
    
    // Apply the filter
    onFilterChange(suggestion.filter);
    
    // Clear suggestions
    setAiSuggestions([]);
    setQuery('');
  };

  const removeFilter = (filterId) => {
    setActiveFilters(prev => prev.filter(f => f.id !== filterId));
    // Reset to show all contacts when no filters
    if (activeFilters.length === 1) {
      onFilterChange({});
    }
  };

  const getSuggestionIcon = (type) => {
    switch (type) {
      case 'industry': return <Building2 className="w-4 h-4" />;
      case 'seniority': return <TrendingUp className="w-4 h-4" />;
      case 'company': return <Building2 className="w-4 h-4" />;
      case 'temporal': return <Users className="w-4 h-4" />;
      case 'ai': return <Brain className="w-4 h-4" />;
      default: return <Search className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="p-6">
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                handleAISearch(e.target.value);
              }}
              placeholder="Search contacts or ask AI: 'Show me prospects from tech companies' or 'Find C-level executives'"
              className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
              {isLoading && (
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent" />
              )}
              <Brain className="w-5 h-5 text-blue-500" />
            </div>
          </div>
        </div>
        
        {/* Active Filters */}
        <AnimatePresence>
          {activeFilters.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 flex flex-wrap gap-2"
            >
              {activeFilters.map((filter) => (
                <Badge
                  key={filter.id}
                  variant="secondary"
                  className="flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800"
                >
                  {getSuggestionIcon(filter.type)}
                  <span>{filter.description}</span>
                  <button
                    onClick={() => removeFilter(filter.id)}
                    className="ml-1 hover:bg-blue-200 rounded-full p-0.5"
                  >
                    <Filter className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* AI Search Suggestions */}
        <AnimatePresence>
          {aiSuggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mt-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-200"
            >
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-blue-600" />
                <p className="text-sm font-medium text-blue-800">AI-Powered Search Suggestions</p>
              </div>
              <div className="space-y-2">
                {aiSuggestions.map((suggestion, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => executeAISearch(suggestion)}
                    className="flex items-center justify-between w-full text-left p-3 text-sm bg-white hover:bg-blue-50 border border-blue-200 hover:border-blue-300 rounded-lg transition-all duration-200 group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-blue-600">
                        {getSuggestionIcon(suggestion.type)}
                      </div>
                      <span className="text-gray-700 group-hover:text-blue-800">
                        {suggestion.description}
                      </span>
                      {suggestion.isAI && (
                        <Badge variant="outline" className="text-xs bg-purple-100 text-purple-700 border-purple-300">
                          AI
                        </Badge>
                      )}
                    </div>
                    <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                      {suggestion.count} contacts
                    </Badge>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}