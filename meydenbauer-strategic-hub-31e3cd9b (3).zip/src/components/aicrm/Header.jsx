import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, ArrowLeft } from 'lucide-react';

export default function Header({ title, onBack }) {
  return (
    <header className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
      <div className="flex items-center gap-4">
        {onBack && (
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}
        <h1 className="text-xl font-bold text-dark-gray">{title}</h1>
      </div>
      <div>
        {!onBack && (
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Contact
          </Button>
        )}
      </div>
    </header>
  );
}