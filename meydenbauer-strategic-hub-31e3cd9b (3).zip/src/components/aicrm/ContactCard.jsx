import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Clock, MessageSquare, Star } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ContactCard({ contact }) {
  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <Avatar>
            <AvatarImage src={contact.profile_picture_url} alt={contact.name} />
            <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-dark-gray">{contact.name}</h3>
                <p className="text-sm text-neutral-gray">{contact.job_title} at {contact.company}</p>
              </div>
              {contact.starred && <Star className="h-4 w-4 text-yellow-400 fill-current" />}
            </div>
            <div className="mt-3 space-y-2 text-xs text-neutral-gray">
              {contact.last_interaction_date && (
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-3 w-3" />
                  <span>Last touch: {formatDistanceToNow(new Date(contact.last_interaction_date), { addSuffix: true })}</span>
                </div>
              )}
              {contact.next_reminder_date && (
                <div className="flex items-center gap-2">
                  <Clock className="h-3 w-3" />
                  <span>Next reminder: {formatDistanceToNow(new Date(contact.next_reminder_date), { addSuffix: true })}</span>
                </div>
              )}
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {contact.tags?.map(tag => (
                <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}