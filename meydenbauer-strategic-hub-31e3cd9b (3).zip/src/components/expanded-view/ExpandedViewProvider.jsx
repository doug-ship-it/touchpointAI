import React, { createContext, useContext, useState } from 'react';

const ExpandedViewContext = createContext();

export const useExpandedView = () => {
  const context = useContext(ExpandedViewContext);
  if (!context) {
    throw new Error('useExpandedView must be used within an ExpandedViewProvider');
  }
  return context;
};

export const ExpandedViewProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [content, setContent] = useState(null);
  const [title, setTitle] = useState('');

  const openExpandedView = (url, viewTitle = '') => {
    setContent(url);
    setTitle(viewTitle);
    setIsOpen(true);
  };

  const closeExpandedView = () => {
    setIsOpen(false);
    setContent(null);
    setTitle('');
  };

  return (
    <ExpandedViewContext.Provider value={{
      isOpen,
      content,
      title,
      openExpandedView,
      closeExpandedView
    }}>
      {children}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-[80vw] h-[80vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold">{title}</h2>
              <button 
                onClick={closeExpandedView}
                className="text-gray-500 hover:text-gray-700 text-2xl leading-none p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe 
                src={content} 
                className="w-full h-full border-0"
                title={title}
              />
            </div>
          </div>
        </div>
      )}
    </ExpandedViewContext.Provider>
  );
};