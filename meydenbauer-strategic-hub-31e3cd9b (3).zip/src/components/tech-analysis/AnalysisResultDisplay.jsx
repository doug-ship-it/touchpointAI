
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DollarSign,
  TrendingUp,
  Clock,
  Layers,
  FileText,
  Lightbulb,
  CheckCircle,
  Download,
  Shield,
  Briefcase,
  GitMerge,
  BarChart3,
  Book,
  Link as LinkIcon,
  Loader2,
  Check,
  List
} from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { generateTechAnalysisPdf } from '@/api/functions';
import { toast } from 'sonner';

const formatCurrency = (value) => {
  if (typeof value !== 'number' || isNaN(value)) return '$ -'; // Handle NaN or non-numeric values
  return value.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
};

const Section = ({ icon: Icon, title, children, badge }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-3">
        {Icon && <Icon className="w-6 h-6 text-indigo-600" />}
        {title}
      </h2>
      {badge}
    </div>
    <div>
      {children}
    </div>
  </div>
);

const MetricCard = ({ icon: Icon, label, value, subValue, confidence }) => (
  <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm flex items-start gap-4">
    <div className="p-2 bg-indigo-100 rounded-lg">
      <Icon className="w-6 h-6 text-indigo-600" />
    </div>
    <div>
      <p className="text-sm text-gray-500">{label}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      {subValue && <p className="text-xs text-gray-500">{subValue}</p>}
      {confidence && (
          <div className="flex items-center text-xs text-gray-500 mt-1">
            <Shield className="w-3 h-3 mr-1 text-green-600" />
            <span>{confidence}% confidence</span>
          </div>
      )}
    </div>
  </div>
);

export default function AnalysisResultDisplay({ result }) {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadPdf = async () => {
    setIsDownloading(true);
    toast.info("Generating your detailed PDF report...", { duration: 5000 });
    try {
      const response = await generateTechAnalysisPdf({ analysisData: result });
      
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Tech-Stack-Analysis-Report.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      toast.success("Your PDF report has been downloaded.");
    } catch (error) {
      console.error("PDF download failed:", error);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setIsDownloading(false);
    }
  };

  if (!result) return null;

  return (
    <div className="p-6 space-y-8">
      {/* Header with completion message and PDF Export Button */}
      <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4">
        <h3 className="text-2xl font-bold flex items-center gap-3 text-gray-800">
          <CheckCircle className="w-8 h-8 text-green-600" />
          Tech Stack Analysis Complete
        </h3>
        <Button onClick={handleDownloadPdf} disabled={isDownloading} className="min-w-[200px]">
            {isDownloading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
                <Download className="w-4 h-4 mr-2" />
            )}
            Produce My Detailed Report
        </Button>
      </div>
      
      {/* Executive Summary */}
      {result.executive_summary && (
        <Section icon={FileText} title="Executive Summary">
          <p className="text-gray-600 leading-relaxed">{result.executive_summary}</p>
        </Section>
      )}

      {/* Financial Impact */}
      {(result.financial_impact || result.current_stack_cost) && (
        <Section icon={DollarSign} title="Financial Impact">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {result.current_stack_cost?.total_annual_cost !== undefined && (
              <MetricCard 
                icon={DollarSign}
                label="Current Annual Cost"
                value={formatCurrency(result.current_stack_cost.total_annual_cost)}
              />
            )}
            {result.financial_impact?.potential_annual_savings !== undefined && (
              <MetricCard 
                icon={TrendingUp}
                label="Potential Savings"
                value={formatCurrency(result.financial_impact.potential_annual_savings)}
                subValue={result.financial_impact?.roi_percentage !== undefined ? `${result.financial_impact.roi_percentage}% ROI` : null}
              />
            )}
            {result.financial_impact?.payback_period_months !== undefined && (
              <MetricCard 
                icon={Clock}
                label="Payback Period"
                value={`${result.financial_impact.payback_period_months} months`}
              />
            )}
            {result.financial_impact?.confidence_score !== undefined && (
              <MetricCard
                icon={Shield}
                label="Analysis Confidence"
                value={`${result.financial_impact.confidence_score}%`}
              />
            )}
          </div>
        </Section>
      )}
      
      {/* Current Stack Cost Breakdown */}
      {result.current_stack_cost?.cost_breakdown && result.current_stack_cost.cost_breakdown.length > 0 && (
        <Section icon={Layers} title="Current Stack Cost Breakdown">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="cost-breakdown">
              <AccordionTrigger className="text-base font-medium text-gray-700">View Detailed Cost Breakdown</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                  {result.current_stack_cost.cost_breakdown.map((item, index) => (
                    <div key={index} className="flex flex-col py-3 border-b border-gray-100 last:border-b-0">
                      <div className='flex justify-between items-center'>
                        <div>
                          <div className="font-bold text-gray-800">{item.tool}</div>
                          <div className="text-gray-500 text-sm">
                            {item.licenses_needed} licenses × {formatCurrency(item.cost_per_license)} ({item.license_tier})
                          </div>
                        </div>
                        <span className="font-bold text-gray-800">{formatCurrency(item.annual_cost)}</span>
                      </div>
                      {item.key_features && item.key_features.length > 0 && (
                          <div className='mt-2 text-xs text-gray-600'>
                              <p className='font-semibold flex items-center gap-1'><Check className='w-3 h-3 text-green-600'/> Key Features:</p>
                              <p className='pl-4'>{item.key_features.join(', ')}</p>
                          </div>
                      )}
                      {item.common_addons && item.common_addons.length > 0 && (
                          <div className='mt-1 text-xs text-gray-500'>
                              <p className='font-semibold flex items-center gap-1'><List className='w-3 h-3 text-blue-600'/> Common Add-ons:</p>
                              <p className='pl-4'>{item.common_addons.join(', ')}</p>
                          </div>
                      )}
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Section>
      )}

      {/* Detailed Consolidation Plan */}
      {result.detailed_consolidation_plan && (
        <Section icon={Briefcase} title="Proactive Consolidation Plan">
          <p className="text-gray-700 whitespace-pre-wrap">{result.detailed_consolidation_plan}</p>
        </Section>
      )}

      {/* Feature Overlap Analysis */}
      {result.overlap_analysis?.length > 0 && (
        <Section icon={GitMerge} title="Feature Overlap Analysis">
          <Accordion type="multiple" className="w-full">
            {result.overlap_analysis.map((overlap, index) => (
              <AccordionItem value={`overlap-${index}`} key={index}>
                <AccordionTrigger>
                  <div className="flex flex-col text-left w-full pr-6">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-bold text-gray-800">
                        {overlap.overlapping_tools.join(' + ')}
                      </span>
                      <Badge variant="secondary" className="ml-2 bg-green-50 text-green-700 border-green-200">
                        Save {formatCurrency(overlap.consolidation_savings)}/year
                      </Badge>
                    </div>
                    <span className="text-sm text-gray-600 font-normal">
                      {overlap.conflicting_features?.length || 0} conflicting features identified
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 p-4 bg-gray-50 rounded-b-lg border-t border-gray-100">
                  <div>
                    <h4 className="font-semibold text-sm mb-2 text-gray-700">Conflicting Features:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                      {overlap.conflicting_features?.map((feature, i) => (
                        <li key={i}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-1 text-gray-700">Recommendation:</h4>
                    <p className="text-sm text-gray-700">{overlap.recommendation}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-1 text-gray-700">Trade-off Analysis:</h4>
                    <p className="text-sm text-gray-700">{overlap.tradeoff_analysis}</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Section>
      )}
      
      {/* Optimization Recommendations */}
      {result.optimization_recommendations?.length > 0 && (
        <Section icon={Lightbulb} title="Strategic Recommendations">
          <div className="space-y-4">
            {result.optimization_recommendations.map((rec, index) => (
              <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg border border-gray-100">
                <div className="p-2 bg-yellow-100 rounded-full mt-1">
                  <Lightbulb className="w-5 h-5 text-yellow-700" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-800">{rec.category}</h4>
                    {rec.estimated_savings > 0 && (
                      <Badge variant="outline" className="text-green-600 bg-green-50 border-green-200">
                        Save {formatCurrency(rec.estimated_savings)}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{rec.recommendation}</p>
                  <div className="text-xs text-gray-500">
                    Implementation Effort: {rec.implementation_effort}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Methodology and Sources */}
      <div className="grid md:grid-cols-2 gap-6">
        {result.methodology_and_assumptions && (
          <Section icon={BarChart3} title="Methodology & Assumptions">
            <div className="prose prose-sm max-w-none text-gray-700 text-sm">
              {result.methodology_and_assumptions.split('\n').map((line, i) => (
                <p key={i} className="mb-2">{line}</p>
              ))}
            </div>
          </Section>
        )}

        {result.sources_referenced?.length > 0 && (
          <Section icon={Book} title="Data Sources">
            <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
              {result.sources_referenced.map((source, i) => (
                <li key={i}>
                  {source.startsWith('http') ? (
                    <a href={source} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                      {source} <LinkIcon className="inline w-3 h-3 ml-1"/>
                    </a>
                  ) : (
                    source
                  )}
                </li>
              ))}
            </ul>
          </Section>
        )}
      </div>
    </div>
  );
}
