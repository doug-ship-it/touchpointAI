
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tag, ArrowRight, Quote } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const slideVariants = {
  enter: (direction) => ({
    x: direction > 0 ? 1000 : -1000,
    opacity: 0,
  }),
  center: { zIndex: 1, x: 0, opacity: 1 },
  exit: (direction) => ({
    zIndex: 0,
    x: direction < 0 ? 1000 : -1000,
    opacity: 0,
  }),
};

const caseStudiesData = [
  {
    type: 'case_study',
    client: 'Series-B SaaS',
    title: 'Revenue Acceleration Program',
    description: 'Directed strategic sales enablement program that generated $392K in incremental revenue through 18 high-quality meetings in first quarter. Delivered systematic approach achieving $125K average deal size in Annual Recurring Revenue while strategically expanding market footprint.',
    tags: ['Revenue Growth', 'Sales Enablement', 'B2B Sales'],
    image_url: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=2344&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'GitHub',
    title: 'Actions Platform Development',
    description: 'Oversaw the team of 20 engineers across the US and Eastern Europe that built GitHub Actions from the ground up, establishing the foundational platform architecture for CI/CD automation. Managed ongoing platform maintenance and modernization efforts that continue to serve millions of developers worldwide today.',
    tags: ['CI/CD', 'Platform Architecture', 'Developer Tools'],
    image_url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Nordic Partners',
    title: 'Investment Pipeline Acceleration',
    description: 'Led targeted lead generation strategy for Nordic Partners Investments that generated a 380% surge in qualified investor connections within 90 days. Established systematic pipeline management delivering 12+ qualified meetings monthly, maintaining consistent deal flow for the premier Seattle-based Commercial Real Estate and Private Equity firm.',
    tags: ['Lead Generation', 'Investment Strategy', 'Financial Services'],
    image_url: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c743df2b981f4e31e3cd9b/e83d78c46_RealEstate.jpg'
  },
  {
    type: 'case_study',
    client: 'Microsoft',
    title: 'Customer Success Intelligent Routing AI',
    description: 'Led the engineering team that architected and deployed the AI-powered backbone for Microsoft\'s customer success intelligent routing system. Delivered automated triage and routing capabilities processing over 50,000 customer requests monthly with improved response times and resolution accuracy.',
    tags: ['AI/ML', 'Customer Success', 'Enterprise Scale'],
    image_url: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Dalrae Solutions',
    title: 'ROI Acceleration',
    description: 'Orchestrated proprietary accelerators and LinkedIn content strategy achieving 800%+ ROI with 42% lower customer acquisition costs. Delivered systematic approach resulting in 2.8x faster sales velocity within first year of engagement for enterprise client.',
    tags: ['ROI Optimization', 'LinkedIn Strategy', 'Sales Velocity'],
    image_url: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Shrapnel',
    title: 'Web3 Gaming Platform',
    description: 'Oversaw full-stack development teams building blockchain infrastructure for Shrapnel\'s Web3 shooter game launch. Managed collaboration with AAA gaming studios and implemented cutting-edge technology stack supporting next-generation gaming experiences.',
    tags: ['Web3', 'Blockchain Infrastructure', 'Gaming Platform'],
    image_url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Reddit',
    title: 'Analytics Infrastructure',
    description: 'Led cross-functional teams in designing and implementing comprehensive analytics infrastructure for Reddit\'s marketing and user engagement systems. Established monitoring, optimization processes, and third-party integrations that enhanced data-driven decision making across the platform.',
    tags: ['Data Analytics', 'Marketing Intelligence', 'User Engagement'],
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Seattle Seahawks',
    title: 'Performance Portal',
    description: 'Oversaw development of comprehensive team performance management application for professional sports analytics. Delivered real-time reporting, training session management, and flexible configuration systems for athletic performance optimization.',
    tags: ['Sports Analytics', 'Performance Management', 'Athletic Optimization'],
    image_url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'Guardant Health',
    title: 'Infinity Platform',
    description: 'Directed front-end development teams building Guardant Health\'s proprietary Infinity platform for multiomic insights. Delivered scalable genomic, epigenomic, and RNA-based fusion data visualization tools bridging research and clinical applications.',
    tags: ['Genomics', 'Healthcare Technology', 'Biotech Platform'],
    image_url: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  },
  {
    type: 'case_study',
    client: 'AI Startup',
    title: 'Investment Acceleration',
    description: 'Led targeted campaign strategy that secured $200K in angel investment within one week for innovative AI startup. Established systematic meeting generation delivering 13 monthly meetings with Enterprise Consumer Goods/Retail CSOs, accelerating MVP development and strategic advisory board recruitment.',
    tags: ['Angel Investment', 'AI Startup', 'Strategic Advisory'],
    image_url: 'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2340&auto=format&fit=crop&ixlib=rb-4.0.3'
  }
];

export default function AnimatedCaseStudies() {
  const [[page, direction], setPage] = useState([0, 0]);
  const navigate = useNavigate();

  const paginate = useCallback((newDirection) => {
    setPage(([currentPage, _]) => [currentPage + newDirection, newDirection]);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => paginate(1), 8000);
    return () => clearInterval(interval);
  }, [paginate]);

  const contentIndex = ((page % caseStudiesData.length) + caseStudiesData.length) % caseStudiesData.length;
  const currentContent = caseStudiesData[contentIndex];

  const handleContentClick = () => {
    navigate(createPageUrl('Intake'));
  };

  const renderCaseStudy = (content) => (
    <div className="grid md:grid-cols-2 gap-8 items-center bg-gray-800/50 p-8 rounded-2xl shadow-2xl border border-gray-700 cursor-pointer hover:shadow-teal-500/10 transition-all duration-300" onClick={handleContentClick}>
      <div className="order-2 md:order-1">
        <span className="text-sm font-semibold text-teal-400 uppercase tracking-wider">{content.client}</span>
        <h3 className="text-2xl font-bold text-white mt-2 mb-4">{content.title}</h3>
        <p className="text-gray-400 leading-relaxed mb-4">{content.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {content.tags?.map(tag => (
            <div key={tag} className="flex items-center gap-1.5 text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded">
              <Tag className="w-3 h-3"/> {tag}
            </div>
          ))}
        </div>
        <div className="flex items-center text-teal-400 font-semibold hover:text-teal-300 transition-colors">
          <span>Learn More About Our Approach</span>
          <ArrowRight className="w-4 h-4 ml-2" />
        </div>
      </div>
      <div className="order-1 md:order-2 h-64 md:h-80 w-full overflow-hidden rounded-lg group">
        <img 
          src={content.image_url} 
          alt={content.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
        />
      </div>
    </div>
  );

  return (
    <section className="bg-gray-950 py-20 overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Integrated Talent & Technology solutions for modern business.</h2>
        </div>

        <div className="relative min-h-[450px] flex items-center justify-center">
          <AnimatePresence initial={false} custom={direction}>
            <motion.div
              key={page}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: 'spring', stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 },
              }}
              className="absolute w-full"
            >
              {renderCaseStudy(currentContent)}
            </motion.div>
          </AnimatePresence>
        </div>
        
        <div className="flex justify-center mt-8 space-x-2">
          {caseStudiesData.map((_, i) => (
            <div key={i} className="w-8 h-1 rounded-full bg-gray-700 overflow-hidden cursor-pointer" onClick={() => setPage([i, i > contentIndex ? 1 : -1])}>
                <motion.div
                    className="h-full bg-teal-500"
                    initial={{ width: '0%' }}
                    animate={{ width: i === contentIndex ? '100%' : '0%' }}
                    transition={{ duration: i === contentIndex ? 8 : 0.5 }}
                />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
