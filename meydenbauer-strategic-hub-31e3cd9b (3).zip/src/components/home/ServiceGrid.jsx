import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Service } from '@/api/entities';
import { ArrowRight, Code, TrendingUp, Hammer, Building2, Users, GitFork } from 'lucide-react';

const iconMap = {
  Code, TrendingUp, Hammer, Building2, Users, GitFork
};

export default function ServiceGrid() {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchServices = async () => {
      const data = await Service.list();
      // Remove duplicates by filtering unique page_link values
      const uniqueServices = data.reduce((acc, current) => {
        const existingService = acc.find(service => service.page_link === current.page_link);
        if (!existingService) {
          acc.push(current);
        }
        return acc;
      }, []);
      
      // Filter out Strategic Consulting option and update Business Operations title
      const filteredServices = uniqueServices.filter(service => 
        service.title !== "Strategic Consulting" && 
        !service.title.toLowerCase().includes("strategic consulting")
      ).map(service => {
        // Update Business Operations to Operations + VA
        if (service.title === "Business Operations" || service.title === "Operations + Executive Assistance") {
          return { ...service, title: "Operations + VA" };
        }
        return service;
      });
      
      setServices(filteredServices);
    };
    fetchServices();
  }, []);

  if (services.length === 0) return null;

  return (
    <section className="bg-gray-900 py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = iconMap[service.icon_name] || GitFork;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link to={createPageUrl(service.page_link)} className="block h-full">
                  <div className="group bg-gray-800/50 hover:bg-gray-800 p-8 rounded-2xl h-full border border-gray-700 hover:border-teal-500/50 transition-all duration-300 transform hover:-translate-y-1">
                    <Icon className="w-10 h-10 text-teal-400 mb-4" />
                    <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
                    <p className="text-gray-400 mb-4 flex-grow">{service.description}</p>
                    <div className="flex items-center text-teal-400 font-semibold text-sm group-hover:underline">
                      Learn More <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}