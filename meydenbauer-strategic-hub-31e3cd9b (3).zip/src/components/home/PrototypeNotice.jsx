import React from 'react';
import { motion } from 'framer-motion';
import { Globe, MapPin, BarChart3, Zap, User, Database, CheckCircle } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description }) => (
    <div className="bg-black/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50 flex gap-4 transition-all duration-300 hover:bg-black/50 hover:border-gray-600">
        <div className="p-2 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-lg h-fit">
            <Icon className="w-5 h-5 text-white" />
        </div>
        <div>
            <h4 className="font-semibold text-white mb-1">{title}</h4>
            <p className="text-sm text-gray-400">{description}</p>
        </div>
    </div>
);

const PriceItem = ({ name, icon: Icon, isMarket }) => (
    <div className={`flex items-center gap-3 text-sm ${isMarket ? 'text-gray-400' : 'text-white'}`}>
        <Icon className={`w-4 h-4 ${isMarket ? 'text-gray-500' : 'text-teal-400'}`} />
        <span>{name}</span>
    </div>
);

export default function PrototypeNotice() {
  return (
    <div className="my-12 sm:my-16">
        <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="bg-gradient-to-br from-gray-900 to-black rounded-2xl p-6 sm:p-8 md:p-12 text-white shadow-2xl relative overflow-hidden"
        >
            <motion.div className="absolute -bottom-1/2 -left-1/4 w-full h-full bg-gradient-to-r from-teal-500/20 via-transparent to-transparent rounded-full filter blur-3xl animate-gradient-wave" />
            <motion.div className="absolute -top-1/2 -right-1/4 w-full h-full bg-gradient-to-l from-orange-500/20 via-transparent to-transparent rounded-full filter blur-3xl animate-gradient-wave" style={{ animationDelay: '-2s' }} />

            <div className="relative z-10 text-center max-w-4xl mx-auto">
                <h2 className="text-3xl sm:text-4xl font-bold mb-3" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
                    Unified Contact Portal - Network Intelligence Command Center
                </h2>
                <div className="inline-block bg-yellow-400 text-gray-900 text-xs font-bold px-3 py-1 rounded-full mb-4">
                    Launching Q4 2025
                </div>
                <p className="text-base sm:text-lg text-gray-400 max-w-2xl mx-auto mb-10">
                    Consolidate LinkedIn, Gmail, Outlook, Calendly, HubSpot, Instagram, and Facebook into one strategic intelligence hub.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    <FeatureCard icon={Globe} title="Total Network Consolidation" description="Auto-sync contacts across all platforms with real-time job change alerts and professional intelligence updates." />
                    <FeatureCard icon={MapPin} title="Geographic Intelligence" description="Visual network clustering. Instantly spot Greater Seattle contacts for coffee vs. remote connections for strategic calls." />
                    <FeatureCard icon={BarChart3} title="AI Relationship Intelligence" description="Relationship temperature scoring, optimal engagement timing, and executive dashboard analytics that drive ROI." />
                </div>

                <div className="bg-black/40 border border-gray-700 rounded-2xl p-6 sm:p-8 mb-12">
                    <h3 className="text-xl sm:text-2xl font-semibold mb-2">Built For Leaders Managing 1,000+ Professional Connections</h3>
                    <p className="text-gray-500 mb-6 max-w-xl mx-auto text-sm sm:text-base">Stop juggling multiple platforms. Get systematic relationship management that scales with your network.</p>
                    
                    <div className="flex flex-col md:flex-row justify-center items-center gap-8">
                        <div className="text-left space-y-3">
                            <h4 className="font-bold text-gray-400 text-sm">MARKET STACK</h4>
                            <PriceItem name="Personal CRM" icon={User} isMarket />
                            <PriceItem name="LinkedIn Automation" icon={Zap} isMarket />
                            <PriceItem name="Contact Intelligence" icon={Database} isMarket />
                            <PriceItem name="Relationship Analytics" icon={BarChart3} isMarket />
                            <div className="text-3xl md:text-4xl font-bold text-gray-600 line-through pt-2">$750+/mo</div>
                        </div>

                        <div className="w-full md:w-px md:h-32 bg-gray-700"></div>

                        <div className="text-left space-y-3 p-6 rounded-lg bg-gradient-to-tr from-teal-900/50 to-orange-900/50 border border-teal-500/50 w-full md:w-auto">
                            <h4 className="font-bold text-teal-300 text-sm">OUR INTEGRATED PLATFORM</h4>
                            <p className="text-white font-medium flex items-center gap-3 text-sm">
                               <CheckCircle className="w-4 h-4 text-teal-400"/>
                               All-in-One Strategic Hub
                            </p>
                            <p className="text-gray-300 text-xs max-w-xs">Includes all market stack features, plus proprietary AI-driven insights and cross-platform automation.</p>
                            
                            <div className="flex items-end gap-4 pt-2 pb-3">
                                <div className="text-3xl md:text-4xl font-bold text-white">$20/mo</div>
                                <div className="text-sm text-gray-300">+ Smart Credit System</div>
                            </div>

                            <div className="space-y-2 text-xs text-gray-300">
                                <div className="flex items-center gap-2">
                                    <div className="w-1 h-1 bg-teal-400 rounded-full"></div>
                                    Contact Data Enrichment
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-1 h-1 bg-teal-400 rounded-full"></div>
                                    LinkedIn Copilot Usage
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-1 h-1 bg-teal-400 rounded-full"></div>
                                    Custom API Integrations
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-1 h-1 bg-teal-400 rounded-full"></div>
                                    Advanced Analytics Features
                                </div>
                            </div>

                            <div className="border-t border-gray-600 pt-3 mt-3">
                                <p className="text-xs text-gray-400 mb-2">
                                    <strong className="text-teal-300">Built-in Cost Protection:</strong> Custom limits to your preferences to ensure predictable budgeting.
                                </p>
                                <motion.div 
                                    initial={{ scale: 0 }}
                                    whileInView={{ scale: 1 }}
                                    transition={{ type: 'spring', stiffness: 300, damping: 15, delay: 0.2 }}
                                    className="bg-teal-500 text-white text-sm font-bold py-2 px-4 rounded-full inline-block"
                                >
                                    92% SAVINGS
                                </motion.div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </motion.div>
    </div>
  );
}