import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MindMapNode({ resource, style, index }) {
  const nodeVariants = {
    hidden: { scale: 0, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        delay: 0.3 + index * 0.1, 
        duration: 0.5 
      } 
    }
  };

  const getNodeUrl = () => {
    // Handle different resource formats
    if (resource.link) return resource.link;
    if (resource.url) return resource.url;
    
    // Convert title to page URL for navigation
    const titleToPageMap = {
      'Command Center': 'CommandCenter',
      'Find Connections': 'NetworkIntelligenceDeep',
      'Verified Partners': 'VerifiedPartners',
      'Tech Stack Analysis': 'TechStackAnalysis',
      'Candidate Portal': 'CandidatePortal',
      'Leadership Assessment': 'ArchetypeDNALearning',
      'Network Intelligence': 'NetworkIntelligenceDeep',
      'Vendor Portal': 'VerifiedPartners',
      'ArchetypeDNA': 'ArchetypeDNALearning',
      'Tech Stack Audit': 'TechStackAnalysis',
      'Resource Library': 'ResourceLibrary'
    };

    const pageName = titleToPageMap[resource.title];
    return pageName ? createPageUrl(pageName) : '#';
  };

  return (
    <motion.div
      className="absolute w-[173px] h-[173px]"
      style={style}
      variants={nodeVariants}
      animate={{ rotate: -360 }}
      transition={{
        duration: 60,
        repeat: Infinity,
        ease: "linear",
      }}
    >
        <motion.div 
            className="w-full h-full"
            whileHover={{ scale: 1.1 }}
            animate={{ scale: [1, 1.03, 1] }}
            transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.5
            }}
        >
            <Link to={getNodeUrl()} className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-white/90 backdrop-blur-sm border-2 border-gray-200 shadow-lg group rounded-xl transition-all duration-300 hover:shadow-xl">
                {resource.Icon && (
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-teal-500 to-blue-500 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <resource.Icon className="w-6 h-6 text-white" />
                </div>
                )}
                <h3 className="text-sm font-bold text-gray-800 mb-1 leading-tight">
                {resource.title}
                </h3>
                <p className="text-xs text-gray-600 leading-tight">
                {resource.description}
                </p>
            </Link>
        </motion.div>
    </motion.div>
  );
}