import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Calendar, Building2, MapPin, ExternalLink, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function RecentActivity({ people, services }) {
  const getSeniorityColor = (seniority) => {
    const colors = {
      'Entry Level': 'bg-blue-100 text-blue-800',
      'Mid Level': 'bg-green-100 text-green-800', 
      'Senior Level': 'bg-purple-100 text-purple-800',
      'Director': 'bg-orange-100 text-orange-800',
      'Executive': 'bg-red-100 text-red-800',
      'C-Level': 'bg-pink-100 text-pink-800'
    };
    return colors[seniority] || 'bg-gray-100 text-gray-800';
  };

  const getIndustryColor = (industry) => {
    const colors = {
      'Technology': 'bg-blue-100 text-blue-800',
      'Financial Services': 'bg-green-100 text-green-800',
      'Professional Services': 'bg-purple-100 text-purple-800',
      'Healthcare': 'bg-red-100 text-red-800',
      'Manufacturing': 'bg-yellow-100 text-yellow-800'
    };
    return colors[industry] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      
      {/* Recent Contacts */}
      <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Recent Network Activity
          </CardTitle>
          <Link to={createPageUrl("NetworkIntelligenceDeep")}>
            <Button variant="outline" size="sm" className="gap-2">
              <ExternalLink className="w-4 h-4" />
              View All
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {people && people.length > 0 ? (
            <div className="space-y-4">
              {people.slice(0, 5).map((person) => (
                <div key={person.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
                  
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center">
                      <span className="text-white font-semibold">
                        {person.connection_name ? person.connection_name.split(' ').map(n => n[0]).join('').substring(0, 2) : 'N'}
                      </span>
                    </div>
                    
                    <div>
                      <div className="font-semibold text-slate-900">{person.connection_name || 'Unknown Contact'}</div>
                      <div className="text-sm text-slate-600">{person.connection_title || 'No title'}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Building2 className="w-3 h-3 text-slate-400" />
                        <span className="text-xs text-slate-500">{person.connection_company || 'No company'}</span>
                        {person.enriched_location && (
                          <>
                            <MapPin className="w-3 h-3 text-slate-400 ml-2" />
                            <span className="text-xs text-slate-500">{person.enriched_location}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {person.enriched_seniority && (
                      <Badge className={getSeniorityColor(person.enriched_seniority)}>
                        {person.enriched_seniority}
                      </Badge>
                    )}
                    {person.enriched_industry && (
                      <Badge className={getIndustryColor(person.enriched_industry)}>
                        {person.enriched_industry}
                      </Badge>
                    )}
                  </div>
                  
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No recent network activity</p>
              <Link to={createPageUrl("NetworkIntelligenceDeep")}>
                <Button variant="outline" size="sm" className="mt-3">
                  Upload Your Network
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Access to Services */}
      <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            Service Hub
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {services.map((service, index) => (
              <Link key={index} to={service.url} className="block">
                <div className="p-4 rounded-lg bg-gradient-to-r from-slate-50 to-slate-100 hover:from-slate-100 hover:to-slate-200 transition-all duration-300 group">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-teal-500 to-blue-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <service.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">
                        {service.title}
                      </h4>
                      <p className="text-xs text-slate-600">{service.description}</p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}