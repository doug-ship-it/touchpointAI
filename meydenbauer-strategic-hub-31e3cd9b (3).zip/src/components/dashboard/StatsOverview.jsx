import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, List, TrendingUp, Briefcase, Award, Mail } from "lucide-react";
import { motion } from "framer-motion";

export default function StatsOverview({ stats }) {
  // Provide safe defaults for all stats
  const safeStats = {
    networkConnections: { value: 0, label: "Network Connections" },
    verifiedVendors: { value: 0, label: "Verified Vendors" },
    activeCandidates: { value: 0, label: "Active Candidates" },
    strategicTools: { value: 0, label: "Strategic Tools" },
    ...stats
  };

  const statCards = [
    {
      title: "Network Connections",
      value: (safeStats.networkConnections?.value || 0).toLocaleString(),
      icon: Users,
      color: "blue",
      trend: "+12% this month"
    },
    {
      title: "Verified Vendors", 
      value: (safeStats.verifiedVendors?.value || 0).toLocaleString(),
      icon: Award,
      color: "purple",
      trend: `${safeStats.verifiedVendors?.value || 0} partners`
    },
    {
      title: "Active Candidates",
      value: `${safeStats.activeCandidates?.value || 0}`,
      icon: Mail,
      color: "green",
      trend: "Pipeline active"
    },
    {
      title: "Strategic Tools",
      value: (safeStats.strategicTools?.value || 0).toString(),
      icon: Briefcase,
      color: "orange",
      trend: "Available tools"
    }
  ];

  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    green: "from-green-500 to-green-600", 
    purple: "from-purple-500 to-purple-600",
    orange: "from-orange-500 to-orange-600"
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="relative overflow-hidden bg-white/80 backdrop-blur-sm shadow-xl border-0 hover:shadow-2xl transition-shadow duration-300">
            
            {/* Background Pattern */}
            <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${colorClasses[stat.color]} opacity-10 rounded-full transform translate-x-8 -translate-y-8`} />
            
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-slate-600">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-lg bg-gradient-to-r ${colorClasses[stat.color]} bg-opacity-20`}>
                  <stat.icon className={`w-4 h-4 text-${stat.color}-600`} />
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="text-3xl font-bold text-slate-900 mb-1">
                {stat.value}
              </div>
              <p className="text-xs text-slate-500">
                {stat.trend}
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}