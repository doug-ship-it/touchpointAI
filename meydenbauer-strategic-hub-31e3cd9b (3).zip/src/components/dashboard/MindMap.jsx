import React from 'react';
import { motion } from 'framer-motion';
import MindMapNode from './MindMapNode';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const lineVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: {
      pathLength: 1,
      opacity: 1,
      transition: {
        pathLength: { type: "spring", duration: 1.5, bounce: 0 },
        opacity: { duration: 0.01 }
      }
    }
};

const MindMap = ({ resources = [] }) => {
  // Ensure resources is an array and has content
  const safeResources = Array.isArray(resources) ? resources : [];
  const numNodes = safeResources.length;
  
  // If no resources, show a default set
  const defaultResources = [
    { id: 'command-center', title: 'Command Center', description: 'Strategic dashboard' },
    { id: 'find-connections', title: 'Find Connections', description: 'Network intelligence' },
    { id: 'verified-partners', title: 'Verified Partners', description: 'Partner ecosystem' },
    { id: 'tech-analysis', title: 'Tech Stack Analysis', description: 'ROI analysis' },
    { id: 'candidate-portal', title: 'Candidate Portal', description: 'Executive search' },
    { id: 'leadership-assessment', title: 'Leadership Assessment', description: 'ArchetypeDNA' }
  ];
  
  const displayResources = numNodes > 0 ? safeResources : defaultResources;
  const displayNumNodes = displayResources.length;
  
  // Use different radius for desktop and mobile
  const radius = typeof window !== 'undefined' && window.innerWidth > 768 ? 280 : 160; 
  const center = { x: '50%', y: '50%' };
  const nodePositions = [];

  for (let i = 0; i < displayNumNodes; i++) {
    // Start from -90 degrees (top)
    const angle = -Math.PI / 2 + (i * 2 * Math.PI) / displayNumNodes;
    const nodeSize = 173; // Increased by 20% from 144px to 173px
    const x = `calc(${center.x} + ${radius * Math.cos(angle)}px - ${nodeSize / 2}px)`;
    const y = `calc(${center.y} + ${radius * Math.sin(angle)}px - ${nodeSize / 2}px)`;
    nodePositions.push({ x, y, angle });
  }

  return (
    <motion.div
      className="relative w-full h-[700px] flex items-center justify-center"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Central Node */}
      <motion.div
        className="w-48 h-48 rounded-full bg-gradient-to-br from-slate-700 to-slate-900 text-white
                   flex flex-col items-center justify-center text-center p-4 shadow-2xl z-10"
        variants={{
          hidden: { scale: 0 },
          visible: { scale: 1, transition: { delay: 0.1, duration: 0.5 } }
        }}
      >
        <h2 className="text-xl font-bold">Your Strategic Hub</h2>
        <p className="text-sm text-slate-300">Interconnected Resources</p>
      </motion.div>

      {/* Orbital Container for Animated Lines and Nodes */}
      <motion.div
        className="absolute top-0 left-0 w-full h-full"
        animate={{ rotate: 360 }}
        transition={{
          duration: 60, // 60 seconds for full rotation
          repeat: Infinity,
          ease: "linear"
        }}
      >
        {/* Lines */}
        <svg className="absolute top-0 left-0 w-full h-full" style={{ pointerEvents: 'none' }}>
          {nodePositions.map((pos, i) => (
              <motion.line
                  key={`line-${i}`}
                  x1="50%"
                  y1="50%"
                  x2={`calc(${pos.x} + 86.5px)`} // Adjusted for new node size
                  y2={`calc(${pos.y} + 86.5px)`}
                  stroke="#cbd5e1"
                  strokeWidth="2"
                  variants={lineVariants}
              />
          ))}
        </svg>
        
        {displayResources.map((resource, i) => (
          <MindMapNode
            key={resource.id || i}
            resource={resource}
            style={{ top: nodePositions[i].y, left: nodePositions[i].x }}
            index={i}
          />
        ))}
      </motion.div>
    </motion.div>
  );
};

export default MindMap;