import React from 'react';
import { motion } from 'framer-motion';
import { User, Building, ClipboardList, Send, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const steps = [
  { name: 'Contact', icon: User },
  { name: 'Company', icon: Building },
  { name: 'Needs', icon: ClipboardList },
  { name: 'Finalize', icon: Send },
];

export default function IntakeProgressTracker({ currentStep, totalSteps }) {
  return (
    <div className="w-full max-w-2xl mx-auto mb-12">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const stepIndex = index + 1;
          const isCompleted = currentStep > stepIndex;
          const isActive = currentStep === stepIndex;

          return (
            <React.Fragment key={step.name}>
              <div className="flex flex-col items-center text-center relative z-10">
                <motion.div
                  animate={isCompleted || isActive ? "active" : "inactive"}
                  variants={{
                    active: { scale: 1.1, y: -2 },
                    inactive: { scale: 1, y: 0 },
                  }}
                  transition={{ duration: 0.3, type: 'spring', stiffness: 300, damping: 20 }}
                  className={cn(
                    "w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-300",
                    isCompleted ? "bg-blue-600 border-blue-600 text-white" :
                    isActive ? "bg-white border-blue-600 text-blue-600 shadow-lg" :
                    "bg-gray-100 border-gray-300 text-gray-400"
                  )}
                >
                  {isCompleted ? <CheckCircle className="w-6 h-6" /> : <step.icon className="w-6 h-6" />}
                </motion.div>
                <p className={cn(
                  "mt-2 text-sm font-medium transition-colors duration-300",
                  isActive || isCompleted ? "text-blue-700" : "text-gray-500"
                )}>
                  {step.name}
                </p>
              </div>
              {index < steps.length - 1 && (
                <div className="flex-1 h-1 bg-gray-200 mx-[-1px] relative">
                   <motion.div
                    className="h-1 bg-blue-600 absolute top-0 left-0"
                    initial={{ width: 0 }}
                    animate={{ width: isCompleted ? '100%' : isActive ? '50%' : '0%' }}
                    transition={{ duration: 0.5, ease: 'easeInOut' }}
                  />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}