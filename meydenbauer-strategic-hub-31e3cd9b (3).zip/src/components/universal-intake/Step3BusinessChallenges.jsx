import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ArrowRight, ArrowLeft, Loader2, AlertTriangle, Check, Code, TrendingUp, Target, DollarSign, BarChart, Cog, Zap, BrainCircuit, Globe, UserCheck, Database, Smartphone, Shield, Users } from 'lucide-react';
import { cn } from '@/lib/utils';

const getIconForChallenge = (challenge) => {
  const text = challenge.toLowerCase();
  if (text.includes('revenue') || text.includes('sales') || text.includes('financial')) return DollarSign;
  if (text.includes('growth') || text.includes('market') || text.includes('expansion')) return TrendingUp;
  if (text.includes('customer') || text.includes('client')) return Target;
  if (text.includes('talent') || text.includes('hiring') || text.includes('team')) return Users;
  if (text.includes('ai') || text.includes('artificial intelligence')) return BrainCircuit;
  if (text.includes('tech') || text.includes('digital') || text.includes('data')) return Code;
  if (text.includes('process') || text.includes('operations')) return Cog;
  if (text.includes('competitive') || text.includes('competition')) return Zap;
  if (text.includes('security') || text.includes('compliance')) return Shield;
  if (text.includes('mobile') || text.includes('app')) return Smartphone;
  if (text.includes('database') || text.includes('storage')) return Database;
  if (text.includes('global') || text.includes('international')) return Globe;
  return BarChart;
};

const ChallengeCard = ({ challenge, isSelected, onClick }) => {
  const Icon = getIconForChallenge(challenge);
  
  return (
    <motion.div whileTap={{ scale: 0.97 }} className="h-full">
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "w-full h-full text-left p-4 rounded-xl border-2 text-sm font-medium transition-all duration-200 flex items-center gap-3",
          isSelected
            ? "bg-blue-50 border-blue-500 text-blue-800 shadow-md"
            : "bg-white border-gray-300 hover:border-blue-400 hover:bg-blue-50/50"
        )}
      >
        <Icon className={cn("w-5 h-5 flex-shrink-0", isSelected ? "text-blue-600" : "text-gray-500")} />
        <span className="flex-grow">{challenge}</span>
        <div className={cn(
          "w-5 h-5 rounded-sm border-2 flex-shrink-0 flex items-center justify-center",
          isSelected ? "bg-blue-600 border-blue-600" : "border-gray-400"
        )}>
          {isSelected && <Check className="w-3 h-3 text-white" />}
        </div>
      </button>
    </motion.div>
  );
};

export default function Step3BusinessChallenges({ formData, updateFormData, onNext, onPrevious }) {
  const [challenges, setChallenges] = useState([]);
  const [selectedChallenges, setSelectedChallenges] = useState(formData.challenges || []);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const generateChallenges = async () => {
      const { industry, size, name: companyName } = formData.company || {};
      if (!industry || !size) {
        setError("Company industry and size are required to generate personalized challenges.");
        setIsLoading(false);
        return;
      }

      const prompt = `You are a strategic business consultant AI. For a company named "${companyName}" in the "${industry}" industry with ${size} employees, generate a JSON object with a list of the top 8 most pressing business challenges.

      **Critical Requirements:**
      1. **Universal Core Challenges**: ALWAYS include these three strategically tailored challenges as the TOP priorities:
         - "Accelerate Revenue Growth & Market Expansion" (tailored for ${industry})
         - "Attract & Retain Top-Tier Talent" (relevant to ${size} company size)
         - "Integrate AI & Automation for Competitive Advantage" (industry-specific AI applications)

      2. **Industry-Specific Challenges**: Generate 5 additional highly specific challenges for a ${industry} company of ${size} size, using online data about current market trends, regulatory changes, and industry-specific pain points.

      3. **Deduplication**: Ensure no redundancy between the universal challenges and industry-specific ones.

      4. **Prioritization**: Order all 8 challenges by urgency and impact for this company profile.

      The final JSON output must be:
      {
        "challenges": ["Challenge 1", "Challenge 2", "Challenge 3", "Challenge 4", "Challenge 5", "Challenge 6", "Challenge 7", "Challenge 8"]
      }`;

      try {
        setIsLoading(true);
        const result = await InvokeLLM({
          prompt,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              challenges: { type: "array", items: { type: "string" } }
            },
            required: ["challenges"]
          }
        });
        
        setChallenges(result.challenges || []);
      } catch (err) {
        console.error("Failed to generate challenges:", err);
        setError("Could not generate personalized challenges. Please proceed to the next step.");
        // Fallback challenges
        setChallenges([
          "Accelerate Revenue Growth & Market Expansion",
          "Attract & Retain Top-Tier Talent", 
          "Integrate AI & Automation for Competitive Advantage",
          "Scale Operations Efficiently",
          "Improve Customer Acquisition",
          "Enhance Digital Transformation",
          "Optimize Financial Performance",
          "Strengthen Market Position"
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    generateChallenges();
  }, [formData.company]);

  const handleToggle = (challenge) => {
    const newSelection = selectedChallenges.includes(challenge)
      ? selectedChallenges.filter(c => c !== challenge)
      : [...selectedChallenges, challenge];
    
    setSelectedChallenges(newSelection);
    updateFormData('challenges', newSelection);
  };

  const handleNext = () => {
    onNext();
  };

  const isValid = selectedChallenges.length > 0;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 mb-4">
          <Target className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Identify Business Challenges</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Help us understand your most pressing business challenges so we can provide targeted recommendations.
        </p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div key="loader" className="flex flex-col items-center justify-center h-64">
              <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
              <p className="mt-4 text-gray-600">Generating personalized challenges for {formData.company?.name || 'your company'}...</p>
            </motion.div>
          ) : error ? (
            <motion.div key="error" className="flex flex-col items-center justify-center h-64 text-center">
              <AlertTriangle className="w-12 h-12 text-red-500" />
              <p className="mt-4 text-red-700 font-medium">{error}</p>
              <Button onClick={onPrevious} variant="outline" className="mt-4">Go Back to Company Info</Button>
            </motion.div>
          ) : (
            <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Label className="text-lg font-semibold text-gray-800 block mb-6">
                What are your most pressing business challenges? 
                <span className="text-gray-500 text-sm ml-2">(Select all that apply)</span>
              </Label>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {challenges.map((challenge, idx) => (
                  <ChallengeCard 
                    key={idx}
                    challenge={challenge}
                    isSelected={selectedChallenges.includes(challenge)}
                    onClick={() => handleToggle(challenge)}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex justify-between pt-6 border-t border-gray-200">
          <Button onClick={onPrevious} variant="outline" size="lg">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={handleNext} disabled={!isValid && !error} size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
            Continue <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}