
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ArrowRight, ArrowLeft, Check, User, Search, Users, Target, Settings, Zap, Cog, Headphones } from 'lucide-react';
import { cn } from '@/lib/utils';

const supportOptions = [
  {
    title: "Fractional Leadership", 
    description: "Access senior expertise on a part-time basis for strategic direction.",
    icon: User,
    keywords: ['leadership', 'executive', 'senior', 'management', 'cto', 'cfo', 'cmo', 'coo', 'direction', 'strategy']
  },
  {
    title: "Talent Search",
    description: "Discover exceptional, off-market candidates for full-time roles.",
    icon: Search,
    keywords: ['hiring', 'talent', 'recruitment', 'executive search', 'attract', 'retain', 'candidate', 'role']
  },
  {
    title: "Team Augmentation",
    description: "Quickly scale your team with skilled professionals who integrate effortlessly.",
    icon: Users,
    keywords: ['team', 'scaling', 'staff augmentation', 'augment', 'resources', 'scale up', 'integrate', 'professionals']
  },
  {
    title: "Project-Based Consulting",
    description: "Define and execute specific initiatives with certified experts.",
    icon: Target,
    keywords: ['project', 'consulting', 'initiative', 'specific', 'defined', 'execution', 'expert']
  },
  {
    title: "Technology Implementation",
    description: "Integrate cutting-edge tools to boost performance.",
    icon: Settings,
    keywords: ['technology', 'implementation', 'digital', 'tools', 'systems', 'integrate', 'software', 'platform']
  },
  {
    title: "Digital Transformation",
    description: "Modernize your business using digital-first strategies and emerging technologies.",
    icon: Zap,
    keywords: ['digital transformation', 'modernize', 'emerging tech', 'ai', 'automation', 'data-driven']
  },
  {
    title: "Process Optimization",
    description: "Simplify operations and improve efficiency through optimized workflows.",
    icon: Cog,
    keywords: ['process optimization', 'workflow', 'efficiency', 'simplify', 'operations', 'streamline']
  }
];

const SupportCard = ({ option, isSelected, onClick }) => {
  return (
    <motion.div whileTap={{ scale: 0.97 }} className="h-full">
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "w-full h-full text-left p-4 rounded-xl border-2 transition-all duration-200 relative",
          isSelected
            ? "bg-orange-50 border-orange-500 text-orange-800 shadow-md"
            : "bg-white border-gray-300 hover:border-orange-400 hover:bg-orange-50/50"
        )}
      >
        <div className="flex items-center justify-between mb-3">
          <div className={cn(
            "p-2 rounded-lg",
            isSelected ? "bg-orange-100" : "bg-gray-100"
          )}>
            <option.icon className={cn("w-5 h-5", isSelected ? "text-orange-600" : "text-gray-600")} />
          </div>
          {isSelected && <Check className="w-4 h-4 text-orange-600" />}
        </div>
        <h4 className={cn("font-semibold text-sm mb-2", isSelected ? "text-orange-900" : "text-gray-900")}>
          {option.title}
        </h4>
        <p className={cn("text-xs leading-relaxed", isSelected ? "text-orange-700" : "text-gray-600")}>
          {option.description}
        </p>
      </button>
    </motion.div>
  );
};

export default function Step5SupportNeeds({ formData, updateFormData, onNext, onPrevious }) {
  const [selectedSupport, setSelectedSupport] = useState(formData.support || []);

  // Calculate priority based on previous selections
  const prioritizedOptions = useMemo(() => {
    const challenges = formData.challenges || [];
    const hiring = formData.hiring || [];
    // Convert arrays to a single lowercase string for keyword matching
    const allSelections = [...challenges, ...hiring].join(' ').toLowerCase();

    return supportOptions.map(option => {
      let matchScore = 0;
      // Iterate through each keyword in the option's keywords array
      option.keywords.forEach(keyword => {
        // Check if the selection string includes the full keyword
        // Using word boundaries regex to match whole words for better accuracy
        const regex = new RegExp(`\\b${keyword.toLowerCase()}\\b`);
        if (regex.test(allSelections)) {
          matchScore += 1;
        }
      });
      return { ...option, score: matchScore };
    }).sort((a, b) => b.score - a.score); // Sort by score descending
  }, [formData.challenges, formData.hiring]);

  const handleToggle = (option) => {
    const newSelection = selectedSupport.includes(option.title)
      ? selectedSupport.filter(s => s !== option.title)
      : [...selectedSupport, option.title];
    
    setSelectedSupport(newSelection);
    updateFormData('support', newSelection);
  };

  const handleNext = () => {
    onNext();
  };

  const isValid = selectedSupport.length > 0;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-orange-50 mb-4">
          <Headphones className="w-8 h-8 text-orange-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Specify Support Needs</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Based on your challenges and hiring needs, select the types of support that would be most valuable.
        </p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <Label className="text-lg font-semibold text-gray-800 block mb-6">
          What type of support are you looking for? 
          <span className="text-gray-500 text-sm ml-2">(Select all that apply)</span>
        </Label>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {prioritizedOptions.map((option) => (
            <SupportCard 
              key={option.title}
              option={option}
              isSelected={selectedSupport.includes(option.title)}
              onClick={() => handleToggle(option)}
            />
          ))}
        </div>

        <div className="flex justify-between pt-6 border-t border-gray-200">
          <Button onClick={onPrevious} variant="outline" size="lg">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={handleNext} disabled={!isValid} size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
            Continue <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
