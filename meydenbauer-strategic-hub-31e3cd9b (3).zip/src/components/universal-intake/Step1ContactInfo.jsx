
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mail, User, Briefcase } from 'lucide-react';

const functionOptions = [
  "Administrative", "Art & Design", "Community & Social Services", "Education", 
  "Engineering", "Entrepreneurship", "Finance", "Healthcare Services", 
  "Human Resources", "Information Technology", "Legal", "Marketing", 
  "Media & Communications", "Military & Public Services", "Operations", 
  "Product Management", "Program & Project Management", "Purchasing", 
  "Quality Assurance", "Real Estate", "Research", "Sales", "Support"
];

export default function Step1ContactInfo({ formData, updateFormData, onNext }) {
  const [localFormData, setLocalFormData] = useState(formData.contact || {
    firstName: '',
    email: '',
    function: '',
  });

  const handleChange = (field, value) => {
    const newLocalData = { ...localFormData, [field]: value };
    setLocalFormData(newLocalData);
    updateFormData('contact', newLocalData); // Changed this line to pass the entire updated localFormData object
  };

  // Auto-advance when all required fields are completed
  useEffect(() => {
    const isComplete = localFormData.firstName && 
                      localFormData.email && 
                      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(localFormData.email) && 
                      localFormData.function;
    
    if (isComplete) {
      // Small delay to allow user to see the completion before advancing
      const timer = setTimeout(() => {
        onNext();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [localFormData, onNext]);

  const isValid = localFormData.firstName && 
                  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(localFormData.email) && 
                  localFormData.function;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Welcome to Meydenbauer</h1>
        <p className="text-lg text-gray-600 max-w-xl mx-auto">Let's start with a few quick details so we can personalize your experience.</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="firstName" className="flex items-center gap-2">
              <User className="w-4 h-4"/>
              First Name *
            </Label>
            <Input 
              id="firstName" 
              placeholder="Jane" 
              value={localFormData.firstName} 
              onChange={(e) => handleChange('firstName', e.target.value)}
              className="text-lg h-12"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="flex items-center gap-2">
              <Mail className="w-4 h-4"/>
              Business Email *
            </Label>
            <Input 
              id="email" 
              type="email" 
              placeholder="jane.doe@company.com" 
              value={localFormData.email} 
              onChange={(e) => handleChange('email', e.target.value)}
              className="text-lg h-12"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="function" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Professional Function *
            </Label>
            <Select
              value={localFormData.function}
              onValueChange={(value) => handleChange('function', value)}
            >
              <SelectTrigger className="h-12 text-lg">
                <SelectValue placeholder="Select your primary function" />
              </SelectTrigger>
              <SelectContent>
                {functionOptions.map((func) => (
                  <SelectItem key={func} value={func}>{func}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isValid && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-2 text-green-600 bg-green-50 p-4 rounded-lg">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-5 h-5 border-2 border-green-600 border-t-transparent rounded-full"
                />
                <span className="font-medium">Preparing your personalized experience...</span>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
