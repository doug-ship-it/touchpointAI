
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowRight, ArrowLeft, Loader2, AlertTriangle, Check, Users, Code, TrendingUp, Cog, PlusCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const RoleCard = ({ role, isSelected, onClick, Icon }) => (
  <motion.div whileTap={{ scale: 0.97 }} className="h-full">
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "w-full h-full text-left p-4 rounded-xl border-2 text-sm font-medium transition-all duration-200 flex items-center gap-3",
        isSelected
          ? "bg-green-50 border-green-500 text-green-800 shadow-md"
          : "bg-white border-gray-300 hover:border-green-400 hover:bg-green-50/50"
      )}
    >
      <Icon className={cn("w-5 h-5 flex-shrink-0", isSelected ? "text-green-600" : "text-gray-500")} />
      <span className="flex-grow">{role}</span>
      <div className={cn(
        "w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center",
        isSelected ? "bg-green-600 border-green-600" : "border-gray-400 bg-white"
      )}>
        {isSelected && <Check className="w-3 h-3 text-white" />}
      </div>
    </button>
  </motion.div>
);

const mapUserFunctionToCategory = (func) => {
  if (!func) return 'tech';
  const fn = func.toLowerCase();
  if (['sales', 'marketing', 'business development', 'media'].some(k => fn.includes(k))) return 'sales';
  if (['operations', 'finance', 'human resources', 'legal', 'administrative'].some(k => fn.includes(k))) return 'ops';
  return 'tech'; // Default to tech
};

export default function Step4HiringPriorities({ formData, updateFormData, onNext, onPrevious }) {
  const [roleLists, setRoleLists] = useState({ sales: [], tech: [], ops: [] });
  const [selectedRoles, setSelectedRoles] = useState(formData.hiring || []);
  const [otherRole, setOtherRole] = useState(formData.otherHiringRole || '');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const categories = useMemo(() => {
    const userFunction = formData.contact?.function;
    const userCategory = mapUserFunctionToCategory(userFunction);

    const allCategories = [
      { id: 'sales', title: 'Sales / Marketing', icon: TrendingUp, roles: roleLists.sales },
      { id: 'tech', title: 'Software, Cloud + AI', icon: Code, roles: roleLists.tech },
      { id: 'ops', title: 'Operations / Finance', icon: Cog, roles: roleLists.ops },
    ];

    return allCategories.sort((a, b) => {
      if (a.id === userCategory) return -1;
      if (b.id === userCategory) return 1;
      return 0;
    });
  }, [formData.contact, roleLists]);

  useEffect(() => {
    const generateHiringRoles = async () => {
      const { industry, size, name: companyName, website } = formData.company || {};
      if (!industry || !size) {
        setError("Company details are required to generate personalized hiring priorities.");
        setIsLoading(false);
        return;
      }

      const prompt = `You are an expert talent acquisition strategist. Analyze the company "${companyName}", a ${size} employee company in the "${industry}" industry with the website ${website}.
      
      Based on your analysis of their website and public data, generate a JSON object containing the top 5 most likely and immediate hiring priorities for each of the following three functional areas:
      1.  **Sales / Marketing**: High-impact roles to drive revenue and market presence.
      2.  **Software, Cloud + AI**: Critical technical roles for product innovation and scalability.
      3.  **Operations / Finance**: Essential roles for business efficiency and financial health.

      **Requirements**:
      - The roles must be specific job titles (e.g., "Senior Account Executive, Enterprise" not "Salesperson").
      - Ensure the roles are highly relevant to a company of this size, industry, and likely growth stage.
      - Return the output as a single JSON object with three keys: "sales_marketing_roles", "tech_roles", and "ops_finance_roles". Each key's value must be an array of exactly 5 string job titles.`;

      try {
        setIsLoading(true);
        const rawResult = await InvokeLLM({
          prompt,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              sales_marketing_roles: { type: "array", items: { type: "string" } },
              tech_roles: { type: "array", items: { type: "string" } },
              ops_finance_roles: { type: "array", items: { type: "string" } }
            },
            required: ["sales_marketing_roles", "tech_roles", "ops_finance_roles"]
          }
        });
        
        let result;
        // Defensive parsing: If InvokeLLM returns a string, try to parse it.
        if (typeof rawResult === 'string') {
          try {
            result = JSON.parse(rawResult);
          } catch (parseError) {
            console.error("Failed to parse AI response string:", parseError);
            throw new Error("AI response was malformed JSON string.");
          }
        } else if (rawResult === null || rawResult === undefined) {
            throw new Error("AI response was empty or undefined.");
        } else {
            result = rawResult; // Assume it's already a parsed object
        }

        if (result && Array.isArray(result.tech_roles) && Array.isArray(result.sales_marketing_roles) && Array.isArray(result.ops_finance_roles)) {
          setRoleLists({
            tech: result.tech_roles,
            sales: result.sales_marketing_roles,
            ops: result.ops_finance_roles
          });
        } else {
          // This else block will now catch if parsedResult is missing keys or is not a well-formed object/arrays.
          throw new Error("AI response was missing required role lists or was not a well-formed JSON object.");
        }
      } catch (err) {
        console.error("Failed to generate hiring roles:", err);
        setError("Could not generate personalized roles. Please proceed with manual entry or go back.");
        setRoleLists({ // Provide fallback data on error
            sales: ["Account Executive", "Digital Marketing Manager", "Content Strategist", "Sales Development Rep", "Product Marketing Manager"],
            tech: ["Senior Full-Stack Engineer", "Cloud/DevOps Engineer", "AI/ML Specialist", "UX/UI Designer", "Lead Data Scientist"],
            ops: ["Operations Manager", "Financial Analyst", "HR Business Partner", "Project Manager", "Controller"]
        });
      } finally {
        setIsLoading(false);
      }
    };

    generateHiringRoles();
  }, [formData.company]);

  const handleToggleRole = (role) => {
    const newSelection = selectedRoles.includes(role)
      ? selectedRoles.filter(r => r !== role)
      : [...selectedRoles, role];
    setSelectedRoles(newSelection);
    updateFormData('hiring', newSelection);
  };
  
  const handleOtherRoleChange = (e) => {
    const value = e.target.value;
    setOtherRole(value);
    updateFormData('otherHiringRole', value);
  };

  const handleNext = () => {
    onNext();
  };

  const isValid = selectedRoles.length > 0 || otherRole.trim() !== '';

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-50 mb-4">
          <Users className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Define Hiring Priorities</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Based on our analysis of {formData.company?.name || 'your company'}, here are the most likely hiring priorities. Select all that apply or add your own.
        </p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div key="loader" className="flex flex-col items-center justify-center h-96">
              <Loader2 className="w-12 h-12 animate-spin text-green-600" />
              <p className="mt-4 text-gray-600">Generating hiring priorities for {formData.company?.name || 'your company'}...</p>
            </motion.div>
          ) : error && !roleLists.tech.length ? (
            <motion.div key="error" className="flex flex-col items-center justify-center h-96 text-center">
              <AlertTriangle className="w-12 h-12 text-red-500" />
              <p className="mt-4 text-red-700 font-medium">{error}</p>
              <Button onClick={onPrevious} variant="outline" className="mt-4">Go Back</Button>
            </motion.div>
          ) : (
            <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {error && (
                <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm p-3 rounded-md mb-6">
                  {error} Fallback suggestions are shown below.
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                {categories.map(category => (
                  <div key={category.id}>
                    <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
                      <category.icon className="w-6 h-6 text-gray-600" />
                      {category.title}
                    </h3>
                    <div className="space-y-3">
                      {category.roles.map((role, idx) => (
                        <RoleCard
                          key={idx}
                          role={role}
                          isSelected={selectedRoles.includes(role)}
                          onClick={() => handleToggleRole(role)}
                          Icon={Users}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <Label className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
                  <PlusCircle className="w-6 h-6 text-gray-600" />
                  Other Priorities
                </Label>
                <Textarea
                  placeholder="Specify any other roles you are hiring for..."
                  value={otherRole}
                  onChange={handleOtherRoleChange}
                  className="text-base"
                />
              </div>

            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex justify-between pt-8 mt-8 border-t border-gray-200">
          <Button onClick={onPrevious} variant="outline" size="lg">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={handleNext} disabled={!isValid && !error} size="lg" className="bg-green-600 hover:bg-green-700 text-white">
            Continue <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
