
import React from 'react';
import { motion } from 'framer-motion';
import { User, Building, Target, Users, Headphones, FileText, CheckCircle, BrainCircuit, TrendingUp, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

const steps = [
  { name: 'Contact', icon: User },
  { name: 'Company', icon: Building },
  { name: 'Challenges', icon: Target },
  { name: 'Hiring', icon: Users },
  { name: 'Support', icon: Headphones },
  { name: 'Details', icon: FileText },
];

const Metric = ({ value, label, Icon }) => (
  <div className="text-center">
    <div className="font-bold text-base text-yellow-300">{value}</div>
    <div className="text-sm opacity-80">{label}</div>
  </div>
);

export default function GamefiedProgressHeader({ currentStep, totalSteps }) {
  const completionPercentage = Math.round((currentStep / totalSteps) * 100);
  const currentStepName = steps[currentStep - 1]?.name || 'Complete';

  return (
    <div className="w-full bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden"
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-purple-400/10"
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-6">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <BrainCircuit className="w-12 h-12 text-yellow-300" />
              </motion.div>
              <div>
                <h3 className="text-2xl font-bold mb-2">Intelligent AI Routing & Enrichment</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Metric value={`${completionPercentage}%`} label="Complete" Icon={CheckCircle} />
                  <Metric value={`${currentStep}/${totalSteps}`} label="Progress" Icon={Sparkles} />
                  <Metric value="AI-Powered" label="Analysis" Icon={TrendingUp} />
                  <Metric value={currentStepName} label="Current Step" Icon={steps[currentStep - 1]?.icon || FileText} />
                </div>
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="text-right">
                <div className="text-sm opacity-80 mb-1">Step {currentStep} of {totalSteps}</div>
                <div className="text-lg font-bold">{currentStepName}</div>
                <div className="w-32 bg-gray-700 rounded-full h-2 mt-2">
                  <motion.div 
                    className="bg-yellow-300 h-2 rounded-full" 
                    initial={{ width: 0 }}
                    animate={{ width: `${completionPercentage}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mt-6 text-center"
        >
          <Link to={createPageUrl('Intake')}>
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <Button size="lg" className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-bold shadow-lg text-base">
                <Sparkles className="w-5 h-5 mr-2" />
                Start Your 45-Second Assessment
              </Button>
            </motion.div>
          </Link>
          <div className="text-gray-600 text-sm max-w-2xl mx-auto mt-4 p-4 bg-gray-100 rounded-lg border border-gray-200">
            <p className="font-semibold mb-2">Complete in 45 seconds to unlock a fully personalized experience, plus access to:</p>
            <ul className="list-disc list-inside text-left text-xs space-y-1">
              <li>Intelligent Network Search and Our Exclusive Connections</li>
              <li>Verified Development Partners</li>
              <li>Contact Enrichment, plus an optional TouchpointAI trial</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
