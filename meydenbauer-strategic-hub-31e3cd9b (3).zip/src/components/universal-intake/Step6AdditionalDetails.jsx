import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Loader2, FileText } from 'lucide-react';

export default function Step6AdditionalDetails({ formData, updateFormData, onSubmit, onPrevious, isLoading }) {
  const [additionalDetails, setAdditionalDetails] = useState(formData.additionalDetails || '');

  const handleChange = (value) => {
    setAdditionalDetails(value);
    updateFormData('additionalDetails', value);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 mb-4">
          <FileText className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">Additional Details & Requirements</h1>
        <p className="text-lg text-gray-600">Share any unique requirements, challenges, or additional context that will help us tailor our recommendations.</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <div className="space-y-6">
          <div>
            <Label htmlFor="additionalDetails" className="text-lg font-semibold text-gray-800 flex items-center gap-2 mb-4">
              Additional Details & Specific Requirements 
              <span className="text-gray-500 text-sm">(Optional)</span>
            </Label>
            <Textarea 
              id="additionalDetails" 
              value={additionalDetails} 
              onChange={(e) => handleChange(e.target.value)} 
              placeholder="Please share any specific requirements, unique challenges, timeline considerations, budget constraints, or additional context that would help us provide the most relevant and tailored recommendations for your business..." 
              rows={8}
              className="text-base"
            />
          </div>
        </div>

        <div className="mt-8 flex justify-between pt-8 border-t border-gray-200">
          <Button onClick={onPrevious} variant="outline" size="lg">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={onSubmit} disabled={isLoading} size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                Processing...
              </>
            ) : (
              <>
                Complete Assessment
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}