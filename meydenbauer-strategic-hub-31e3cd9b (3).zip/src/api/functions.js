import { base44 } from './base44Client';


export const generateTechAnalysisPdf = base44.functions.generateTechAnalysisPdf;

export const cleanConnectionData = base44.functions.cleanConnectionData;

export const deleteAllConnections = base44.functions.deleteAllConnections;

export const manualCleanupConnections = base44.functions.manualCleanupConnections;

export const parseCsvData = base44.functions.parseCsvData;

export const processCsvBatch = base44.functions.processCsvBatch;

export const requestIntroduction = base44.functions.requestIntroduction;

export const enrichContactData = base44.functions.enrichContactData;

export const createShortlist = base44.functions.createShortlist;

export const manageShortlistContact = base44.functions.manageShortlistContact;

export const getAICRMData = base44.functions.getAICRMData;

export const getFilteredContacts = base44.functions.getFilteredContacts;

export const analyzeLinkedInProfile = base44.functions.analyzeLinkedInProfile;

export const filterConnectionsByICP = base44.functions.filterConnectionsByICP;

export const processIcpAndTechStack = base44.functions.processIcpAndTechStack;

export const createShareableLink = base44.functions.createShareableLink;

export const getSharedLinkDetails = base44.functions.getSharedLinkDetails;

export const revokeShareableLink = base44.functions.revokeShareableLink;

export const removePlaceholderContacts = base44.functions.removePlaceholderContacts;

